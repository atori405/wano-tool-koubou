// newtab.js - Sticky Notes Wallpaper Logic

document.addEventListener('DOMContentLoaded', () => {
  const wallpaperBoard = document.getElementById('wallpaper-board');
  const notesContainer = document.getElementById('notes-container');
  const addNoteBtn = document.getElementById('add-note-btn');
  const clearNotesBtn = document.getElementById('clear-notes-btn');
  const emptyGuide = document.getElementById('empty-guide');

  // Theme Buttons
  const themeBtns = {
    tatami: document.getElementById('theme-tatami'),
    cedar: document.getElementById('theme-cedar'),
    sand: document.getElementById('theme-sand')
  };

  // State variables
  let notes = [];
  let currentTheme = 'tatami';
  let zIndexCounter = 10;

  // Initial load
  chrome.storage.local.get('stickyNotesWallpaperData', (result) => {
    if (result.stickyNotesWallpaperData) {
      const data = result.stickyNotesWallpaperData;
      currentTheme = data.theme || 'tatami';
      notes = data.notes || [];
    } else {
      // Setup some default demo sticky notes on first launch
      // 注: これは実際のあなたの予定やタスクではなく、使い方を示すための見本(サンプル)。
      // isSample:trueを付け、createNoteDOM()で「サンプル」バッジを表示して区別する。
      notes = [
        {
          id: 'demo_1',
          text: "ようこそ、付箋壁紙へ！\n\n・ダブルクリックで付箋を追加できます。\n・ドラッグで自由に配置できます。\n・右下の角をドラッグしてサイズ変更が可能です。",
          x: 120,
          y: 120,
          width: 220,
          height: 180,
          color: "karashi",
          date: getTodayString(),
          isSample: true
        },
        {
          id: 'demo_2',
          text: "📌 付箋の記入例\n\n1. メールの確認\n2. 資料の下書き推敲\n3. 集中タイマーを使って作業",
          x: 450,
          y: 150,
          width: 180,
          height: 180,
          color: "uguisu",
          date: getTodayString(),
          isSample: true
        }
      ];
      chrome.storage.local.set({ stickyNotesWallpaperData: { theme: currentTheme, notes } });
    }

    setTheme(currentTheme);
    renderAllNotes();
    updateGuideVisibility();
  });

  // Render all saved notes
  function renderAllNotes() {
    notesContainer.innerHTML = '';
    notes.forEach(note => {
      createNoteDOM(note);
    });
  }

  // Create Note DOM Element
  function createNoteDOM(note) {
    const card = document.createElement('div');
    card.className = `sticky-note color-${note.color}`;
    card.id = `note_${note.id}`;
    card.style.left = `${note.x}px`;
    card.style.top = `${note.y}px`;
    card.style.width = `${note.width || 180}px`;
    card.style.height = `${note.height || 180}px`;
    card.style.zIndex = zIndexCounter++;

    // Drag Handle Header
    const header = document.createElement('div');
    header.className = 'sticky-header';

    if (note.isSample) {
      const sampleBadge = document.createElement('span');
      sampleBadge.className = 'sample-badge';
      sampleBadge.textContent = 'サンプル';
      header.appendChild(sampleBadge);
    }

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'peel-btn';
    deleteBtn.innerHTML = '×';
    deleteBtn.title = 'ふせんを剥がす';
    deleteBtn.addEventListener('click', () => {
      deleteNote(note.id);
    });
    header.appendChild(deleteBtn);
    card.appendChild(header);

    // Note text body
    const body = document.createElement('div');
    body.className = 'sticky-body';

    const textarea = document.createElement('textarea');
    textarea.className = 'sticky-textarea';
    textarea.placeholder = '書き留める...';
    textarea.value = note.text;
    
    // Autosave on edit
    textarea.addEventListener('input', (e) => {
      note.text = e.target.value;
      saveData();
    });
    body.appendChild(textarea);
    card.appendChild(body);

    // Note Footer
    const footer = document.createElement('div');
    footer.className = 'sticky-footer';

    // Color picker
    const picker = document.createElement('div');
    picker.className = 'color-picker';

    const colors = ['uguisu', 'akane', 'fuji', 'karashi', 'ainezu'];
    colors.forEach(col => {
      const dot = document.createElement('div');
      dot.className = `color-dot dot-${col}`;
      dot.addEventListener('mousedown', (e) => {
        e.stopPropagation();
        e.preventDefault();
        
        // Change color classes cleanly
        colors.forEach(c => card.classList.remove(`color-${c}`));
        card.classList.add(`color-${col}`);
        
        note.color = col;
        playPlaceSound(); // Play soft pad sound on change
        saveData();
      });
      picker.appendChild(dot);
    });
    footer.appendChild(picker);

    // Date
    const dateSpan = document.createElement('span');
    dateSpan.className = 'sticky-date';
    dateSpan.textContent = note.date;
    footer.appendChild(dateSpan);
    card.appendChild(footer);

    // Resize handle
    const resizeHandle = document.createElement('div');
    resizeHandle.className = 'resize-handle';
    card.appendChild(resizeHandle);

    notesContainer.appendChild(card);

    // Enable Drag and Drop
    setupDragging(card, note);

    // Enable Resizing
    setupResizing(card, resizeHandle, note);
  }

  // Drag and drop event listeners
  function setupDragging(card, note) {
    let isDragging = false;
    let startX, startY;
    let initialX, initialY;

    card.addEventListener('mousedown', (e) => {
      // Don't drag if clicking textarea, close button, or color dots
      if (
        e.target.tagName === 'TEXTAREA' || 
        e.target.classList.contains('peel-btn') || 
        e.target.classList.contains('color-dot') || 
        e.target.classList.contains('resize-handle')
      ) {
        return;
      }

      isDragging = true;
      card.style.zIndex = zIndexCounter++;
      
      startX = e.clientX;
      startY = e.clientY;
      initialX = card.offsetLeft;
      initialY = card.offsetTop;

      document.addEventListener('mousemove', dragMove);
      document.addEventListener('mouseup', dragEnd);
      
      e.preventDefault();
    });

    function dragMove(e) {
      if (!isDragging) return;
      
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      
      // Calculate new positions within bounds of board
      let newX = initialX + dx;
      let newY = initialY + dy;

      // Keep inside bounds
      const minX = 0;
      const minY = 52; // below header
      const maxX = window.innerWidth - card.offsetWidth;
      const maxY = window.innerHeight - card.offsetHeight - 24; // above footer

      newX = Math.max(minX, Math.min(newX, maxX));
      newY = Math.max(minY, Math.min(newY, maxY));

      card.style.left = `${newX}px`;
      card.style.top = `${newY}px`;
      
      note.x = newX;
      note.y = newY;
    }

    function dragEnd() {
      if (isDragging) {
        isDragging = false;
        document.removeEventListener('mousemove', dragMove);
        document.removeEventListener('mouseup', dragEnd);
        saveData();
      }
    }
  }

  // Resizing notes listeners
  function setupResizing(card, handle, note) {
    let isResizing = false;
    let startW, startH;
    let startX, startY;

    handle.addEventListener('mousedown', (e) => {
      isResizing = true;
      startX = e.clientX;
      startY = e.clientY;
      startW = card.offsetWidth;
      startH = card.offsetHeight;

      document.addEventListener('mousemove', resizeMove);
      document.addEventListener('mouseup', resizeEnd);

      e.preventDefault();
      e.stopPropagation();
    });

    function resizeMove(e) {
      if (!isResizing) return;
      const dw = e.clientX - startX;
      const dh = e.clientY - startY;

      const newW = Math.max(120, startW + dw);
      const newH = Math.max(120, startH + dh);

      card.style.width = `${newW}px`;
      card.style.height = `${newH}px`;

      note.width = newW;
      note.height = newH;
    }

    function resizeEnd() {
      if (isResizing) {
        isResizing = false;
        document.removeEventListener('mousemove', resizeMove);
        document.removeEventListener('mouseup', resizeEnd);
        saveData();
      }
    }
  }

  // Theme settings
  function setTheme(theme) {
    wallpaperBoard.className = `theme-${theme}`;
    Object.keys(themeBtns).forEach(key => {
      if (key === theme) {
        themeBtns[key].classList.add('active');
      } else {
        themeBtns[key].classList.remove('active');
      }
    });
    currentTheme = theme;
  }

  // Register click events for themes
  Object.keys(themeBtns).forEach(key => {
    themeBtns[key].addEventListener('click', () => {
      setTheme(key);
      saveData();
    });
  });

  // Action: Add note button click
  addNoteBtn.addEventListener('click', () => {
    const x = Math.random() * (window.innerWidth - 220) + 20;
    const y = Math.random() * (window.innerHeight - 300) + 80;
    addNewNote(x, y);
  });

  // Action: Double click board to add note
  wallpaperBoard.addEventListener('dblclick', (e) => {
    // Only double click the background, not existing notes
    if (e.target !== wallpaperBoard && e.target.id !== 'notes-container') return;
    
    // Position note centered under cursor
    const noteWidth = 180;
    const noteHeight = 180;
    const x = e.clientX - noteWidth / 2;
    const y = e.clientY - noteHeight / 2;

    // Check bounds
    const cleanX = Math.max(10, Math.min(x, window.innerWidth - noteWidth - 10));
    const cleanY = Math.max(60, Math.min(y, window.innerHeight - noteHeight - 34));

    addNewNote(cleanX, cleanY);
  });

  function addNewNote(x, y) {
    const colors = ['uguisu', 'akane', 'fuji', 'karashi', 'ainezu'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    
    const newNote = {
      id: `note_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      text: "",
      x: Math.round(x),
      y: Math.round(y),
      width: 180,
      height: 180,
      color: randomColor,
      date: getTodayString()
    };

    notes.push(newNote);
    createNoteDOM(newNote);
    
    // Focus textarea of new note immediately
    const cardEl = document.getElementById(`note_${newNote.id}`);
    if (cardEl) {
      const ta = cardEl.querySelector('textarea');
      if (ta) ta.focus();
    }

    playPlaceSound(); // Play soft paste sound
    updateGuideVisibility();
    saveData();
  }

  // Action: Delete note
  function deleteNote(id) {
    const cardEl = document.getElementById(`note_${id}`);
    if (cardEl) {
      // Peel animation (fade out and scale down slightly)
      cardEl.style.transition = 'transform 0.2s, opacity 0.2s';
      cardEl.style.transform = 'scale(0.8) rotate(-5deg)';
      cardEl.style.opacity = '0';
      
      playPeelSound(); // Play paper tearing/peeling sound
      
      setTimeout(() => {
        cardEl.remove();
        notes = notes.filter(n => n.id !== id);
        updateGuideVisibility();
        saveData();
      }, 200);
    }
  }

  // Action: Clear all notes
  clearNotesBtn.addEventListener('click', () => {
    if (notes.length === 0) return;
    
    if (confirm("現在壁に貼られているすべての和紙付箋を剥がしますか？")) {
      notes = [];
      renderAllNotes();
      playPeelSound();
      updateGuideVisibility();
      saveData();
    }
  });

  // Show guide message if board is empty
  function updateGuideVisibility() {
    if (notes.length === 0) {
      emptyGuide.style.display = 'block';
    } else {
      emptyGuide.style.display = 'none';
    }
  }

  // Save state to storage
  function saveData() {
    chrome.storage.local.set({
      stickyNotesWallpaperData: {
        theme: currentTheme,
        notes: notes
      }
    });
  }

  function getTodayString() {
    const d = new Date();
    return `${d.getFullYear()}/${String(d.getMonth()+1).padStart(2,'0')}/${String(d.getDate()).padStart(2,'0')}`;
  }

  // --- Web Audio API Synth Engines ---
  let audioCtx = null;

  function initAudio() {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
  }

  // Plop/Place Sound Effect (ペタッという柔らかい貼り付け音)
  function playPlaceSound() {
    try {
      initAudio();
      const now = audioCtx.currentTime;

      // Soft drum/tap sine combined with filtered noise
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(140, now);
      osc.frequency.exponentialRampToValueAtTime(70, now + 0.05);

      gain.gain.setValueAtTime(0.3, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

      osc.start(now);
      osc.stop(now + 0.06);

      // Noise burst for sticking paper texture
      const bufferSize = audioCtx.sampleRate * 0.04;
      const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      const noise = audioCtx.createBufferSource();
      noise.buffer = buffer;
      
      const filter = audioCtx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.value = 600;
      filter.Q.value = 1.0;

      const noiseGain = audioCtx.createGain();
      noiseGain.gain.setValueAtTime(0.05, now);
      noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

      noise.connect(filter);
      filter.connect(noiseGain);
      noiseGain.connect(audioCtx.destination);

      noise.start(now);
    } catch (e) {
      console.warn(e);
    }
  }

  // Peeling Sound Effect (ペリペリッと剥がす乾いたノイズ摩擦音)
  function playPeelSound() {
    try {
      initAudio();
      const now = audioCtx.currentTime;

      // We synthesize the peel sound by playing multiple quick crackling noise bursts
      // and sliding the filter frequency upwards to match the slide/peeling feel.
      const duration = 0.22; // 220ms
      const bufferSize = audioCtx.sampleRate * duration;
      const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
      const data = buffer.getChannelData(0);
      
      // Generate slightly crackly white noise
      for (let i = 0; i < bufferSize; i++) {
        const rawNoise = Math.random() * 2 - 1;
        // Introduce small crackle drops
        if (Math.random() < 0.15) {
          data[i] = rawNoise * 0.9;
        } else {
          data[i] = rawNoise * 0.3;
        }
      }

      const noise = audioCtx.createBufferSource();
      noise.buffer = buffer;

      const filter = audioCtx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1000, now);
      filter.frequency.exponentialRampToValueAtTime(2200, now + duration);
      filter.Q.value = 2.0;

      const gain = audioCtx.createGain();
      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.12, now + 0.05); // quick attack
      gain.gain.linearRampToValueAtTime(0.08, now + 0.15); // sustain
      gain.gain.exponentialRampToValueAtTime(0.001, now + duration); // decay

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(audioCtx.destination);

      noise.start(now);
    } catch (e) {
      console.warn(e);
    }
  }
});
