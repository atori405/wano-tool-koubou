// background.js
// この拡張機能は新しいタブを開いたときに使う「New Tab Override」型で、
// ツールバーアイコン自体にポップアップは無い。クリックしても何も起きないと
// 壊れているように見えるため、クリック時に新しいタブ(=付箋壁紙)を開く。
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({});
});
