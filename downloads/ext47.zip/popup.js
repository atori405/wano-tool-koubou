// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 640);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window&tabId=" + tabs[0].id),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 640,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// popup.js - Japanese Barrier Free Checker Core

document.addEventListener("DOMContentLoaded", () => {
  // Wrong-tab fix: when opened as a standalone popup window (mode=window),
  // chrome.tabs.query({currentWindow:true}) would resolve to this window itself,
  // not the original page tab, so use the explicitly passed tabId when present.
  const urlParams = new URLSearchParams(window.location.search);
  const explicitTabId = urlParams.get("tabId") ? parseInt(urlParams.get("tabId"), 10) : null;
  function getTargetTab(callback) {
    if (explicitTabId) {
      chrome.tabs.get(explicitTabId, (tab) => {
        if (chrome.runtime.lastError || !tab) return;
        callback(tab);
      });
    } else {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0]) callback(tabs[0]);
      });
    }
  }

  // --- 1. Element References ---
  const btnScan = document.getElementById("btn-scan");
  const btnClear = document.getElementById("btn-clear");
  const summarySection = document.getElementById("summary-section");
  const adviceSection = document.getElementById("advice-section");
  const guideSection = document.getElementById("guide-section");
  
  const totalErrorsSpan = document.getElementById("total-errors");
  const jisTierBadge = document.getElementById("jis-tier-badge");
  
  const countAltSpan = document.getElementById("count-alt");
  const countContrastSpan = document.getElementById("count-contrast");
  const countHeadingsSpan = document.getElementById("count-headings");
  const countLabelsSpan = document.getElementById("count-labels");
  
  const adviceList = document.getElementById("advice-list");

  // --- 2. JIS X 8341-3 Standards Reference ---
  const JIS_STANDARDS = {
    "alt-missing": {
      title: "画像（img）の alt 属性欠損",
      jisCode: "JIS X 8341-3 7.1.1.1 (レベルA)",
      jisName: "非テキストコンテンツの適合性",
      reason: "視覚障害をお持ちの方が音声読み上げソフト（スクリーンリーダー）を使用する際、alt属性がない画像の内容を理解することができなくなります。特に官公庁や地方自治体のサイトでは必須要件です。",
      fix: "画像の内容を説明する適切な <code>alt</code> 属性を付与してください。装飾目的の場合は <code>alt=\"\"</code> と空文字を設定してください。",
      codeGood: '<img src="logo.png" alt="和沙システム株式会社のコーポレートロゴ">'
    },
    "contrast-low": {
      title: "文字と背景のコントラスト比不足",
      jisCode: "JIS X 8341-3 7.1.4.3 (レベルAA)",
      jisName: "最低限のコントラスト",
      reason: "文字色と背景色の明るさのコントラスト比が不足していると、高齢の方や視覚が過敏な方、屋外の明るい環境下で画面を見ているユーザーが文字を読めなくなります。",
      fix: "コントラスト比を <strong>4.5:1 以上</strong> (大きな文字の場合は 3.0:1 以上) にしてください。推奨カラーコード例の通り、文字色を暗くするか背景色を明るく調整してください。",
      codeGood: '/* 修正前 contrast: 2.1:1 */\ncolor: #9c958c; background-color: #0f1012;\n\n/* 修正後 (推奨) contrast: 6.2:1 */\ncolor: #f0ede9; background-color: #0f1012;'
    },
    "heading-hierarchy": {
      title: "見出し階層（Heading Hierarchy）の順序崩れ",
      jisCode: "JIS X 8341-3 7.2.4.1 (レベルA)",
      jisName: "ページの構成と見出しの順序",
      reason: "見出しのレベル（h1➔h3など）がスキップされていると、スクリーンリーダーで見出し一覧ジャンプ機能を使ってページ内を移動するユーザーが、情報の包含関係や順序を正しく把握できなくなります。",
      fix: "見出しタグを数字の小さい順（h1 ➔ h2 ➔ h3 ...）に階層を飛ばさずに配置してください。装飾目的で文字の大きさを変えたい場合は見出しタグではなくCSSで調整してください。",
      codeGood: '<h1>ページタイトル</h1>\n  <h2>セクションの大見出し</h2>\n    <h3>詳細な小見出し</h3>'
    },
    "label-missing": {
      title: "フォーム入力欄（input等）のラベル欠如",
      jisCode: "JIS X 8341-3 7.1.3.1 (レベルA)",
      jisName: "情報及び関係性（フォーム部品の関連付け）",
      reason: "入力フォーム（input, select, textarea）に対して `<label>` が結びついていないと、音声読み上げソフトが「何を入力すべきエリアなのか」を読み上げることができません。",
      fix: "入力項目のテキストと <code>&lt;label for=\"ID\"&gt;</code> で明示的に紐付けるか、<code>aria-label</code> または <code>aria-labelledby</code> 属性を付与してください。",
      codeGood: '<label for="user-email">メールアドレス</label>\n<input type="email" id="user-email" placeholder="example@domain.com">'
    }
  };

  // --- 3. Relative Luminance & Contrast Ratio Calculator ---
  // Returns relative luminance for a given sRGB channel
  function getLuminance(r, g, b) {
    const a = [r, g, b].map(v => {
      v /= 255;
      return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    });
    return a[0] * 0.2126 + a[1] * 0.7152 + a[2] * 0.0722;
  }

  function getContrastRatio(rgb1, rgb2) {
    const lum1 = getLuminance(rgb1[0], rgb1[1], rgb1[2]);
    const lum2 = getLuminance(rgb2[0], rgb2[1], rgb2[2]);
    const brightest = Math.max(lum1, lum2);
    const darkest = Math.min(lum1, lum2);
    return (brightest + 0.05) / (darkest + 0.05);
  }

  // Parse color string (rgb, rgba, hex) into [r,g,b] array
  function parseRGB(colorStr) {
    if (!colorStr) return [255, 255, 255]; // default white
    
    // Check if rgba
    let match = colorStr.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
    if (match) {
      return [parseInt(match[1]), parseInt(match[2]), parseInt(match[3])];
    }
    
    // Check if Hex
    match = colorStr.match(/#([a-fA-F0-9]{2})([a-fA-F0-9]{2})([a-fA-F0-9]{2})/);
    if (match) {
      return [parseInt(match[1], 16), parseInt(match[2], 16), parseInt(match[3], 16)];
    }
    
    // Quick hex shorthand
    match = colorStr.match(/#([a-fA-F0-9])([a-fA-F0-9])([a-fA-F0-9])/);
    if (match) {
      return [parseInt(match[1] + match[1], 16), parseInt(match[2] + match[2], 16), parseInt(match[3] + match[3], 16)];
    }

    // Default fallbacks for text colors
    if (colorStr === "gray" || colorStr === "grey") return [128, 128, 128];
    if (colorStr === "black") return [0, 0, 0];
    if (colorStr === "white") return [255, 255, 255];
    
    return [255, 255, 255];
  }

  // --- 4. Core Scanner Function (Can run locally in sandbox or inside executeScript) ---
  // In a real extension, we pass this code as a string to be executed in target tab page.
  // In sandbox, we run this directly on the parent window or local demo container.
  function scanAccessibilityDOM(containerElementSelector) {
    // --- Inner Helpers to make the script self-contained when executed inside activeTab context ---
    function getLuminance(r, g, b) {
      const a = [r, g, b].map(v => {
        v /= 255;
        return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
      });
      return a[0] * 0.2126 + a[1] * 0.7152 + a[2] * 0.0722;
    }

    function getContrastRatio(rgb1, rgb2) {
      const lum1 = getLuminance(rgb1[0], rgb1[1], rgb1[2]);
      const lum2 = getLuminance(rgb2[0], rgb2[1], rgb2[2]);
      const brightest = Math.max(lum1, lum2);
      const darkest = Math.min(lum1, lum2);
      return (brightest + 0.05) / (darkest + 0.05);
    }

    function parseRGB(colorStr) {
      if (!colorStr) return [255, 255, 255];
      let match = colorStr.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
      if (match) {
        return [parseInt(match[1]), parseInt(match[2]), parseInt(match[3])];
      }
      match = colorStr.match(/#([a-fA-F0-9]{2})([a-fA-F0-9]{2})([a-fA-F0-9]{2})/);
      if (match) {
        return [parseInt(match[1], 16), parseInt(match[2], 16), parseInt(match[3], 16)];
      }
      match = colorStr.match(/#([a-fA-F0-9])([a-fA-F0-9])([a-fA-F0-9])/);
      if (match) {
        return [parseInt(match[1] + match[1], 16), parseInt(match[2] + match[2], 16), parseInt(match[3] + match[3], 16)];
      }
      if (colorStr === "gray" || colorStr === "grey") return [128, 128, 128];
      if (colorStr === "black") return [0, 0, 0];
      if (colorStr === "white") return [255, 255, 255];
      return [255, 255, 255];
    }

    const root = containerElementSelector ? document.querySelector(containerElementSelector) : document;
    if (!root) return { alt: [], contrast: [], headings: [], labels: [] };

    const errors = {
      alt: [],
      contrast: [],
      headings: [],
      labels: []
    };

    // Helper to generate unique identifier for element highlight binding
    let uniqueIdCounter = 0;
    function markElement(el, type, details) {
      uniqueIdCounter++;
      const id = `wabi-a11y-err-${type}-${uniqueIdCounter}`;
      el.setAttribute("data-a11y-error-id", id);
      el.setAttribute("data-a11y-error-type", type);
      el.setAttribute("data-a11y-error-details", details);
      return id;
    }

    // A. Scan Alt attributes on <img>
    const imgs = root.querySelectorAll("img");
    imgs.forEach(img => {
      const alt = img.getAttribute("alt");
      if (alt === null || alt.trim() === "") {
        const id = markElement(img, "alt-missing", "alt属性がありません");
        errors.alt.push({
          id,
          tagName: "img",
          src: img.getAttribute("src") || "画像URLなし",
          outerHTML: img.outerHTML.slice(0, 120) + "..."
        });
      }
    });

    // B. Scan Heading hierarchies
    const headingElements = root.querySelectorAll("h1, h2, h3, h4, h5, h6");
    let prevLevel = 0;
    headingElements.forEach(h => {
      const currentLevel = parseInt(h.tagName.substring(1));
      if (prevLevel > 0 && currentLevel > prevLevel + 1) {
        // Skipped level detected (e.g. h1 to h3)
        const id = markElement(h, "heading-hierarchy", `見出し順序のスキップ: H${prevLevel}からH${currentLevel}へ`);
        errors.headings.push({
          id,
          tagName: h.tagName.toLowerCase(),
          text: h.textContent.trim().slice(0, 40) || "(見出しテキストなし)",
          prevLevel,
          currentLevel
        });
      }
      prevLevel = currentLevel;
    });

    // C. Scan Form Labeling
    const formFields = root.querySelectorAll("input, select, textarea");
    formFields.forEach(field => {
      const type = field.getAttribute("type");
      if (type === "submit" || type === "button" || type === "hidden" || type === "image") return;

      let hasLabel = false;
      if (field.closest("label")) {
        hasLabel = true;
      }
      if (!hasLabel && field.id) {
        const matchingLabel = root.querySelector(`label[for="${field.id}"]`);
        if (matchingLabel && matchingLabel.textContent.trim() !== "") {
          hasLabel = true;
        }
      }
      if (!hasLabel) {
        const ariaLabel = field.getAttribute("aria-label");
        const ariaLabelledBy = field.getAttribute("aria-labelledby");
        if ((ariaLabel && ariaLabel.trim() !== "") || (ariaLabelledBy && ariaLabelledBy.trim() !== "")) {
          hasLabel = true;
        }
      }

      if (!hasLabel) {
        const id = markElement(field, "label-missing", "入力項目にラベルの関連付けがありません");
        errors.labels.push({
          id,
          tagName: field.tagName.toLowerCase(),
          type: type || "text",
          outerHTML: field.outerHTML.slice(0, 100)
        });
      }
    });

    // D. Scan Color Contrast
    const textNodes = root.querySelectorAll("p, span, label, li, a, h1, h2, h3, h4, h5, h6");
    textNodes.forEach(el => {
      if (el.children.length === 0 && el.textContent.trim() !== "") {
        const style = window.getComputedStyle(el);
        const color = style.color;
        let bg = style.backgroundColor;
        let parent = el.parentElement;
        while ((bg === "rgba(0, 0, 0, 0)" || bg === "transparent") && parent && parent !== root) {
          bg = window.getComputedStyle(parent).backgroundColor;
          parent = parent.parentElement;
        }
        if (bg === "rgba(0, 0, 0, 0)" || bg === "transparent") bg = "rgb(255, 255, 255)";

        const rgbColor = parseRGB(color);
        const rgbBg = parseRGB(bg);
        const cr = getContrastRatio(rgbColor, rgbBg);

        if (cr < 4.5) {
          if (!el.hasAttribute("data-a11y-error-id")) {
            const id = markElement(el, "contrast-low", `コントラスト比不足: ${cr.toFixed(2)}:1`);
            errors.contrast.push({
              id,
              tagName: el.tagName.toLowerCase(),
              text: el.textContent.trim().slice(0, 40),
              contrastRatio: cr.toFixed(2),
              color,
              backgroundColor: bg
            });
          }
        }
      }
    });

    return errors;
  }

  // --- 5. Render Advice Lists and Update Summary Cards ---
  function displayScanResults(errors) {
    // Hide guide, show results
    guideSection.style.display = "none";
    summarySection.style.display = "flex";
    adviceSection.style.display = "flex";
    btnClear.style.display = "inline-block";

    // Set counts
    const altCount = errors.alt.length;
    const contrastCount = errors.contrast.length;
    const headingCount = errors.headings.length;
    const labelCount = errors.labels.length;
    const totalCount = altCount + contrastCount + headingCount + labelCount;

    countAltSpan.textContent = altCount;
    countContrastSpan.textContent = contrastCount;
    countHeadingsSpan.textContent = headingCount;
    countLabelsSpan.textContent = labelCount;
    totalErrorsSpan.textContent = totalCount;

    // Update JIS Tier Badge
    if (totalCount === 0) {
      // 注意: このツールが検証しているのはJIS X 8341-3(WCAG)のうちalt属性・コントラスト比・
      // 見出し順序・フォームラベルの4項目のみ。「AAA適合」等の正式な適合レベルを判定できる
      // 網羅性は無いため、4項目に問題が無かった旨のみを表示する。
      jisTierBadge.textContent = "主要4項目 問題なし";
      jisTierBadge.className = "jis-badge tier-aaa";
    } else if (altCount > 0 || headingCount > 0 || labelCount > 0) {
      // level A failure exists
      jisTierBadge.textContent = "レベルA 不適合";
      jisTierBadge.className = "jis-badge tier-a-fail";
    } else {
      // level AA contrast failure exists
      jisTierBadge.textContent = "レベルAA 不適合";
      jisTierBadge.className = "jis-badge tier-aa-fail";
    }

    // Build advice list html
    adviceList.innerHTML = "";
    
    if (totalCount === 0) {
      adviceList.innerHTML = `<div class="advice-success-box">🎉 おめでとうございます！JIS X 8341-3 の主要なアクセシビリティエラーは検出されませんでした。バリアフリー要件を高く満たしています。</div>`;
      return;
    }

    const appendAdviceCard = (item, type, elementInfo, detailsText) => {
      const std = JIS_STANDARDS[type];
      const card = document.createElement("div");
      card.className = "advice-card";
      card.innerHTML = `
        <div class="advice-card-header">
          <span class="advice-error-type-tag ${type}">${std.title}</span>
          <div class="advice-jis-code">${std.jisCode}</div>
        </div>
        <div class="advice-card-body">
          <p class="advice-desc"><strong>【原因・背景】</strong><br>${std.reason}</p>
          <div class="advice-detail-box">
            <div><strong>対象要素:</strong> <code>&lt;${elementInfo}&gt;</code></div>
            <div class="advice-alert-text">${detailsText}</div>
          </div>
          <p class="advice-fix"><strong>【JIS準拠 修正アクション】</strong><br>${std.fix}</p>
          <div class="advice-code-title">💡 修正後のHTML記述例 (推奨)</div>
          <pre class="advice-code-pre"><code>${escapeHTML(std.codeGood)}</code></pre>
        </div>
      `;

      // Set focus interaction to highlight target on demopage when clicked
      card.addEventListener("click", () => {
        const targetId = item.id;
        
        if (window.chrome && chrome.tabs && chrome.scripting) {
          // In Extension mode: run scroll & pulse inside activeTab context
          getTargetTab((activeTab) => {
            if (activeTab) {
              chrome.scripting.executeScript({
                target: { tabId: activeTab.id },
                func: function(id) {
                  const el = document.querySelector(`[data-a11y-error-id="${id}"]`);
                  if (el) {
                    el.scrollIntoView({ behavior: "smooth", block: "center" });
                    el.classList.add("focus-pulse");
                    setTimeout(() => {
                      el.classList.remove("focus-pulse");
                    }, 2000);
                  }
                },
                args: [targetId]
              });
            }
          });
        } else {
          // In Simulator mode: local scroll & pulse
          const targetEl = document.querySelector(`#demo-page-container [data-a11y-error-id="${targetId}"]`) || 
                           document.querySelector(`[data-a11y-error-id="${targetId}"]`);
          if (targetEl) {
            targetEl.scrollIntoView({ behavior: "smooth", block: "center" });
            targetEl.classList.add("focus-pulse");
            setTimeout(() => {
              targetEl.classList.remove("focus-pulse");
            }, 2000);
          }
        }
      });

      adviceList.appendChild(card);
    };

    // Alt missing advice
    errors.alt.forEach(item => {
      appendAdviceCard(item, "alt-missing", `img src="${item.src.slice(0,25)}..."`, "JIS X 8341-3 要件: 画像には必ずその目的を表す alt属性を付加する必要があります。");
    });

    // Contrast low advice
    errors.contrast.forEach(item => {
      const details = `コントラスト比が低すぎます (${item.contrastRatio}:1)。文字色 ${item.color} と 背景色 ${item.backgroundColor} の輝度比を 4.5:1 以上に補正する必要があります。`;
      appendAdviceCard(item, "contrast-low", `${item.tagName}`, details);
    });

    // Headings hierarchy advice
    errors.headings.forEach(item => {
      const details = `見出し階層がスキップされています（H${item.prevLevel} ➔ H${item.currentLevel}）。スクリーンリーダー利用者が混乱するため、H2 の次は H3 というように順序よく構成する必要があります。`;
      appendAdviceCard(item, "heading-hierarchy", `${item.tagName}`, details);
    });

    // Labels missing advice
    errors.labels.forEach(item => {
      const details = `入力フォーム (type="${item.type}") に関連付けられた &lt;label&gt; または aria-label 属性がありません。ラベルがないと読み上げソフトで操作できません。`;
      appendAdviceCard(item, "label-missing", `${item.tagName} type="${item.type}"`, details);
    });
  }

  // --- 6. Overlay Highlights Injector into active Web Page ---
  // Renders border lines and absolute tooltip badges over elements
  function injectVisualHighlights() {
    const errorElements = document.querySelectorAll("[data-a11y-error-id]");
    
    // Clear previous highlights
    document.querySelectorAll(".wabi-a11y-highlight-badge").forEach(b => b.remove());

    errorElements.forEach(el => {
      const type = el.getAttribute("data-a11y-error-type");
      const details = el.getAttribute("data-a11y-error-details");
      
      // Inject dashed borders based on error type
      el.classList.add("wabi-a11y-highlighted-element");
      if (type === "alt-missing") {
        el.classList.add("err-alt");
      } else if (type === "contrast-low") {
        el.classList.add("err-contrast");
      } else if (type === "heading-hierarchy") {
        el.classList.add("err-headings");
      } else if (type === "label-missing") {
        el.classList.add("err-labels");
      }

      // Create a floating badge label
      // To prevent disrupting page flow, we position it relative or calculate offset
      const badge = document.createElement("span");
      badge.className = `wabi-a11y-highlight-badge ${type}`;
      
      let typeLabel = "JISエラー";
      if (type === "alt-missing") typeLabel = "⚠️ alt欠損";
      if (type === "contrast-low") typeLabel = "🎨 コントラスト比不足";
      if (type === "heading-hierarchy") typeLabel = "階層エラー";
      if (type === "label-missing") typeLabel = "🏷️ ラベルなし";

      badge.textContent = typeLabel;
      
      // Append badge nearby
      if (el.tagName.toLowerCase() === "img") {
        el.parentNode.insertBefore(badge, el.nextSibling);
      } else {
        el.appendChild(badge);
      }
    });
  }

  function clearVisualHighlights() {
    document.querySelectorAll("[data-a11y-error-id]").forEach(el => {
      el.classList.remove(
        "wabi-a11y-highlighted-element", 
        "err-alt", 
        "err-contrast", 
        "err-headings", 
        "err-labels"
      );
      el.removeAttribute("data-a11y-error-id");
      el.removeAttribute("data-a11y-error-type");
      el.removeAttribute("data-a11y-error-details");
    });
    document.querySelectorAll(".wabi-a11y-highlight-badge").forEach(b => b.remove());
  }

  // Helper for string escaping
  function escapeHTML(str) {
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  // --- 7. Execution Handlers (Active Tab scripting vs Simulator mode) ---
  btnScan.addEventListener("click", () => {
    // Check if running in Chrome Extension environment
    if (window.chrome && chrome.tabs && chrome.scripting) {
      getTargetTab((activeTab) => {
        if (!activeTab) return;

        // Execute scanner in activeTab
        chrome.scripting.executeScript({
          target: { tabId: activeTab.id },
          func: scanAccessibilityDOM,
          args: [null] // scan full document
        }, (results) => {
          if (results && results[0] && results[0].result) {
            const errors = results[0].result;
            
            // Execute highlight injection in activeTab
            chrome.scripting.executeScript({
              target: { tabId: activeTab.id },
              func: function(errData) {
                // Clear previous badges and style blocks
                document.querySelectorAll(".wabi-a11y-highlight-badge").forEach(b => b.remove());
                document.querySelectorAll("[data-a11y-error-id]").forEach(el => {
                  el.classList.remove("wabi-a11y-highlighted-element", "err-alt", "err-contrast", "err-headings", "err-labels");
                });

                // Dynamically inject custom highlight style block to target page
                let styleBlock = document.getElementById("wabi-a11y-styles-prod");
                if (!styleBlock) {
                  styleBlock = document.createElement("style");
                  styleBlock.id = "wabi-a11y-styles-prod";
                  styleBlock.innerHTML = `
                    .wabi-a11y-highlighted-element {
                      outline: none !important;
                      box-sizing: border-box !important;
                      position: relative !important;
                    }
                    .wabi-a11y-highlighted-element.err-alt { border: 2px dashed #eb6100 !important; }
                    .wabi-a11y-highlighted-element.err-contrast { border: 2px dashed #f39c12 !important; }
                    .wabi-a11y-highlighted-element.err-headings { border: 2px dashed #bbbcde !important; }
                    .wabi-a11y-highlighted-element.err-labels { border: 2px dashed #3498db !important; }
                    
                    .wabi-a11y-highlight-badge {
                      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif !important;
                      font-size: 10px !important;
                      font-weight: bold !important;
                      color: #ffffff !important;
                      padding: 2px 6px !important;
                      border-radius: 4px !important;
                      display: inline-block !important;
                      margin: 2px !important;
                      vertical-align: middle !important;
                      z-index: 99999 !important;
                      pointer-events: none !important;
                      box-shadow: 0 2px 5px rgba(0,0,0,0.3) !important;
                    }
                    .wabi-a11y-highlight-badge.alt-missing { background-color: #eb6100 !important; }
                    .wabi-a11y-highlight-badge.contrast-low { background-color: #f39c12 !important; }
                    .wabi-a11y-highlight-badge.heading-hierarchy { background-color: #bbbcde !important; color: #0c0d0e !important; }
                    .wabi-a11y-highlight-badge.label-missing { background-color: #3498db !important; }
                    
                    @keyframes wabi-err-pulse {
                      from { box-shadow: 0 0 4px rgba(235,97,0,0.4); }
                      to { box-shadow: 0 0 16px rgba(235,97,0,0.85); }
                    }
                    .wabi-a11y-highlighted-element.focus-pulse {
                      animation: wabi-err-pulse 0.5s ease-in-out infinite alternate !important;
                    }
                  `;
                  document.head.appendChild(styleBlock);
                }

                // Render badges next to marked elements on active page
                document.querySelectorAll("[data-a11y-error-id]").forEach(el => {
                  const type = el.getAttribute("data-a11y-error-type");
                  el.classList.add("wabi-a11y-highlighted-element", `err-${type}`);

                  const badge = document.createElement("span");
                  badge.className = `wabi-a11y-highlight-badge ${type}`;
                  
                  let label = "JISエラー";
                  if (type === "alt-missing") label = "⚠️ alt欠損";
                  if (type === "contrast-low") label = "🎨 コントラスト比不足";
                  if (type === "heading-hierarchy") label = "階層エラー";
                  if (type === "label-missing") label = "🏷️ ラベルなし";

                  badge.textContent = label;

                  if (el.tagName.toLowerCase() === "img") {
                    el.parentNode.insertBefore(badge, el.nextSibling);
                  } else {
                    el.appendChild(badge);
                  }
                });
              },
              args: [errors]
            });

            displayScanResults(errors);
          }
        });
      });
    } else {
      // Simulator mode (run locally on sandbox mock DOM)
      clearVisualHighlights();
      
      // Perform scan on the mock demo page container
      const errors = scanAccessibilityDOM("#demo-page-container");
      
      // Apply mock highlights on demo page container
      injectVisualHighlights();
      
      // Display summaries and lists
      displayScanResults(errors);
    }
  });

  btnClear.addEventListener("click", () => {
    if (window.chrome && chrome.tabs && chrome.scripting) {
      getTargetTab((activeTab) => {
        if (activeTab) {
          chrome.scripting.executeScript({
            target: { tabId: activeTab.id },
            func: function() {
              document.querySelectorAll(".wabi-a11y-highlight-badge").forEach(b => b.remove());
              document.querySelectorAll("[data-a11y-error-id]").forEach(el => {
                el.classList.remove("wabi-a11y-highlighted-element", "err-alt", "err-contrast", "err-headings", "err-labels");
                el.removeAttribute("data-a11y-error-id");
                el.removeAttribute("data-a11y-error-type");
                el.removeAttribute("data-a11y-error-details");
              });
              const styleBlock = document.getElementById("wabi-a11y-styles-prod");
              if (styleBlock) styleBlock.remove();
            }
          });
        }
      });
    } else {
      // Simulator reset
      clearVisualHighlights();
    }

    // Restore UI state to original
    guideSection.style.display = "flex";
    summarySection.style.display = "none";
    adviceSection.style.display = "none";
    btnClear.style.display = "none";
  });
});
