// background.js - Service Worker for Japanese Barrier Free Checker

chrome.runtime.onInstalled.addListener(() => {
  console.log("日本語バリアフリー検証 拡張機能が正常にインストールされました。");
});
