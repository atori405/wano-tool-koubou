// ==========================================================================
// E-book Price Searcher - Background Service Worker
// ==========================================================================

const CONTEXT_MENU_ID = "ebps-search-context-menu";

// Create context menu on installation
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: CONTEXT_MENU_ID,
    title: "コミック最安サーチで『%s』を検索",
    contexts: ["selection"]
  });
});

// Listener for context menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === CONTEXT_MENU_ID && info.selectionText) {
    const keyword = info.selectionText.trim();
    if (keyword && tab && tab.id) {
      // Send a message to the active tab's content script to show the comparison sidebar
      chrome.tabs.sendMessage(tab.id, { action: "searchManga", keyword: keyword }, (response) => {
        // Handle potential errors (e.g., if content script isn't loaded on the page yet)
        if (chrome.runtime.lastError) {
          console.warn("Could not send message to tab. Content script might not be injected:", chrome.runtime.lastError.message);
        }
      });
    }
  }
});
