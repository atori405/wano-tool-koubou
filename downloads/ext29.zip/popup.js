// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// ==========================================================================
// E-book Price Searcher - Core Logic
// ==========================================================================

// --- Store Configurations ---
const STORES = {
  Kindle: { name: "Amazon Kindle", badge: "K", color: "var(--brand-kindle)", url: "https://www.amazon.co.jp/" },
  ピッコマ: { name: "ピッコマ", badge: "ピ", color: "var(--brand-piccoma)", url: "https://piccoma.com/" },
  コミックシーモア: { name: "コミックシーモア", badge: "シ", color: "var(--brand-cmoa)", url: "https://www.cmoa.jp/" },
  LINEマンガ: { name: "LINEマンガ", badge: "Ｌ", color: "var(--brand-linemanga)", url: "https://manga.line.me/" },
  ブックライブ: { name: "ブックライブ", badge: "ブ", color: "var(--brand-booklive)", url: "https://booklive.jp/" },
  まんが王国: { name: "まんが王国", badge: "王", color: "var(--brand-kkingdom)", url: "https://comic.kkingdom.jp/" }
};

// --- Store Search Query Builders ---
function getStoreSearchUrl(storeKey, title) {
  const encoded = encodeURIComponent(title);
  switch (storeKey) {
    case "Kindle": return `https://www.amazon.co.jp/s?k=${encoded}&i=digital-text`;
    case "コミックシーモア": return `https://www.cmoa.jp/search/result/?key=${encoded}`;
    case "ピッコマ": return `https://piccoma.com/web/search?word=${encoded}`;
    case "LINEマンガ": return `https://manga.line.me/search?q=${encoded}`;
    case "ブックライブ": return `https://booklive.jp/search/keyword?keyword=${encoded}`;
    case "まんが王国": return `https://comic.kkingdom.jp/search-result?key=${encoded}`;
    default: return STORES[storeKey].url;
  }
}

// --- Mock Database (Popular Titles) ---
const POPULAR_MANGA_DB = {
  "one piece": {
    title: "ONE PIECE",
    author: "尾田栄一郎 (集英社)",
    status: "連載中",
    genre: "少年コミック",
    stores: {
      Kindle: { price: 501, originalPrice: 501, points: 5, freeVolume: 0, notes: "最新刊配信中" },
      ピッコマ: { price: 501, originalPrice: 501, points: 1, freeVolume: 3, rentalPrice: 350, notes: "待てば無料(1〜3巻)" },
      コミックシーモア: { price: 501, originalPrice: 501, points: 2, freeVolume: 0, rentalPrice: 400, notes: "新刊pt還元対象" },
      LINEマンガ: { price: 501, originalPrice: 501, points: 1, freeVolume: 5, notes: "毎日無料チャージ対象(1〜5巻)" },
      ブックライブ: { price: 501, originalPrice: 501, points: 10, freeVolume: 0, notes: "まとめ買い割引あり" },
      まんが王国: { price: 501, originalPrice: 501, points: 15, freeVolume: 0, notes: "最大50%pt還元中" }
    }
  },
  "鬼滅の刃": {
    title: "鬼滅の刃",
    author: "吾峠呼世晴 (集英社)",
    status: "完結",
    genre: "少年コミック",
    stores: {
      Kindle: { price: 459, originalPrice: 459, points: 10, freeVolume: 1, notes: "1巻無料お試し" },
      ピッコマ: { price: 459, originalPrice: 459, points: 2, freeVolume: 2, rentalPrice: 300, notes: "待てば無料(1〜2巻)" },
      コミックシーモア: { price: 459, originalPrice: 459, points: 5, freeVolume: 1, rentalPrice: 280, notes: "レンタルでお得" },
      LINEマンガ: { price: 459, originalPrice: 459, points: 1, freeVolume: 3, notes: "時短アイテム対象" },
      ブックライブ: { price: 459, originalPrice: 459, points: 8, freeVolume: 1, notes: "1巻無料キャンペ" },
      まんが王国: { price: 459, originalPrice: 459, points: 20, freeVolume: 0, notes: "全巻まとめpt対象" }
    }
  },
  "チェンソーマン": {
    title: "チェンソーマン",
    author: "藤本タツキ (集英社)",
    status: "連載中",
    genre: "少年コミック",
    stores: {
      Kindle: { price: 0, originalPrice: 480, points: 0, freeVolume: 2, notes: "1〜2巻期間限定無料！" },
      ピッコマ: { price: 0, originalPrice: 480, points: 1, freeVolume: 3, notes: "3巻まで丸ごと無料" },
      コミックシーモア: { price: 0, originalPrice: 480, points: 2, freeVolume: 2, rentalPrice: 250, notes: "2巻無料＆レンタル有" },
      LINEマンガ: { price: 0, originalPrice: 480, points: 1, freeVolume: 3, notes: "3巻無料＆待てば無料" },
      ブックライブ: { price: 0, originalPrice: 480, points: 10, freeVolume: 2, notes: "1〜2巻無料試し読み" },
      まんが王国: { price: 480, originalPrice: 480, points: 30, freeVolume: 0, notes: "ポイント超還元！" }
    }
  },
  "呪術廻戦": {
    title: "呪術廻戦",
    author: "芥見下々 (集英社)",
    status: "完結",
    genre: "少年コミック",
    stores: {
      Kindle: { price: 480, originalPrice: 480, points: 3, freeVolume: 0, notes: "最新刊発売記念pt" },
      ピッコマ: { price: 480, originalPrice: 480, points: 1, freeVolume: 1, rentalPrice: 320, notes: "1巻待てば無料" },
      コミックシーモア: { price: 480, originalPrice: 480, points: 10, freeVolume: 0, rentalPrice: 350, notes: "シーモア限定還元" },
      LINEマンガ: { price: 480, originalPrice: 480, points: 1, freeVolume: 2, notes: "待てば無料(2巻まで)" },
      ブックライブ: { price: 480, originalPrice: 480, points: 5, freeVolume: 0, notes: "Tポイントたまります" },
      まんが王国: { price: 480, originalPrice: 480, points: 25, freeVolume: 0, notes: "最大ポイント還元中" }
    }
  },
  "推しの子": {
    title: "【推しの子】",
    author: "赤坂アカ×横槍メンゴ (集英社)",
    status: "完結",
    genre: "青年コミック",
    stores: {
      Kindle: { price: 712, originalPrice: 712, points: 5, freeVolume: 0, notes: "アニメ化フェアpt" },
      ピッコマ: { price: 680, originalPrice: 680, points: 1, freeVolume: 2, notes: "待てば無料(1〜2巻)" },
      コミックシーモア: { price: 712, originalPrice: 712, points: 2, freeVolume: 0, rentalPrice: 500, notes: "レンタルあり" },
      LINEマンガ: { price: 680, originalPrice: 680, points: 1, freeVolume: 2, notes: "無料チャージ対応(1〜2巻)" },
      ブックライブ: { price: 712, originalPrice: 712, points: 12, freeVolume: 0, notes: "Luv割対象" },
      まんが王国: { price: 712, originalPrice: 712, points: 15, freeVolume: 0, notes: "全巻まとめ買い対応" }
    }
  },
  "葬送のフリーレン": {
    title: "葬送のフリーレン",
    author: "山田鐘人×アベツカサ (小学館)",
    status: "連載中",
    genre: "少年コミック",
    stores: {
      Kindle: { price: 600, originalPrice: 600, points: 10, freeVolume: 0, notes: "小学館フェアpt" },
      ピッコマ: { price: 600, originalPrice: 600, points: 2, freeVolume: 1, rentalPrice: 420, notes: "1巻待てばタダ" },
      コミックシーモア: { price: 600, originalPrice: 600, points: 3, freeVolume: 0, rentalPrice: 400, notes: "レンタルOK" },
      LINEマンガ: { price: 600, originalPrice: 600, points: 1, freeVolume: 1, notes: "1話ずつ無料チャージ" },
      ブックライブ: { price: 600, originalPrice: 600, points: 15, freeVolume: 0, notes: "15%還元中" },
      まんが王国: { price: 600, originalPrice: 600, points: 20, freeVolume: 0, notes: "ポイントまとめ対象" }
    }
  }
};

// --- Store Deals Data (Tab 2) ---
const STORE_DEALS = [
  { store: "Kindle", title: "夏のコミック大還元祭", desc: "対象作品が最大50%ポイント還元中。まとめ買いに最適！", tag: "半額相当還元", url: "https://www.amazon.co.jp/Kindle-ストア/b?node=2250738051" },
  { store: "コミックシーモア", title: "新規無料登録キャンペーン", desc: "新規登録で今すぐ使える【70%OFFクーポン】を即時配布中！", tag: "70%OFF", url: "https://www.cmoa.jp/" },
  { store: "ピッコマ", title: "独占先行 待てばタダ拡大！", desc: "ピッコマ独占・先行の人気作品が合計300話以上、期間限定チャージ短縮中！", tag: "チャージ時短", url: "https://piccoma.com/" },
  { store: "LINEマンガ", title: "金曜夜のボーナスコイン増量", desc: "金曜日18:00〜23:59限定で、チャージで貰えるボーナスコインが20%増量。", tag: "コイン増量", url: "https://manga.line.me/" },
  { store: "ブックライブ", title: "毎日引けるクーポンガチャ", desc: "ハズレなし！最大50%OFF（全ジャンル対象）クーポンが毎日当たります。", tag: "最大50%OFF", url: "https://booklive.jp/" },
  { store: "まんが王国", title: "最大50%ポイント還元デー", desc: "ポイント購入と使用の組み合わせで、毎日最大50%分のポイントが戻る！", tag: "最大50%還元", url: "https://comic.kkingdom.jp/" }
];

// --- Initial Default Coupons (Tab 3) ---
const DEFAULT_COUPONS = [
  { id: "def-1", site: "コミックシーモア", name: "新規登録 70%OFF", type: "percent", value: 70, minPrice: 0 },
  { id: "def-2", site: "ブックライブ", name: "ガチャ 20%OFF", type: "percent", value: 20, minPrice: 0 },
  { id: "def-3", site: "まんが王国", name: "ポイント還元 20%UP", type: "points", value: 20, minPrice: 0 }
];

// ==========================================================================
// Stateful Variables & Initialization
// ==========================================================================
let currentHistory = [];
let userCoupons = [];
let activeSearchManga = null;

document.addEventListener("DOMContentLoaded", () => {
  initTabs();
  loadData();
  setupEventListeners();
  renderDeals();
});

// --- Tab System ---
function initTabs() {
  const tabs = document.querySelectorAll(".tab-btn");
  tabs.forEach(tab => {
    tab.addEventListener("click", () => {
      // Deactivate all
      document.querySelectorAll(".tab-btn").forEach(t => t.classList.remove("active"));
      document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
      
      // Activate clicked
      tab.classList.add("active");
      const targetPanel = document.getElementById(tab.getAttribute("data-tab"));
      if (targetPanel) targetPanel.classList.add("active");

      // Preserve active tab state
      saveData("lastActiveTab", tab.getAttribute("data-tab"));
    });
  });
}

// --- Load/Save Local Data ---
function loadData() {
  // Use extension storage if available, fallback to localStorage
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(["userCoupons", "searchHistory", "lastSearchQuery", "lastActiveTab"], (result) => {
      userCoupons = result.userCoupons || DEFAULT_COUPONS;
      currentHistory = result.searchHistory || [];
      renderCoupons();
      renderHistory();

      // Restore active tab
      if (result.lastActiveTab) {
        const targetTab = document.querySelector(`[data-tab="${result.lastActiveTab}"]`);
        if (targetTab) targetTab.click();
      }

      // Restore last search
      if (result.lastSearchQuery) {
        document.getElementById("manga-search-input").value = result.lastSearchQuery;
        performSearch(result.lastSearchQuery, false); // false to prevent adding duplicates to history list
      }
    });
  } else {
    // Web environment fallback
    const savedCoupons = localStorage.getItem("userCoupons");
    const savedHistory = localStorage.getItem("searchHistory");
    const lastQuery = localStorage.getItem("lastSearchQuery");
    const lastTab = localStorage.getItem("lastActiveTab");
    
    userCoupons = savedCoupons ? JSON.parse(savedCoupons) : DEFAULT_COUPONS;
    currentHistory = savedHistory ? JSON.parse(savedHistory) : [];
    
    renderCoupons();
    renderHistory();

    if (lastTab) {
      const targetTab = document.querySelector(`[data-tab="${lastTab}"]`);
      if (targetTab) targetTab.click();
    }

    if (lastQuery) {
      document.getElementById("manga-search-input").value = lastQuery;
      performSearch(lastQuery, false);
    }
  }
}

function saveData(key, val) {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    const obj = {};
    obj[key] = val;
    chrome.storage.local.set(obj);
  } else {
    localStorage.setItem(key, JSON.stringify(val));
  }
}

// --- Event Listeners Setup ---
function setupEventListeners() {
  const searchInput = document.getElementById("manga-search-input");
  const searchBtn = document.getElementById("manga-search-btn");
  const clearHistoryBtn = document.getElementById("clear-history-btn");
  
  // Search actions
  searchBtn.addEventListener("click", () => performSearch(searchInput.value.trim()));
  searchInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") performSearch(searchInput.value.trim());
  });

  // Suggestion list logic
  searchInput.addEventListener("input", () => {
    const text = searchInput.value.trim().toLowerCase();
    const sugBox = document.getElementById("search-suggestions");
    
    if (!text) {
      sugBox.classList.add("hidden");
      return;
    }

    const matches = Object.keys(POPULAR_MANGA_DB).filter(key => key.includes(text));
    if (matches.length > 0) {
      sugBox.innerHTML = matches.map(mKey => {
        const item = POPULAR_MANGA_DB[mKey];
        return `<div class="suggestion-item" data-title="${item.title}">${item.title} <span style="font-size:10px;color:var(--color-text-sub)">(${item.author})</span></div>`;
      }).join('');
      sugBox.classList.remove("hidden");

      // Bind suggestions clicks
      document.querySelectorAll(".suggestion-item").forEach(el => {
        el.addEventListener("click", () => {
          searchInput.value = el.getAttribute("data-title");
          sugBox.classList.add("hidden");
          performSearch(searchInput.value);
        });
      });
    } else {
      sugBox.classList.add("hidden");
    }
  });

  // Close suggestion box on outside click
  document.addEventListener("click", (e) => {
    if (e.target.id !== "manga-search-input") {
      document.getElementById("search-suggestions").classList.add("hidden");
    }
  });

  // Coupon Toggle and CRUD
  const addCouponBtn = document.getElementById("add-coupon-btn");
  const couponForm = document.getElementById("coupon-form");
  const couponCancelBtn = document.getElementById("coupon-cancel-btn");

  addCouponBtn.addEventListener("click", () => couponForm.classList.remove("hidden"));
  couponCancelBtn.addEventListener("click", () => couponForm.classList.add("hidden"));

  couponForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const site = document.getElementById("coupon-site").value;
    const name = document.getElementById("coupon-name").value.trim();
    const type = document.getElementById("coupon-type").value;
    const value = parseInt(document.getElementById("coupon-value").value, 10);
    const minPrice = parseInt(document.getElementById("coupon-min-price").value, 10) || 0;

    const newCoupon = {
      id: "coupon-" + Date.now(),
      site,
      name,
      type,
      value,
      minPrice
    };

    userCoupons.push(newCoupon);
    saveData("userCoupons", userCoupons);
    renderCoupons();
    couponForm.reset();
    couponForm.classList.add("hidden");

    // Recalculate if there is an active search
    if (activeSearchManga) recalculateAndRender();
  });

  // Clear History
  clearHistoryBtn.addEventListener("click", () => {
    currentHistory = [];
    saveData("searchHistory", currentHistory);
    renderHistory();
  });

  // Sort Changes
  document.getElementById("price-sort-select").addEventListener("change", () => {
    if (activeSearchManga) recalculateAndRender();
  });

  // Coupon Apply Checkbox Change
  document.getElementById("apply-coupons-check").addEventListener("change", () => {
    if (activeSearchManga) recalculateAndRender();
  });

  // Quick Tags in Empty State
  document.querySelectorAll(".quick-search-tag").forEach(btn => {
    btn.addEventListener("click", () => {
      searchInput.value = btn.innerText;
      performSearch(btn.innerText);
    });
  });
}

// ==========================================================================
// Mock Search Engine & Long-tail Generator
// ==========================================================================

function getDeterministicManga(title) {
  const normTitle = title.trim().toLowerCase();
  
  // 1. Direct hit on popular db
  if (POPULAR_MANGA_DB[normTitle]) {
    return POPULAR_MANGA_DB[normTitle];
  }

  // 2. Generate a deterministic mock manga using title hash
  let hash = 0;
  for (let i = 0; i < normTitle.length; i++) {
    hash = normTitle.charCodeAt(i) + ((hash << 5) - hash);
  }
  hash = Math.abs(hash);

  // Derive reasonable properties
  const basePrice = 450 + (hash % 25) * 10; // ¥450 ~ ¥690
  const isFinished = hash % 2 === 0;
  const genres = ["少年コミック", "青年コミック", "少女コミック", "ファンタジー"];
  const genre = genres[hash % genres.length];
  const authors = ["佐藤 慎一", "高橋 優香", "鈴木 翼", "田中 健太", "中村 恵"];
  const author = authors[hash % authors.length] + " (コミック・モック社)";

  const stores = {};
  
  // Calculate deterministic values for all stores
  // Kindle (always has base or slightly less)
  stores["Kindle"] = {
    price: basePrice,
    originalPrice: basePrice,
    points: 1 + (hash % 15), // 1% ~ 15%
    freeVolume: hash % 5 === 0 ? 1 : 0,
    notes: hash % 5 === 0 ? "1巻無料配信中" : "通常配信"
  };

  // ピッコマ (often has rental or wait-for-free)
  stores["ピッコマ"] = {
    price: basePrice - (hash % 3) * 10,
    originalPrice: basePrice,
    points: 1 + (hash % 5),
    freeVolume: hash % 3 === 0 ? 2 : 0,
    rentalPrice: basePrice > 500 ? Math.floor(basePrice * 0.7) : null,
    notes: hash % 3 === 0 ? "待てば無料(2巻分)" : "通常配信"
  };

  // コミックシーモア (popular for rental)
  stores["コミックシーモア"] = {
    price: basePrice,
    originalPrice: basePrice,
    points: 2 + (hash % 10),
    freeVolume: hash % 6 === 0 ? 1 : 0,
    rentalPrice: Math.floor(basePrice * 0.65), // Always has rental
    notes: "レンタル可能"
  };

  // LINEマンガ (wait-for-free specialty)
  stores["LINEマンガ"] = {
    price: basePrice - (hash % 2) * 5,
    originalPrice: basePrice,
    points: 1 + (hash % 4),
    freeVolume: hash % 4 === 0 ? 3 : 0,
    notes: hash % 4 === 0 ? "3巻待てば無料" : "話チャージ対象"
  };

  // ブックライブ
  stores["ブックライブ"] = {
    price: basePrice,
    originalPrice: basePrice,
    points: 5 + (hash % 12),
    freeVolume: 0,
    notes: "ガチャクーポン適用可"
  };

  // まんが王国 (point heavy)
  stores["まんが王国"] = {
    price: basePrice,
    originalPrice: basePrice,
    points: 10 + (hash % 20), // 10% ~ 30% points
    freeVolume: 0,
    notes: "お得なまとめpt還元"
  };

  return {
    title: title,
    author: author,
    status: isFinished ? "完結" : "連載中",
    genre: genre,
    stores
  };
}

// ==========================================================================
// Search & Calculation Implementation
// ==========================================================================

function performSearch(title, saveToHistory = true) {
  if (!title) return;

  const manga = getDeterministicManga(title);
  activeSearchManga = manga;

  // Add to history
  if (saveToHistory) {
    addHistoryItem(manga.title);
  }

  // Save last search query
  saveData("lastSearchQuery", manga.title);

  // Render Manga Info Header
  document.getElementById("manga-info-card").classList.remove("hidden");
  document.getElementById("manga-title").innerText = manga.title;
  document.getElementById("manga-author").innerText = manga.author;
  document.getElementById("manga-status-tag").innerText = manga.status;
  document.getElementById("manga-genre-tag").innerText = manga.genre;

  // Recalculate prices and render list
  recalculateAndRender();
}

function recalculateAndRender() {
  if (!activeSearchManga) return;

  const applyCoupons = document.getElementById("apply-coupons-check").checked;
  const sortBy = document.getElementById("price-sort-select").value;

  const calculatedStores = [];

  // For each store, calculate applied price
  for (const [storeKey, storeData] of Object.entries(activeSearchManga.stores)) {
    let finalPrice = storeData.price;
    let finalPoints = storeData.points;
    let activeCouponsList = [];

    if (applyCoupons) {
      // Find coupons targeting this store and applicable for the price
      const eligibleCoupons = userCoupons.filter(c => c.site === storeKey && finalPrice >= c.minPrice);
      
      eligibleCoupons.forEach(coupon => {
        if (coupon.type === "percent") {
          finalPrice = Math.floor(finalPrice * (1 - coupon.value / 100));
          activeCouponsList.push(coupon.name);
        } else if (coupon.type === "value") {
          finalPrice = Math.max(0, finalPrice - coupon.value);
          activeCouponsList.push(coupon.name);
        } else if (coupon.type === "points") {
          finalPoints += coupon.value;
          activeCouponsList.push(coupon.name);
        }
      });
    }

    calculatedStores.push({
      storeKey,
      ...storeData,
      finalPrice,
      finalPoints,
      activeCouponsList,
      // For sorting: if price is 0, it means it's free. We treat it as 0.
      sortBuyPrice: finalPrice,
      sortRentalPrice: storeData.rentalPrice !== undefined && storeData.rentalPrice !== null ? storeData.rentalPrice : 99999
    });
  }

  // Sort based on selection
  if (sortBy === "buy") {
    calculatedStores.sort((a, b) => a.sortBuyPrice - b.sortBuyPrice);
  } else if (sortBy === "rental") {
    calculatedStores.sort((a, b) => a.sortRentalPrice - b.sortRentalPrice);
  } else if (sortBy === "points") {
    calculatedStores.sort((a, b) => b.finalPoints - a.finalPoints);
  }

  // Identify cheapest
  const lowestBuyPrice = Math.min(...calculatedStores.map(s => s.finalPrice));

  // Render list
  const resultsContainer = document.getElementById("comparison-results");
  resultsContainer.innerHTML = "";

  calculatedStores.forEach(s => {
    const storeMeta = STORES[s.storeKey];
    const isCheapest = s.finalPrice === lowestBuyPrice && s.finalPrice > 0;
    const isFree = s.finalPrice === 0;

    let badgesHtml = "";
    if (isFree) {
      badgesHtml += `<span class="price-badge badge-free">無料開放中</span>`;
    } else if (isCheapest) {
      badgesHtml += `<span class="price-badge badge-cheapest">👑 最安値</span>`;
    }
    
    if (s.rentalPrice !== undefined && s.rentalPrice !== null) {
      badgesHtml += `<span class="price-badge badge-rental">レンタル ¥${s.rentalPrice}</span>`;
    }

    if (s.finalPoints > 5) {
      badgesHtml += `<span class="price-badge badge-points">${s.finalPoints}%還元</span>`;
    }

    if (s.activeCouponsList.length > 0) {
      badgesHtml += `<span class="price-badge badge-discount">クーポン適用</span>`;
    }

    const priceText = isFree ? "無料" : `¥${s.finalPrice}`;
    const originalText = (s.originalPrice > s.finalPrice && !isFree) ? `¥${s.originalPrice}` : "";

    const card = document.createElement("div");
    card.className = `result-row ${isCheapest ? "cheapest" : ""}`;
    card.innerHTML = `
      <div class="store-info">
        <div class="store-badge" style="background: ${storeMeta.color}">${storeMeta.badge}</div>
        <div class="store-names">
          <span class="store-name-ja">${storeMeta.name}</span>
          <span class="store-status-note">${s.notes}</span>
        </div>
      </div>
      <div class="pricing-area">
        <div class="price-main-wrapper">
          ${originalText ? `<span class="price-original">${originalText}</span>` : ""}
          <span class="price-number">${priceText}</span>
        </div>
        <div class="price-badge-row">
          ${badgesHtml}
        </div>
      </div>
    `;

    // Click to search this comic directly on store
    card.addEventListener("click", () => {
      const searchUrl = getStoreSearchUrl(s.storeKey, activeSearchManga.title);
      if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.create) {
        chrome.tabs.create({ url: searchUrl });
      } else {
        window.open(searchUrl, '_blank');
      }
    });

    resultsContainer.appendChild(card);
  });

  // Build recommendation advisory
  const cheapestStore = calculatedStores.find(s => s.finalPrice === lowestBuyPrice);
  const storesWithFree = calculatedStores.filter(s => s.freeVolume > 0 || s.finalPrice === 0);
  
  let recText = "";
  if (cheapestStore.finalPrice === 0) {
    recText = `<span class="rec-highlight">${cheapestStore.storeKey}</span>等で<span class="rec-highlight">無料キャンペーン</span>が実施されています！今すぐ無料で読み始めるのがおすすめです。`;
  } else {
    recText = `今すぐ全巻揃えるなら、クーポンを適用した <span class="rec-highlight">${cheapestStore.storeKey} (¥${cheapestStore.finalPrice})</span> が最もお買い得です。`;
    
    // Check if wait-for-free alternative exists
    const waitFreeStore = calculatedStores.find(s => s.freeVolume > 0);
    if (waitFreeStore) {
      recText += `<br>⏳ また、<span class="rec-highlight">${waitFreeStore.storeKey}</span> を使えば最初の方の巻 (最大 ${waitFreeStore.freeVolume} 巻) は「待てば無料」で読めます！`;
    }
  }

  document.getElementById("recommendation-box").classList.remove("hidden");
  document.getElementById("rec-text").innerHTML = recText;
}

// ==========================================================================
// Coupons Tab Rendering & Actions (Tab 3)
// ==========================================================================

function renderCoupons() {
  const container = document.getElementById("coupons-list");
  container.innerHTML = "";

  if (userCoupons.length === 0) {
    container.innerHTML = `<div class="empty-state" style="padding:12px;"><p>登録済みのクーポンはありません。</p></div>`;
    return;
  }

  userCoupons.forEach(coupon => {
    const valText = coupon.type === "percent" ? `${coupon.value}%` : coupon.type === "points" ? `+${coupon.value}%` : `¥${coupon.value}`;
    const typeLabel = coupon.type === "percent" ? "OFF" : coupon.type === "points" ? "還元" : "割引";
    const condText = coupon.minPrice > 0 ? `¥${coupon.minPrice} 以上注文で適用` : "条件なし";

    const card = document.createElement("div");
    card.className = "coupon-card";
    card.innerHTML = `
      <div class="coupon-left">
        <div class="coupon-val-badge">
          <div>
            <div style="font-size: 13px; font-weight:700;">${valText}</div>
            <div style="font-size: 8px; margin-top:-2px;">${typeLabel}</div>
          </div>
        </div>
        <div class="coupon-info">
          <span class="coupon-site-tag">${coupon.site}</span>
          <span class="coupon-name-txt">${coupon.name}</span>
          <span class="coupon-min-txt">条件: ${condText}</span>
        </div>
      </div>
      <button class="coupon-delete-btn" data-id="${coupon.id}">🗑️</button>
    `;

    // Delete binder
    card.querySelector(".coupon-delete-btn").addEventListener("click", () => {
      deleteCoupon(coupon.id);
    });

    container.appendChild(card);
  });
}

function deleteCoupon(id) {
  userCoupons = userCoupons.filter(c => c.id !== id);
  saveData("userCoupons", userCoupons);
  renderCoupons();
  if (activeSearchManga) recalculateAndRender();
}

// ==========================================================================
// Deals Tab Rendering (Tab 2)
// ==========================================================================

function renderDeals() {
  const container = document.getElementById("deals-list");
  container.innerHTML = "";

  STORE_DEALS.forEach(deal => {
    const storeMeta = STORES[deal.store];
    const card = document.createElement("div");
    card.className = "deal-card";
    card.innerHTML = `
      <div class="deal-store-side" style="background: ${storeMeta.color}"></div>
      <div class="deal-content">
        <div class="deal-header-row">
          <span class="deal-store-name" style="color: ${storeMeta.color}">${storeMeta.name}</span>
          <span class="deal-tag">${deal.tag}</span>
        </div>
        <div class="deal-text">${deal.title}</div>
        <div class="deal-desc">${deal.desc}</div>
      </div>
    `;
    // Click to open store promo URL
    card.addEventListener("click", () => {
      if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.create) {
        chrome.tabs.create({ url: deal.url });
      } else {
        window.open(deal.url, '_blank');
      }
    });
    container.appendChild(card);
  });
}

// ==========================================================================
// History Tab Rendering & Actions (Tab 4)
// ==========================================================================

function renderHistory() {
  const container = document.getElementById("history-list");
  container.innerHTML = "";

  if (currentHistory.length === 0) {
    container.innerHTML = `<div class="empty-state" style="padding:12px;"><p>最近の検索履歴はありません。</p></div>`;
    return;
  }

  currentHistory.forEach(title => {
    const li = document.createElement("li");
    li.className = "history-item";
    li.innerHTML = `
      <span class="history-title">${title}</span>
      <span class="history-date">🔍 検索</span>
    `;

    li.addEventListener("click", () => {
      document.getElementById("manga-search-input").value = title;
      // Switch to comparison tab
      document.querySelector('[data-tab="tab-comparison"]').click();
      performSearch(title);
    });

    container.appendChild(li);
  });
}

function addHistoryItem(title) {
  // Remove duplicate if exists
  currentHistory = currentHistory.filter(h => h.toLowerCase() !== title.toLowerCase());
  // Add to start
  currentHistory.unshift(title);
  // Cap at 10 items
  if (currentHistory.length > 10) currentHistory.pop();
  
  saveData("searchHistory", currentHistory);
  renderHistory();
}
