// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// ==========================================================================
// 電子書籍・レンタルコミック横断検索 - Core Logic
// ==========================================================================
//
// 以前は、タイトルの文字列ハッシュ値から価格・著者名(架空の「コミック・モック社」
// という表記まで含む)・キャンペーンを自動生成し、あたかも実際の最安値比較や
// クーポン割引計算を行っているかのように表示していた。各ストアの実際の価格・
// 在庫・キャンペーンは本来ここからは分からないため、捏造をやめて「6ストアへ
// 正直に検索リンクを開く」機能に作り直した。クーポン機能も自動計算をやめ、
// 自分が実際に受け取ったクーポンを記録しておくだけのメモ機能にしている。

// --- Store Configurations ---
const STORES = {
  Kindle: { name: "Amazon Kindle", badge: "K", color: "var(--brand-kindle)", url: "https://www.amazon.co.jp/" },
  ピッコマ: { name: "ピッコマ", badge: "ピ", color: "var(--brand-piccoma)", url: "https://piccoma.com/" },
  コミックシーモア: { name: "コミックシーモア", badge: "シ", color: "var(--brand-cmoa)", url: "https://www.cmoa.jp/" },
  LINEマンガ: { name: "LINEマンガ", badge: "Ｌ", color: "var(--brand-linemanga)", url: "https://manga.line.me/" },
  ブックライブ: { name: "ブックライブ", badge: "ブ", color: "var(--brand-booklive)", url: "https://booklive.jp/" },
  まんが王国: { name: "まんが王国", badge: "王", color: "var(--brand-kkingdom)", url: "https://comic.k-manga.jp/" }
};

// --- Store Search Query Builders (本物の検索URL) ---
// 注: 実際にブラウザで動作確認したところ、ピッコマは旧URL(/web/search)がエラーページに
// 直結し、コミックシーモアは旧パラメータ(key)が無視され絞り込みなしの全件一覧になり、
// まんが王国は旧ドメイン(comic.kkingdom.jp)がそもそも存在しない(DNS解決不可)、
// LINEマンガも旧URL(/search?q=)が404という、4ストアで検索リンクが実際には機能して
// いなかった不具合が見つかったため、ユーザーに実際のサイトで確認してもらった上で
// 正しいURLに修正した。
function getStoreSearchUrl(storeKey, title) {
  const encoded = encodeURIComponent(title);
  switch (storeKey) {
    case "Kindle": return `https://www.amazon.co.jp/s?k=${encoded}&i=digital-text`;
    case "コミックシーモア": return `https://www.cmoa.jp/search/result/?header_word=${encoded}`;
    case "ピッコマ": return `https://piccoma.com/web/search/result?word=${encoded}`;
    case "LINEマンガ": return `https://manga.line.me/search_product/list?word=${encoded}`;
    case "ブックライブ": return `https://booklive.jp/search/keyword?keyword=${encoded}`;
    case "まんが王国": return `https://comic.k-manga.jp/search/word/${encoded}`;
    default: return STORES[storeKey].url;
  }
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

function openUrl(url) {
  if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.create) {
    chrome.tabs.create({ url });
  } else {
    window.open(url, '_blank');
  }
}

// ==========================================================================
// Stateful Variables & Initialization
// ==========================================================================
let currentHistory = [];
let userCoupons = [];
let priceObservations = [];

document.addEventListener("DOMContentLoaded", () => {
  initTabs();
  loadData();
  setupEventListeners();
  renderStoreList();
});

// --- Tab System ---
function initTabs() {
  const tabs = document.querySelectorAll(".tab-btn");
  tabs.forEach(tab => {
    tab.addEventListener("click", () => {
      // Deactivate all
      document.querySelectorAll(".tab-btn").forEach(t => t.classList.remove("active"));
      document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));

      // Activate clicked
      tab.classList.add("active");
      const targetPanel = document.getElementById(tab.getAttribute("data-tab"));
      if (targetPanel) targetPanel.classList.add("active");

      // Preserve active tab state
      saveData("lastActiveTab", tab.getAttribute("data-tab"));
    });
  });
}

// --- Load/Save Local Data ---
function loadData() {
  // Use extension storage if available, fallback to localStorage
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(["userCoupons", "searchHistory", "lastSearchQuery", "lastActiveTab", "ebpsPriceObservations"], (result) => {
      userCoupons = result.userCoupons || [];
      currentHistory = result.searchHistory || [];
      priceObservations = result.ebpsPriceObservations || [];
      renderCoupons();
      renderHistory();
      renderPriceObservations();

      // Restore active tab
      if (result.lastActiveTab) {
        const targetTab = document.querySelector(`[data-tab="${result.lastActiveTab}"]`);
        if (targetTab) targetTab.click();
      }

      // Restore last search
      if (result.lastSearchQuery) {
        document.getElementById("manga-search-input").value = result.lastSearchQuery;
        performSearch(result.lastSearchQuery, false); // false to prevent adding duplicates to history list
      }
    });
  } else {
    // Web environment fallback
    const savedCoupons = localStorage.getItem("userCoupons");
    const savedHistory = localStorage.getItem("searchHistory");
    const lastQuery = localStorage.getItem("lastSearchQuery");
    const lastTab = localStorage.getItem("lastActiveTab");
    const savedObservations = localStorage.getItem("ebpsPriceObservations");

    userCoupons = savedCoupons ? JSON.parse(savedCoupons) : [];
    currentHistory = savedHistory ? JSON.parse(savedHistory) : [];
    priceObservations = savedObservations ? JSON.parse(savedObservations) : [];

    renderCoupons();
    renderHistory();
    renderPriceObservations();

    if (lastTab) {
      const targetTab = document.querySelector(`[data-tab="${lastTab}"]`);
      if (targetTab) targetTab.click();
    }

    if (lastQuery) {
      document.getElementById("manga-search-input").value = lastQuery;
      performSearch(lastQuery, false);
    }
  }
}

function saveData(key, val) {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    const obj = {};
    obj[key] = val;
    chrome.storage.local.set(obj);
  } else {
    localStorage.setItem(key, JSON.stringify(val));
  }
}

// --- Event Listeners Setup ---
function setupEventListeners() {
  const searchInput = document.getElementById("manga-search-input");
  const searchBtn = document.getElementById("manga-search-btn");
  const clearHistoryBtn = document.getElementById("clear-history-btn");

  // Search actions
  searchBtn.addEventListener("click", () => performSearch(searchInput.value.trim()));
  searchInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") performSearch(searchInput.value.trim());
  });

  // Coupon Toggle and CRUD
  const addCouponBtn = document.getElementById("add-coupon-btn");
  const couponForm = document.getElementById("coupon-form");
  const couponCancelBtn = document.getElementById("coupon-cancel-btn");

  addCouponBtn.addEventListener("click", () => couponForm.classList.remove("hidden"));
  couponCancelBtn.addEventListener("click", () => couponForm.classList.add("hidden"));

  couponForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const site = document.getElementById("coupon-site").value;
    const name = document.getElementById("coupon-name").value.trim();
    const note = document.getElementById("coupon-note").value.trim();

    const newCoupon = {
      id: "coupon-" + Date.now(),
      site,
      name,
      note
    };

    userCoupons.push(newCoupon);
    saveData("userCoupons", userCoupons);
    renderCoupons();
    couponForm.reset();
    couponForm.classList.add("hidden");
  });

  // Clear History
  clearHistoryBtn.addEventListener("click", () => {
    currentHistory = [];
    saveData("searchHistory", currentHistory);
    renderHistory();
  });

  // Clear Price Observations
  const clearObservationsBtn = document.getElementById("clear-observations-btn");
  clearObservationsBtn.addEventListener("click", () => {
    priceObservations = [];
    saveData("ebpsPriceObservations", priceObservations);
    renderPriceObservations();
  });

  // Quick Tags in Empty State
  document.querySelectorAll(".quick-search-tag").forEach(btn => {
    btn.addEventListener("click", () => {
      searchInput.value = btn.innerText;
      performSearch(btn.innerText);
    });
  });
}

// ==========================================================================
// Search: honest 6-store search links (no price/author/campaign fabrication)
// ==========================================================================

function performSearch(title, saveToHistory = true) {
  if (!title) return;

  // Add to history
  if (saveToHistory) {
    addHistoryItem(title);
  }

  // Save last search query
  saveData("lastSearchQuery", title);

  // Render searched title header
  document.getElementById("manga-info-card").classList.remove("hidden");
  document.getElementById("manga-title").innerText = title;

  renderSearchResults(title);
}

function renderSearchResults(title) {
  const resultsContainer = document.getElementById("comparison-results");
  resultsContainer.innerHTML = "";

  Object.keys(STORES).forEach(storeKey => {
    const storeMeta = STORES[storeKey];
    const searchUrl = getStoreSearchUrl(storeKey, title);

    const card = document.createElement("div");
    card.className = "result-row";
    card.innerHTML = `
      <div class="store-info">
        <div class="store-badge" style="background: ${storeMeta.color}">${storeMeta.badge}</div>
        <div class="store-names">
          <span class="store-name-ja">${storeMeta.name}</span>
          <span class="store-status-note">「${escapeHtml(title)}」を検索</span>
        </div>
      </div>
      <span class="go-arrow">→</span>
    `;

    card.addEventListener("click", () => openUrl(searchUrl));
    resultsContainer.appendChild(card);
  });
}

// ==========================================================================
// Coupon Memo Tab Rendering & Actions (Tab 3)
// ==========================================================================

function renderCoupons() {
  const container = document.getElementById("coupons-list");
  container.innerHTML = "";

  if (userCoupons.length === 0) {
    container.innerHTML = `<div class="empty-state" style="padding:12px;"><p>登録済みのクーポンメモはありません。</p></div>`;
    return;
  }

  userCoupons.forEach(coupon => {
    const card = document.createElement("div");
    card.className = "coupon-card";
    card.innerHTML = `
      <div class="coupon-left">
        <div class="coupon-info">
          <span class="coupon-site-tag">${escapeHtml(coupon.site)}</span>
          <span class="coupon-name-txt">${escapeHtml(coupon.name)}</span>
          ${coupon.note ? `<span class="coupon-min-txt">${escapeHtml(coupon.note)}</span>` : ""}
        </div>
      </div>
      <button class="coupon-delete-btn" data-id="${coupon.id}">🗑️</button>
    `;

    // Delete binder
    card.querySelector(".coupon-delete-btn").addEventListener("click", () => {
      deleteCoupon(coupon.id);
    });

    container.appendChild(card);
  });
}

function deleteCoupon(id) {
  userCoupons = userCoupons.filter(c => c.id !== id);
  saveData("userCoupons", userCoupons);
  renderCoupons();
}

// ==========================================================================
// Store List Rendering (Tab 2) - plain links to each store's own site
// ==========================================================================

function renderStoreList() {
  const container = document.getElementById("deals-list");
  container.innerHTML = "";

  Object.keys(STORES).forEach(storeKey => {
    const storeMeta = STORES[storeKey];
    const card = document.createElement("div");
    card.className = "deal-card";
    card.innerHTML = `
      <div class="deal-store-side" style="background: ${storeMeta.color}"></div>
      <div class="deal-content">
        <div class="deal-header-row">
          <span class="deal-store-name" style="color: ${storeMeta.color}">${storeMeta.name}</span>
        </div>
        <div class="deal-desc">公式サイトを開く →</div>
      </div>
    `;
    card.addEventListener("click", () => openUrl(storeMeta.url));
    container.appendChild(card);
  });
}

// ==========================================================================
// History Tab Rendering & Actions (Tab 4)
// ==========================================================================

function renderHistory() {
  const container = document.getElementById("history-list");
  container.innerHTML = "";

  if (currentHistory.length === 0) {
    container.innerHTML = `<div class="empty-state" style="padding:12px;"><p>最近の検索履歴はありません。</p></div>`;
    return;
  }

  currentHistory.forEach(title => {
    const li = document.createElement("li");
    li.className = "history-item";
    li.innerHTML = `
      <span class="history-title">${escapeHtml(title)}</span>
      <span class="history-date">🔍 検索</span>
    `;

    li.addEventListener("click", () => {
      document.getElementById("manga-search-input").value = title;
      // Switch to comparison tab
      document.querySelector('[data-tab="tab-comparison"]').click();
      performSearch(title);
    });

    container.appendChild(li);
  });
}

// ==========================================================================
// Price Observations (Tab 4 sub-section) - honest personal record
// ==========================================================================
// Kindle・コミックシーモアの商品ページを開いたときに実際に表示されていた価格を
// そのまま記録したもの。自動計算や他ストアとの比較は一切行わない。

function formatObservedDate(iso) {
  try {
    const d = new Date(iso);
    return d.toLocaleString('ja-JP', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  } catch (e) {
    return "";
  }
}

function renderPriceObservations() {
  const container = document.getElementById("price-observations-list");
  if (!container) return;
  container.innerHTML = "";

  if (!priceObservations || priceObservations.length === 0) {
    container.innerHTML = `<div class="empty-state" style="padding:12px;"><p>まだ価格の記録はありません。Kindleやコミックシーモアの商品ページを開くと、実際に表示されていた価格がここに記録されます。</p></div>`;
    return;
  }

  priceObservations.forEach(obs => {
    const storeMeta = STORES[obs.store] || { name: obs.store, badge: "?" };
    const li = document.createElement("li");
    li.className = "history-item";
    li.innerHTML = `
      <span class="history-title">${escapeHtml(storeMeta.name)} ¥${obs.price.toLocaleString()}<br><span style="font-size:9px;color:var(--color-text-sub);font-weight:400;">${escapeHtml(obs.title)}</span></span>
      <span class="history-date">${formatObservedDate(obs.observedAt)}に閲覧</span>
    `;
    li.addEventListener("click", () => openUrl(obs.url));
    container.appendChild(li);
  });
}

function addHistoryItem(title) {
  // Remove duplicate if exists
  currentHistory = currentHistory.filter(h => h.toLowerCase() !== title.toLowerCase());
  // Add to start
  currentHistory.unshift(title);
  // Cap at 10 items
  if (currentHistory.length > 10) currentHistory.pop();

  saveData("searchHistory", currentHistory);
  renderHistory();
}
