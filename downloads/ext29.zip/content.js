// ==========================================================================
// 電子書籍・レンタルコミック最安サーチ - Content Script
// ==========================================================================
//
// 以前は、検索したタイトルが無かった場合に文字列のハッシュ値から価格・著者名・
// キャンペーン情報を自動生成し(生成される著者名には「コミック・モック社」という
// 架空の会社名まで入っていた)、「リアル価格比較」として表示していた。
// 各ストアの実際の価格は本来ここからは分からないため、捏造をやめて
// 「6ストアの検索結果を正直に開く」機能に作り直した。

// --- Store Brand Styles for Sidebar/Banner ---
const EBPS_STORES = {
  Kindle: { name: "Amazon Kindle", badge: "K", color: "#ff9900", url: "https://www.amazon.co.jp/" },
  ピッコマ: { name: "ピッコマ", badge: "ピ", color: "#ffcc00", url: "https://piccoma.com/" },
  コミックシーモア: { name: "コミックシーモア", badge: "シ", color: "#e63946", url: "https://www.cmoa.jp/" },
  LINEマンガ: { name: "LINEマンガ", badge: "Ｌ", color: "#06c755", url: "https://manga.line.me/" },
  ブックライブ: { name: "ブックライブ", badge: "ブ", color: "#95c11f", url: "https://booklive.jp/" },
  まんが王国: { name: "まんが王国", badge: "王", color: "#ff6600", url: "https://comic.k-manga.jp/" }
};

// --- Store Search Query Builders (本物の検索URL) ---
// 注: 実際にブラウザで動作確認したところ、ピッコマは旧URL(/web/search)がエラーページに
// 直結し、コミックシーモアは旧パラメータ(key)が無視され絞り込みなしの全件一覧になり、
// まんが王国は旧ドメイン(comic.kkingdom.jp)がそもそも存在しない(DNS解決不可)、
// LINEマンガも旧URL(/search?q=)が404という、4ストアで検索リンクが実際には機能して
// いなかった不具合が見つかったため、ユーザーに実際のサイトで確認してもらった上で
// 正しいURLに修正した。
function getStoreSearchUrl(storeKey, title) {
  const encoded = encodeURIComponent(title);
  switch (storeKey) {
    case "Kindle": return `https://www.amazon.co.jp/s?k=${encoded}&i=digital-text`;
    case "コミックシーモア": return `https://www.cmoa.jp/search/result/?header_word=${encoded}`;
    case "ピッコマ": return `https://piccoma.com/web/search/result?word=${encoded}`;
    case "LINEマンガ": return `https://manga.line.me/search_product/list?word=${encoded}`;
    case "ブックライブ": return `https://booklive.jp/search/keyword?keyword=${encoded}`;
    case "まんが王国": return `https://comic.k-manga.jp/search/word/${encoded}`;
    default: return EBPS_STORES[storeKey].url;
  }
}

// ==========================================================================
// 1. Text Selection -> Floating Action Button
// ==========================================================================
let floatingBtn = null;
let lastSelectedText = "";

document.addEventListener("mouseup", (e) => {
  // If clicked inside the floating button or sidebar, ignore
  if (e.target.closest("#ebps-floating-button") || e.target.closest("#ebps-sidebar")) {
    return;
  }

  setTimeout(() => {
    const selection = window.getSelection();
    const selectedText = selection.toString().trim();

    // Remove existing button if text is empty
    if (!selectedText || selectedText.length < 2 || selectedText.length > 25) {
      removeFloatingButton();
      return;
    }

    lastSelectedText = selectedText;
    createFloatingButton(e.pageX, e.pageY);
  }, 10);
});

// Hide floating button on scroll or selection change
document.addEventListener("mousedown", (e) => {
  if (e.target.closest("#ebps-floating-button") || e.target.closest("#ebps-sidebar")) return;
  removeFloatingButton();
});

function createFloatingButton(x, y) {
  removeFloatingButton();

  floatingBtn = document.createElement("div");
  floatingBtn.id = "ebps-floating-button";
  floatingBtn.innerHTML = `📚 他ストアで検索`;

  // Set positioning offset
  floatingBtn.style.left = `${x + 10}px`;
  floatingBtn.style.top = `${y + 10}px`;

  document.body.appendChild(floatingBtn);

  // Click handler -> Toggle Sidebar
  floatingBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    removeFloatingButton();
    toggleSidebar(lastSelectedText);
  });
}

function removeFloatingButton() {
  if (floatingBtn && floatingBtn.parentNode) {
    floatingBtn.parentNode.removeChild(floatingBtn);
    floatingBtn = null;
  }
}

// ==========================================================================
// 2. Slide-in Search-Links Sidebar(正直な検索リンク一覧)
// ==========================================================================
let sidebar = null;

function toggleSidebar(mangaTitle) {
  if (sidebar) {
    removeSidebar();
  }

  const title = cleanTitle(mangaTitle) || mangaTitle;

  sidebar = document.createElement("div");
  sidebar.id = "ebps-sidebar";
  sidebar.className = "ebps-slide-in";

  const storeKeys = Object.keys(EBPS_STORES);

  const resultsHtml = storeKeys.map(storeKey => {
    const store = EBPS_STORES[storeKey];
    const url = getStoreSearchUrl(storeKey, title);
    return `
      <a class="ebps-card" href="${url}" target="_blank" rel="noopener">
        <div class="ebps-card-header">
          <div class="ebps-store-badge" style="background: ${store.color}">${store.badge}</div>
          <span class="ebps-store-name">${store.name}</span>
        </div>
        <span class="ebps-visit-btn">検索結果を見る ➔</span>
      </a>
    `;
  }).join('');

  sidebar.innerHTML = `
    <div class="ebps-sidebar-inner">
      <div class="ebps-sidebar-header">
        <div>
          <h2 class="ebps-title">📚 コミック最安サーチ</h2>
          <p class="ebps-subtitle">6ストアの検索結果をまとめて開く</p>
        </div>
        <button id="ebps-close-sidebar" class="ebps-close-btn">&times;</button>
      </div>

      <div class="ebps-book-info">
        <h3 class="ebps-book-title">${escapeHtml(title)}</h3>
      </div>

      <div class="ebps-advisory">
        💡 各ストアの実際の価格・キャンペーンは、リンク先のページでご確認ください。このツール自体は価格を取得していません。
      </div>

      <div class="ebps-results-title">ストアで検索</div>
      <div class="ebps-results-container">
        ${resultsHtml}
      </div>

      <div class="ebps-sidebar-footer">
        検索結果を一括で開けます
      </div>
    </div>
  `;

  document.body.appendChild(sidebar);

  // Close event listener
  document.getElementById("ebps-close-sidebar").addEventListener("click", () => {
    removeSidebar();
  });
}

function removeSidebar() {
  if (sidebar) {
    sidebar.classList.remove("ebps-slide-in");
    sidebar.classList.add("ebps-slide-out");
    // Remove from DOM after animation completes
    setTimeout(() => {
      if (sidebar && sidebar.parentNode) {
        sidebar.parentNode.removeChild(sidebar);
      }
      sidebar = null;
    }, 300);
  }
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// ==========================================================================
// 3. E-commerce Detail Page Detection & Top Bar Injection
// ==========================================================================
function checkStoreAndInject() {
  const currentUrl = window.location.href;
  let detectedTitle = "";
  let currentStore = "";

  // For local testing in sandbox
  if (currentUrl.includes("localhost") || currentUrl.includes("127.0.0.1") || currentUrl.includes("test_sandbox.html")) {
    const params = new URLSearchParams(window.location.search);
    const mockStore = params.get("mockStore");
    if (mockStore) {
      currentStore = mockStore === "Kindle" ? "Kindle" :
                     mockStore === "cmoa" ? "コミックシーモア" :
                     mockStore === "piccoma" ? "ピッコマ" :
                     mockStore === "booklive" ? "ブックライブ" : "";

      const titleEl = document.getElementById("mock-manga-title");
      if (titleEl && currentStore) {
        detectedTitle = cleanTitle(titleEl.innerText);
      }
    }
  }

  // Amazon Kindle detect
  if (!detectedTitle && currentUrl.includes("amazon.co.jp")) {
    const titleEl = document.getElementById("productTitle") || document.getElementById("ebooksProductTitle");
    if (titleEl && (currentUrl.includes("/dp/") || currentUrl.includes("/gp/product/") || currentUrl.includes("/ASIN/"))) {
      detectedTitle = cleanTitle(titleEl.innerText);
      currentStore = "Kindle";
    }
  }
  // Comic CMOA detect
  // 注: 旧セレクタ(.title_header h1 / .title_name h1 / .title_name)は実際のページ構造と
  // 一致しておらず、.title_nameは無関係なおすすめ作品カルーセルにも大量に付与されている
  // クラス名だったため、そちらの1件目(=無関係な作品)を誤って拾っていた。実際にページの
  // メインタイトルに使われているのは一意な h1.titleName のみ。
  else if (currentUrl.includes("cmoa.jp/title/") || currentUrl.includes("cmoa.jp/volume/")) {
    const titleEl = document.querySelector("h1.titleName");
    if (titleEl) {
      detectedTitle = cleanTitle(titleEl.innerText);
      currentStore = "コミックシーモア";
    }
  }
  // Piccoma detect
  // 注: 旧セレクタ(.productHeader__title / .yk-product__title)は現行ページに存在せず、
  // 常に検出失敗していた。実際のタイトル要素は h1.PCM-productTitle。
  // また"piccoma.com"を含むだけで発火する条件だとトップページ等でも誤発火するため、
  // 商品ページのURLパターンに限定する。
  else if (currentUrl.includes("piccoma.com/web/product/")) {
    const titleEl = document.querySelector("h1.PCM-productTitle");
    if (titleEl) {
      detectedTitle = cleanTitle(titleEl.innerText);
      currentStore = "ピッコマ";
    }
  }
  // BookLive detect
  // 注: 旧URL条件(booklive.jp/product/info/)は実際のURL形式
  // (booklive.jp/product/index/title_id/.../vol_no/...)と一致せず、常に検出失敗していた。
  // 旧タイトルセレクタも同様に存在しないクラス名だったため、素の h1 に修正。
  else if (currentUrl.includes("booklive.jp/product/index/")) {
    const titleEl = document.querySelector("h1");
    if (titleEl) {
      detectedTitle = cleanTitle(titleEl.innerText);
      currentStore = "ブックライブ";
    }
  }

  if (detectedTitle && currentStore) {
    injectTopComparisonBar(detectedTitle, currentStore);

    // 実際にページ上に表示されている価格が確実に読み取れるストアに限り
    // (Kindle・コミックシーモアのみ。ピッコマ/ブックライブは話売り・待てば無料等で
    // ページ内に複数の価格ブロックが並び、どれが該当巻の価格か一意に断定できないため対象外)、
    // その場で見た実際の価格を自分の端末にだけ記録する。捏造や自動計算は行わない。
    const observedPrice = extractObservedPrice(currentStore);
    if (observedPrice) {
      recordPriceObservation(detectedTitle, currentStore, observedPrice, currentUrl);
    }
  }
}

// 表示中のページから実際の価格をそのまま読み取る(捏造・計算なし)。
// 対象外のストアやテキストが見つからない場合はnullを返す。
function extractObservedPrice(storeKey) {
  let priceText = "";
  if (storeKey === "Kindle") {
    const el = document.querySelector("#tmm-grid-swatch-KINDLE .a-color-price");
    priceText = el ? el.textContent : "";
  } else if (storeKey === "コミックシーモア") {
    const el = document.querySelector(".price");
    priceText = el ? el.textContent : "";
  } else {
    return null;
  }
  return extractYenAmount(priceText);
}

function extractYenAmount(text) {
  if (!text) return null;
  const yenSymbolMatch = text.match(/[¥￥]\s*([\d,]+)/);
  const yenSuffixMatch = text.match(/([\d,]+)\s*円/);
  const match = yenSymbolMatch || yenSuffixMatch;
  if (!match) return null;
  const amount = parseInt(match[1].replace(/,/g, ""), 10);
  return isNaN(amount) ? null : amount;
}

// 実際に見た価格を自分の端末(chrome.storage.local)にだけ記録する。
// 直近20件まで保持し、同じURLは上書き(最新の観測日時に更新)。
function recordPriceObservation(title, storeKey, price, url) {
  if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local) return;
  chrome.storage.local.get(["ebpsPriceObservations"], (result) => {
    let list = result.ebpsPriceObservations || [];
    list = list.filter(o => o.url !== url);
    list.unshift({
      store: storeKey,
      title: title,
      price: price,
      url: url,
      observedAt: new Date().toISOString()
    });
    if (list.length > 20) list = list.slice(0, 20);
    chrome.storage.local.set({ ebpsPriceObservations: list });
  });
}

// Cleans junk symbols from manga titles
function cleanTitle(raw) {
  if (!raw) return "";
  return raw
    .replace(/（[^）]*）/g, '') // Remove fullwidth parenthesis info
    .replace(/\([^\)]*\)/g, '') // Remove halfwidth parenthesis info
    .replace(/【[^】]*】/g, '') // Remove brackets info
    .replace(/(巻|巻セット|BOX|合本版|分冊版|単行本|Kindle版|コミック|電子書籍|電子版).*$/gi, '') // Remove volumes, formats
    .trim();
}

function injectTopComparisonBar(title, activeStoreKey) {
  // Check if already injected
  if (document.getElementById("ebps-top-bar")) return;

  // 他ストアの実際の価格はここからは分からないため、「最安値」等の断定はせず
  // 「他ストアでも検索できます」という誘導のみ行う。
  const message = `この作品は他の${Object.keys(EBPS_STORES).length - 1}ストアでも取り扱いがあるかもしれません。価格を比較してみましょう。`;

  const bar = document.createElement("div");
  bar.id = "ebps-top-bar";
  bar.innerHTML = `
    <div class="ebps-top-bar-content">
      <span class="ebps-top-bar-logo">📚 コミック最安サーチ</span>
      <span class="ebps-top-bar-msg">${message}</span>
      <div class="ebps-top-bar-actions">
        <button id="ebps-top-bar-open-sidebar" class="ebps-bar-btn">他5サイトで検索</button>
        <button id="ebps-top-bar-close" class="ebps-bar-close-btn">&times;</button>
      </div>
    </div>
  `;

  // Push body down slightly to fit the top bar
  document.body.style.paddingTop = "40px";
  document.body.insertBefore(bar, document.body.firstChild);

  // Click events
  document.getElementById("ebps-top-bar-open-sidebar").addEventListener("click", () => {
    toggleSidebar(title);
  });
  document.getElementById("ebps-top-bar-close").addEventListener("click", () => {
    bar.parentNode.removeChild(bar);
    document.body.style.paddingTop = "0px";
  });
}

// Run e-commerce page checking on load
setTimeout(checkStoreAndInject, 1500);

// Background communication listener for Context Menu Search
if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "searchManga") {
      toggleSidebar(request.keyword);
      sendResponse({ status: "success" });
    }
  });
}


// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // Add temporary shield to prevent iframe from stealing mouse events during dragging
      const existingShield = document.getElementById("wano-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = "wano-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      // Use getBoundingClientRect() for correct viewport-relative position
      // (element.offsetTop is unreliable for position:fixed elements on scrolled pages)
      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      // Restrict within window boundaries to prevent going offscreen
      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById("wano-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  // 拡張機能ごとに一意のIDでネームスペースを切る(他拡張機能とのDOM ID衝突防止。
  // persistent-panelスキルのGotcha4)
  const NS_ID = "wano-" + chrome.runtime.id;

  function toggleFloatingPanel() {
    let container = document.getElementById(NS_ID + "-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "flex" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = NS_ID + "-floating-container";

    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 452) + "px !important; z-index:2147483647 !important; width:442px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="${NS_ID}-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">Ebook Price Search</span>
        </div>
        <button id="${NS_ID}-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#" + NS_ID + "-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#" + NS_ID + "-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
