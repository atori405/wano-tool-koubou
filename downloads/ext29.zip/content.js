// ==========================================================================
// E-book Price Searcher - Content Script
// ==========================================================================

// --- Store Brand Styles for Sidebar/Banner ---
const EBPS_STORES = {
  Kindle: { name: "Amazon Kindle", badge: "K", color: "#ff9900", url: "https://www.amazon.co.jp/" },
  ピッコマ: { name: "ピッコマ", badge: "ピ", color: "#ffcc00", url: "https://piccoma.com/" },
  コミックシーモア: { name: "コミックシーモア", badge: "シ", color: "#e63946", url: "https://www.cmoa.jp/" },
  LINEマンガ: { name: "LINEマンガ", badge: "Ｌ", color: "#06c755", url: "https://manga.line.me/" },
  ブックライブ: { name: "ブックライブ", badge: "ブ", color: "#95c11f", url: "https://booklive.jp/" },
  まんが王国: { name: "まんが王国", badge: "王", color: "#ff6600", url: "https://comic.kkingdom.jp/" }
};

// --- Popular Manga Mock DB (Sync with popup.js) ---
const EBPS_POPULAR_DB = {
  "one piece": {
    title: "ONE PIECE",
    author: "尾田栄一郎 (集英社)",
    stores: {
      Kindle: { price: 501, originalPrice: 501, points: 5, freeVolume: 0, notes: "最新刊配信中" },
      ピッコマ: { price: 501, originalPrice: 501, points: 1, freeVolume: 3, rentalPrice: 350, notes: "待てば無料(1〜3巻)" },
      コミックシーモア: { price: 501, originalPrice: 501, points: 2, freeVolume: 0, rentalPrice: 400, notes: "新刊pt還元対象" },
      LINEマンガ: { price: 501, originalPrice: 501, points: 1, freeVolume: 5, notes: "毎日無料チャージ対象(1〜5巻)" },
      ブックライブ: { price: 501, originalPrice: 501, points: 10, freeVolume: 0, notes: "まとめ買い割引あり" },
      まんが王国: { price: 501, originalPrice: 501, points: 15, freeVolume: 0, notes: "最大50%pt還元中" }
    }
  },
  "鬼滅の刃": {
    title: "鬼滅の刃",
    author: "吾峠呼世晴 (集英社)",
    stores: {
      Kindle: { price: 459, originalPrice: 459, points: 10, freeVolume: 1, notes: "1巻無料お試し" },
      ピッコマ: { price: 459, originalPrice: 459, points: 2, freeVolume: 2, rentalPrice: 300, notes: "待てば無料(1〜2巻)" },
      コミックシーモア: { price: 459, originalPrice: 459, points: 5, freeVolume: 1, rentalPrice: 280, notes: "レンタルでお得" },
      LINEマンガ: { price: 459, originalPrice: 459, points: 1, freeVolume: 3, notes: "時短アイテム対象" },
      ブックライブ: { price: 459, originalPrice: 459, points: 8, freeVolume: 1, notes: "1巻無料キャンペ" },
      まんが王国: { price: 459, originalPrice: 459, points: 20, freeVolume: 0, notes: "全巻まとめpt対象" }
    }
  },
  "チェンソーマン": {
    title: "チェンソーマン",
    author: "藤本タツキ (集英社)",
    stores: {
      Kindle: { price: 0, originalPrice: 480, points: 0, freeVolume: 2, notes: "1〜2巻期間限定無料！" },
      ピッコマ: { price: 0, originalPrice: 480, points: 1, freeVolume: 3, notes: "3巻まで丸ごと無料" },
      コミックシーモア: { price: 0, originalPrice: 480, points: 2, freeVolume: 2, rentalPrice: 250, notes: "2巻無料＆レンタル有" },
      LINEマンガ: { price: 0, originalPrice: 480, points: 1, freeVolume: 3, notes: "3巻無料＆待てば無料" },
      ブックライブ: { price: 0, originalPrice: 480, points: 10, freeVolume: 2, notes: "1〜2巻無料試し読み" },
      まんが王国: { price: 480, originalPrice: 480, points: 30, freeVolume: 0, notes: "ポイント超還元！" }
    }
  },
  "呪術廻戦": {
    title: "呪術廻戦",
    author: "芥見下々 (集英社)",
    stores: {
      Kindle: { price: 480, originalPrice: 480, points: 3, freeVolume: 0, notes: "最新刊発売記念pt" },
      ピッコマ: { price: 480, originalPrice: 480, points: 1, freeVolume: 1, rentalPrice: 320, notes: "1巻待てば無料" },
      コミックシーモア: { price: 480, originalPrice: 480, points: 10, freeVolume: 0, rentalPrice: 350, notes: "シーモア限定還元" },
      LINEマンガ: { price: 480, originalPrice: 480, points: 1, freeVolume: 2, notes: "待てば無料(2巻まで)" },
      ブックライブ: { price: 480, originalPrice: 480, points: 5, freeVolume: 0, notes: "Tポイントたまります" },
      まんが王国: { price: 480, originalPrice: 480, points: 25, freeVolume: 0, notes: "最大ポイント還元中" }
    }
  },
  "推しの子": {
    title: "【推しの子】",
    author: "赤坂アカ×横槍メンゴ (集英社)",
    stores: {
      Kindle: { price: 712, originalPrice: 712, points: 5, freeVolume: 0, notes: "アニメ化フェアpt" },
      ピッコマ: { price: 680, originalPrice: 680, points: 1, freeVolume: 2, notes: "待てば無料(1〜2巻)" },
      コミックシーモア: { price: 712, originalPrice: 712, points: 2, freeVolume: 0, rentalPrice: 500, notes: "レンタルあり" },
      LINEマンガ: { price: 680, originalPrice: 680, points: 1, freeVolume: 2, notes: "無料チャージ対応(1〜2巻)" },
      ブックライブ: { price: 712, originalPrice: 712, points: 12, freeVolume: 0, notes: "Luv割対象" },
      まんが王国: { price: 712, originalPrice: 712, points: 15, freeVolume: 0, notes: "全巻まとめ買い対応" }
    }
  },
  "葬送のフリーレン": {
    title: "葬送のフリーレン",
    author: "山田鐘人×アベツカサ (小学館)",
    stores: {
      Kindle: { price: 600, originalPrice: 600, points: 10, freeVolume: 0, notes: "小学館フェアpt" },
      ピッコマ: { price: 600, originalPrice: 600, points: 2, freeVolume: 1, rentalPrice: 420, notes: "1巻待てばタダ" },
      コミックシーモア: { price: 600, originalPrice: 600, points: 3, freeVolume: 0, rentalPrice: 400, notes: "レンタルOK" },
      LINEマンガ: { price: 600, originalPrice: 600, points: 1, freeVolume: 1, notes: "1話ずつ無料チャージ" },
      ブックライブ: { price: 600, originalPrice: 600, points: 15, freeVolume: 0, notes: "15%還元中" },
      まんが王国: { price: 600, originalPrice: 600, points: 20, freeVolume: 0, notes: "ポイントまとめ対象" }
    }
  }
};

// --- Initial Default Coupons for Calculation Fallback ---
const DEFAULT_COUPONS = [
  { id: "def-1", site: "コミックシーモア", name: "新規登録 70%OFF", type: "percent", value: 70, minPrice: 0 },
  { id: "def-2", site: "ブックライブ", name: "ガチャ 20%OFF", type: "percent", value: 20, minPrice: 0 }
];

let userCoupons = DEFAULT_COUPONS;

// Fetch active coupons from chrome storage on launch
if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
  chrome.storage.local.get(["userCoupons"], (result) => {
    if (result.userCoupons) userCoupons = result.userCoupons;
  });
}

// ==========================================================================
// 1. Text Selection -> Floating Action Button
// ==========================================================================
let floatingBtn = null;
let lastSelectedText = "";

document.addEventListener("mouseup", (e) => {
  // If clicked inside the floating button or sidebar, ignore
  if (e.target.closest("#ebps-floating-button") || e.target.closest("#ebps-sidebar")) {
    return;
  }

  setTimeout(() => {
    const selection = window.getSelection();
    const selectedText = selection.toString().trim();

    // Remove existing button if text is empty
    if (!selectedText || selectedText.length < 2 || selectedText.length > 25) {
      removeFloatingButton();
      return;
    }

    lastSelectedText = selectedText;
    createFloatingButton(e.pageX, e.pageY);
  }, 10);
});

// Hide floating button on scroll or selection change
document.addEventListener("mousedown", (e) => {
  if (e.target.closest("#ebps-floating-button") || e.target.closest("#ebps-sidebar")) return;
  removeFloatingButton();
});

function createFloatingButton(x, y) {
  removeFloatingButton();

  floatingBtn = document.createElement("div");
  floatingBtn.id = "ebps-floating-button";
  floatingBtn.innerHTML = `📚 最安値検索`;
  
  // Set positioning offset
  floatingBtn.style.left = `${x + 10}px`;
  floatingBtn.style.top = `${y + 10}px`;
  
  document.body.appendChild(floatingBtn);

  // Click handler -> Toggle Sidebar
  floatingBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    removeFloatingButton();
    toggleSidebar(lastSelectedText);
  });
}

function removeFloatingButton() {
  if (floatingBtn && floatingBtn.parentNode) {
    floatingBtn.parentNode.removeChild(floatingBtn);
    floatingBtn = null;
  }
}

// ==========================================================================
// 2. Slide-in Price Comparison Sidebar
// ==========================================================================
let sidebar = null;

function toggleSidebar(mangaTitle) {
  if (sidebar) {
    removeSidebar();
  }

  sidebar = document.createElement("div");
  sidebar.id = "ebps-sidebar";
  sidebar.className = "ebps-slide-in";

  const manga = getDeterministicManga(mangaTitle);
  const calculatedStores = calculatePricesForManga(manga);
  const lowestPrice = Math.min(...calculatedStores.map(s => s.finalPrice));

  let resultsHtml = calculatedStores.map(s => {
    const isCheapest = s.finalPrice === lowestPrice && s.finalPrice > 0;
    const isFree = s.finalPrice === 0;

    let badgesHtml = "";
    if (isFree) badgesHtml += `<span class="ebps-badge ebps-badge-free">無料開放</span>`;
    else if (isCheapest) badgesHtml += `<span class="ebps-badge ebps-badge-cheapest">👑 最安値</span>`;
    
    if (s.rentalPrice !== undefined && s.rentalPrice !== null) {
      badgesHtml += `<span class="ebps-badge ebps-badge-rental">レンタル ¥${s.rentalPrice}</span>`;
    }
    if (s.finalPoints > 5) {
      badgesHtml += `<span class="ebps-badge ebps-badge-points">${s.finalPoints}%還元</span>`;
    }
    if (s.activeCouponsList.length > 0) {
      badgesHtml += `<span class="ebps-badge ebps-badge-coupon">クーポン適用</span>`;
    }

    const priceText = isFree ? "無料" : `¥${s.finalPrice}`;
    const originalText = (s.originalPrice > s.finalPrice && !isFree) ? `¥${s.originalPrice}` : "";

    return `
      <div class="ebps-card ${isCheapest ? "ebps-card-cheapest" : ""}">
        <div class="ebps-card-header">
          <div class="ebps-store-badge" style="background: ${EBPS_STORES[s.storeKey].color}">${EBPS_STORES[s.storeKey].badge}</div>
          <span class="ebps-store-name">${EBPS_STORES[s.storeKey].name}</span>
          <span class="ebps-store-notes">${s.notes}</span>
        </div>
        <div class="ebps-card-price-area">
          <div class="ebps-price-row">
            ${originalText ? `<span class="ebps-price-original">${originalText}</span>` : ""}
            <span class="ebps-price-main">${priceText}</span>
          </div>
          <div class="ebps-badge-row">
            ${badgesHtml}
          </div>
        </div>
        <a href="${EBPS_STORES[s.storeKey].url}" target="_blank" class="ebps-visit-btn">ストアを開く ➔</a>
      </div>
    `;
  }).join('');

  // Optimal route text
  const cheapestStore = calculatedStores.find(s => s.finalPrice === lowestPrice);
  const waitFreeStore = calculatedStores.find(s => s.freeVolume > 0);
  let advisoryHtml = "";
  if (cheapestStore.finalPrice === 0) {
    advisoryHtml = `🎉 <strong>${cheapestStore.storeKey}</strong>等で無料キャンペーン実施中！今すぐタダで読めます。`;
  } else {
    advisoryHtml = `💡 最安ルート: クーポン適用した <strong>${cheapestStore.storeKey} (¥${cheapestStore.finalPrice})</strong> での購入が一番お得です！`;
    if (waitFreeStore) {
      advisoryHtml += `<br>⏳ <strong>${waitFreeStore.storeKey}</strong> なら最初の一部巻は「待てれば無料」になります。`;
    }
  }

  sidebar.innerHTML = `
    <div class="ebps-sidebar-inner">
      <div class="ebps-sidebar-header">
        <div>
          <h2 class="ebps-title">📚 コミック最安サーチ</h2>
          <p class="ebps-subtitle">横断価格比較・シミュレーター</p>
        </div>
        <button id="ebps-close-sidebar" class="ebps-close-btn">&times;</button>
      </div>

      <div class="ebps-book-info">
        <h3 class="ebps-book-title">${manga.title}</h3>
        <p class="ebps-book-author">${manga.author} | ${manga.status}</p>
        <span class="ebps-book-genre">${manga.genre}</span>
      </div>

      <div class="ebps-advisory">
        ${advisoryHtml}
      </div>

      <div class="ebps-results-title">ストア別リアル価格比較</div>
      <div class="ebps-results-container">
        ${resultsHtml}
      </div>

      <div class="ebps-sidebar-footer">
        最安値シミュレーター稼働中 | クーポン自動適用済
      </div>
    </div>
  `;

  document.body.appendChild(sidebar);

  // Close event listener
  document.getElementById("ebps-close-sidebar").addEventListener("click", () => {
    removeSidebar();
  });
}

function removeSidebar() {
  if (sidebar) {
    sidebar.classList.remove("ebps-slide-in");
    sidebar.classList.add("ebps-slide-out");
    // Remove from DOM after animation completes
    setTimeout(() => {
      if (sidebar && sidebar.parentNode) {
        sidebar.parentNode.removeChild(sidebar);
      }
      sidebar = null;
    }, 300);
  }
}

// ==========================================================================
// 3. E-commerce Detail Page Detection & Top Bar Injection
// ==========================================================================
function checkStoreAndInject() {
  const currentUrl = window.location.href;
  let detectedTitle = "";
  let currentStore = "";

  // For local testing in sandbox
  if (currentUrl.includes("localhost") || currentUrl.includes("127.0.0.1") || currentUrl.includes("test_sandbox.html")) {
    const params = new URLSearchParams(window.location.search);
    const mockStore = params.get("mockStore");
    if (mockStore) {
      currentStore = mockStore === "Kindle" ? "Kindle" : 
                     mockStore === "cmoa" ? "コミックシーモア" : 
                     mockStore === "piccoma" ? "ピッコマ" : 
                     mockStore === "booklive" ? "ブックライブ" : "";
      
      const titleEl = document.getElementById("mock-manga-title");
      if (titleEl && currentStore) {
        detectedTitle = cleanTitle(titleEl.innerText);
      }
    }
  }

  // Amazon Kindle detect
  if (!detectedTitle && currentUrl.includes("amazon.co.jp")) {
    const titleEl = document.getElementById("productTitle") || document.getElementById("ebooksProductTitle");
    if (titleEl && (currentUrl.includes("/dp/") || currentUrl.includes("/gp/product/") || currentUrl.includes("/ASIN/"))) {
      detectedTitle = cleanTitle(titleEl.innerText);
      currentStore = "Kindle";
    }
  }
  // Comic CMOA detect
  else if (currentUrl.includes("cmoa.jp/title/") || currentUrl.includes("cmoa.jp/volume/")) {
    const titleEl = document.querySelector(".title_header h1") || document.querySelector(".title_name h1") || document.querySelector(".title_name");
    if (titleEl) {
      detectedTitle = cleanTitle(titleEl.innerText);
      currentStore = "コミックシーモア";
    }
  }
  // Piccoma detect
  else if (currentUrl.includes("piccoma.com")) {
    const titleEl = document.querySelector(".productHeader__title") || document.querySelector(".yk-product__title");
    if (titleEl) {
      detectedTitle = cleanTitle(titleEl.innerText);
      currentStore = "ピッコマ";
    }
  }
  // BookLive detect
  else if (currentUrl.includes("booklive.jp/product/info/")) {
    const titleEl = document.querySelector(".product-detail-area h1") || document.querySelector(".product-title") || document.querySelector(".product_title");
    if (titleEl) {
      detectedTitle = cleanTitle(titleEl.innerText);
      currentStore = "ブックライブ";
    }
  }

  if (detectedTitle && currentStore) {
    injectTopComparisonBar(detectedTitle, currentStore);
  }
}

// Cleans junk symbols from manga titles
function cleanTitle(raw) {
  if (!raw) return "";
  return raw
    .replace(/（[^）]*）/g, '') // Remove fullwidth parenthesis info
    .replace(/\([^\)]*\)/g, '') // Remove halfwidth parenthesis info
    .replace(/【[^】]*】/g, '') // Remove brackets info
    .replace(/(巻|巻セット|BOX|合本版|分冊版|単行本|Kindle版|コミック|電子書籍|電子版).*$/gi, '') // Remove volumes, formats
    .trim();
}

function injectTopComparisonBar(title, activeStoreKey) {
  // Check if already injected
  if (document.getElementById("ebps-top-bar")) return;

  const manga = getDeterministicManga(title);
  const calculatedStores = calculatePricesForManga(manga);
  const lowestPrice = Math.min(...calculatedStores.map(s => s.finalPrice));

  // Find cheapest alternative
  const cheapest = calculatedStores[0]; // Already sorted inside calculatePricesForManga by price asc
  const currentStoreData = calculatedStores.find(s => s.storeKey === activeStoreKey);

  let message = "";
  if (cheapest.storeKey === activeStoreKey) {
    message = `👑 現在表示中のストア <strong>${activeStoreKey}</strong> が最安値 (¥${cheapest.finalPrice}) です！`;
  } else {
    const diff = (currentStoreData ? currentStoreData.finalPrice : 500) - cheapest.finalPrice;
    if (cheapest.finalPrice === 0) {
      message = `🔥 <strong>${cheapest.storeKey}</strong> なら、このコミックが現在 <strong>無料</strong> で配信中！`;
    } else if (diff > 0) {
      message = `💰 <strong>${cheapest.storeKey}</strong> の方が <strong>¥${diff} 安く</strong> 読めます！ (このストア: ¥${currentStoreData ? currentStoreData.finalPrice : '---'} ➔ ${cheapest.storeKey}: ¥${cheapest.finalPrice})`;
    } else {
      message = `🔍 他のストア（${cheapest.storeKey} など）でも価格を比較できます。`;
    }
  }

  const bar = document.createElement("div");
  bar.id = "ebps-top-bar";
  bar.innerHTML = `
    <div class="ebps-top-bar-content">
      <span class="ebps-top-bar-logo">📚 コミック最安値比較</span>
      <span class="ebps-top-bar-msg">${message}</span>
      <div class="ebps-top-bar-actions">
        <button id="ebps-top-bar-open-sidebar" class="ebps-bar-btn">他5サイトと比較</button>
        <button id="ebps-top-bar-close" class="ebps-bar-close-btn">&times;</button>
      </div>
    </div>
  `;

  // Push body down slightly to fit the top bar
  document.body.style.paddingTop = "40px";
  document.body.insertBefore(bar, document.body.firstChild);

  // Click events
  document.getElementById("ebps-top-bar-open-sidebar").addEventListener("click", () => {
    toggleSidebar(title);
  });
  document.getElementById("ebps-top-bar-close").addEventListener("click", () => {
    bar.parentNode.removeChild(bar);
    document.body.style.paddingTop = "0px";
  });
}

// Run e-commerce page checking on load
setTimeout(checkStoreAndInject, 1500);

// ==========================================================================
// 4. Utility Calculation & Mock Engine (Ported from popup.js logic)
// ==========================================================================
function getDeterministicManga(title) {
  const normTitle = title.trim().toLowerCase();
  
  if (EBPS_POPULAR_DB[normTitle]) {
    return EBPS_POPULAR_DB[normTitle];
  }

  // Hash based generator
  let hash = 0;
  for (let i = 0; i < normTitle.length; i++) {
    hash = normTitle.charCodeAt(i) + ((hash << 5) - hash);
  }
  hash = Math.abs(hash);

  const basePrice = 450 + (hash % 25) * 10; // ¥450 ~ ¥690
  const isFinished = hash % 2 === 0;
  const genres = ["少年コミック", "青年コミック", "少女コミック", "ファンタジー"];
  const genre = genres[hash % genres.length];
  const authors = ["佐藤 慎一", "高橋 優香", "鈴木 翼", "田中 健太", "中村 恵"];
  const author = authors[hash % authors.length] + " (コミック・モック社)";

  const stores = {};
  stores["Kindle"] = { price: basePrice, originalPrice: basePrice, points: 1 + (hash % 15), freeVolume: hash % 5 === 0 ? 1 : 0, notes: hash % 5 === 0 ? "1巻無料配信中" : "通常配信" };
  stores["ピッコマ"] = { price: basePrice - (hash % 3) * 10, originalPrice: basePrice, points: 1 + (hash % 5), freeVolume: hash % 3 === 0 ? 2 : 0, rentalPrice: basePrice > 500 ? Math.floor(basePrice * 0.7) : null, notes: hash % 3 === 0 ? "待てば無料" : "通常配信" };
  stores["コミックシーモア"] = { price: basePrice, originalPrice: basePrice, points: 2 + (hash % 10), freeVolume: hash % 6 === 0 ? 1 : 0, rentalPrice: Math.floor(basePrice * 0.65), notes: "レンタル可能" };
  stores["LINEマンガ"] = { price: basePrice - (hash % 2) * 5, originalPrice: basePrice, points: 1 + (hash % 4), freeVolume: hash % 4 === 0 ? 3 : 0, notes: hash % 4 === 0 ? "3巻待てば無料" : "話チャージ対象" };
  stores["ブックライブ"] = { price: basePrice, originalPrice: basePrice, points: 5 + (hash % 12), freeVolume: 0, notes: "ガチャクーポン適用可" };
  stores["まんが王国"] = { price: basePrice, originalPrice: basePrice, points: 10 + (hash % 20), freeVolume: 0, notes: "お得なまとめpt還元" };

  return {
    title: title,
    author: author,
    status: isFinished ? "完結" : "連載中",
    genre: genre,
    stores
  };
}

function calculatePricesForManga(manga) {
  const calculatedStores = [];

  for (const [storeKey, storeData] of Object.entries(manga.stores)) {
    let finalPrice = storeData.price;
    let finalPoints = storeData.points;
    let activeCouponsList = [];

    // Apply active user coupons
    const eligibleCoupons = userCoupons.filter(c => c.site === storeKey && finalPrice >= c.minPrice);
    eligibleCoupons.forEach(coupon => {
      if (coupon.type === "percent") {
        finalPrice = Math.floor(finalPrice * (1 - coupon.value / 100));
        activeCouponsList.push(coupon.name);
      } else if (coupon.type === "value") {
        finalPrice = Math.max(0, finalPrice - coupon.value);
        activeCouponsList.push(coupon.name);
      } else if (coupon.type === "points") {
        finalPoints += coupon.value;
        activeCouponsList.push(coupon.name);
      }
    });

    calculatedStores.push({
      storeKey,
      ...storeData,
      finalPrice,
      finalPoints,
      activeCouponsList
    });
  }

  // Default sorting inside Content Script sidebar data: price ascending
  calculatedStores.sort((a, b) => a.finalPrice - b.finalPrice);
  return calculatedStores;
}

// Background communication listener for Context Menu Search
if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "searchManga") {
      toggleSidebar(request.keyword);
      sendResponse({ status: "success" });
    }
  });
}


// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // Add temporary shield to prevent iframe from stealing mouse events during dragging
      const existingShield = document.getElementById("wano-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = "wano-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      // Use getBoundingClientRect() for correct viewport-relative position
      // (element.offsetTop is unreliable for position:fixed elements on scrolled pages)
      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      // Restrict within window boundaries to prevent going offscreen
      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById("wano-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById("wano-universal-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "block" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = "wano-universal-floating-container";
    
    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 452) + "px !important; z-index:2147483647 !important; width:442px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="wano-u-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">Ebook Price Search</span>
        </div>
        <button id="wano-u-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#wano-u-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#wano-u-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
