



document.addEventListener('DOMContentLoaded', () => {
  // --- State ---
  let currentTheme = 'light';

  // --- Theme Toggle ---
  const themeToggle = document.getElementById('theme-toggle');
  const sunIcon = themeToggle.querySelector('.sun-icon');
  const moonIcon = themeToggle.querySelector('.moon-icon');

  const applyTheme = (theme) => {
    if (theme === 'dark') {
      document.body.classList.remove('light-theme');
      document.body.classList.add('dark-theme');
      sunIcon.style.display = 'none';
      moonIcon.style.display = 'block';
    } else {
      document.body.classList.remove('dark-theme');
      document.body.classList.add('light-theme');
      sunIcon.style.display = 'block';
      moonIcon.style.display = 'none';
    }
    currentTheme = theme;
    localStorage.setItem('adjuster-theme', theme);
  };

  const savedTheme = localStorage.getItem('adjuster-theme') || 'light';
  applyTheme(savedTheme);

  themeToggle.addEventListener('click', () => {
    applyTheme(currentTheme === 'light' ? 'dark' : 'light');
  });

  // --- Tab Navigation ---
  const navTabs = document.querySelectorAll('.nav-tab');
  const tabContents = document.querySelectorAll('.tab-content');

  navTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const targetTab = tab.getAttribute('data-tab');
      navTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      tabContents.forEach(content => {
        if (content.id === targetTab) {
          content.classList.add('active');
        } else {
          content.classList.remove('active');
        }
      });
    });
  });

  // --- Toast ---
  const toast = document.getElementById('toast');
  const triggerToast = () => {
    toast.classList.remove('hidden');
    setTimeout(() => {
      toast.classList.add('hidden');
    }, 2000);
  };

  // --- Elements ---
  const inputText = document.getElementById('input-text');
  const clearInputBtn = document.getElementById('clear-input');
  const countTotal = document.getElementById('count-total');
  const timeRead = document.getElementById('time-read');

  const selectLimitPreset = document.getElementById('select-limit-preset');
  const customLimitGroup = document.getElementById('custom-limit-group');
  const inputCustomLimit = document.getElementById('input-custom-limit');
  const btnAdjust = document.getElementById('btn-adjust');

  const adjustResultContainer = document.getElementById('adjust-result-container');
  const resultCharCount = document.getElementById('result-char-count');
  const outputAdjusted = document.getElementById('output-adjusted');
  const btnCopyAdjusted = document.getElementById('btn-copy-adjusted');

  // Tab 2 Elements
  const barKanji = document.getElementById('bar-kanji');
  const barHiragana = document.getElementById('bar-hiragana');
  const barKatakana = document.getElementById('bar-katakana');
  const barOther = document.getElementById('bar-other');

  const lblKanji = document.getElementById('lbl-kanji');
  const lblHiragana = document.getElementById('lbl-hiragana');
  const lblKatakana = document.getElementById('lbl-katakana');
  const lblOther = document.getElementById('lbl-other');

  const verdictBadge = document.getElementById('verdict-badge');
  const verdictDesc = document.getElementById('verdict-desc');

  const polishCardContainer = document.getElementById('polish-card-container');
  const polishSuggestionsList = document.getElementById('polish-suggestions-list');

  // Show/Hide custom limit group
  selectLimitPreset.addEventListener('change', () => {
    if (selectLimitPreset.value === 'custom') {
      customLimitGroup.classList.remove('hidden');
    } else {
      customLimitGroup.classList.add('hidden');
    }
  });

  clearInputBtn.addEventListener('click', () => {
    inputText.value = '';
    adjustResultContainer.classList.add('hidden');
    updateAnalysis();
    inputText.focus();
  });

  // Wording advice dictionary (ひらがなに開く)
  const wordingRules = [
    { word: '頂く', dest: 'いただく', desc: '〜していただく等、動詞に添える補助動詞はひらがな表記にするのが一般的です。' },
    { word: '致す', dest: 'いたす', desc: '「〜いたします」などの補助動詞は、ひらがなにすると文章が柔らかくなります。' },
    { word: '出来る', dest: 'できる', desc: '「〜することができる」の「できる」は、ひらがな表記がビジネス公用文のルールです。' },
    { word: '事', dest: 'こと', desc: '「〜すること」といった形式名詞は、ひらがな表記にするのが基本です。' },
    { word: '為', dest: 'ため', desc: '「〜のため」という接続詞・形式名詞は、ひらがなで書くほうが読みやすいです。' },
    { word: '様', dest: 'よう', desc: '「〜のように」などの比況・形式名詞は、ひらがなでの表記が推奨されます。' },
    { word: '有難う', dest: 'ありがとう', desc: '「有難うございます」は堅苦しすぎるため、ひらがなに開きます。' },
    { word: '何時も', dest: 'いつも', desc: '常用外漢字であるため、ひらがなで表記しましょう。' }
  ];

  // Character counter & Golden ratio calculations
  const updateAnalysis = () => {
    const text = inputText.value;
    const len = text.length;
    countTotal.textContent = len;

    // Estimate read time (reading speed: approx 500 chars/min)
    if (len === 0) {
      timeRead.textContent = '0秒';
    } else if (len < 500) {
      const sec = Math.ceil(len / 8.3);
      timeRead.textContent = `${sec}秒`;
    } else {
      const min = Math.ceil(len / 500);
      timeRead.textContent = `${min}分`;
    }

    if (len === 0) {
      // Reset progress bars
      barKanji.style.width = '0%';
      barHiragana.style.width = '0%';
      barKatakana.style.width = '0%';
      barOther.style.width = '0%';

      lblKanji.textContent = 0;
      lblHiragana.textContent = 0;
      lblKatakana.textContent = 0;
      lblOther.textContent = 0;

      verdictBadge.textContent = '判定なし';
      verdictBadge.className = 'verdict-badge';
      verdictDesc.textContent = '文章を入力すると、読みやすさの比率判定が行われます。';
      
      polishCardContainer.classList.add('hidden');
      return;
    }

    // Character classification
    const kanjiCount = (text.match(/[\u4e00-\u9faf\u3400-\u4dbf]/g) || []).length;
    const hiraganaCount = (text.match(/[\u3040-\u309f]/g) || []).length;
    const katakanaCount = (text.match(/[\u30a0-\u30ff]/g) || []).length;
    const otherCount = len - kanjiCount - hiraganaCount - katakanaCount;

    // Percentages
    const pctKanji = Math.round((kanjiCount / len) * 100);
    const pctHiragana = Math.round((hiraganaCount / len) * 100);
    const pctKatakana = Math.round((katakanaCount / len) * 100);
    const pctOther = 100 - pctKanji - pctHiragana - pctKatakana;

    // Update bar widths
    barKanji.style.width = `${pctKanji}%`;
    barHiragana.style.width = `${pctHiragana}%`;
    barKatakana.style.width = `${pctKatakana}%`;
    barOther.style.width = `${pctOther}%`;

    // Update labels
    lblKanji.textContent = pctKanji;
    lblHiragana.textContent = pctHiragana;
    lblKatakana.textContent = pctKatakana;
    lblOther.textContent = pctOther;

    // Evaluate Readability Verdict
    verdictBadge.className = 'verdict-badge';
    if (pctKanji > 40) {
      verdictBadge.textContent = '漢字過多';
      verdictBadge.classList.add('kanji');
      verdictDesc.textContent = '漢字の比率が40%を超えており、文章が堅苦しく読みづらくなっています。補助動詞や形式名詞（「こと」「ため」など）を「ひらがな」に直すことで、親しみやすく読みやすい文章になります。';
    } else if (pctKatakana > 25) {
      verdictBadge.textContent = 'カタカナ過多';
      verdictBadge.classList.add('katakana');
      verdictDesc.textContent = 'カタカナ（外来語・ビジネスIT用語）が多く含まれています。乱用は読み手を疲れさせるため、可能であれば日本語の表現に直すことを検討してください。';
    } else if (pctKanji < 20 && len > 30) {
      verdictBadge.textContent = 'ひらがな過多';
      verdictBadge.classList.add('katakana');
      verdictDesc.textContent = 'ひらがなの比率が多く、文章が少し幼稚に見えてしまう可能性があります。名詞や動詞を適度に漢字に変えるか、句読点の位置を整えてみてください。';
    } else {
      verdictBadge.textContent = '黄金比率達成！';
      verdictBadge.classList.add('golden');
      verdictDesc.textContent = '漢字・ひらがな・カタカナのバランスが非常に良く、読み手の目に優しい理想的な黄金比率（漢字30%：ひらがな40%：カタカナ30%）に近いクリーンな文章です！';
    }

    // Populate wording polish suggestions
    polishSuggestionsList.innerHTML = '';
    let foundSuggestions = 0;

    wordingRules.forEach(rule => {
      if (text.includes(rule.word)) {
        foundSuggestions++;
        const item = document.createElement('div');
        item.className = 'polish-item';
        item.innerHTML = `
          <div class="polish-compare">
            <span class="polish-orig">${rule.word}</span>
            <span class="polish-arrow">➔</span>
            <span class="polish-dest">${rule.dest}</span>
          </div>
          <div class="polish-item-desc">${rule.desc}</div>
        `;
        polishSuggestionsList.appendChild(item);
      }
    });

    if (foundSuggestions > 0) {
      polishCardContainer.classList.remove('hidden');
    } else {
      polishCardContainer.classList.add('hidden');
    }
  };

  inputText.addEventListener('input', updateAnalysis);

  // --- AI Text Length Adjuster Action ---
  btnAdjust.addEventListener('click', () => {
    const text = inputText.value.trim();
    if (!text) return;

    btnAdjust.innerHTML = '<span>AI文章調整中...</span>';
    btnAdjust.classList.add('loading');

    setTimeout(() => {
      // Find Limit
      let limit = 140;
      const preset = selectLimitPreset.value;
      if (preset === 'custom') {
        limit = parseInt(inputCustomLimit.value) || 50;
      } else {
        limit = parseInt(preset);
      }

      let adjusted = text;
      
      if (text.length > limit) {
        // Simulated AI Trimming / Summarization
        if (limit === 140) {
          // Twitter style optimization
          adjusted = text
            .replace(/予定していた時間を大幅に超えてしまい申し訳ありませんでした/g, '時間超過をお詫びいたします')
            .replace(/アジェンダが多すぎたことが原因だと思いますので、次回は優先度が高いものに絞って進めましょう/g, 'アジェンダ過多が原因のため、次回は優先度の高い案件に絞って進行します');
          
          if (adjusted.length > 140) {
            adjusted = adjusted.slice(0, 137) + '...';
          }
        } else if (limit === 32) {
          // Title Optimization mockup
          if (text.includes('ミーティング')) {
            adjusted = '開発ミーティングの時間超過お詫びと次回改善策について';
          } else {
            adjusted = text.slice(0, 29) + '...';
          }
        } else if (limit === 80) {
          // Press release summary style
          adjusted = '昨日の開発ミーティング時間超過へのお詫びと、次回に向けアジェンダを優先度の高いものに絞り進行する改善策を提案。';
          if (adjusted.length > 80) {
            adjusted = adjusted.slice(0, 77) + '...';
          }
        } else {
          // Custom limit slicing
          adjusted = text.slice(0, limit - 3) + '...';
        }
      }

      resultCharCount.textContent = adjusted.length;
      outputAdjusted.textContent = adjusted;

      // Show Results
      adjustResultContainer.classList.remove('hidden');

      // Reset Button State
      btnAdjust.innerHTML = `
        <span>AI文字数を調整する</span>
        <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="15 3 21 3 21 9"/>
          <polyline points="9 21 3 21 3 15"/>
          <line x1="21" y1="3" x2="14" y2="10"/>
          <line x1="3" y1="21" x2="10" y2="14"/>
        </svg>
      `;
      btnAdjust.classList.remove('loading');
    }, 450); // Small processing timeout
  });

  // Copy Result
  btnCopyAdjusted.addEventListener('click', () => {
    const text = outputAdjusted.innerText || outputAdjusted.textContent;
    navigator.clipboard.writeText(text).then(triggerToast);
  });

  // Initialize view state
  updateAnalysis();
});
