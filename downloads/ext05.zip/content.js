// content.js - AI文字数調整カウンター の常設ページ内パネル
// ツールバーアイコンのクリックで表示/非表示を切り替える、ドラッグ移動できる
// 独立パネルです。ネイティブのブラウザ拡張ポップアップは、コピー先アプリに
// 切り替えた瞬間に自動で閉じてしまう仕様(拡張機能側では回避不可)のため、
// 通常のDOM要素としてページ上に直接差し込むことで解決しています。
// 影響範囲は Shadow DOM 内 + このコンテナ要素だけに限定し、閲覧中のページ
// 本体には一切手を加えません。

(function () {
  'use strict';
  if (window.__wanoExt05Injected) return;
  window.__wanoExt05Injected = true;

  var container = null;
  var shadow = null;

  chrome.runtime.onMessage.addListener(function (msg) {
    if (msg && msg.action === 'toggleWidget') {
      toggleWidget();
    }
  });

  function toggleWidget() {
    try {
      if (container) {
        removeWidget();
      } else {
        createWidget();
      }
    } catch (e) {
      console.error('[wano-ext05] toggleWidget failed:', e);
    }
  }

  function removeWidget() {
    if (container) { container.remove(); }
    container = null;
    shadow = null;
  }

  function createWidget() {
    container = document.createElement('div');
    container.id = 'wano-ext05-widget-root';
    container.style.cssText = 'position:fixed; top:20px; right:20px; z-index:2147483647; width:340px; font-size:13px;';
    document.body.appendChild(container);
    shadow = container.attachShadow({ mode: 'open' });
    shadow.innerHTML = baseTemplate();
    document.body.appendChild(container);
    wireBase();
    wireAdjustTab();
    wireReadabilityTab();
    if (window.makeDraggable) {
      window.makeDraggable(container, shadow.querySelector('#drag-handle'));
    }
    applyLicenseGate();
  }

  function $(sel) { return shadow.querySelector(sel); }
  function $all(sel) { return shadow.querySelectorAll(sel); }

  // ========================= Shell / Template =========================
  function baseTemplate() {
    return (
      '<style>' + baseCSS() + '</style>' +
      '<div class="wano-panel" id="wano-panel">' +
        '<div class="head" id="drag-handle">' +
          '<span class="head-title"><span class="dot">文</span> AI文字数調整カウンター</span>' +
          '<button class="close-btn" id="close-btn" title="閉じる">✕</button>' +
        '</div>' +
        '<div id="trial-banner-slot"></div>' +
        '<div class="tabs">' +
          '<button class="tab-btn active" data-tab="tab-adjust">文字数調整</button>' +
          '<button class="tab-btn" data-tab="tab-readability">黄金比診断</button>' +
        '</div>' +
        '<div class="tab-content active" id="tab-adjust">' +
          '<label class="field-label">文章を入力してください</label>' +
          '<div class="textarea-wrap">' +
            '<textarea id="input-text" placeholder="例：昨日の開発ミーティングですが、予定していた時間を大幅に超えてしまい申し訳ありませんでした。"></textarea>' +
            '<button class="clear-btn" id="clear-input" title="入力をクリア">✕</button>' +
          '</div>' +
          '<div class="metrics-bar">' +
            '<div class="metric-item"><span class="metric-val" id="count-total">0</span><span class="metric-lbl">文字数</span></div>' +
            '<div class="metric-item"><span class="metric-val" id="time-read">0秒</span><span class="metric-lbl">想定読了時間</span></div>' +
          '</div>' +
          '<label class="field-label">目標の制限文字数</label>' +
          '<select id="select-limit-preset" class="select-input">' +
            '<option value="140" selected>Twitter投稿 (140文字以内)</option>' +
            '<option value="32">記事タイトル (32文字以内)</option>' +
            '<option value="80">プレスリリース概要 (80文字以内)</option>' +
            '<option value="custom">カスタム文字数指定</option>' +
          '</select>' +
          '<div class="hidden" id="custom-limit-group"><label class="field-label">文字数</label><input type="number" id="input-custom-limit" min="1" max="1000" value="50"></div>' +
          '<button class="primary-btn full" id="btn-adjust"><span>文字数を調整する</span> →</button>' +
          '<p class="hint">文末（。）や読点（、）を目安に、指定文字数に収まる自然な位置で区切ります。文章の意味を書き換えるものではありません。</p>' +
          '<div class="result hidden" id="adjust-result-container">' +
            '<div class="result-head"><span>調整後の文章 (<span id="result-char-count">0</span>文字)</span></div>' +
            '<div class="output-box" id="output-adjusted"></div>' +
            '<button class="secondary-btn full" id="btn-copy-adjusted">📋 コピーする</button>' +
          '</div>' +
        '</div>' +
        '<div class="tab-content" id="tab-readability">' +
          '<label class="field-label">漢字・ひらがな・カタカナ比率</label>' +
          '<div class="ratio-bar">' +
            '<div class="seg seg-kanji" id="bar-kanji"></div>' +
            '<div class="seg seg-hiragana" id="bar-hiragana"></div>' +
            '<div class="seg seg-katakana" id="bar-katakana"></div>' +
            '<div class="seg seg-other" id="bar-other"></div>' +
          '</div>' +
          '<div class="legends">' +
            '<span><i class="dot dot-kanji"></i>漢字 <b id="lbl-kanji">0</b>%</span>' +
            '<span><i class="dot dot-hiragana"></i>ひらがな <b id="lbl-hiragana">0</b>%</span>' +
            '<span><i class="dot dot-katakana"></i>カタカナ <b id="lbl-katakana">0</b>%</span>' +
            '<span><i class="dot dot-other"></i>英数他 <b id="lbl-other">0</b>%</span>' +
          '</div>' +
          '<div class="verdict-card">' +
            '<div class="verdict-head"><span>診断結果</span><span class="verdict-badge" id="verdict-badge">判定なし</span></div>' +
            '<p class="verdict-desc" id="verdict-desc">文章を入力すると、読みやすさの比率判定が行われます。</p>' +
          '</div>' +
          '<div class="polish-card hidden" id="polish-card-container">' +
            '<label class="field-label">読みやすさ改善提案（ひらがなに開く）</label>' +
            '<div id="polish-suggestions-list"></div>' +
          '</div>' +
        '</div>' +
        '<div class="toast hidden" id="toast">コピーしました！</div>' +
      '</div>'
    );
  }

  function baseCSS() {
    return (
      ':host{all:initial;}' +
      '*{box-sizing:border-box; font-family:-apple-system,BlinkMacSystemFont,"Hiragino Sans","Yu Gothic",sans-serif;}' +
      '.wano-panel{background:#fff; border-radius:14px; box-shadow:0 12px 32px rgba(0,0,0,.2); border:1px solid #e5e7eb; overflow:hidden; color:#111827;}' +
      '.head{cursor:move; display:flex; align-items:center; justify-content:space-between; padding:10px 12px; background:linear-gradient(135deg,#f97316,#ea580c); color:#fff;}' +
      '.head-title{font-size:13px; font-weight:700; display:flex; align-items:center; gap:6px;}' +
      '.dot{background:rgba(255,255,255,.25); border-radius:50%; width:18px; height:18px; display:inline-flex; align-items:center; justify-content:center; font-size:11px;}' +
      '.close-btn{cursor:pointer; background:rgba(255,255,255,.25); border:none; color:#fff; width:22px; height:22px; border-radius:6px; font-size:13px; line-height:1;}' +
      '.close-btn:hover{background:rgba(255,255,255,.4);}' +
      '#trial-banner-slot:empty{display:none;}' +
      '.tabs{display:flex; gap:4px; padding:8px 10px 0;}' +
      '.tab-btn{flex:1; background:#f3f4f6; border:none; border-radius:8px; padding:7px 6px; font-size:11.5px; font-weight:700; color:#111827; cursor:pointer;}' +
      '.tab-btn.active{background:#ea580c22; color:#c2410c;}' +
      '.tab-content{display:none; padding:12px; max-height:70vh; overflow-y:auto;}' +
      '.tab-content.active{display:block;}' +
      '.field-label{display:block; font-size:11px; font-weight:700; color:#111827; margin:10px 0 5px;}' +
      '.field-label:first-child{margin-top:0;}' +
      '.textarea-wrap{position:relative;}' +
      'textarea{width:100%; min-height:80px; resize:vertical; border:1px solid #e5e7eb; border-radius:10px; padding:10px 28px 10px 10px; font-size:12.5px; line-height:1.6; color:#111827;}' +
      '.clear-btn{position:absolute; top:8px; right:8px; background:#f3f4f6; border:none; border-radius:50%; width:20px; height:20px; font-size:11px; cursor:pointer; color:#111827;}' +
      '.metrics-bar{display:flex; gap:10px; margin-top:10px;}' +
      '.metric-item{flex:1; background:#f9fafb; border:1px solid #e5e7eb; border-radius:8px; padding:8px; text-align:center;}' +
      '.metric-val{display:block; font-size:16px; font-weight:800; color:#c2410c;}' +
      '.metric-lbl{font-size:10.5px; color:#111827;}' +
      '.select-input{width:100%; border:1px solid #e5e7eb; border-radius:8px; padding:8px; font-size:12px; color:#111827; background:#fff;}' +
      'input[type="number"]{width:100%; border:1px solid #e5e7eb; border-radius:8px; padding:7px 8px; font-size:12px; color:#111827;}' +
      '.primary-btn{background:linear-gradient(135deg,#f97316,#ea580c); color:#fff; border:none; border-radius:10px; padding:9px 16px; font-size:12.5px; font-weight:700; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:6px;}' +
      '.primary-btn.full{width:100%; margin-top:10px;}' +
      '.secondary-btn{background:#f3f4f6; color:#111827; border:1px solid #e5e7eb; border-radius:10px; padding:8px 14px; font-size:12px; font-weight:700; cursor:pointer;}' +
      '.secondary-btn.full{width:100%; margin-top:8px;}' +
      '.hint{font-size:10.5px; color:#111827; line-height:1.5; margin:6px 0 0;}' +
      '.result{margin-top:14px; border-top:1px solid #f3f4f6; padding-top:12px;}' +
      '.result.hidden{display:none;}' +
      '.result-head{font-size:11.5px; font-weight:700; color:#111827; margin-bottom:8px;}' +
      '.output-box{background:#f9fafb; border:1px solid #e5e7eb; border-radius:10px; padding:10px; font-size:12.5px; line-height:1.7; color:#111827; white-space:pre-wrap;}' +
      '.ratio-bar{display:flex; height:14px; border-radius:999px; overflow:hidden; background:#f3f4f6; margin-bottom:8px;}' +
      '.seg-kanji{background:#ea580c;} .seg-hiragana{background:#f59e0b;} .seg-katakana{background:#0d9488;} .seg-other{background:#9ca3af;}' +
      '.legends{display:flex; flex-wrap:wrap; gap:10px; font-size:11px; color:#111827; margin-bottom:12px;}' +
      '.dot{display:inline-block; width:8px; height:8px; border-radius:50%; margin-right:4px;}' +
      '.dot-kanji{background:#ea580c;} .dot-hiragana{background:#f59e0b;} .dot-katakana{background:#0d9488;} .dot-other{background:#9ca3af;}' +
      '.verdict-card{background:#f9fafb; border:1px solid #e5e7eb; border-radius:10px; padding:10px; margin-bottom:10px;}' +
      '.verdict-head{display:flex; justify-content:space-between; align-items:center; font-size:11.5px; font-weight:700; margin-bottom:4px;}' +
      '.verdict-badge{background:#ea580c22; color:#c2410c; font-size:10.5px; font-weight:700; padding:2px 8px; border-radius:999px;}' +
      '.verdict-desc{font-size:11.5px; color:#111827; line-height:1.6; margin:0;}' +
      '.polish-card.hidden{display:none;}' +
      '.polish-item{border:1px solid #e5e7eb; border-radius:8px; padding:8px 10px; margin-bottom:6px; font-size:11.5px;}' +
      '.polish-compare{display:flex; align-items:center; gap:6px; margin-bottom:3px;}' +
      '.polish-orig{color:#e11d48; text-decoration:line-through;}' +
      '.polish-dest{color:#0f9d78; font-weight:700;}' +
      '.polish-desc{color:#111827; line-height:1.5;}' +
      '.toast{position:absolute; bottom:10px; left:50%; transform:translateX(-50%); background:#111827; color:#fff; font-size:11px; padding:6px 14px; border-radius:999px;}' +
      '.toast.hidden{display:none;}' +
      '.hidden{display:none;}' +
      '.lock-screen{padding:24px 18px; text-align:center; background:linear-gradient(135deg,#0f172a,#1e1b4b); color:#f8fafc;}' +
      '.lock-screen h3{font-size:14px; color:#f59e0b; margin:0 0 8px;}' +
      '.lock-screen p{font-size:11.5px; color:#94a3b8; line-height:1.6; margin:0 0 14px;}' +
      '.lock-screen button{background:#d97706; color:#fff; border:none; border-radius:8px; padding:9px 16px; font-size:12px; font-weight:600; cursor:pointer;}'
    );
  }

  function wireBase() {
    $('#close-btn').addEventListener('click', removeWidget);
    $all('.tab-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        $all('.tab-btn').forEach(function (b) { b.classList.remove('active'); });
        $all('.tab-content').forEach(function (c) { c.classList.remove('active'); });
        btn.classList.add('active');
        $('#' + btn.dataset.tab).classList.add('active');
      });
    });
  }

  function triggerToast() {
    var toast = $('#toast');
    toast.classList.remove('hidden');
    setTimeout(function () { toast.classList.add('hidden'); }, 2000);
  }

  // ========================= Tab 1: 文字数調整 =========================
  // 文末（。！？）や読点（、）の位置を尊重して、できるだけ自然な場所で
  // 文章を区切る。内容の言い換え・要約は行わない（単なる賢いトリミング）。
  function smartTrim(text, limit) {
    if (text.length <= limit) return text;
    var sentenceEnd = /[。！？]/;
    var commaEnd = /[、,]/;
    var searchLimit = Math.min(limit, text.length);
    var minAcceptable = Math.floor(limit * 0.4);

    var cutAt = -1;
    for (var i = searchLimit - 1; i >= 0; i--) {
      if (sentenceEnd.test(text[i])) { cutAt = i + 1; break; }
    }
    if (cutAt === -1 || cutAt < minAcceptable) {
      for (var j = searchLimit - 1; j >= 0; j--) {
        if (commaEnd.test(text[j])) { cutAt = j + 1; break; }
      }
    }
    if (cutAt === -1 || cutAt < minAcceptable) {
      return text.slice(0, Math.max(0, limit - 1)) + '…';
    }
    var cut = text.slice(0, cutAt);
    return sentenceEnd.test(cut[cut.length - 1]) ? cut : cut + '…';
  }

  function wireAdjustTab() {
    var inputText = $('#input-text');
    var clearBtn = $('#clear-input');
    var countTotal = $('#count-total');
    var timeRead = $('#time-read');
    var selectPreset = $('#select-limit-preset');
    var customGroup = $('#custom-limit-group');
    var customLimit = $('#input-custom-limit');
    var btnAdjust = $('#btn-adjust');
    var resultContainer = $('#adjust-result-container');
    var resultCharCount = $('#result-char-count');
    var outputAdjusted = $('#output-adjusted');
    var btnCopy = $('#btn-copy-adjusted');

    var updateMetrics = function () {
      var len = inputText.value.length;
      countTotal.textContent = len;
      if (len === 0) timeRead.textContent = '0秒';
      else if (len < 500) timeRead.textContent = Math.ceil(len / 8.3) + '秒';
      else timeRead.textContent = Math.ceil(len / 500) + '分';
    };

    inputText.addEventListener('input', function () { updateMetrics(); updateReadabilityIfActive(); });
    selectPreset.addEventListener('change', function () {
      customGroup.classList.toggle('hidden', selectPreset.value !== 'custom');
    });
    clearBtn.addEventListener('click', function () {
      inputText.value = '';
      resultContainer.classList.add('hidden');
      updateMetrics();
      updateReadabilityIfActive();
    });

    btnAdjust.addEventListener('click', function () {
      var text = inputText.value.trim();
      if (!text) return;
      var limit = selectPreset.value === 'custom' ? (parseInt(customLimit.value, 10) || 50) : parseInt(selectPreset.value, 10);
      var adjusted = smartTrim(text, limit);
      resultCharCount.textContent = adjusted.length;
      outputAdjusted.textContent = adjusted;
      resultContainer.classList.remove('hidden');
    });

    btnCopy.addEventListener('click', function () {
      navigator.clipboard.writeText(outputAdjusted.textContent || '').then(triggerToast);
    });

    updateMetrics();
  }

  // ========================= Tab 2: 黄金比診断 =========================
  var wordingRules = [
    { word: '頂く', dest: 'いただく', desc: '〜していただく等、動詞に添える補助動詞はひらがな表記にするのが一般的です。' },
    { word: '致す', dest: 'いたす', desc: '「〜いたします」などの補助動詞は、ひらがなにすると文章が柔らかくなります。' },
    { word: '出来る', dest: 'できる', desc: '「〜することができる」の「できる」は、ひらがな表記がビジネス公用文のルールです。' },
    { word: '事', dest: 'こと', desc: '「〜すること」といった形式名詞は、ひらがな表記にするのが基本です。' },
    { word: '為', dest: 'ため', desc: '「〜のため」という接続詞・形式名詞は、ひらがなで書くほうが読みやすいです。' },
    { word: '様', dest: 'よう', desc: '「〜のように」などの比況・形式名詞は、ひらがなでの表記が推奨されます。' },
    { word: '有難う', dest: 'ありがとう', desc: '「有難うございます」は堅苦しすぎるため、ひらがなに開きます。' },
    { word: '何時も', dest: 'いつも', desc: '常用外漢字であるため、ひらがなで表記しましょう。' }
  ];

  function updateReadability() {
    var text = $('#input-text').value;
    var len = text.length;
    var barKanji = $('#bar-kanji'), barHiragana = $('#bar-hiragana'), barKatakana = $('#bar-katakana'), barOther = $('#bar-other');
    var lblKanji = $('#lbl-kanji'), lblHiragana = $('#lbl-hiragana'), lblKatakana = $('#lbl-katakana'), lblOther = $('#lbl-other');
    var verdictBadge = $('#verdict-badge'), verdictDesc = $('#verdict-desc');
    var polishContainer = $('#polish-card-container'), polishList = $('#polish-suggestions-list');

    if (len === 0) {
      [barKanji, barHiragana, barKatakana, barOther].forEach(function (b) { b.style.width = '0%'; });
      [lblKanji, lblHiragana, lblKatakana, lblOther].forEach(function (l) { l.textContent = '0'; });
      verdictBadge.textContent = '判定なし';
      verdictDesc.textContent = '文章を入力すると、読みやすさの比率判定が行われます。';
      polishContainer.classList.add('hidden');
      return;
    }

    var kanjiCount = (text.match(/[一-龯㐀-䶿]/g) || []).length;
    var hiraganaCount = (text.match(/[぀-ゟ]/g) || []).length;
    var katakanaCount = (text.match(/[゠-ヿ]/g) || []).length;

    var pctKanji = Math.round((kanjiCount / len) * 100);
    var pctHiragana = Math.round((hiraganaCount / len) * 100);
    var pctKatakana = Math.round((katakanaCount / len) * 100);
    var pctOther = 100 - pctKanji - pctHiragana - pctKatakana;

    barKanji.style.width = pctKanji + '%';
    barHiragana.style.width = pctHiragana + '%';
    barKatakana.style.width = pctKatakana + '%';
    barOther.style.width = pctOther + '%';
    lblKanji.textContent = pctKanji;
    lblHiragana.textContent = pctHiragana;
    lblKatakana.textContent = pctKatakana;
    lblOther.textContent = pctOther;

    if (pctKanji > 40) {
      verdictBadge.textContent = '漢字過多';
      verdictDesc.textContent = '漢字の比率が40%を超えており、文章が堅苦しく読みづらくなっています。補助動詞や形式名詞（「こと」「ため」など）を「ひらがな」に直すことで、親しみやすく読みやすい文章になります。';
    } else if (pctKatakana > 25) {
      verdictBadge.textContent = 'カタカナ過多';
      verdictDesc.textContent = 'カタカナ（外来語・ビジネスIT用語）が多く含まれています。乱用は読み手を疲れさせるため、可能であれば日本語の表現に直すことを検討してください。';
    } else if (pctKanji < 20 && len > 30) {
      verdictBadge.textContent = 'ひらがな過多';
      verdictDesc.textContent = 'ひらがなの比率が多く、文章が少し幼稚に見えてしまう可能性があります。名詞や動詞を適度に漢字に変えるか、句読点の位置を整えてみてください。';
    } else {
      verdictBadge.textContent = '黄金比率達成！';
      verdictDesc.textContent = '漢字・ひらがな・カタカナのバランスが非常に良く、読み手の目に優しい理想的な黄金比率（漢字30%：ひらがな40%：カタカナ30%）に近いクリーンな文章です！';
    }

    polishList.innerHTML = '';
    var found = 0;
    wordingRules.forEach(function (rule) {
      if (text.includes(rule.word)) {
        found++;
        var item = document.createElement('div');
        item.className = 'polish-item';
        item.innerHTML = '<div class="polish-compare"><span class="polish-orig">' + rule.word + '</span><span>➔</span><span class="polish-dest">' + rule.dest + '</span></div><div class="polish-desc">' + rule.desc + '</div>';
        polishList.appendChild(item);
      }
    });
    polishContainer.classList.toggle('hidden', found === 0);
  }

  function updateReadabilityIfActive() {
    // 常に裏で計算しておく（タブを切り替えた瞬間に古い結果が見えないように）
    updateReadability();
  }

  function wireReadabilityTab() {
    updateReadability();
  }

  // ========================= ライセンス / トライアル =========================
  function applyLicenseGate() {
    if (typeof LicenseManager === 'undefined') return;
    LicenseManager.checkStatus().then(function (status) {
      if (!shadow) return;
      if (status.status === 'expired') {
        lockPanel();
      } else if (status.status === 'trial') {
        showTrialBanner(status.daysLeft);
      }
    });
  }

  function lockPanel() {
    var panel = $('#wano-panel');
    var head = panel.querySelector('.head');
    Array.prototype.forEach.call(panel.children, function (child) {
      if (child !== head) child.remove();
    });
    var lock = document.createElement('div');
    lock.className = 'lock-screen';
    lock.innerHTML =
      '<h3>🔒 無料体験期間が終了しました</h3>' +
      '<p>この機能を引き続きご利用いただくには、ライセンスキーの入力、またはメールアドレスの登録（無料期間の延長）が必要です。</p>' +
      '<button id="open-license-btn">ライセンスを設定する</button>';
    panel.appendChild(lock);
    lock.querySelector('#open-license-btn').addEventListener('click', function () {
      chrome.runtime.sendMessage({ action: 'openOptionsPage' });
    });
  }

  function showTrialBanner(daysLeft) {
    var slot = $('#trial-banner-slot');
    slot.innerHTML =
      '<div style="background:#1e293b;color:#94a3b8;padding:6px 12px;font-size:11px;display:flex;justify-content:space-between;align-items:center;">' +
        '<span>無料体験中（残り ' + daysLeft + ' 日）</span>' +
        '<a href="#" id="upgrade-link" style="color:#f59e0b;text-decoration:none;font-weight:700;">プロ版へ有効化 ➔</a>' +
      '</div>';
    slot.querySelector('#upgrade-link').addEventListener('click', function (e) {
      e.preventDefault();
      chrome.runtime.sendMessage({ action: 'openOptionsPage' });
    });
  }
})();
