



// --- Japanese AI Meeting Minutes Assistant JS ---

// --- 1. Facade-to-Truth Dictionary Data ---
const DICTIONARY = [
  {
    phrase: "前向きに検討します",
    type: "回答・返答",
    honne: "現時点では保留、または見送る可能性が高い",
    action: "社交辞令の可能性が高いため、具体的な検討期日や判断基準を投げかけましょう。"
  },
  {
    phrase: "検討させていただきます",
    type: "回答・返答",
    honne: "やんわりとお断りする（何もしない）",
    action: "「いつまでに」「何を」決めるかを合意するか、断られた前提で別プランを用意します。"
  },
  {
    phrase: "持ち帰って相談します",
    type: "合意・拒絶",
    honne: "その場での決定を避けて社内で却下したい / 時間稼ぎ",
    action: "「いつ頃回答をいただけるか」の回答期限をその場で約束し、保留を防ぎます。"
  },
  {
    phrase: "リソース的な兼ね合い",
    type: "理由・言い訳",
    honne: "人員不足、または予算不足で優先度が極めて低い",
    action: "「稼働が空く予定の時期」を確認するか、作業スコープを絞ったミニマムプランを再提案します。"
  },
  {
    phrase: "ちょっと今は立て込んでおりまして",
    type: "理由・言い訳",
    honne: "優先順位が低いため、後回しにしたい",
    action: "「来月中旬頃であればお時間ありますでしょうか？」など、時期をずらして再打診します。"
  },
  {
    phrase: "様子を見させていただければ",
    type: "合意・拒絶",
    honne: "実施する意思が薄い（実質的な却下・見送り）",
    action: "「様子を見る」期間を区切り、例えば「来月末の状況を見て再相談」など期限を設けます。"
  },
  {
    phrase: "タイミングを見て行いたい",
    type: "スケジュール",
    honne: "時期未定（現時点ではやる気がない）",
    action: "「タイミング」を具体的に定義（例：四半期決算の後など）し、スケジュールを合意します。"
  },
  {
    phrase: "ご意見を参考にさせていただきます",
    type: "回答・返答",
    honne: "その意見や提案は採用しない（聞き流す）",
    action: "単なる意見ではなく、数値データや競合調査結果など「採用せざるを得ない根拠」を持って再度交渉します。"
  },
  {
    phrase: "なるべく善処します",
    type: "回答・返答",
    honne: "期待しないでほしい（努力はするが結果は保証しない）",
    action: "善処の具体的な内容（アクションプラン）を確認し、最低限の目標（デッドライン）を取り決めます。"
  },
  {
    phrase: "基本的には賛成ですが",
    type: "合意・拒絶",
    honne: "細かい条件や前提に反対、あるいは重大な懸念点がある",
    action: "「基本的には」以外の『懸念されている具体的な点』について聞き出し、先回りで解消します。"
  },
  {
    phrase: "認識の相違がありました",
    type: "トラブル",
    honne: "あなたの勘違い（またはこちらのミスだが有耶無耶にしたい）",
    action: "言った言わないを防ぐため、要点と認識が合致した内容を必ずテキスト（メール等）で再確認します。"
  },
  {
    phrase: "諸般の事情により",
    type: "理由・言い訳",
    honne: "社内政治、予算不足など、明かしたくない不都合がある",
    action: "ネックになっているのは予算なのか、上司の意向なのか、外部要因なのかを個別に探ります。"
  },
  {
    phrase: "軽く頭出しするくらいでいい",
    type: "スケジュール",
    honne: "正式な検討や提案は不要（重要視していない）",
    action: "簡易な情報共有に留まるため、次回いつ本格審議にかけるのか次のステップを握ります。"
  },
  {
    phrase: "一度ペンディングに",
    type: "回答・返答",
    honne: "事実上の白紙化・中止",
    action: "保留になった要因を整理し、再度案件を掘り起こすための再開条件を確認しておきます。"
  },
  {
    phrase: "基本線としては問題ない",
    type: "回答・返答",
    honne: "修正すべき細かい問題が山積している",
    action: "「基本線」以外のクリアすべき詳細なチェックリストをもらい、素早く修正対応をします。"
  },
  {
    phrase: "こちらで調整しておきます",
    type: "合意・拒絶",
    honne: "自分で勝手にやるから口を挟まないでほしい",
    action: "主導権を渡すことになります。進捗共有のタイミング（いつ報告を受けるか）だけ握ります。"
  },
  {
    phrase: "お忙しそうなのでまた改めて",
    type: "回答・返答",
    honne: "話す時間を作りたくない（断り文句）",
    action: "「明日の〇時頃に1分だけお時間を」と超短時間のアポで切り崩します。"
  },
  {
    phrase: "今後の課題ですね",
    type: "合意・拒絶",
    honne: "今やるつもりはない（お蔵入り）",
    action: "重要だが緊急度が低いフォルダに入れられるため、今やるべき小さな第一歩を提案します。"
  }
];

// --- 2. Demo Meeting Conversation Script ---
const DEMO_CONVERSATION = [
  { speaker: "A", name: "鈴木課長", text: "お疲れ様です、田中部長。例の「新規オンラインキャンペーン企画」の件ですが、進捗いかがでしょうか？", delay: 1200 },
  { speaker: "B", name: "田中部長", text: "ああ、鈴木くん。その企画ね。内容は見させてもらったよ。基本的には前向きに社内で検討したいと考えてるんだよね。", delay: 2800 },
  { speaker: "A", name: "鈴木課長", text: "ありがとうございます！前向きに、ということは今クォーター中にテスト配信などをスタートできますでしょうか？", delay: 2000 },
  { speaker: "B", name: "田中部長", text: "うーん、前向きに検討はしているんだけどね、ちょっと今は社内の他プロジェクトとのリソース的な兼ね合いというか、今期はいろいろと立て込んでおりましてね。", delay: 3500 },
  { speaker: "A", name: "鈴木課長", text: "なるほど、人員の調整や稼働率が厳しいという感じでしょうか。", delay: 1800 },
  { speaker: "B", name: "田中部長", text: "そうだね。だから、決してやらないというわけではないんだけど、少し様子を見させていただければなと。上層部の合意を取るのもタイミングを見て行いたいと思っているんだ。", delay: 3500 },
  { speaker: "A", name: "鈴木課長", text: "そういうことですね。私の方でも追加のデータを集めてご説明に伺うことも可能ですが、どういたしましょうか。", delay: 2500 },
  { speaker: "B", name: "田中部長", text: "そうだねえ。鈴木くんの熱意はありがたいんだけど、焦って資料を作るのもアレだし、まずは次の定例会議のあたりで、アジェンダの一つとして軽く頭出しするくらいでいいんじゃないかな。", delay: 3800 },
  { speaker: "A", name: "鈴木課長", text: "承知いたしました。では、次回定例でアジェンダ共有だけ行い、企画自体は一旦保留ということで進めます。", delay: 2500 },
  { speaker: "B", name: "田中部長", text: "うん、それで頼むよ。お手数をおかけするけれど、いただいたご意見は参考にさせていただきつつ、タイミングを見て再度ご相談させてください。", delay: 3200 }
];

document.addEventListener("DOMContentLoaded", () => {
  // Elements
  const themeToggle = document.getElementById("theme-toggle");
  const tabs = document.querySelectorAll(".nav-tab");
  const tabContents = document.querySelectorAll(".tab-content");
  
  const btnRecord = document.getElementById("btn-record");
  const btnDemo = document.getElementById("btn-demo");
  const btnReset = document.getElementById("btn-reset");
  const btnAnalyze = document.getElementById("btn-analyze");
  
  const voiceWaveContainer = document.getElementById("voice-wave-container");
  const voiceWaveStatus = document.getElementById("voice-wave-status");
  const speakerBtns = document.querySelectorAll(".speaker-btn");
  
  const transcriptLog = document.getElementById("transcript-log");
  const logEmptyState = document.getElementById("log-empty-state");
  const transcriptCount = document.getElementById("transcript-count");
  
  const analysisResultCard = document.getElementById("analysis-result-card");
  const resTabs = document.querySelectorAll(".res-tab");
  const resTabContents = document.querySelectorAll(".res-tab-content");
  const outputMinutes = document.getElementById("output-minutes");
  const translationTableBody = document.getElementById("translation-table-body");
  const translationEmptyState = document.getElementById("translation-empty-state");
  
  const btnSaveMinutes = document.getElementById("btn-save-minutes");
  const btnCopyMinutes = document.getElementById("btn-copy-minutes");
  
  const historyList = document.getElementById("history-list");
  const historyPreviewCard = document.getElementById("history-preview-card");
  const historyPreviewTitle = document.getElementById("history-preview-title");
  const historyPreviewText = document.getElementById("history-preview-text");
  const btnClosePreview = document.getElementById("btn-close-preview");
  const btnDeleteHistory = document.getElementById("btn-delete-history");
  const btnCopyHistory = document.getElementById("btn-copy-history");
  
  const dictSearch = document.getElementById("dict-search");
  const dictionaryList = document.getElementById("dictionary-list");
  
  const toast = document.getElementById("toast");

  // State Variables
  let isRecording = false;
  let isDemoPlaying = false;
  let currentSpeaker = "A"; // "A" or "B"
  let conversationData = []; // Array of { speaker, name, text, timestamp }
  let recognition = null;
  let demoTimer = null;
  let activeHistoryId = null;

  // --- 3. Theme Init ---
  const activeTheme = localStorage.getItem("theme") || "dark";
  if (activeTheme === "light") {
    document.body.classList.remove("dark-theme");
    document.body.classList.add("light-theme");
    themeToggle.querySelector(".sun-icon").style.display = "none";
    themeToggle.querySelector(".moon-icon").style.display = "block";
  } else {
    document.body.classList.remove("light-theme");
    document.body.classList.add("dark-theme");
    themeToggle.querySelector(".sun-icon").style.display = "block";
    themeToggle.querySelector(".moon-icon").style.display = "none";
  }

  themeToggle.addEventListener("click", () => {
    if (document.body.classList.contains("dark-theme")) {
      document.body.classList.remove("dark-theme");
      document.body.classList.add("light-theme");
      themeToggle.querySelector(".sun-icon").style.display = "none";
      themeToggle.querySelector(".moon-icon").style.display = "block";
      localStorage.setItem("theme", "light");
    } else {
      document.body.classList.remove("light-theme");
      document.body.classList.add("dark-theme");
      themeToggle.querySelector(".sun-icon").style.display = "block";
      themeToggle.querySelector(".moon-icon").style.display = "none";
      localStorage.setItem("theme", "dark");
    }
  });

  // --- 4. Navigation Tab Switcher ---
  tabs.forEach(tab => {
    tab.addEventListener("click", () => {
      tabs.forEach(t => t.classList.remove("active"));
      tabContents.forEach(tc => tc.classList.remove("active"));

      tab.classList.add("active");
      const targetTab = tab.getAttribute("data-tab");
      document.getElementById(targetTab).classList.add("active");
      
      if (targetTab === "tab-history") {
        renderHistory();
      }
    });
  });

  // Result Sub-tabs (Minutes vs Translation)
  resTabs.forEach(tab => {
    tab.addEventListener("click", () => {
      resTabs.forEach(t => t.classList.remove("active"));
      resTabContents.forEach(rtc => rtc.classList.remove("active"));
      
      tab.classList.add("active");
      const targetResTab = tab.getAttribute("data-res-tab");
      document.getElementById(targetResTab).classList.add("active");
    });
  });

  // --- 5. Speaker Selection Toggle ---
  speakerBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      speakerBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      currentSpeaker = btn.getAttribute("data-speaker");
    });
  });

  // --- 6. Voice Recognition Setup (Web Speech API) ---
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    console.warn("Web Speech API is not supported in this browser.");
    voiceWaveStatus.textContent = "音声認識非対応ブラウザです";
  } else {
    recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = false;
    recognition.lang = "ja-JP";

    recognition.onstart = () => {
      isRecording = true;
      btnRecord.classList.add("recording");
      btnRecord.querySelector("#record-btn-text").textContent = "文字起こし停止";
      voiceWaveContainer.classList.remove("hidden");
      voiceWaveStatus.textContent = "音声を入力中...";
      btnDemo.disabled = true;
      btnReset.disabled = false;
    };

    recognition.onresult = (event) => {
      const resultText = event.results[event.results.length - 1][0].transcript.trim();
      if (resultText) {
        const name = currentSpeaker === "A" ? "話者A" : "話者B (自分)";
        addTranscriptBubble(currentSpeaker, name, resultText);
      }
    };

    recognition.onerror = (event) => {
      console.error("Speech recognition error", event.error);
      if (event.error === "not-allowed") {
        showToast("マイクの使用許可が必要です。");
        stopRecording();
      }
    };

    recognition.onend = () => {
      // Auto-restart if we are still supposed to record
      if (isRecording) {
        recognition.start();
      } else {
        stopRecordingState();
      }
    };
  }

  function startRecording() {
    if (!recognition) {
      showToast("マイク機能がサポートされていません。");
      return;
    }
    // Clean up analysis result from previous sessions
    analysisResultCard.classList.add("hidden");
    logEmptyState.classList.add("hidden");
    
    recognition.start();
  }

  function stopRecording() {
    isRecording = false;
    if (recognition) {
      recognition.stop();
    }
    stopRecordingState();
  }

  function stopRecordingState() {
    btnRecord.classList.remove("recording");
    btnRecord.querySelector("#record-btn-text").textContent = "文字起こし開始";
    voiceWaveContainer.classList.add("hidden");
    btnDemo.disabled = false;
  }

  btnRecord.addEventListener("click", () => {
    if (isDemoPlaying) {
      stopDemo();
    }
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  });

  // --- 7. Demo Playback Logic ---
  function playDemo() {
    if (isRecording) {
      stopRecording();
    }
    
    // Reset conversation log for fresh demo
    resetConversation();
    analysisResultCard.classList.add("hidden");
    logEmptyState.classList.add("hidden");
    
    isDemoPlaying = true;
    btnDemo.classList.add("recording");
    btnDemo.querySelector("span").textContent = "デモ停止";
    btnRecord.disabled = true;
    btnReset.disabled = false;
    
    let currentIndex = 0;
    
    function playNext() {
      if (currentIndex >= DEMO_CONVERSATION.length) {
        stopDemo();
        showToast("デモ再生が完了しました。AI分析をお試しください！");
        return;
      }
      
      const step = DEMO_CONVERSATION[currentIndex];
      // Switch current speaker state automatically for visuals
      currentSpeaker = step.speaker;
      speakerBtns.forEach(b => {
        b.classList.toggle("active", b.getAttribute("data-speaker") === currentSpeaker);
      });
      
      addTranscriptBubble(step.speaker, step.name, step.text);
      
      currentIndex++;
      demoTimer = setTimeout(playNext, step.delay);
    }
    
    demoTimer = setTimeout(playNext, 500);
  }

  function stopDemo() {
    isDemoPlaying = false;
    clearTimeout(demoTimer);
    btnDemo.classList.remove("recording");
    btnDemo.querySelector("span").textContent = "デモ再生";
    btnRecord.disabled = false;
  }

  btnDemo.addEventListener("click", () => {
    if (isDemoPlaying) {
      stopDemo();
    } else {
      playDemo();
    }
  });

  // --- 8. Append Speech Bubbles ---
  function addTranscriptBubble(speaker, name, text) {
    if (logEmptyState) {
      logEmptyState.classList.add("hidden");
    }
    
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    
    const bubbleWrapper = document.createElement("div");
    bubbleWrapper.className = `speech-bubble-wrapper speaker-${speaker.toLowerCase()}`;
    
    const speechInfo = document.createElement("div");
    speechInfo.className = "speech-info";
    speechInfo.innerHTML = `<span>${name}</span><span>${time}</span>`;
    
    const speechBubble = document.createElement("div");
    speechBubble.className = "speech-bubble";
    speechBubble.textContent = text;
    
    bubbleWrapper.appendChild(speechInfo);
    bubbleWrapper.appendChild(speechBubble);
    transcriptLog.appendChild(bubbleWrapper);
    
    // Scroll to bottom
    transcriptLog.scrollTop = transcriptLog.scrollHeight;
    
    // Save to memory
    conversationData.push({ speaker, name, text, timestamp: time });
    
    // Update count
    transcriptCount.textContent = `${conversationData.length} 行のテキスト`;
    
    // Enable Analyze button
    if (conversationData.length > 0) {
      btnAnalyze.disabled = false;
    }
  }

  // --- 9. Reset Conversation ---
  function resetConversation() {
    conversationData = [];
    transcriptLog.innerHTML = "";
    transcriptLog.appendChild(logEmptyState);
    logEmptyState.classList.remove("hidden");
    transcriptCount.textContent = "0 行のテキスト";
    btnAnalyze.disabled = true;
    btnReset.disabled = true;
    analysisResultCard.classList.add("hidden");
  }

  btnReset.addEventListener("click", () => {
    if (isDemoPlaying) stopDemo();
    if (isRecording) stopRecording();
    resetConversation();
  });

  // --- 10. AI Ambiguity Analysis Engine & Minutes Summary ---
  btnAnalyze.addEventListener("click", () => {
    if (conversationData.length === 0) return;
    
    if (isRecording) stopRecording();
    if (isDemoPlaying) stopDemo();
    
    // 10a. Scan Tatemae phrases
    const detectedTatemae = [];
    const fullConversationText = conversationData.map(c => c.text).join(" ");
    
    DICTIONARY.forEach(dict => {
      // Simple exact match check
      if (fullConversationText.includes(dict.phrase)) {
        detectedTatemae.push(dict);
      }
    });

    // Populate Translation Table
    translationTableBody.innerHTML = "";
    if (detectedTatemae.length > 0) {
      translationEmptyState.classList.add("hidden");
      detectedTatemae.forEach(item => {
        const row = document.createElement("tr");
        row.innerHTML = `
          <td>「${item.phrase}」</td>
          <td>${item.honne}</td>
        `;
        translationTableBody.appendChild(row);
      });
    } else {
      translationEmptyState.classList.remove("hidden");
    }

    // 10b. Generate Markdown Minutes
    const dateStr = new Date().toLocaleDateString("ja-JP");
    
    // Title estimation based on conversation text
    let title = "Web会議要約議事録";
    if (fullConversationText.includes("キャンペーン")) {
      title = "新規オンラインキャンペーン企画進捗会議";
    } else if (fullConversationText.includes("不具合") || fullConversationText.includes("バグ")) {
      title = "システム不具合緊急対応会議";
    } else if (fullConversationText.includes("お詫び") || fullConversationText.includes("クレーム")) {
      title = "顧客トラブルお詫び対応会議";
    } else if (fullConversationText.includes("アジェンダ") || fullConversationText.includes("進捗")) {
      title = "プロジェクト進捗定例会議";
    }

    // Extract Attendees
    const attendeeSet = new Set(conversationData.map(c => c.name));
    const attendees = Array.from(attendeeSet).join("、");

    // Dynamic Decisions & Actions extraction
    let decisions = [];
    let actions = [];

    // Demo specific high-fidelity outputs
    const isDemoConversation = conversationData.some(c => c.text.includes("新規オンラインキャンペーン企画"));
    if (isDemoConversation) {
      decisions = [
        "オンラインキャンペーン企画は今期（今クォーター）の実施を見送り、一旦保留（ペンディング）とする。",
        "追加企画書の作成は焦って行わず、不要とする。"
      ];
      actions = [
        "[ ] 次回定例会議にて、本企画のアジェンダの頭出し・簡易共有を行う（鈴木課長）",
        "[ ] 状況を見て、上層部への相談タイミングを再検討する（田中部長）"
      ];
    } else {
      // General heuristic analysis
      // Decisions: find sentences with confirmation words or conclusive actions
      conversationData.forEach(c => {
        if (c.text.includes("決定") || c.text.includes("進めます") || c.text.includes("でお願いします") || c.text.includes("賛成") || c.text.includes("保留")) {
          // clean it up
          let cleanText = c.text;
          if (cleanText.length > 50) cleanText = cleanText.substring(0, 50) + "...";
          decisions.push(cleanText);
        }
        if (c.text.includes("します") || c.text.includes("頼む") || c.text.includes("データ") || c.text.includes("連絡") || c.text.includes("確認")) {
          let cleanText = c.text;
          if (cleanText.length > 50) cleanText = cleanText.substring(0, 50) + "...";
          actions.push(`[ ] ${cleanText} (${c.name})`);
        }
      });

      // Default values if nothing found
      if (decisions.length === 0) decisions.push("保留事項の継続調査");
      if (actions.length === 0) actions.push("[ ] 本日会議事項のまとめメール送信");
    }

    let markdown = `# 【議事録】${title}\n\n`;
    markdown += `**日時:** ${dateStr} (作成日)\n`;
    markdown += `**出席者:** ${attendees}\n\n`;
    markdown += `## 1. 会議の決定事項\n`;
    decisions.forEach(d => {
      markdown += `- ${d}\n`;
    });
    markdown += `\n`;
    
    if (detectedTatemae.length > 0) {
      markdown += `## 2. AI検出した曖昧語・本音の整理\n`;
      detectedTatemae.forEach(item => {
        markdown += `- **発言**: 「${item.phrase}」\n  - **本音**: ${item.honne}\n  - **推奨対応**: ${item.action}\n`;
      });
      markdown += `\n`;
    }

    markdown += `## 3. 次アクション (To-Do)\n`;
    actions.forEach(a => {
      markdown += `- ${a}\n`;
    });
    markdown += `\n`;
    markdown += `--------------------\n`;
    markdown += `*Generated by 日本語AI議事録アシスト*`;

    // Output markdown
    outputMinutes.value = markdown;
    
    // Show results card
    analysisResultCard.classList.remove("hidden");
    analysisResultCard.scrollIntoView({ behavior: "smooth" });
  });

  // --- 11. Clipboard Copies & Toast Helpers ---
  btnCopyMinutes.addEventListener("click", () => {
    navigator.clipboard.writeText(outputMinutes.value)
      .then(() => showToast("議事録(Markdown)をコピーしました！"))
      .catch(err => console.error("Copy failed", err));
  });

  function showToast(message) {
    toast.textContent = message;
    toast.classList.remove("hidden");
    setTimeout(() => {
      toast.classList.add("hidden");
    }, 2000);
  }

  // --- 12. History Storage Logic ---
  btnSaveMinutes.addEventListener("click", () => {
    const text = outputMinutes.value.trim();
    if (!text) return;
    
    // Parse title from Markdown
    const titleMatch = text.match(/# 【議事録】(.*)/);
    const title = titleMatch ? titleMatch[1] : "無題の議事録";
    const dateStr = new Date().toLocaleDateString("ja-JP");
    const id = "min_" + Date.now();
    
    const newItem = { id, title, date: dateStr, text };
    
    const history = JSON.parse(localStorage.getItem("minutes_history") || "[]");
    history.unshift(newItem); // add to top
    localStorage.setItem("minutes_history", JSON.stringify(history));
    
    showToast("履歴に議事録を保存しました。");
  });

  function renderHistory() {
    const history = JSON.parse(localStorage.getItem("minutes_history") || "[]");
    historyList.innerHTML = "";
    
    if (history.length === 0) {
      historyList.innerHTML = `
        <div class="empty-state">
          <p>保存された議事録がありません。</p>
        </div>
      `;
      return;
    }

    history.forEach(item => {
      const historyItem = document.createElement("div");
      historyItem.className = "history-item";
      historyItem.dataset.id = item.id;
      
      historyItem.innerHTML = `
        <div class="history-details">
          <span class="history-title">${item.title}</span>
          <span class="history-meta">${item.date}</span>
        </div>
        <span class="history-chevron">→</span>
      `;
      
      historyItem.addEventListener("click", () => {
        openHistoryPreview(item);
      });
      
      historyList.appendChild(historyItem);
    });
  }

  function openHistoryPreview(item) {
    activeHistoryId = item.id;
    historyPreviewTitle.textContent = item.title;
    historyPreviewText.value = item.text;
    historyPreviewCard.classList.remove("hidden");
    historyPreviewCard.scrollIntoView({ behavior: "smooth" });
  }

  btnClosePreview.addEventListener("click", () => {
    historyPreviewCard.classList.add("hidden");
    activeHistoryId = null;
  });

  btnCopyHistory.addEventListener("click", () => {
    if (!historyPreviewText.value) return;
    navigator.clipboard.writeText(historyPreviewText.value)
      .then(() => showToast("議事録をコピーしました！"))
      .catch(err => console.error("Copy failed", err));
  });

  btnDeleteHistory.addEventListener("click", () => {
    if (!activeHistoryId) return;
    
    let history = JSON.parse(localStorage.getItem("minutes_history") || "[]");
    history = history.filter(item => item.id !== activeHistoryId);
    localStorage.setItem("minutes_history", JSON.stringify(history));
    
    historyPreviewCard.classList.add("hidden");
    activeHistoryId = null;
    renderHistory();
    showToast("議事録を削除しました。");
  });

  // --- 13. Dictionary Tab Rendering & Search ---
  function renderDictionary(filter = "") {
    dictionaryList.innerHTML = "";
    const cleanFilter = filter.trim().toLowerCase();
    
    const filtered = DICTIONARY.filter(item => {
      return item.phrase.toLowerCase().includes(cleanFilter) ||
             item.honne.toLowerCase().includes(cleanFilter) ||
             item.action.toLowerCase().includes(cleanFilter);
    });

    if (filtered.length === 0) {
      dictionaryList.innerHTML = `
        <div class="empty-state">
          <p>一致する表現が見つかりません。</p>
        </div>
      `;
      return;
    }

    filtered.forEach(item => {
      const card = document.createElement("div");
      card.className = "dict-card";
      
      card.innerHTML = `
        <div class="dict-header">
          <span class="dict-phrase">「${item.phrase}」</span>
          <span class="dict-type">${item.type}</span>
        </div>
        <div class="dict-translation-row">
          <span class="dict-lbl">AIが紐解く本音</span>
          <span class="dict-honne">${item.honne}</span>
        </div>
        <div class="dict-action">
          <span class="dict-lbl">おすすめの対策：</span>${item.action}
        </div>
      `;
      
      dictionaryList.appendChild(card);
    });
  }

  dictSearch.addEventListener("input", (e) => {
    renderDictionary(e.target.value);
  });

  // Initial Dictionary render
  renderDictionary();
});
