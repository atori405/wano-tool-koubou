// content.js - 日本語AI議事録アシスト の常設ページ内パネル
// ツールバーアイコンのクリックで表示/非表示を切り替える、ドラッグ移動できる
// 独立パネルです。ネイティブのブラウザ拡張ポップアップは、コピー先アプリに
// 切り替えた瞬間に自動で閉じてしまう仕様(拡張機能側では回避不可)のため、
// 通常のDOM要素としてページ上に直接差し込むことで解決しています。
// 影響範囲は Shadow DOM 内 + このコンテナ要素だけに限定し、閲覧中のページ
// 本体には一切手を加えません。
//
// 注意: マイク許可のダイアログは、今見ているWebサイトの名前で表示されます
// (拡張機能ではなく、そのページの権限として許可を求める仕様のため)。

(function () {
  'use strict';
  if (window.__wanoExt09Injected) return;
  window.__wanoExt09Injected = true;

  var container = null;
  var shadow = null;

  chrome.runtime.onMessage.addListener(function (msg) {
    if (msg && msg.action === 'toggleWidget') {
      toggleWidget();
    }
  });

  function toggleWidget() {
    try {
      if (container) {
        removeWidget();
      } else {
        createWidget();
      }
    } catch (e) {
      console.error('[wano-ext09] toggleWidget failed:', e);
    }
  }

  function removeWidget() {
    if (container) {
      if (typeof stopAllActivity === 'function') stopAllActivity();
      container.remove();
    }
    container = null;
    shadow = null;
  }

  function createWidget() {
    container = document.createElement('div');
    container.id = 'wano-ext09-widget-root';
    container.style.cssText = 'position:fixed; top:20px; right:20px; z-index:2147483647; width:380px; font-size:13px;';
    document.body.appendChild(container);
    shadow = container.attachShadow({ mode: 'open' });
    shadow.innerHTML = baseTemplate();
    document.body.appendChild(container);
    wireBase();
    wireLiveTab();
    wireHistoryTab();
    wireDictionaryTab();
    if (window.makeDraggable) {
      window.makeDraggable(container, shadow.querySelector('#drag-handle'));
    }
    applyLicenseGate();
  }

  function $(sel) { return shadow.querySelector(sel); }
  function $all(sel) { return shadow.querySelectorAll(sel); }

  // ========================= Shell / Template =========================
  function baseTemplate() {
    return (
      '<style>' + baseCSS() + '</style>' +
      '<div class="wano-panel" id="wano-panel">' +
        '<div class="head" id="drag-handle">' +
          '<span class="head-title"><span class="dot">議</span> 日本語AI議事録アシスト</span>' +
          '<button class="close-btn" id="close-btn" title="閉じる">✕</button>' +
        '</div>' +
        '<div id="trial-banner-slot"></div>' +
        '<div class="tabs">' +
          '<button class="tab-btn active" data-tab="tab-live">会議の記録</button>' +
          '<button class="tab-btn" data-tab="tab-history">議事録履歴</button>' +
          '<button class="tab-btn" data-tab="tab-dictionary">建前逆引き辞書</button>' +
        '</div>' +
        '<div class="tab-content active" id="tab-live">' +
          '<div class="rec-row">' +
            '<button class="primary-btn" id="btn-record">🎙️ <span id="record-btn-text">文字起こし開始</span></button>' +
            '<button class="secondary-btn" id="btn-demo" title="マイクなしでデモ対話を再生します">▶ デモ再生</button>' +
            '<button class="secondary-btn icon-only" id="btn-reset" title="文字起こしをクリア" disabled>🗑️</button>' +
          '</div>' +
          '<div class="hint">マイク許可は今見ているサイトの名前で確認されます（ブラウザの標準仕様）。</div>' +
          '<div class="voice-wave hidden" id="voice-wave-container"><span id="voice-wave-status">音声を入力中...</span></div>' +
          '<div class="speaker-row">' +
            '<span class="speaker-lbl">現在の話者:</span>' +
            '<button class="speaker-btn active" data-speaker="A" id="speaker-a-btn">話者A</button>' +
            '<button class="speaker-btn" data-speaker="B" id="speaker-b-btn">話者B(自分)</button>' +
          '</div>' +
          '<div class="transcript-head"><span>💬 会話ログ</span><span id="transcript-count">0 行のテキスト</span></div>' +
          '<div class="transcript-log" id="transcript-log">' +
            '<div class="empty-state" id="log-empty-state"><p>文字起こしが開始されていません。</p><p class="empty-sub">「文字起こし開始」を押して話すか、「デモ再生」で体験してください。</p></div>' +
          '</div>' +
          '<button class="primary-btn full" id="btn-analyze" disabled>✨ AI議事録を作成する</button>' +
          '<div class="result hidden" id="analysis-result-card">' +
            '<div class="res-tabs">' +
              '<button class="res-tab active" data-res-tab="res-minutes">要約議事録</button>' +
              '<button class="res-tab" data-res-tab="res-translation">建前 vs 本音</button>' +
            '</div>' +
            '<div class="res-tab-content active" id="res-minutes">' +
              '<textarea id="output-minutes" class="markdown-output" readonly></textarea>' +
              '<div class="btn-row"><button class="secondary-btn" id="btn-save-minutes">💾 履歴に保存</button><button class="primary-btn" id="btn-copy-minutes">📋 コピー</button></div>' +
            '</div>' +
            '<div class="res-tab-content" id="res-translation">' +
              '<div id="translation-list"></div>' +
              '<div class="empty-state hidden" id="translation-empty-state"><p>この会話中には、顕著な建前表現は検出されませんでした。</p></div>' +
            '</div>' +
          '</div>' +
        '</div>' +
        '<div class="tab-content" id="tab-history">' +
          '<p class="tab-intro">ローカルに保存されている議事録の一覧です。クリックして確認・コピーできます。</p>' +
          '<div class="history-list" id="history-list"><div class="empty-state"><p>保存された議事録がありません。</p></div></div>' +
          '<div class="result hidden" id="history-preview-card">' +
            '<div class="result-head"><span id="history-preview-title">議事録プレビュー</span><button class="close-btn sm" id="btn-close-preview">✕</button></div>' +
            '<textarea id="history-preview-text" class="markdown-output" readonly></textarea>' +
            '<div class="btn-row"><button class="secondary-btn danger" id="btn-delete-history">削除する</button><button class="primary-btn" id="btn-copy-history">コピー</button></div>' +
          '</div>' +
        '</div>' +
        '<div class="tab-content" id="tab-dictionary">' +
          '<p class="tab-intro">会議やメールで頻出する「建前」表現を、本音と対応策つきで参照できる辞書です（登録済みの定型表現のみを検索します）。</p>' +
          '<input type="text" id="dict-search" class="select-input" placeholder="表現やキーワードで検索...">' +
          '<div id="dictionary-list"></div>' +
        '</div>' +
        '<div class="toast hidden" id="toast">コピーしました！</div>' +
      '</div>'
    );
  }

  function baseCSS() {
    return (
      ':host{all:initial;}' +
      '*{box-sizing:border-box; font-family:-apple-system,BlinkMacSystemFont,"Hiragino Sans","Yu Gothic",sans-serif;}' +
      '.wano-panel{background:#fff; border-radius:14px; box-shadow:0 12px 32px rgba(0,0,0,.2); border:1px solid #e5e7eb; overflow:hidden; color:#111827;}' +
      '.head{cursor:move; display:flex; align-items:center; justify-content:space-between; padding:10px 12px; background:linear-gradient(135deg,#6366f1,#4338ca); color:#fff;}' +
      '.head-title{font-size:13px; font-weight:700; display:flex; align-items:center; gap:6px;}' +
      '.dot{background:rgba(255,255,255,.25); border-radius:50%; width:18px; height:18px; display:inline-flex; align-items:center; justify-content:center; font-size:11px;}' +
      '.close-btn{cursor:pointer; background:rgba(255,255,255,.25); border:none; color:#fff; width:22px; height:22px; border-radius:6px; font-size:13px; line-height:1;}' +
      '.close-btn:hover{background:rgba(255,255,255,.4);}' +
      '.close-btn.sm{background:#f3f4f6; color:#111827;}' +
      '#trial-banner-slot:empty{display:none;}' +
      '.tabs{display:flex; gap:4px; padding:8px 10px 0;}' +
      '.tab-btn{flex:1; background:#f3f4f6; border:none; border-radius:8px; padding:7px 4px; font-size:10.5px; font-weight:700; color:#111827; cursor:pointer;}' +
      '.tab-btn.active{background:#4338ca22; color:#3730a3;}' +
      '.tab-content{display:none; padding:12px; max-height:70vh; overflow-y:auto;}' +
      '.tab-content.active{display:block;}' +
      '.tab-intro{font-size:11.5px; color:#111827; line-height:1.6; margin:0 0 10px;}' +
      '.rec-row{display:flex; gap:6px;}' +
      '.primary-btn{background:linear-gradient(135deg,#6366f1,#4338ca); color:#fff; border:none; border-radius:10px; padding:9px 12px; font-size:12px; font-weight:700; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:5px; flex:1;}' +
      '.primary-btn:disabled{opacity:.5; cursor:not-allowed;}' +
      '.primary-btn.full{width:100%; margin-top:10px;}' +
      '.primary-btn.recording{background:linear-gradient(135deg,#e11d48,#be123c);}' +
      '.secondary-btn{background:#f3f4f6; color:#111827; border:1px solid #e5e7eb; border-radius:10px; padding:9px 10px; font-size:11.5px; font-weight:700; cursor:pointer;}' +
      '.secondary-btn:disabled{opacity:.5; cursor:not-allowed;}' +
      '.secondary-btn.icon-only{flex:none; width:38px;}' +
      '.secondary-btn.danger{color:#e11d48; border-color:#fca5a5;}' +
      '.hint{font-size:10.5px; color:#111827; margin:6px 0; line-height:1.5;}' +
      '.voice-wave{background:#4338ca11; border-radius:8px; padding:6px 10px; font-size:11px; color:#3730a3; margin-bottom:8px; text-align:center;}' +
      '.voice-wave.hidden{display:none;}' +
      '.speaker-row{display:flex; align-items:center; gap:6px; margin-bottom:10px; flex-wrap:wrap;}' +
      '.speaker-lbl{font-size:11px; color:#111827;}' +
      '.speaker-btn{background:#f3f4f6; border:1px solid #e5e7eb; border-radius:999px; padding:4px 10px; font-size:10.5px; font-weight:700; color:#111827; cursor:pointer;}' +
      '.speaker-btn.active{background:#4338ca; border-color:#4338ca; color:#fff;}' +
      '.transcript-head{display:flex; justify-content:space-between; font-size:11px; font-weight:700; color:#111827; margin-bottom:6px;}' +
      '.transcript-log{max-height:180px; overflow-y:auto; background:#f9fafb; border:1px solid #e5e7eb; border-radius:10px; padding:8px; margin-bottom:10px;}' +
      '.empty-state{text-align:center; color:#111827; font-size:11px; padding:14px 4px;}' +
      '.empty-sub{color:#6b7280; font-size:10.5px;}' +
      '.speech-bubble-wrapper{margin-bottom:8px;}' +
      '.speech-info{display:flex; justify-content:space-between; font-size:10px; color:#6b7280; margin-bottom:2px;}' +
      '.speech-bubble{background:#fff; border:1px solid #e5e7eb; border-radius:8px; padding:6px 8px; font-size:11.5px; line-height:1.5;}' +
      '.speaker-b .speech-bubble{background:#4338ca11;}' +
      '.result{margin-top:12px; border-top:1px solid #f3f4f6; padding-top:12px;}' +
      '.result.hidden{display:none;}' +
      '.result-head{display:flex; justify-content:space-between; align-items:center; font-size:11.5px; font-weight:700; margin-bottom:8px;}' +
      '.res-tabs{display:flex; gap:4px; margin-bottom:8px;}' +
      '.res-tab{flex:1; background:#f3f4f6; border:none; border-radius:8px; padding:6px; font-size:10.5px; font-weight:700; color:#111827; cursor:pointer;}' +
      '.res-tab.active{background:#4338ca22; color:#3730a3;}' +
      '.res-tab-content{display:none;}' +
      '.res-tab-content.active{display:block;}' +
      '.markdown-output{width:100%; min-height:140px; border:1px solid #e5e7eb; border-radius:8px; padding:8px; font-size:11px; font-family:ui-monospace,monospace; color:#111827; resize:vertical;}' +
      '.btn-row{display:flex; gap:6px; margin-top:8px;}' +
      '.translation-item{border:1px solid #e5e7eb; border-radius:8px; padding:8px; margin-bottom:6px; font-size:11.5px;}' +
      '.translation-item .tatemae{font-weight:700; margin-bottom:3px;}' +
      '.translation-item .honne{color:#e11d48;}' +
      '.history-item{display:flex; justify-content:space-between; align-items:center; border:1px solid #e5e7eb; border-radius:8px; padding:8px 10px; margin-bottom:6px; cursor:pointer; font-size:11.5px;}' +
      '.history-item:hover{border-color:#4338ca;}' +
      '.history-meta{font-size:10px; color:#6b7280;}' +
      '.select-input{width:100%; border:1px solid #e5e7eb; border-radius:8px; padding:8px; font-size:12px; color:#111827; margin-bottom:10px;}' +
      '.dict-card{border:1px solid #e5e7eb; border-radius:8px; padding:9px 10px; margin-bottom:8px;}' +
      '.dict-phrase{font-weight:700; font-size:12px;}' +
      '.dict-type{float:right; background:#4338ca22; color:#3730a3; font-size:10px; font-weight:700; padding:1px 8px; border-radius:999px;}' +
      '.dict-row{font-size:11px; margin-top:4px; line-height:1.5;}' +
      '.dict-lbl{color:#6b7280; font-weight:700; margin-right:4px;}' +
      '.toast{position:absolute; bottom:10px; left:50%; transform:translateX(-50%); background:#111827; color:#fff; font-size:11px; padding:6px 14px; border-radius:999px;}' +
      '.toast.hidden{display:none;}' +
      '.hidden{display:none;}' +
      '.lock-screen{padding:24px 18px; text-align:center; background:linear-gradient(135deg,#0f172a,#1e1b4b); color:#f8fafc;}' +
      '.lock-screen h3{font-size:14px; color:#f59e0b; margin:0 0 8px;}' +
      '.lock-screen p{font-size:11.5px; color:#94a3b8; line-height:1.6; margin:0 0 14px;}' +
      '.lock-screen button{background:#d97706; color:#fff; border:none; border-radius:8px; padding:9px 16px; font-size:12px; font-weight:600; cursor:pointer;}'
    );
  }

  function wireBase() {
    $('#close-btn').addEventListener('click', removeWidget);
    $all('.tab-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        $all('.tab-btn').forEach(function (b) { b.classList.remove('active'); });
        $all('.tab-content').forEach(function (c) { c.classList.remove('active'); });
        btn.classList.add('active');
        $('#' + btn.dataset.tab).classList.add('active');
        if (btn.dataset.tab === 'tab-history') renderHistory();
      });
    });
  }

  function showToast(message) {
    var toast = $('#toast');
    toast.textContent = message;
    toast.classList.remove('hidden');
    setTimeout(function () { toast.classList.add('hidden'); }, 2000);
  }

  // ========================= 建前→本音 辞書(実在データ) =========================
  var DICTIONARY = [
    { phrase: "前向きに検討します", type: "回答・返答", honne: "現時点では保留、または見送る可能性が高い", action: "社交辞令の可能性が高いため、具体的な検討期日や判断基準を投げかけましょう。" },
    { phrase: "検討させていただきます", type: "回答・返答", honne: "やんわりとお断りする（何もしない）", action: "「いつまでに」「何を」決めるかを合意するか、断られた前提で別プランを用意します。" },
    { phrase: "持ち帰って相談します", type: "合意・拒絶", honne: "その場での決定を避けて社内で却下したい / 時間稼ぎ", action: "「いつ頃回答をいただけるか」の回答期限をその場で約束し、保留を防ぎます。" },
    { phrase: "リソース的な兼ね合い", type: "理由・言い訳", honne: "人員不足、または予算不足で優先度が極めて低い", action: "「稼働が空く予定の時期」を確認するか、作業スコープを絞ったミニマムプランを再提案します。" },
    { phrase: "ちょっと今は立て込んでおりまして", type: "理由・言い訳", honne: "優先順位が低いため、後回しにしたい", action: "「来月中旬頃であればお時間ありますでしょうか？」など、時期をずらして再打診します。" },
    { phrase: "様子を見させていただければ", type: "合意・拒絶", honne: "実施する意思が薄い（実質的な却下・見送り）", action: "「様子を見る」期間を区切り、例えば「来月末の状況を見て再相談」など期限を設けます。" },
    { phrase: "タイミングを見て行いたい", type: "スケジュール", honne: "時期未定（現時点ではやる気がない）", action: "「タイミング」を具体的に定義（例：四半期決算の後など）し、スケジュールを合意します。" },
    { phrase: "ご意見を参考にさせていただきます", type: "回答・返答", honne: "その意見や提案は採用しない（聞き流す）", action: "単なる意見ではなく、数値データや競合調査結果など「採用せざるを得ない根拠」を持って再度交渉します。" },
    { phrase: "なるべく善処します", type: "回答・返答", honne: "期待しないでほしい（努力はするが結果は保証しない）", action: "善処の具体的な内容（アクションプラン）を確認し、最低限の目標（デッドライン）を取り決めます。" },
    { phrase: "基本的には賛成ですが", type: "合意・拒絶", honne: "細かい条件や前提に反対、あるいは重大な懸念点がある", action: "「基本的には」以外の『懸念されている具体的な点』について聞き出し、先回りで解消します。" },
    { phrase: "認識の相違がありました", type: "トラブル", honne: "あなたの勘違い（またはこちらのミスだが有耶無耶にしたい）", action: "言った言わないを防ぐため、要点と認識が合致した内容を必ずテキスト（メール等）で再確認します。" },
    { phrase: "諸般の事情により", type: "理由・言い訳", honne: "社内政治、予算不足など、明かしたくない不都合がある", action: "ネックになっているのは予算なのか、上司の意向なのか、外部要因なのかを個別に探ります。" },
    { phrase: "軽く頭出しするくらいでいい", type: "スケジュール", honne: "正式な検討や提案は不要（重要視していない）", action: "簡易な情報共有に留まるため、次回いつ本格審議にかけるのか次のステップを握ります。" },
    { phrase: "一度ペンディングに", type: "回答・返答", honne: "事実上の白紙化・中止", action: "保留になった要因を整理し、再度案件を掘り起こすための再開条件を確認しておきます。" },
    { phrase: "基本線としては問題ない", type: "回答・返答", honne: "修正すべき細かい問題が山積している", action: "「基本線」以外のクリアすべき詳細なチェックリストをもらい、素早く修正対応をします。" },
    { phrase: "こちらで調整しておきます", type: "合意・拒絶", honne: "自分で勝手にやるから口を挟まないでほしい", action: "主導権を渡すことになります。進捗共有のタイミング（いつ報告を受けるか）だけ握ります。" },
    { phrase: "お忙しそうなのでまた改めて", type: "回答・返答", honne: "話す時間を作りたくない（断り文句）", action: "「明日の〇時頃に1分だけお時間を」と超短時間のアポで切り崩します。" },
    { phrase: "今後の課題ですね", type: "合意・拒絶", honne: "今やるつもりはない（お蔵入り）", action: "重要だが緊急度が低いフォルダに入れられるため、今やるべき小さな第一歩を提案します。" }
  ];

  var DEMO_CONVERSATION = [
    { speaker: "A", name: "鈴木課長", text: "お疲れ様です、田中部長。例の「新規オンラインキャンペーン企画」の件ですが、進捗いかがでしょうか？", delay: 1200 },
    { speaker: "B", name: "田中部長", text: "ああ、鈴木くん。その企画ね。内容は見させてもらったよ。基本的には前向きに社内で検討したいと考えてるんだよね。", delay: 2800 },
    { speaker: "A", name: "鈴木課長", text: "ありがとうございます！前向きに、ということは今クォーター中にテスト配信などをスタートできますでしょうか？", delay: 2000 },
    { speaker: "B", name: "田中部長", text: "うーん、前向きに検討はしているんだけどね、ちょっと今は社内の他プロジェクトとのリソース的な兼ね合いというか、今期はいろいろと立て込んでおりましてね。", delay: 3500 },
    { speaker: "A", name: "鈴木課長", text: "なるほど、人員の調整や稼働率が厳しいという感じでしょうか。", delay: 1800 },
    { speaker: "B", name: "田中部長", text: "そうだね。だから、決してやらないというわけではないんだけど、少し様子を見させていただければなと。上層部の合意を取るのもタイミングを見て行いたいと思っているんだ。", delay: 3500 },
    { speaker: "A", name: "鈴木課長", text: "そういうことですね。私の方でも追加のデータを集めてご説明に伺うことも可能ですが、どういたしましょうか。", delay: 2500 },
    { speaker: "B", name: "田中部長", text: "そうだねえ。鈴木くんの熱意はありがたいんだけど、焦って資料を作るのもアレだし、まずは次の定例会議のあたりで、アジェンダの一つとして軽く頭出しするくらいでいいんじゃないかな。", delay: 3800 },
    { speaker: "A", name: "鈴木課長", text: "承知いたしました。では、次回定例でアジェンダ共有だけ行い、企画自体は一旦保留ということで進めます。", delay: 2500 },
    { speaker: "B", name: "田中部長", text: "うん、それで頼むよ。お手数をおかけするけれど、いただいたご意見は参考にさせていただきつつ、タイミングを見て再度ご相談させてください。", delay: 3200 }
  ];

  // ========================= Tab 1: 会議の記録 =========================
  var isRecording = false;
  var isDemoPlaying = false;
  var currentSpeaker = 'A';
  var conversationData = [];
  var recognition = null;
  var demoTimer = null;

  function stopAllActivity() {
    if (isRecording) { isRecording = false; if (recognition) recognition.stop(); }
    if (isDemoPlaying) { isDemoPlaying = false; clearTimeout(demoTimer); }
  }

  function wireLiveTab() {
    var btnRecord = $('#btn-record');
    var btnDemo = $('#btn-demo');
    var btnReset = $('#btn-reset');
    var btnAnalyze = $('#btn-analyze');
    var voiceWave = $('#voice-wave-container');
    var voiceWaveStatus = $('#voice-wave-status');
    var speakerBtns = $all('.speaker-btn');
    var transcriptLog = $('#transcript-log');
    var logEmptyState = $('#log-empty-state');
    var transcriptCount = $('#transcript-count');
    var analysisResultCard = $('#analysis-result-card');

    speakerBtns.forEach(function (btn) {
      btn.addEventListener('click', function () {
        speakerBtns.forEach(function (b) { b.classList.remove('active'); });
        btn.classList.add('active');
        currentSpeaker = btn.dataset.speaker;
      });
    });

    var SpeechRecognitionCtor = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognitionCtor) {
      btnRecord.disabled = true;
      voiceWaveStatus.textContent = '音声認識非対応ブラウザです';
    } else {
      recognition = new SpeechRecognitionCtor();
      recognition.continuous = true;
      recognition.interimResults = false;
      recognition.lang = 'ja-JP';

      recognition.onstart = function () {
        isRecording = true;
        btnRecord.classList.add('recording');
        $('#record-btn-text').textContent = '文字起こし停止';
        voiceWave.classList.remove('hidden');
        btnDemo.disabled = true;
        btnReset.disabled = false;
      };
      recognition.onresult = function (event) {
        var resultText = event.results[event.results.length - 1][0].transcript.trim();
        if (resultText) {
          var name = currentSpeaker === 'A' ? '話者A' : '話者B(自分)';
          addTranscriptBubble(currentSpeaker, name, resultText);
        }
      };
      recognition.onerror = function (event) {
        console.error('Speech recognition error', event.error);
        if (event.error === 'not-allowed') {
          showToast('マイクの使用許可が必要です。');
          stopRecording();
        }
      };
      recognition.onend = function () {
        if (isRecording) { recognition.start(); } else { stopRecordingUI(); }
      };
    }

    function startRecording() {
      if (!recognition) { showToast('マイク機能がサポートされていません。'); return; }
      analysisResultCard.classList.add('hidden');
      logEmptyState.classList.add('hidden');
      recognition.start();
    }
    function stopRecording() {
      isRecording = false;
      if (recognition) recognition.stop();
      stopRecordingUI();
    }
    function stopRecordingUI() {
      btnRecord.classList.remove('recording');
      $('#record-btn-text').textContent = '文字起こし開始';
      voiceWave.classList.add('hidden');
      btnDemo.disabled = false;
    }
    btnRecord.addEventListener('click', function () {
      if (isDemoPlaying) stopDemo();
      if (isRecording) stopRecording(); else startRecording();
    });

    function playDemo() {
      if (isRecording) stopRecording();
      resetConversation();
      analysisResultCard.classList.add('hidden');
      logEmptyState.classList.add('hidden');
      isDemoPlaying = true;
      btnDemo.classList.add('recording');
      btnDemo.querySelector('span') ? null : null;
      btnDemo.innerHTML = '⏸ デモ停止';
      btnRecord.disabled = true;
      btnReset.disabled = false;

      var idx = 0;
      function playNext() {
        if (idx >= DEMO_CONVERSATION.length) { stopDemo(); showToast('デモ再生が完了しました。AI議事録の作成をお試しください！'); return; }
        var step = DEMO_CONVERSATION[idx];
        currentSpeaker = step.speaker;
        speakerBtns.forEach(function (b) { b.classList.toggle('active', b.dataset.speaker === currentSpeaker); });
        addTranscriptBubble(step.speaker, step.name, step.text);
        idx++;
        demoTimer = setTimeout(playNext, step.delay);
      }
      demoTimer = setTimeout(playNext, 500);
    }
    function stopDemo() {
      isDemoPlaying = false;
      clearTimeout(demoTimer);
      btnDemo.classList.remove('recording');
      btnDemo.innerHTML = '▶ デモ再生';
      btnRecord.disabled = false;
    }
    btnDemo.addEventListener('click', function () { if (isDemoPlaying) stopDemo(); else playDemo(); });

    function addTranscriptBubble(speaker, name, text) {
      logEmptyState.classList.add('hidden');
      var time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      var wrapper = document.createElement('div');
      wrapper.className = 'speech-bubble-wrapper speaker-' + speaker.toLowerCase();
      wrapper.innerHTML = '<div class="speech-info"><span>' + name + '</span><span>' + time + '</span></div><div class="speech-bubble"></div>';
      wrapper.querySelector('.speech-bubble').textContent = text;
      transcriptLog.appendChild(wrapper);
      transcriptLog.scrollTop = transcriptLog.scrollHeight;
      conversationData.push({ speaker: speaker, name: name, text: text, timestamp: time });
      transcriptCount.textContent = conversationData.length + ' 行のテキスト';
      if (conversationData.length > 0) btnAnalyze.disabled = false;
    }

    function resetConversation() {
      conversationData = [];
      transcriptLog.innerHTML = '';
      transcriptLog.appendChild(logEmptyState);
      logEmptyState.classList.remove('hidden');
      transcriptCount.textContent = '0 行のテキスト';
      btnAnalyze.disabled = true;
      btnReset.disabled = true;
      analysisResultCard.classList.add('hidden');
    }
    btnReset.addEventListener('click', function () {
      if (isDemoPlaying) stopDemo();
      if (isRecording) stopRecording();
      resetConversation();
    });

    // 結果タブ切り替え
    $all('.res-tab').forEach(function (tab) {
      tab.addEventListener('click', function () {
        $all('.res-tab').forEach(function (t) { t.classList.remove('active'); });
        $all('.res-tab-content').forEach(function (c) { c.classList.remove('active'); });
        tab.classList.add('active');
        $('#' + tab.dataset.resTab).classList.add('active');
      });
    });

    // --- AI議事録作成(キーワード抽出。デモ会話専用の固定出力は使わない) ---
    btnAnalyze.addEventListener('click', function () {
      if (conversationData.length === 0) return;
      if (isRecording) stopRecording();
      if (isDemoPlaying) stopDemo();

      var fullText = conversationData.map(function (c) { return c.text; }).join(' ');
      var detected = DICTIONARY.filter(function (d) { return fullText.includes(d.phrase); });

      var translationList = $('#translation-list');
      var translationEmpty = $('#translation-empty-state');
      translationList.innerHTML = '';
      if (detected.length > 0) {
        translationEmpty.classList.add('hidden');
        detected.forEach(function (item) {
          var div = document.createElement('div');
          div.className = 'translation-item';
          div.innerHTML = '<div class="tatemae">「' + item.phrase + '」</div><div class="honne">→ ' + item.honne + '</div>';
          translationList.appendChild(div);
        });
      } else {
        translationEmpty.classList.remove('hidden');
      }

      var dateStr = new Date().toLocaleDateString('ja-JP');
      var title = '会議要約議事録';
      if (fullText.includes('キャンペーン')) title = '企画・キャンペーン進捗会議';
      else if (fullText.includes('不具合') || fullText.includes('バグ')) title = 'システム不具合対応会議';
      else if (fullText.includes('お詫び') || fullText.includes('クレーム')) title = '顧客対応会議';
      else if (fullText.includes('アジェンダ') || fullText.includes('進捗')) title = 'プロジェクト進捗定例会議';

      var attendees = Array.from(new Set(conversationData.map(function (c) { return c.name; }))).join('、');

      // 決定事項・アクションは常にキーワード検出による実データ抽出のみを使う
      // (以前はデモ会話にだけ固定の高精度出力を返す特別扱いがあったが、
      //  実際の会話では再現できない見せかけの結果だったため廃止した)
      var decisions = [];
      var actions = [];
      conversationData.forEach(function (c) {
        if (/決定|進めます|でお願いします|賛成|保留/.test(c.text)) {
          decisions.push(c.text.length > 60 ? c.text.slice(0, 60) + '…' : c.text);
        }
        if (/します|頼む|データ|連絡|確認/.test(c.text)) {
          actions.push('[ ] ' + (c.text.length > 60 ? c.text.slice(0, 60) + '…' : c.text) + '（' + c.name + '）');
        }
      });
      if (decisions.length === 0) decisions.push('（決定事項に該当する発言は検出されませんでした）');
      if (actions.length === 0) actions.push('[ ] （アクションに該当する発言は検出されませんでした）');

      var md = '# 【議事録】' + title + '\n\n';
      md += '**日時:** ' + dateStr + '（作成日）\n';
      md += '**出席者:** ' + attendees + '\n\n';
      md += '## 1. 会議の決定事項（キーワード検出）\n';
      decisions.forEach(function (d) { md += '- ' + d + '\n'; });
      md += '\n';
      if (detected.length > 0) {
        md += '## 2. 検出された建前表現の整理\n';
        detected.forEach(function (item) {
          md += '- **発言**: 「' + item.phrase + '」\n  - **本音**: ' + item.honne + '\n  - **推奨対応**: ' + item.action + '\n';
        });
        md += '\n';
      }
      md += '## 3. 次アクション（キーワード検出・要確認）\n';
      actions.forEach(function (a) { md += '- ' + a + '\n'; });
      md += '\n--------------------\n*登録済み辞書とキーワード一致による自動抽出です。内容は必ず人の目でご確認ください。*';

      $('#output-minutes').value = md;
      analysisResultCard.classList.remove('hidden');
    });

    $('#btn-copy-minutes').addEventListener('click', function () {
      navigator.clipboard.writeText($('#output-minutes').value).then(function () { showToast('議事録(Markdown)をコピーしました！'); });
    });

    $('#btn-save-minutes').addEventListener('click', function () {
      var text = $('#output-minutes').value.trim();
      if (!text) return;
      var titleMatch = text.match(/# 【議事録】(.*)/);
      var title = titleMatch ? titleMatch[1] : '無題の議事録';
      var item = { id: 'min_' + Date.now(), title: title, date: new Date().toLocaleDateString('ja-JP'), text: text };
      chrome.storage.local.get({ minutes_history: [] }, function (res) {
        var history = res.minutes_history || [];
        history.unshift(item);
        chrome.storage.local.set({ minutes_history: history }, function () { showToast('履歴に議事録を保存しました。'); });
      });
    });
  }

  // ========================= Tab 2: 議事録履歴 =========================
  // 旧popup.htmlはlocalStorageを使っていたが、コンテンツスクリプトの
  // localStorageは「今見ているページのオリジン」に紐づいてしまうため、
  // 拡張機能専用の chrome.storage.local に保存先を変更している。
  var activeHistoryId = null;

  function renderHistory() {
    chrome.storage.local.get({ minutes_history: [] }, function (res) {
      var history = res.minutes_history || [];
      var list = $('#history-list');
      list.innerHTML = '';
      if (history.length === 0) {
        list.innerHTML = '<div class="empty-state"><p>保存された議事録がありません。</p></div>';
        return;
      }
      history.forEach(function (item) {
        var div = document.createElement('div');
        div.className = 'history-item';
        div.innerHTML = '<div><div>' + item.title + '</div><div class="history-meta">' + item.date + '</div></div><span>→</span>';
        div.addEventListener('click', function () { openHistoryPreview(item); });
        list.appendChild(div);
      });
    });
  }

  function openHistoryPreview(item) {
    activeHistoryId = item.id;
    $('#history-preview-title').textContent = item.title;
    $('#history-preview-text').value = item.text;
    $('#history-preview-card').classList.remove('hidden');
  }

  function wireHistoryTab() {
    $('#btn-close-preview').addEventListener('click', function () {
      $('#history-preview-card').classList.add('hidden');
      activeHistoryId = null;
    });
    $('#btn-copy-history').addEventListener('click', function () {
      var text = $('#history-preview-text').value;
      if (!text) return;
      navigator.clipboard.writeText(text).then(function () { showToast('議事録をコピーしました！'); });
    });
    $('#btn-delete-history').addEventListener('click', function () {
      if (!activeHistoryId) return;
      chrome.storage.local.get({ minutes_history: [] }, function (res) {
        var history = (res.minutes_history || []).filter(function (i) { return i.id !== activeHistoryId; });
        chrome.storage.local.set({ minutes_history: history }, function () {
          $('#history-preview-card').classList.add('hidden');
          activeHistoryId = null;
          renderHistory();
          showToast('議事録を削除しました。');
        });
      });
    });
  }

  // ========================= Tab 3: 建前逆引き辞書 =========================
  function renderDictionary(filter) {
    var list = $('#dictionary-list');
    list.innerHTML = '';
    var f = (filter || '').trim().toLowerCase();
    var filtered = DICTIONARY.filter(function (item) {
      return item.phrase.toLowerCase().includes(f) || item.honne.toLowerCase().includes(f) || item.action.toLowerCase().includes(f);
    });
    if (filtered.length === 0) {
      list.innerHTML = '<div class="empty-state"><p>一致する表現が見つかりません。</p></div>';
      return;
    }
    filtered.forEach(function (item) {
      var card = document.createElement('div');
      card.className = 'dict-card';
      card.innerHTML =
        '<span class="dict-type">' + item.type + '</span>' +
        '<div class="dict-phrase">「' + item.phrase + '」</div>' +
        '<div class="dict-row"><span class="dict-lbl">本音:</span>' + item.honne + '</div>' +
        '<div class="dict-row"><span class="dict-lbl">対策:</span>' + item.action + '</div>';
      list.appendChild(card);
    });
  }

  function wireDictionaryTab() {
    $('#dict-search').addEventListener('input', function (e) { renderDictionary(e.target.value); });
    renderDictionary('');
  }

  // ========================= ライセンス / トライアル =========================
  function applyLicenseGate() {
    if (typeof LicenseManager === 'undefined') return;
    LicenseManager.checkStatus().then(function (status) {
      if (!shadow) return;
      if (status.status === 'expired') lockPanel();
      else if (status.status === 'trial') showTrialBanner(status.daysLeft);
    });
  }

  function lockPanel() {
    var panel = $('#wano-panel');
    var head = panel.querySelector('.head');
    Array.prototype.forEach.call(panel.children, function (child) { if (child !== head) child.remove(); });
    var lock = document.createElement('div');
    lock.className = 'lock-screen';
    lock.innerHTML =
      '<h3>🔒 無料体験期間が終了しました</h3>' +
      '<p>この機能を引き続きご利用いただくには、ライセンスキーの入力、またはメールアドレスの登録（無料期間の延長）が必要です。</p>' +
      '<button id="open-license-btn">ライセンスを設定する</button>';
    panel.appendChild(lock);
    lock.querySelector('#open-license-btn').addEventListener('click', function () {
      chrome.runtime.sendMessage({ action: 'openOptionsPage' });
    });
  }

  function showTrialBanner(daysLeft) {
    var slot = $('#trial-banner-slot');
    slot.innerHTML =
      '<div style="background:#1e293b;color:#94a3b8;padding:6px 12px;font-size:11px;display:flex;justify-content:space-between;align-items:center;">' +
        '<span>無料体験中（残り ' + daysLeft + ' 日）</span>' +
        '<a href="#" id="upgrade-link" style="color:#f59e0b;text-decoration:none;font-weight:700;">プロ版へ有効化 ➔</a>' +
      '</div>';
    slot.querySelector('#upgrade-link').addEventListener('click', function (e) {
      e.preventDefault();
      chrome.runtime.sendMessage({ action: 'openOptionsPage' });
    });
  }
})();
