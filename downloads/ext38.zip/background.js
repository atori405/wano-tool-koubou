// background.js - Service Worker for One-Tap Mute

// Helper to extract hostname from URL
function getHostname(url) {
  try {
    return new URL(url).hostname;
  } catch (e) {
    return "";
  }
}

// Check if a domain is whitelisted
function isWhitelisted(url, whitelist) {
  if (!url || !whitelist) return false;
  const hostname = getHostname(url);
  return whitelist.some(domain => hostname === domain || hostname.endsWith("." + domain));
}

// Update the badge on the extension icon based on current tab's status
function updateBadge(tab) {
  if (!tab || !tab.id) return;

  // Retrieve muted state
  const isMuted = tab.mutedInfo ? tab.mutedInfo.muted : false;
  const isAudible = tab.audible;

  if (isMuted) {
    // Show '静' (Silence) badge with subtle grey color
    chrome.action.setBadgeText({ text: "静", tabId: tab.id });
    chrome.action.setBadgeBackgroundColor({ color: "#787878", tabId: tab.id });
    chrome.action.setTitle({
      title: "【消音中】クリックで音声を再生します",
      tabId: tab.id
    });
  } else if (isAudible) {
    // Show '音' (Sound) badge with vivid royal purple color
    chrome.action.setBadgeText({ text: "音", tabId: tab.id });
    chrome.action.setBadgeBackgroundColor({ color: "#895b8a", tabId: tab.id });
    chrome.action.setTitle({
      title: "【再生中】クリックで消音します",
      tabId: tab.id
    });
  } else {
    // Clear badge when neither muted nor making sound
    chrome.action.setBadgeText({ text: "", tabId: tab.id });
    chrome.action.setTitle({
      title: "ワンタップ消音 (クリックで消音をトグル)",
      tabId: tab.id
    });
  }
}

// Update badge for active tab in current window
function updateActiveTabBadge() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs && tabs[0]) {
      updateBadge(tabs[0]);
    }
  });
}

// Event Listeners for Tab Changes
chrome.tabs.onActivated.addListener((activeInfo) => {
  chrome.tabs.get(activeInfo.tabId, (tab) => {
    if (chrome.runtime.lastError) return;
    updateBadge(tab);
  });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // Update badge when audibility, mutedInfo or URL changes
  if (changeInfo.mutedInfo !== undefined || changeInfo.audible !== undefined || changeInfo.url !== undefined) {
    updateBadge(tab);
  }
});

// Initialize on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["whitelist"], (result) => {
    if (!result.whitelist) {
      chrome.storage.local.set({ whitelist: [] });
    }
  });
  updateActiveTabBadge();
});

// Handle commands (global keyboard shortcuts)
chrome.commands.onCommand.addListener((command) => {
  if (command === "toggle-mute-current") {
    // Toggle mute for active tab
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0]) {
        const tab = tabs[0];
        const nextMuteState = tab.mutedInfo ? !tab.mutedInfo.muted : true;
        chrome.tabs.update(tab.id, { muted: nextMuteState }, (updatedTab) => {
          updateBadge(updatedTab);
        });
      }
    });
  } else if (command === "mute-all-tabs") {
    // Mute all tabs except whitelisted domains
    chrome.storage.local.get(["whitelist"], (result) => {
      const whitelist = result.whitelist || [];
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          if (!isWhitelisted(tab.url, whitelist)) {
            chrome.tabs.update(tab.id, { muted: true });
          }
        });
      });
    });
  } else if (command === "unmute-all-tabs") {
    // Unmute all tabs
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        chrome.tabs.update(tab.id, { muted: false });
      });
    });
  }
});
