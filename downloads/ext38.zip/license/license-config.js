/**
 * license-config.js
 * 
 * 拡張機能ごとの個別ライセンス商品ID設定。
 * 自動生成されたファイルです。手動で変更しないでください。
 */
window.LicenseConfig = {
  productId: "SINGLE_PROD_38",
  allToolsProductId: "ALL_TOOLS_3980",
  singleCheckoutUrl: "https://your-store.lemonsqueezy.com/checkout/buy/single-placeholder-38",
  bundleCheckoutUrl: "https://your-store.lemonsqueezy.com/checkout/buy/mega-bundle-placeholder"
};
