



// popup.js - Interactive Controller for One-Tap Mute

document.addEventListener("DOMContentLoaded", () => {
  // Elements
  const btnToggleMute = document.getElementById("btn-toggle-mute");
  const muteSymbol = document.getElementById("mute-symbol");
  const rippleArea = document.getElementById("ripple-area");
  const currentDomain = document.getElementById("current-domain");
  const statusBadge = document.getElementById("status-badge");
  
  const btnMuteAll = document.getElementById("btn-mute-all");
  const btnUnmuteAll = document.getElementById("btn-unmute-all");
  
  const toggleWhitelist = document.getElementById("toggle-whitelist");
  const btnToggleList = document.getElementById("btn-toggle-list");
  const listArrow = document.getElementById("list-arrow");
  const whitelistContainer = document.getElementById("whitelist-list-container");
  const whitelistUl = document.getElementById("whitelist-ul");
  const whitelistCount = document.getElementById("whitelist-count");

  let activeTab = null;
  let whitelist = [];

  // Get domain helper
  function getHostname(url) {
    try {
      if (!url) return "";
      return new URL(url).hostname;
    } catch (e) {
      return "";
    }
  }

  // Load Whitelist from Storage
  function loadWhitelist(callback) {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.get(["whitelist"], (result) => {
        whitelist = result.whitelist || [];
        if (callback) callback();
      });
    } else {
      whitelist = [];
      if (callback) callback();
    }
  }

  // Save Whitelist to Storage
  function saveWhitelist() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.set({ whitelist: whitelist }, () => {
        renderWhitelist();
        updateWhitelistToggleState();
      });
    } else {
      renderWhitelist();
      updateWhitelistToggleState();
    }
  }

  // Update Whitelist Switch checkbox state based on active tab domain
  function updateWhitelistToggleState() {
    if (!activeTab || !activeTab.url) return;
    const domain = getHostname(activeTab.url);
    toggleWhitelist.checked = whitelist.includes(domain);
  }

  // Render Whitelist Items
  function renderWhitelist() {
    whitelistCount.textContent = whitelist.length;
    whitelistUl.innerHTML = "";

    if (whitelist.length === 0) {
      whitelistUl.innerHTML = '<li class="empty-msg">登録されているサイトはありません</li>';
      return;
    }

    whitelist.forEach((domain) => {
      const li = document.createElement("li");
      
      const textSpan = document.createElement("span");
      textSpan.className = "domain-text";
      textSpan.textContent = domain;
      textSpan.title = domain;

      const deleteBtn = document.createElement("button");
      deleteBtn.className = "btn-remove-domain";
      deleteBtn.textContent = "×";
      deleteBtn.title = "除外リストから削除";
      deleteBtn.addEventListener("click", () => {
        whitelist = whitelist.filter(d => d !== domain);
        saveWhitelist();
      });

      li.appendChild(textSpan);
      li.appendChild(deleteBtn);
      whitelistUl.appendChild(li);
    });
  }

  // Update UI Elements with active tab information
  function updateTabUI(tab) {
    if (!tab) return;
    activeTab = tab;
    
    // Domain Text
    const domain = getHostname(tab.url);
    currentDomain.textContent = domain || "ローカル / システムページ";
    currentDomain.title = tab.url || "";

    // Muted Status
    const isMuted = tab.mutedInfo ? tab.mutedInfo.muted : false;
    const isAudible = tab.audible;

    // Reset Classes
    rippleArea.className = "ripple-container";

    if (isMuted) {
      muteSymbol.textContent = "静";
      rippleArea.classList.add("muted");
      statusBadge.textContent = "消音中";
      statusBadge.className = "status-badge muted-sound";
    } else {
      muteSymbol.textContent = "音";
      rippleArea.classList.add("sounding");
      
      if (isAudible) {
        statusBadge.textContent = "再生中";
        statusBadge.className = "status-badge active-sound";
      } else {
        statusBadge.textContent = "無音";
        statusBadge.className = "status-badge";
      }
    }

    updateWhitelistToggleState();
  }

  // Load Active Tab Status
  function refreshActiveTabInfo() {
    if (window.chrome && chrome.tabs) {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0]) {
          updateTabUI(tabs[0]);
        }
      });
    }
  }

  // Initialize
  loadWhitelist(() => {
    renderWhitelist();
    refreshActiveTabInfo();
  });

  // --- Click Listeners ---

  // Main Button: Toggle Mute
  if (btnToggleMute) {
    btnToggleMute.addEventListener("click", () => {
      if (!activeTab || !activeTab.id) return;

      const isMuted = activeTab.mutedInfo ? activeTab.mutedInfo.muted : false;
      chrome.tabs.update(activeTab.id, { muted: !isMuted }, (updatedTab) => {
        updateTabUI(updatedTab);
      });
    });
  }

  // Panic Button: Mute All (except Whitelist)
  if (btnMuteAll) {
    btnMuteAll.addEventListener("click", () => {
      if (window.chrome && chrome.tabs) {
        chrome.tabs.query({}, (tabs) => {
          tabs.forEach(tab => {
            const domain = getHostname(tab.url);
            if (!whitelist.includes(domain)) {
              chrome.tabs.update(tab.id, { muted: true }, () => {
                // If it's the active tab, refresh UI
                if (tab.id === activeTab.id) {
                  refreshActiveTabInfo();
                }
              });
            }
          });
          // Extra buffer sync
          setTimeout(refreshActiveTabInfo, 150);
        });
      }
    });
  }

  // Panic Button: Unmute All
  if (btnUnmuteAll) {
    btnUnmuteAll.addEventListener("click", () => {
      if (window.chrome && chrome.tabs) {
        chrome.tabs.query({}, (tabs) => {
          tabs.forEach(tab => {
            chrome.tabs.update(tab.id, { muted: false }, () => {
              if (tab.id === activeTab.id) {
                refreshActiveTabInfo();
              }
            });
          });
          setTimeout(refreshActiveTabInfo, 150);
        });
      }
    });
  }

  // Whitelist Toggle Checkbox Change
  if (toggleWhitelist) {
    toggleWhitelist.addEventListener("change", (e) => {
      if (!activeTab || !activeTab.url) return;
      
      const domain = getHostname(activeTab.url);
      if (!domain) return;

      if (e.target.checked) {
        if (!whitelist.includes(domain)) {
          whitelist.push(domain);
        }
      } else {
        whitelist = whitelist.filter(d => d !== domain);
      }
      saveWhitelist();
    });
  }

  // Whitelist Panel Header Toggle (Accordion animation)
  if (btnToggleList) {
    btnToggleList.addEventListener("click", () => {
      whitelistContainer.classList.toggle("collapsed");
      listArrow.classList.toggle("open");
    });
  }
});
