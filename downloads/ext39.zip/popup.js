



// popup.js - Japanese Style QR Code Generator Controller

document.addEventListener("DOMContentLoaded", () => {
  // Elements
  const inputText = document.getElementById("input-text");
  const renderCanvas = document.getElementById("render-canvas");
  const selectPattern = document.getElementById("select-pattern");
  const patternOpacity = document.getElementById("pattern-opacity");
  const patternOpacityVal = document.getElementById("pattern-opacity-val");
  const selectKamon = document.getElementById("select-kamon");
  const uploaderContainer = document.getElementById("uploader-container");
  const fileLogo = document.getElementById("file-logo");
  const uploadFilename = document.getElementById("upload-filename");
  const btnDownload = document.getElementById("btn-download");
  
  const dotColorPresets = document.getElementById("dot-color-presets");
  const bgColorPresets = document.getElementById("bg-color-presets");

  // State
  let config = {
    text: "https://example.com",
    dotColor: "#0d0d0d", // 漆黒
    bgColor: "#fbfaf5",  // 生成色
    pattern: "none",
    patternOpacity: 0.10,
    kamon: "none",
    customLogo: null // base64 or Image element
  };
  let lastQR = null; // most recent QRCode instance, for its real module count

  // --- 1. Tab URL Initialization ---
  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0] && tabs[0].url) {
        // Skip extension internal pages
        if (!tabs[0].url.startsWith("chrome://") && !tabs[0].url.startsWith("edge://")) {
          config.text = tabs[0].url;
          inputText.value = tabs[0].url;
        } else {
          inputText.value = config.text;
        }
      }
      regenerate();
    });
  } else {
    inputText.value = config.text;
    regenerate();
  }

  // --- 2. Live Listeners for Inputs ---
  inputText.addEventListener("input", (e) => {
    config.text = e.target.value.trim() || "https://example.com";
    regenerate();
  });

  selectPattern.addEventListener("change", (e) => {
    config.pattern = e.target.value;
    regenerate();
  });

  patternOpacity.addEventListener("input", (e) => {
    const val = parseInt(e.target.value, 10);
    config.patternOpacity = val / 100;
    patternOpacityVal.textContent = val + "%";
    regenerate();
  });

  selectKamon.addEventListener("change", (e) => {
    config.kamon = e.target.value;
    if (config.kamon === "custom") {
      uploaderContainer.classList.remove("hidden");
    } else {
      uploaderContainer.classList.add("hidden");
    }
    regenerate();
  });

  fileLogo.addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;

    uploadFilename.textContent = file.name;
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        config.customLogo = img;
        regenerate();
      };
      img.src = event.target.result;
    };
    reader.readAsDataURL(file);
  });

  // Color preset buttons click handling
  dotColorPresets.addEventListener("click", (e) => {
    const btn = e.target.closest(".color-circle");
    if (!btn) return;
    dotColorPresets.querySelectorAll(".color-circle").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    config.dotColor = btn.getAttribute("data-color");
    regenerate();
  });

  bgColorPresets.addEventListener("click", (e) => {
    const btn = e.target.closest(".color-circle");
    if (!btn) return;
    bgColorPresets.querySelectorAll(".color-circle").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    config.bgColor = btn.getAttribute("data-color");
    regenerate();
  });

  // --- 3. Traditional Vector Watermark Pattern Drawers ---
  function drawWanoPattern(ctx, patternName, width, height, dotColor, opacity) {
    ctx.save();
    ctx.strokeStyle = dotColor;
    ctx.fillStyle = dotColor;
    ctx.globalAlpha = opacity;
    ctx.lineWidth = 1;

    if (patternName === "ichimatsu") {
      // 市松模様 (Checkerboard)
      const size = width / 16;
      for (let r = 0; r < 16; r++) {
        for (let c = 0; c < 16; c++) {
          if ((r + c) % 2 === 0) {
            ctx.fillRect(c * size, r * size, size, size);
          }
        }
      }
    } else if (patternName === "seigaiha") {
      // 青海波 (Wave Crests)
      const R = width / 12; // Radius
      const stepX = R * 1.5;
      const stepY = R * 0.5;

      for (let y = -R; y < height + R; y += stepY) {
        const isShift = Math.floor(y / stepY) % 2 === 0;
        const startX = isShift ? -R : -R - stepX / 2;
        
        for (let x = startX; x < width + R; x += stepX) {
          // Draw multiple concentric semi-circles
          for (let r = R; r > 2; r -= R / 4) {
            ctx.beginPath();
            ctx.arc(x + stepX / 2, y + R, r, Math.PI, 0);
            ctx.stroke();
          }
        }
      }
    } else if (patternName === "asanoha") {
      // 麻の葉 (Hemp Leaf)
      const size = width / 8; // Size of triangle cell
      const h = size * Math.sqrt(3) / 2;

      for (let y = -h; y < height + h; y += h) {
        for (let x = -size; x < width + size; x += size) {
          ctx.save();
          ctx.translate(x, y);

          // Draw hexagon vertices and center
          ctx.beginPath();
          // Outer hexagon
          for (let i = 0; i < 6; i++) {
            const angle = (i * 60) * Math.PI / 180;
            const px = size * Math.cos(angle);
            const py = size * Math.sin(angle);
            if (i === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
          }
          ctx.closePath();
          ctx.stroke();

          // Connect center to vertices and draw internal diagonals
          for (let i = 0; i < 6; i++) {
            const angle = (i * 60) * Math.PI / 180;
            const px = size * Math.cos(angle);
            const py = size * Math.sin(angle);
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.lineTo(px, py);
            ctx.stroke();

            // Internal lines
            const nextAngle = ((i + 1) * 60) * Math.PI / 180;
            const npx = size * Math.cos(nextAngle);
            const npy = size * Math.sin(nextAngle);
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.lineTo((px + npx) / 2, (py + npy) / 2);
            ctx.stroke();
          }

          ctx.restore();
        }
      }
    } else if (patternName === "shippo") {
      // 七宝 (Shippo Cloisonné)
      const R = width / 10;
      const step = R;

      for (let y = -R; y < height + R; y += step) {
        for (let x = -R; x < width + R; x += step) {
          ctx.beginPath();
          ctx.arc(x, y, R, 0, 2 * Math.PI);
          ctx.stroke();
        }
      }
    }

    ctx.restore();
  }

  // --- 4. Traditional Kamon (Family Crest) Vector Drawers ---
  function drawKamon(ctx, kamonName, cx, cy, size, dotColor, bgColor) {
    ctx.save();
    ctx.fillStyle = dotColor;
    ctx.strokeStyle = dotColor;
    ctx.lineWidth = size * 0.04;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    const R = size / 2;

    if (kamonName === "sakura") {
      // 桜紋 (Cherry Blossom)
      ctx.beginPath();
      // Draw 5 petals
      for (let i = 0; i < 5; i++) {
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate((i * 72 - 90) * Math.PI / 180);
        
        // Draw one petal shape (heart shaped leaf)
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.bezierCurveTo(R * 0.4, -R * 0.6, R * 0.8, -R * 0.4, R * 0.9, -R * 0.15);
        ctx.lineTo(R * 0.8, 0); // notch tip
        ctx.lineTo(R * 0.9, R * 0.15);
        ctx.bezierCurveTo(R * 0.8, R * 0.4, R * 0.4, R * 0.6, 0, 0);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }
      // Small gold core circle
      ctx.beginPath();
      ctx.arc(cx, cy, R * 0.18, 0, 2 * Math.PI);
      ctx.fillStyle = bgColor;
      ctx.fill();
      ctx.stroke();
    } 
    else if (kamonName === "tomoe") {
      // 三つ巴 (Mitsu-Tomoe)
      // Outer ring
      ctx.beginPath();
      ctx.arc(cx, cy, R * 0.9, 0, 2 * Math.PI);
      ctx.stroke();

      // 3 Tomoe tails rotated by 120deg
      for (let i = 0; i < 3; i++) {
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate((i * 120 + 30) * Math.PI / 180);

        // Draw one tomoe commas
        ctx.beginPath();
        // Head circle
        const headR = R * 0.25;
        const offset = R * 0.4;
        ctx.arc(0, -offset, headR, 0, 2 * Math.PI);
        ctx.fill();

        // Wave tail
        ctx.beginPath();
        ctx.arc(0, -offset, headR, Math.PI / 2, -Math.PI / 2, true);
        ctx.bezierCurveTo(R * 0.4, -R * 0.5, R * 0.5, -R * 0.1, R * 0.35, R * 0.25);
        ctx.bezierCurveTo(R * 0.1, R * 0.1, 0, -offset + headR, 0, -offset + headR);
        ctx.fill();
        ctx.restore();
      }
    } 
    else if (kamonName === "kiri") {
      // 五七桐 (Paulownia)
      ctx.save();
      ctx.translate(cx, cy);
      
      // Central leaf and left/right leaves
      // Bottom leaves cluster (3 overlapping shapes)
      ctx.beginPath();
      // Center leaf
      ctx.moveTo(0, R * 0.2);
      ctx.quadraticCurveTo(R * 0.4, R * 0.2, R * 0.4, R * 0.6);
      ctx.quadraticCurveTo(0, R * 0.9, 0, R * 0.9);
      ctx.quadraticCurveTo(0, R * 0.9, -R * 0.4, R * 0.6);
      ctx.quadraticCurveTo(-R * 0.4, R * 0.2, 0, R * 0.2);
      ctx.fill();

      // Left leaf
      ctx.beginPath();
      ctx.moveTo(-R * 0.2, R * 0.3);
      ctx.quadraticCurveTo(-R * 0.7, R * 0.2, -R * 0.8, R * 0.5);
      ctx.quadraticCurveTo(-R * 0.5, R * 0.8, -R * 0.2, R * 0.7);
      ctx.closePath();
      ctx.fill();

      // Right leaf
      ctx.beginPath();
      ctx.moveTo(R * 0.2, R * 0.3);
      ctx.quadraticCurveTo(R * 0.7, R * 0.2, R * 0.8, R * 0.5);
      ctx.quadraticCurveTo(R * 0.5, R * 0.8, R * 0.2, R * 0.7);
      ctx.closePath();
      ctx.fill();

      // 3 flower stalks (central 7 buds, left/right 5 buds)
      function drawStalk(xOffset, yMax, numBuds) {
        ctx.beginPath();
        ctx.moveTo(xOffset, R * 0.3);
        ctx.lineTo(xOffset, -yMax);
        ctx.lineWidth = R * 0.08;
        ctx.stroke();

        // Draw dots for buds
        const step = (yMax + R * 0.1) / numBuds;
        ctx.fillStyle = dotColor;
        for (let j = 0; j < numBuds; j++) {
          const by = -yMax + (j * step);
          ctx.beginPath();
          ctx.arc(xOffset, by, R * 0.09, 0, 2 * Math.PI);
          ctx.fill();
        }
      }

      drawStalk(0, R * 0.7, 7); // Center (7)
      drawStalk(-R * 0.4, R * 0.5, 5); // Left (5)
      drawStalk(R * 0.4, R * 0.5, 5); // Right (5)

      ctx.restore();
    } 
    else if (kamonName === "mokko") {
      // 丸に木瓜 (Mokko / Quince)
      // Outer ring
      ctx.beginPath();
      ctx.arc(cx, cy, R * 0.9, 0, 2 * Math.PI);
      ctx.stroke();

      // Inner二重枠
      ctx.beginPath();
      ctx.arc(cx, cy, R * 0.8, 0, 2 * Math.PI);
      ctx.stroke();

      // Central mokko shapes (4 lobes)
      ctx.save();
      ctx.translate(cx, cy);
      ctx.beginPath();
      for (let i = 0; i < 4; i++) {
        ctx.rotate(Math.PI / 2);
        // Draw one lobe arc
        ctx.arc(0, -R * 0.35, R * 0.25, -Math.PI / 6, Math.PI + Math.PI / 6);
      }
      ctx.closePath();
      ctx.fill();

      // Center gold square / diamond cut
      ctx.beginPath();
      ctx.rect(-R * 0.15, -R * 0.15, R * 0.3, R * 0.3);
      ctx.fillStyle = bgColor;
      ctx.fill();
      ctx.restore();
    }

    ctx.restore();
  }

  // --- 5. Render Core Engine ---
  function drawFullQRCode(targetCanvas, rawQRCanvas, modulesCount) {
    const ctx = targetCanvas.getContext("2d");
    const W = targetCanvas.width;
    const H = targetCanvas.height;

    // 1. Draw solid background
    ctx.fillStyle = config.bgColor;
    ctx.fillRect(0, 0, W, H);

    // 2. Draw watermark pattern (if not none)
    if (config.pattern !== "none") {
      drawWanoPattern(ctx, config.pattern, W, H, config.dotColor, config.patternOpacity);
    }

    // 3. Render QR Code dot matrix from the raw qrcodejs output
    const rawCtx = rawQRCanvas.getContext("2d");
    const rawW = rawQRCanvas.width;
    const rawH = rawQRCanvas.height;

    // Read pixel data to map matrix
    const rawImgData = rawCtx.getImageData(0, 0, rawW, rawH).data;

    // modulesCount is passed in from the QRCode instance itself (see
    // regenerate()/btn-download below) instead of being guessed by scanning
    // for the first pixel color change: the top-left finder pattern's solid
    // black border spans several modules before the color changes at all,
    // so that scan used to report a module size several times too large
    // (e.g. detecting 4 modules instead of the real 29), corrupting the
    // entire rendered QR code into unscannable noise.
    const mSize = rawW / modulesCount;
    const mSizeTarget = W / modulesCount;

    // Draw custom color dot modules
    ctx.fillStyle = config.dotColor;
    for (let r = 0; r < modulesCount; r++) {
      for (let c = 0; c < modulesCount; c++) {
        // Read center pixel of raw module
        const rawX = Math.floor(c * mSize + mSize / 2);
        const rawY = Math.floor(r * mSize + mSize / 2);
        const offset = (rawY * rawW + rawX) * 4;
        
        const rVal = rawImgData[offset];
        const gVal = rawImgData[offset+1];
        const bVal = rawImgData[offset+2];
        const aVal = rawImgData[offset+3];

        // If pixel is dark (qrcode.js generates pure black dots)
        if (rVal < 100 && gVal < 100 && bVal < 100 && aVal > 200) {
          // Render rounded or custom dot module, for premium style we do clean pixels
          ctx.fillRect(c * mSizeTarget, r * mSizeTarget, mSizeTarget + 0.5, mSizeTarget + 0.5);
        }
      }
    }

    // 4. Center Kamon Logo Composition
    if (config.kamon !== "none") {
      // High-error-correction H allows 30% area usage
      // We limit to 24% for maximum safety
      const logoSize = W * 0.24;
      const lx = (W - logoSize) / 2;
      const ly = (H - logoSize) / 2;

      // Draw clean solid background block to clear QR dots under logo
      ctx.fillStyle = config.bgColor;
      ctx.beginPath();
      ctx.arc(W / 2, H / 2, logoSize / 2 + 2, 0, 2 * Math.PI);
      ctx.fill();

      if (config.kamon === "custom" && config.customLogo) {
        // Draw user uploaded image
        ctx.save();
        ctx.beginPath();
        ctx.arc(W / 2, H / 2, logoSize / 2, 0, 2 * Math.PI);
        ctx.clip();
        ctx.drawImage(config.customLogo, lx, ly, logoSize, logoSize);
        ctx.restore();
      } else if (config.kamon !== "custom") {
        // Draw vector family crest
        drawKamon(ctx, config.kamon, W / 2, H / 2, logoSize, config.dotColor, config.bgColor);
      }
    }
  }

  // --- 6. Regenerate & Redraw ---
  function regenerate() {
    // Clear raw qrcode div
    const rawDiv = document.getElementById("raw-qrcode");
    rawDiv.innerHTML = "";

    // Generate base QR code using standard lib (Error Correction = H for center logo overlay)
    lastQR = new QRCode(rawDiv, {
      text: config.text,
      width: 256,
      height: 256,
      colorDark: "#000000",
      colorLight: "#ffffff",
      correctLevel: QRCode.CorrectLevel.H
    });

    // We must wait for qrcodejs to draw on the hidden canvas
    const checkCanvas = () => {
      const rawCanvas = rawDiv.querySelector("canvas");
      if (rawCanvas && rawCanvas.width > 0) {
        // Render live preview on main canvas
        drawFullQRCode(renderCanvas, rawCanvas, lastQR._oQRCode.getModuleCount());
      } else {
        setTimeout(checkCanvas, 30);
      }
    };
    checkCanvas();
  }

  // --- 7. Download High-Res PNG ---
  btnDownload.addEventListener("click", () => {
    const rawDiv = document.getElementById("raw-qrcode");
    const rawCanvas = rawDiv.querySelector("canvas");
    if (!rawCanvas || !lastQR) return;

    // Create a 1024x1024 high resolution canvas
    const hiResCanvas = document.createElement("canvas");
    hiResCanvas.width = 1024;
    hiResCanvas.height = 1024;

    // Draw customized QR code on high-res canvas
    drawFullQRCode(hiResCanvas, rawCanvas, lastQR._oQRCode.getModuleCount());

    // Save image trigger
    const link = document.createElement("a");
    link.download = "japanese_qrcode_" + Date.now() + ".png";
    link.href = hiResCanvas.toDataURL("image/png");
    link.click();
  });
});
