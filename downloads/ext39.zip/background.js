// background.js - Service Worker for Japanese Style QR Code Generator

chrome.runtime.onInstalled.addListener(() => {
  console.log("和風デザインQRコード 拡張機能が正常にインストールされました。");
});
