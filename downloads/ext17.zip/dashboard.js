// dashboard.js - Bookmark 5S Controller, Classifier and Synthesizer

document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const scanBtn = document.getElementById('scan-btn');
  const scoreText = document.getElementById('score-text');
  const evaluationStamp = document.getElementById('evaluation-stamp');
  const statusComment = document.getElementById('status-comment');

  const dupCount = document.getElementById('dup-count');
  const dupList = document.getElementById('dup-list');
  const cleanDupBtn = document.getElementById('clean-dup-btn');

  const brokenCount = document.getElementById('broken-count');
  const brokenList = document.getElementById('broken-list');
  const cleanBrokenBtn = document.getElementById('clean-broken-btn');

  const dormantCount = document.getElementById('dormant-count');
  const dormantList = document.getElementById('dormant-list');
  const cleanDormantBtn = document.getElementById('clean-dormant-btn');

  const titleCount = document.getElementById('title-count');
  const titleList = document.getElementById('title-list');
  const cleanTitlesBtn = document.getElementById('clean-titles-btn');

  const folderGrid = document.getElementById('folder-grid');
  const organizeSeitonBtn = document.getElementById('organize-seiton-btn');

  // Settings Modal Elements
  const settingsBtn = document.getElementById('settings-btn');
  const settingsModal = document.getElementById('settings-modal');
  const modalCloseBtn = document.getElementById('modal-close-btn');
  const settingsCancelBtn = document.getElementById('settings-cancel-btn');
  const settingsSaveBtn = document.getElementById('settings-save-btn');
  
  const settingApiKey = document.getElementById('setting-api-key');
  const testApiBtn = document.getElementById('test-api-btn');
  const apiStatusRow = document.getElementById('api-status-row');
  const apiStatusStamp = document.getElementById('api-status-stamp');
  const apiStatusText = document.getElementById('api-status-text');
  
  const settingModel = document.getElementById('setting-model');
  const settingTimeout = document.getElementById('setting-timeout');
  const settingConcurrency = document.getElementById('setting-concurrency');

  // Seiton AI Elements
  const seitonModeBadge = document.getElementById('seiton-mode-badge');
  const triggerAiClassifyBtn = document.getElementById('trigger-ai-classify-btn');
  const seitonLoadingContainer = document.getElementById('seiton-loading-container');
  const seitonLoadingText = document.getElementById('seiton-loading-text');

  // Tab switching
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const tabId = btn.getAttribute('data-tab');
      tabBtns.forEach(b => b.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));
      
      btn.classList.add('active');
      document.getElementById(tabId).classList.add('active');
    });
  });

  // Global Settings State
  let settings = {
    apiKey: '',
    mode: 'local',
    model: 'gemini-2.5-flash',
    timeout: 5,
    concurrency: 5
  };

  // Global Scan State
  let allBookmarks = [];
  let duplicateGroups = [];
  let dormantBookmarks = [];
  let brokenBookmarks = [];
  let cleanableTitles = [];
  let organizedFolderIds = new Set();
  
  let categorizationGroups = {
    unread: { name: '未読（読書予定）', icon: '📖', items: [] },
    materials: { name: '資料（調べ物）', icon: '📚', items: [] },
    work: { name: '仕事（業務効率）', icon: '💼', items: [] },
    leisure: { name: '娯楽（息抜き）', icon: '🌸', items: [] },
    life: { name: '生活（日常）', icon: '🏠', items: [] }
  };
  
  let currentScore = 100;
  let currentLinkCheckSessionId = 0;
  let isCheckingLinks = false;

  // 0. Settings Management
  function loadSettings(callback) {
    chrome.storage.local.get(['geminiApiKey', 'categorizeMode', 'geminiModel', 'linkTimeout', 'linkConcurrency'], (res) => {
      settings.apiKey = res.geminiApiKey || '';
      settings.mode = res.categorizeMode || 'local';
      settings.model = res.geminiModel || 'gemini-2.5-flash';
      settings.timeout = parseInt(res.linkTimeout) || 5;
      settings.concurrency = parseInt(res.linkConcurrency) || 5;

      // Update Inputs
      settingApiKey.value = settings.apiKey;
      settingModel.value = settings.model;
      settingTimeout.value = settings.timeout;
      settingConcurrency.value = settings.concurrency;
      
      const radio = document.querySelector(`input[name="categorize-mode"][value="${settings.mode}"]`);
      if (radio) radio.checked = true;

      updateSeitonModeUI();

      if (callback) callback();
    });
  }

  function updateSeitonModeUI() {
    if (settings.mode === 'ai') {
      seitonModeBadge.textContent = 'AI分類モード';
      seitonModeBadge.classList.add('ai');
      triggerAiClassifyBtn.classList.remove('hidden');
    } else {
      seitonModeBadge.textContent = 'ローカル分類モード';
      seitonModeBadge.classList.remove('ai');
      triggerAiClassifyBtn.classList.add('hidden');
    }
  }

  function saveSettings() {
    const apiKey = settingApiKey.value.trim();
    const mode = document.querySelector('input[name="categorize-mode"]:checked').value;
    const model = settingModel.value;
    const timeout = parseInt(settingTimeout.value) || 5;
    const concurrency = parseInt(settingConcurrency.value) || 5;

    chrome.storage.local.set({
      geminiApiKey: apiKey,
      categorizeMode: mode,
      geminiModel: model,
      linkTimeout: timeout,
      linkConcurrency: concurrency
    }, () => {
      settings.apiKey = apiKey;
      settings.mode = mode;
      settings.model = model;
      settings.timeout = timeout;
      settings.concurrency = concurrency;
      
      updateSeitonModeUI();
      playSweepSound();
      
      settingsModal.classList.remove('active');
      scanBookmarks();
    });
  }

  // API Connection Test (Using v1 endpoint)
  async function testApiConnection() {
    const apiKey = settingApiKey.value.trim();
    const model = settingModel.value;
    if (!apiKey) {
      alert('APIキーを入力してください。');
      return;
    }

    testApiBtn.disabled = true;
    apiStatusRow.classList.remove('hidden');
    apiStatusStamp.className = 'stamp mini';
    apiStatusStamp.style.borderColor = 'var(--color-gold)';
    apiStatusStamp.style.color = 'var(--color-gold)';
    apiStatusStamp.textContent = '試';
    apiStatusText.textContent = '接続確認中...';

    try {
      const url = `https://generativelanguage.googleapis.com/v1/models/${model}:generateContent?key=${apiKey}`;
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          contents: [{ parts: [{ text: "Respond with exactly 'OK'." }] }]
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error?.message || `HTTP ${response.status}`);
      }

      const data = await response.json();
      const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
      
      if (text.includes('OK') || text.trim().length > 0) {
        apiStatusStamp.textContent = '通';
        apiStatusStamp.style.borderColor = 'var(--color-matsu)';
        apiStatusStamp.style.color = 'var(--color-matsu)';
        apiStatusText.textContent = '接続成功！利用可能です。';
        playRinSound();
      } else {
        throw new Error('応答が空です');
      }
    } catch (err) {
      apiStatusStamp.textContent = '否';
      apiStatusStamp.style.borderColor = 'var(--color-shu)';
      apiStatusStamp.style.color = 'var(--color-shu)';
      apiStatusText.textContent = `接続エラー: ${err.message}`;
    } finally {
      testApiBtn.disabled = false;
    }
  }

  // 1. Find root or child folders belonging to 【5S整頓】
  function findOrganizedFolders() {
    return new Promise((resolve) => {
      organizedFolderIds.clear();
      chrome.bookmarks.search({ title: '【5S整頓】' }, (results) => {
        const rootFolder = results.find(f => !f.url);
        if (!rootFolder) {
          resolve();
          return;
        }
        organizedFolderIds.add(rootFolder.id);
        chrome.bookmarks.getSubTree(rootFolder.id, (subtrees) => {
          if (subtrees && subtrees.length > 0) {
            const traverse = (node) => {
              if (!node.url) {
                organizedFolderIds.add(node.id);
              }
              if (node.children) {
                node.children.forEach(traverse);
              }
            };
            if (subtrees[0].children) {
              subtrees[0].children.forEach(traverse);
            }
          }
          resolve();
        });
      });
    });
  }

  // 2. Scan Bookmarks Logic
  function scanBookmarks() {
    statusComment.textContent = '走査中...';
    statusComment.style.color = 'var(--color-gold)';
    
    // Cancel any previous link checks
    currentLinkCheckSessionId++; 
    isCheckingLinks = false;
    document.getElementById('link-progress-container').classList.add('hidden');

    chrome.bookmarks.getTree(async (tree) => {
      await findOrganizedFolders();

      allBookmarks = [];
      flattenBookmarks(tree[0]);
      
      // Reset lists
      duplicateGroups = [];
      dormantBookmarks = [];
      brokenBookmarks = [];
      cleanableTitles = [];
      Object.keys(categorizationGroups).forEach(k => categorizationGroups[k].items = []);

      // Check duplicates
      analyzeDuplicates();

      // Check titles
      analyzeTitles();

      // Check dormant (obtains visitCount for local categorization)
      await analyzeDormant();

      // Local/Heuristic categorization runs instantly
      analyzeCategoriesLocal();

      // Initial UI Render
      renderUI();

      // Non-blocking Parallel Broken Link Check
      const bookmarksToCheck = [...allBookmarks];
      checkBrokenLinks(bookmarksToCheck, settings.timeout, settings.concurrency);
    });
  }

  // Flatten bookmark tree to list of leaves
  function flattenBookmarks(node) {
    if (node.url) {
      if (organizedFolderIds.has(node.parentId)) {
        node.isOrganized = true;
      } else {
        node.isOrganized = false;
      }
      allBookmarks.push(node);
    }
    if (node.children) {
      node.children.forEach(flattenBookmarks);
    }
  }

  // Analyze: Duplicates
  function analyzeDuplicates() {
    const urlMap = {};
    allBookmarks.forEach(bm => {
      if (!urlMap[bm.url]) urlMap[bm.url] = [];
      urlMap[bm.url].push(bm);
    });

    Object.keys(urlMap).forEach(url => {
      if (urlMap[url].length > 1) {
        duplicateGroups.push(urlMap[url]);
      }
    });
  }

  // Analyze: Dormant (checks Chrome history in a single fast query)
  function analyzeDormant() {
    return new Promise((resolve) => {
      const ninetyDaysAgo = Date.now() - (90 * 24 * 60 * 60 * 1000);
      
      chrome.history.search({
        text: '',
        startTime: 0,
        maxResults: 100000
      }, (historyItems) => {
        const historyMap = new Map();
        if (historyItems) {
          historyItems.forEach(item => {
            historyMap.set(item.url, {
              visitCount: item.visitCount || 0,
              lastVisitTime: item.lastVisitTime || 0
            });
          });
        }

        allBookmarks.forEach(bm => {
          const hist = historyMap.get(bm.url);
          bm.visitCount = hist ? hist.visitCount : 0;
          const lastVisit = hist ? hist.lastVisitTime : 0;

          if (lastVisit === 0 || lastVisit < ninetyDaysAgo) {
            dormantBookmarks.push({
              bookmark: bm,
              lastVisit: lastVisit
            });
          }
        });

        resolve();
      });
    });
  }

  // Analyze: Bloated Titles
  function analyzeTitles() {
    const bloatRegex = /\s*([||\-\u2013\u2014\u2022]|\u300C|\u300D)\s*(official|official site|公式サイト|公式ホームページ|公式|まとめ|ホーム|HOME|検索|Google 検索|Yahoo!検索|検索結果).*/i;
    
    allBookmarks.forEach(bm => {
      if (bloatRegex.test(bm.title)) {
        const cleaned = bm.title.replace(bloatRegex, '').trim();
        if (cleaned && cleaned !== bm.title) {
          cleanableTitles.push({
            bookmark: bm,
            cleaned: cleaned
          });
        }
      }
    });
  }

  // Local/Heuristic Categorization
  function analyzeCategoriesLocal() {
    Object.keys(categorizationGroups).forEach(k => categorizationGroups[k].items = []);

    allBookmarks.forEach(bm => {
      if (bm.isOrganized) return;
      const cat = getLocalCategory(bm);
      categorizationGroups[cat].items.push(bm);
    });
  }

  function getLocalCategory(bm) {
    const url = bm.url.toLowerCase();
    const title = bm.title.toLowerCase();
    
    if (bm.visitCount === 0) return 'unread';

    const workDomains = ['slack', 'teams.microsoft', 'jira', 'trello', 'zoom', 'confluence', 'notion', 'figma', 'drive.google', 'docs.google', 'gmail', 'outlook', 'aws.amazon', 'console.cloud.google', 'backlog', 'sansan', 'chatwork', 'kintone', 'salesforce', 'office.com'];
    const workKeywords = ['業務', '管理', 'ダッシュボード', 'ログイン', 'メール', 'カレンダー', '会議', 'ミーティング', '勤怠', 'プロジェクト', '社内', 'ワーク', 'スケジュール'];
    if (workDomains.some(dom => url.includes(dom)) || workKeywords.some(kw => title.includes(kw))) {
      return 'work';
    }

    const leisureDomains = ['youtube', 'netflix', 'spotify', 'twitch', 'steam', 'twitter', 'x.com', 'instagram', 'facebook', 'reddit', 'pixiv', 'discord', 'tiktok', 'game.yahoo', 'nicovideo', 'syosetu'];
    const leisureKeywords = ['動画', '音楽', 'ゲーム', '漫画', 'コミック', 'アニメ', 'sns', '小説', 'お笑い', '趣味', 'イラスト', 'エンタメ', '映画', 'シネマ', '動画プレイヤー'];
    if (leisureDomains.some(dom => url.includes(dom)) || leisureKeywords.some(kw => title.includes(kw))) {
      return 'leisure';
    }

    const lifeDomains = ['amazon', 'rakuten', 'shopping.yahoo', 'mercari', 'weather.yahoo', 'tabelog', 'hotpepper', 'cookpad', 'suumo', 'jordan', 'navitime', 'bank', 'yucho-bank', 'mufg', 'smbc', 'mizuho', 'post.japanpost', 'kuronekoyamato', 'sagawa-exp'];
    const lifeKeywords = ['天気', '料理', 'レシピ', 'ショッピング', '銀行', '乗換', '路線', '地図', '配送', '配達', '宅配', '予約', '家計', '不動産', '賃貸', 'マップ', '銀行口座'];
    if (lifeDomains.some(dom => url.includes(dom)) || lifeKeywords.some(kw => title.includes(kw))) {
      return 'life';
    }

    return 'materials';
  }

  // AI Categorization Engine (Using v1 endpoint)
  async function runAiCategorization() {
    if (!settings.apiKey) {
      alert('Gemini API キーが設定されていません。[⚙️ 設定] からキーを入力してください。');
      settingsModal.classList.add('active');
      return;
    }

    const bookmarksToClassify = allBookmarks.filter(bm => !bm.isOrganized);
    if (bookmarksToClassify.length === 0) {
      alert('自動分類の対象となる未分類ブックマークがありません。');
      return;
    }

    seitonLoadingContainer.classList.remove('hidden');
    triggerAiClassifyBtn.disabled = true;
    organizeSeitonBtn.disabled = true;
    playSweepSound();

    try {
      const batchSize = 35;
      const batches = [];
      for (let i = 0; i < bookmarksToClassify.length; i += batchSize) {
        batches.push(bookmarksToClassify.slice(i, i + batchSize));
      }

      // Reset categories
      Object.keys(categorizationGroups).forEach(k => categorizationGroups[k].items = []);
      let parsedResults = {};

      for (let b = 0; b < batches.length; b++) {
        const batch = batches[b];
        const formattedList = batch.map(bm => ({ id: bm.id, title: bm.title, url: bm.url }));

        seitonLoadingText.textContent = `AI分析中: ${b + 1} / ${batches.length} グループ目を解析中...`;

        const url = `https://generativelanguage.googleapis.com/v1/models/${settings.model}:generateContent?key=${settings.apiKey}`;
        const systemPrompt = `あなたは優秀なブックマーク整理AIです。提供されたブックマーク一覧を分析し、以下の5つのカテゴリのいずれかに分類してください。

カテゴリの選択基準：
- "unread"（未読・後で読む）: ニュース記事、ブログ記事、後で読もうと保存したと思われるページ。
- "materials"（資料・調べ物）: 技術仕様書、学術論文、Wikipedia、GitHub、辞書、ドキュメント、リファレンス、調査資料。
- "work"（仕事・業務効率）: 業務ツール、カレンダー、メール、Slack、Teams、Jira、Notion、管理画面、社内システム。
- "leisure"（娯楽・趣味・SNS）: SNS (X, Instagram, Facebook)、動画サイト (YouTube, Netflix)、音楽、ゲーム、アニメ、個人ブログ、エンタメ情報。
- "life"（生活・日常）: ネットショッピング (Amazon, 楽天)、ネットバンキング、天気、乗換案内、グルメ予約、生活系サービス。

出力形式：
必ず以下のフォーマットのJSONオブジェクトのみを返してください。マークダウンの\`\`\`jsonのような装飾や余計な説明文は一切含めないでください。

{
  "bookmark_id_1": "unread",
  "bookmark_id_2": "materials",
  "bookmark_id_3": "work"
}

ブックマーク一覧：
${JSON.stringify(formattedList)}`;

        const response = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            contents: [{ parts: [{ text: systemPrompt }] }]
          })
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error?.message || `HTTP ${response.status}`);
        }

        const data = await response.json();
        const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
        const cleanedText = text.replace(/```json|```/g, '').trim();
        const json = JSON.parse(cleanedText);
        Object.assign(parsedResults, json);
      }

      // Map bookmarks
      bookmarksToClassify.forEach(bm => {
        const cat = parsedResults[bm.id];
        if (cat && categorizationGroups[cat]) {
          categorizationGroups[cat].items.push(bm);
        } else {
          // Fallback to Heuristics
          const localCat = getLocalCategory(bm);
          categorizationGroups[localCat].items.push(bm);
        }
      });

      playRinSound();
      renderCategories();
      alert('AIによる分類提案が完了しました！');
    } catch (err) {
      console.error(err);
      alert(`AI分類中にエラーが発生しました: ${err.message}\nローカル分類に切り替えます。`);
      analyzeCategoriesLocal();
      renderCategories();
    } finally {
      seitonLoadingContainer.classList.add('hidden');
      triggerAiClassifyBtn.disabled = false;
      organizeSeitonBtn.disabled = false;
    }
  }

  // Broken Link Verification Loop
  async function checkBrokenLinks(bookmarksToCheck, timeoutSec, concurrency) {
    const sessionId = ++currentLinkCheckSessionId;
    isCheckingLinks = true;
    brokenBookmarks = [];
    renderBroken();

    const progressContainer = document.getElementById('link-progress-container');
    const progressBar = document.getElementById('link-progress-bar');
    const progressText = document.getElementById('link-progress-text');
    const progressPercent = document.getElementById('link-progress-percent');

    progressContainer.classList.remove('hidden');
    progressBar.style.width = '0%';
    progressText.textContent = `🔗 リンク確認中: 0 / ${bookmarksToCheck.length} 件`;
    progressPercent.textContent = '0%';

    let currentIndex = 0;
    let completedCount = 0;

    return new Promise((resolve) => {
      if (bookmarksToCheck.length === 0) {
        progressContainer.classList.add('hidden');
        isCheckingLinks = false;
        resolve();
        return;
      }

      async function worker() {
        while (currentIndex < bookmarksToCheck.length && sessionId === currentLinkCheckSessionId) {
          const index = currentIndex++;
          const bm = bookmarksToCheck[index];

          const isBroken = await verifyUrl(bm.url, timeoutSec);
          
          if (sessionId !== currentLinkCheckSessionId) return;

          if (isBroken) {
            brokenBookmarks.push({ bookmark: bm, reason: isBroken.reason });
            renderBroken();
          }

          completedCount++;
          const percent = Math.round((completedCount / bookmarksToCheck.length) * 100);
          progressBar.style.width = `${percent}%`;
          progressPercent.textContent = `${percent}%`;
          progressText.textContent = `🔗 リンク確認中: ${completedCount} / ${bookmarksToCheck.length} 件`;
        }

        if (completedCount === bookmarksToCheck.length && sessionId === currentLinkCheckSessionId) {
          progressContainer.classList.add('hidden');
          isCheckingLinks = false;
          resolve();
        }
      }

      const numWorkers = Math.min(concurrency, bookmarksToCheck.length);
      for (let w = 0; w < numWorkers; w++) {
        worker();
      }
    });
  }

  async function verifyUrl(url, timeoutSec) {
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      return { broken: true, reason: '非サポート形式' };
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutSec * 1000);

    try {
      // Use GET method to check link validity
      // credentials: 'omit' is CRITICAL to prevent Basic Auth login prompts from appearing
      const response = await fetch(url, {
        method: 'GET',
        signal: controller.signal,
        credentials: 'omit',
        headers: {
          'Cache-Control': 'no-cache'
        }
      });
      clearTimeout(timeoutId);
      
      if (response.status >= 400) {
        return { broken: true, reason: `HTTP ${response.status} エラー` };
      }
      return null;
    } catch (error) {
      clearTimeout(timeoutId);
      if (error.name === 'AbortError') {
        return { broken: true, reason: '時間超過 (Timeout)' };
      }
      return { broken: true, reason: '接続不能 (DNS/CORS/Down)' };
    }
  }

  // 3. Render UI
  function renderUI() {
    renderDuplicates();
    renderDormant();
    renderBroken();
    renderTitles();
    renderCategories();

    // Calculate score
    calculateScore();
    
    // Play sound on scan loaded (subtle sweep)
    playSweepSound();
  }

  // Render list: Duplicates
  function renderDuplicates() {
    dupList.innerHTML = '';
    let totalDups = 0;
    
    duplicateGroups.forEach(group => {
      const original = group[0];
      const duplicates = group.slice(1);
      totalDups += duplicates.length;

      duplicates.forEach(dup => {
        const item = document.createElement('div');
        item.className = 'tidy-item';
        
        item.innerHTML = `
          <div class="tidy-item-info">
            <span class="tidy-item-title">${dup.title}</span>
            <span class="tidy-item-url">${dup.url}</span>
            <span class="tidy-item-detail">重複 (オリジナル: ${original.title})</span>
          </div>
          <div class="tidy-item-action">
            <button class="peel-single-btn" data-id="${dup.id}">剥がす</button>
          </div>
        `;

        item.querySelector('.peel-single-btn').addEventListener('click', () => {
          deleteSingleBookmark(dup.id, () => {
            scanBookmarks();
          });
        });

        dupList.appendChild(item);
      });
    });

    if (totalDups === 0) {
      dupList.innerHTML = `
        <div class="empty-placeholder">
          <div class="empty-icon">✨</div>
          <p>重複するブックマークはありません</p>
        </div>
      `;
    }

    dupCount.textContent = totalDups;
    cleanDupBtn.disabled = totalDups === 0;
  }

  // Render list: Broken Links
  function renderBroken() {
    brokenList.innerHTML = '';
    brokenCount.textContent = brokenBookmarks.length;

    brokenBookmarks.forEach(item => {
      const bm = item.bookmark;
      const div = document.createElement('div');
      div.className = 'tidy-item';
      div.innerHTML = `
        <div class="tidy-item-info">
          <span class="tidy-item-title">${bm.title}</span>
          <span class="tidy-item-url">${bm.url}</span>
          <span class="tidy-item-detail" style="color:var(--color-shu);">状態: ${item.reason}</span>
        </div>
        <div class="tidy-item-action">
          <button class="peel-single-btn" data-id="${bm.id}">処分</button>
        </div>
      `;

      div.querySelector('.peel-single-btn').addEventListener('click', () => {
        deleteSingleBookmark(bm.id, () => {
          scanBookmarks();
        });
      });

      brokenList.appendChild(div);
    });

    if (brokenBookmarks.length === 0) {
      if (isCheckingLinks) {
        brokenList.innerHTML = `
          <div class="empty-placeholder">
            <div class="empty-icon">🔄</div>
            <p>生存状況を確認中...</p>
          </div>
        `;
      } else {
        brokenList.innerHTML = `
          <div class="empty-placeholder">
            <div class="empty-icon">✅</div>
            <p>リンク切れブックマークはありません</p>
          </div>
        `;
      }
    }

    cleanBrokenBtn.disabled = brokenBookmarks.length === 0;
    
    // Recalculate score during dynamic loading
    calculateScore();
  }

  // Render list: Dormant
  function renderDormant() {
    dormantList.innerHTML = '';
    dormantCount.textContent = dormantBookmarks.length;

    dormantBookmarks.forEach(item => {
      const bm = item.bookmark;
      const days = item.lastVisit === 0 ? '履歴なし' : `${Math.round((Date.now() - item.lastVisit) / (24 * 60 * 60 * 1000))}日前`;

      const div = document.createElement('div');
      div.className = 'tidy-item';
      div.innerHTML = `
        <div class="tidy-item-info">
          <span class="tidy-item-title">${bm.title}</span>
          <span class="tidy-item-url">${bm.url}</span>
          <span class="tidy-item-detail">最終訪問: ${days}</span>
        </div>
        <div class="tidy-item-action">
          <button class="peel-single-btn" data-id="${bm.id}">間引く</button>
        </div>
      `;

      div.querySelector('.peel-single-btn').addEventListener('click', () => {
        deleteSingleBookmark(bm.id, () => {
          scanBookmarks();
        });
      });

      dormantList.appendChild(div);
    });

    if (dormantBookmarks.length === 0) {
      dormantList.innerHTML = `
        <div class="empty-placeholder">
          <div class="empty-icon">🌱</div>
          <p>休眠ブックマークはありません</p>
        </div>
      `;
    }

    cleanDormantBtn.disabled = dormantBookmarks.length === 0;
  }

  // Render list: Titles
  function renderTitles() {
    titleList.innerHTML = '';
    titleCount.textContent = cleanableTitles.length;

    cleanableTitles.forEach(item => {
      const bm = item.bookmark;
      const div = document.createElement('div');
      div.className = 'tidy-item';
      div.innerHTML = `
        <div class="tidy-item-info">
          <div class="clean-comparer">
            <span class="clean-before">${bm.title}</span>
            <span class="clean-arrow">➡️</span>
            <span class="clean-after">${item.cleaned}</span>
          </div>
          <span class="tidy-item-url">${bm.url}</span>
        </div>
        <div class="tidy-item-action">
          <button class="peel-single-btn" data-id="${bm.id}">清掃</button>
        </div>
      `;

      div.querySelector('.peel-single-btn').addEventListener('click', () => {
        cleanSingleTitle(bm.id, item.cleaned, () => {
          scanBookmarks();
        });
      });

      titleList.appendChild(div);
    });

    if (cleanableTitles.length === 0) {
      titleList.innerHTML = `
        <div class="empty-placeholder">
          <div class="empty-icon">🧹</div>
          <p>清掃が必要なタイトルはありません</p>
        </div>
      `;
    }

    cleanTitlesBtn.disabled = cleanableTitles.length === 0;
  }

  // Render list: Categories
  function renderCategories() {
    folderGrid.innerHTML = '';
    let totalItems = 0;

    Object.keys(categorizationGroups).forEach(key => {
      const group = categorizationGroups[key];
      if (group.items.length === 0) return;
      totalItems += group.items.length;

      const box = document.createElement('div');
      box.className = 'folder-box';

      box.innerHTML = `
        <div class="folder-box-header">
          <span class="folder-box-title">${group.icon} ${group.name}</span>
          <span class="folder-box-count">${group.items.length}件</span>
        </div>
        <div class="folder-box-list">
          ${group.items.map(bm => `<div class="folder-bookmark-item" title="${bm.url}">${bm.title}</div>`).join('')}
        </div>
      `;

      folderGrid.appendChild(box);
    });

    if (totalItems === 0) {
      folderGrid.innerHTML = '<div style="grid-column: span 3; text-align: center; color: var(--color-matsu); padding: 40px 0; font-weight: bold; font-family: \'Hiragino Mincho ProN\', \'Yu Mincho\', serif;">全てのフォルダ整頓が行き届いています！</div>';
    }

    organizeSeitonBtn.disabled = totalItems === 0;
  }

  // Delete Bookmark
  function deleteSingleBookmark(id, callback) {
    playSweepSound();
    chrome.bookmarks.remove(id, () => {
      callback();
    });
  }

  // Clean title
  function cleanSingleTitle(id, newTitle, callback) {
    playSweepSound();
    chrome.bookmarks.update(id, { title: newTitle }, () => {
      callback();
    });
  }

  // 4. Batch cleaners
  cleanDupBtn.addEventListener('click', () => {
    if (confirm("重複している古いブックマークを一括削除しますか？")) {
      playSweepSound();
      let deleteCount = 0;
      let targetCount = 0;

      duplicateGroups.forEach(group => {
        const duplicates = group.slice(1);
        targetCount += duplicates.length;
        duplicates.forEach(dup => {
          chrome.bookmarks.remove(dup.id, () => {
            deleteCount++;
            if (deleteCount === targetCount) {
              scanBookmarks();
            }
          });
        });
      });
    }
  });

  cleanBrokenBtn.addEventListener('click', () => {
    if (confirm("アクセスできないすべてのリンク切れブックマークを削除しますか？")) {
      playSweepSound();
      let deleteCount = 0;
      const targetCount = brokenBookmarks.length;

      brokenBookmarks.forEach(item => {
        chrome.bookmarks.remove(item.bookmark.id, () => {
          deleteCount++;
          if (deleteCount === targetCount) {
            scanBookmarks();
          }
        });
      });
    }
  });

  cleanDormantBtn.addEventListener('click', () => {
    if (confirm("長期間アクセスしていないすべての休眠ブックマークを削除しますか？")) {
      playSweepSound();
      let deleteCount = 0;
      const targetCount = dormantBookmarks.length;

      dormantBookmarks.forEach(item => {
        chrome.bookmarks.remove(item.bookmark.id, () => {
          deleteCount++;
          if (deleteCount === targetCount) {
            scanBookmarks();
          }
        });
      });
    }
  });

  cleanTitlesBtn.addEventListener('click', () => {
    if (confirm("スリム化可能なタイトルを一括清掃しますか？")) {
      playSweepSound();
      let cleanCount = 0;
      const targetCount = cleanableTitles.length;

      cleanableTitles.forEach(item => {
        chrome.bookmarks.update(item.bookmark.id, { title: item.cleaned }, () => {
          cleanCount++;
          if (cleanCount === targetCount) {
            scanBookmarks();
          }
        });
      });
    }
  });

  // Action: Seiton automatic folders
  organizeSeitonBtn.addEventListener('click', () => {
    playSweepSound();
    statusComment.textContent = '整頓中...';
    
    // Create top level folder "【5S整頓】" if not exists
    chrome.bookmarks.search({ title: '【5S整頓】' }, (results) => {
      let rootFolderId;
      const existing = results.find(f => !f.url);

      if (existing) {
        rootFolderId = existing.id;
        proceedToCreateSubfolders(rootFolderId);
      } else {
        // Create new root folder in Bookmark Bar ("1" is usually the parent of bookmark bar "2")
        chrome.bookmarks.create({ parentId: '1', title: '【5S整頓】' }, (newFolder) => {
          rootFolderId = newFolder.id;
          proceedToCreateSubfolders(rootFolderId);
        });
      }
    });
  });

  function proceedToCreateSubfolders(rootId) {
    let completedCount = 0;
    const activeGroups = Object.keys(categorizationGroups).filter(k => categorizationGroups[k].items.length > 0);

    if (activeGroups.length === 0) {
      scanBookmarks();
      return;
    }

    activeGroups.forEach(key => {
      const group = categorizationGroups[key];
      chrome.bookmarks.create({ parentId: rootId, title: group.name }, (subfolder) => {
        let moved = 0;
        group.items.forEach(bm => {
          chrome.bookmarks.move(bm.id, { parentId: subfolder.id }, () => {
            moved++;
            if (moved === group.items.length) {
              completedCount++;
              if (completedCount === activeGroups.length) {
                scanBookmarks();
              }
            }
          });
        });
      });
    });
  }

  // 5. Calculate health score
  function calculateScore() {
    const totalDups = duplicateGroups.reduce((acc, g) => acc + g.length - 1, 0);
    const totalDormant = dormantBookmarks.length;
    const totalBroken = brokenBookmarks.length;
    const totalTitles = cleanableTitles.length;

    let deductions = 0;

    if (allBookmarks.length > 0) {
      deductions += (totalDups * 5);
      deductions += (totalDormant * 1);
      deductions += (totalBroken * 8);
      deductions += (totalTitles * 1.5);
    }

    currentScore = Math.max(0, Math.min(100, Math.round(100 - deductions)));
    scoreText.textContent = currentScore;

    // Draw Score brush arc
    drawScoreBrushArc(currentScore);

    // Set evaluation
    let evalText = '可';
    let evalComment = '整理の余地あり';
    let commentColor = 'var(--color-shu)';

    if (currentScore === 100) {
      evalText = '極';
      evalComment = '完璧な整頓状態！';
      commentColor = 'var(--color-matsu)';
      
      // Play Rin bell chime on 100 score completion
      if (totalDups === 0 && totalDormant === 0 && totalBroken === 0 && totalTitles === 0) {
        playRinSound();
      }
    } else if (currentScore >= 90) {
      evalText = '優';
      evalComment = '大変素晴らしい状態です';
      commentColor = 'var(--color-matsu)';
    } else if (currentScore >= 75) {
      evalText = '良';
      evalComment = '良好。あと一歩です';
      commentColor = 'var(--color-gold)';
    }

    evaluationStamp.textContent = evalText;
    statusComment.textContent = evalComment;
    statusComment.style.color = commentColor;

    // Draw Bonsai Garden
    drawBonsai(currentScore);
  }

  // 6. Draw Brush Circle for Kakejiku
  function drawScoreBrushArc(score) {
    const canvas = document.getElementById('score-brush-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const cx = canvas.width / 2;
    const cy = canvas.height / 2;
    const radius = 40;

    // Calligraphy brush ring stroke
    ctx.strokeStyle = 'rgba(162, 43, 43, 0.85)';
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';

    ctx.beginPath();
    const startAngle = -Math.PI / 2;
    const endAngle = startAngle + (2 * Math.PI * (score / 100));
    
    ctx.arc(cx, cy, radius, startAngle, endAngle);
    ctx.stroke();

    ctx.strokeStyle = 'rgba(162, 43, 43, 0.2)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(cx, cy, radius - 2, startAngle, endAngle);
    ctx.stroke();
  }

  // 7. Draw Canvas Bonsai
  function drawBonsai(score) {
    const canvas = document.getElementById('bonsai-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // POT (鉢)
    ctx.fillStyle = '#5a4b41';
    ctx.beginPath();
    ctx.moveTo(50, 160);
    ctx.lineTo(170, 160);
    ctx.lineTo(150, 175);
    ctx.lineTo(70, 175);
    ctx.closePath();
    ctx.fill();

    // Pot gold rim
    ctx.fillStyle = '#b39556';
    ctx.fillRect(48, 157, 124, 3);

    // TRUNK (幹)
    ctx.strokeStyle = '#3e2f24';
    ctx.lineWidth = 8;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(110, 158);
    ctx.quadraticCurveTo(100, 110, 130, 90);
    ctx.stroke();

    // Branches
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(115, 120);
    ctx.quadraticCurveTo(80, 110, 75, 95);
    ctx.moveTo(125, 100);
    ctx.quadraticCurveTo(155, 90, 160, 75);
    ctx.moveTo(130, 90);
    ctx.lineTo(135, 70);
    ctx.stroke();

    // LEAVES Clumps (葉)
    let leafColor = 'rgba(52, 92, 50, 0.9)';
    let leafShadow = 'rgba(30, 60, 30, 0.4)';
    
    if (score < 60) {
      leafColor = 'rgba(163, 140, 60, 0.85)';
      leafShadow = 'rgba(100, 90, 30, 0.3)';
    } else if (score < 80) {
      leafColor = 'rgba(100, 120, 60, 0.9)';
      leafShadow = 'rgba(50, 70, 30, 0.4)';
    }

    drawLeafCloud(ctx, 75, 90, 22, leafColor, leafShadow);
    drawLeafCloud(ctx, 160, 70, 24, leafColor, leafShadow);
    drawLeafCloud(ctx, 135, 65, 26, leafColor, leafShadow);

    // Flowers depending on score
    if (score >= 90) {
      ctx.fillStyle = '#ffb3c6';
      ctx.beginPath();
      ctx.arc(65, 82, 3, 0, 2*Math.PI);
      ctx.arc(80, 98, 2.5, 0, 2*Math.PI);
      ctx.arc(150, 62, 3, 0, 2*Math.PI);
      ctx.arc(170, 78, 2, 0, 2*Math.PI);
      ctx.arc(130, 52, 3.5, 0, 2*Math.PI);
      ctx.arc(142, 60, 2.5, 0, 2*Math.PI);
      ctx.fill();
    } else if (score < 60) {
      ctx.fillStyle = 'rgba(139, 90, 43, 0.7)';
      ctx.beginPath();
      ctx.ellipse(85, 130, 4, 2, Math.PI/4, 0, 2*Math.PI);
      ctx.ellipse(145, 140, 4.5, 2, -Math.PI/6, 0, 2*Math.PI);
      ctx.fill();
    }
  }

  function drawLeafCloud(ctx, x, y, size, fillCol, shadowCol) {
    ctx.fillStyle = shadowCol;
    ctx.beginPath();
    ctx.arc(x - 5, y + 2, size * 0.75, 0, 2*Math.PI);
    ctx.arc(x + 5, y + 4, size * 0.7, 0, 2*Math.PI);
    ctx.fill();

    ctx.fillStyle = fillCol;
    ctx.beginPath();
    ctx.arc(x, y, size * 0.8, 0, 2*Math.PI);
    ctx.arc(x - 8, y - 2, size * 0.6, 0, 2*Math.PI);
    ctx.arc(x + 8, y - 2, size * 0.6, 0, 2*Math.PI);
    ctx.fill();
  }

  // 8. --- Web Audio API Synth Engines ---
  let audioCtx = null;

  function initAudio() {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
  }

  // Sweep sound (竹箒でザッザッと掃く音)
  function playSweepSound() {
    try {
      initAudio();
      const now = audioCtx.currentTime;
      const duration = 0.35;
      const bufferSize = audioCtx.sampleRate * duration;
      const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
      const data = buffer.getChannelData(0);

      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const noise = audioCtx.createBufferSource();
      noise.buffer = buffer;

      const filter = audioCtx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1000, now);
      filter.frequency.exponentialRampToValueAtTime(350, now + duration);
      filter.Q.value = 1.5;

      const gain = audioCtx.createGain();
      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.22, now + 0.06);
      gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(audioCtx.destination);

      noise.start(now);
    } catch (e) {
      console.warn(e);
    }
  }

  // Rin bell chime (チーン...)
  function playRinSound() {
    try {
      initAudio();
      const now = audioCtx.currentTime;
      const frequencies = [680, 1360, 2040, 2720];

      frequencies.forEach((f, idx) => {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(f, now);

        const amplitude = idx === 0 ? 0.25 : 0.08 / idx;
        const decay = 2.5 / (idx + 1);

        gain.gain.setValueAtTime(amplitude, now);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + decay);

        osc.connect(gain);
        gain.connect(audioCtx.destination);

        osc.start(now);
        osc.stop(now + decay + 0.1);
      });
    } catch (e) {
      console.warn(e);
    }
  }

  // 9. Event Listeners Setup
  scanBtn.addEventListener('click', () => {
    scanBookmarks();
  });

  // Settings Modal Events
  settingsBtn.addEventListener('click', () => {
    loadSettings(() => {
      // Clear connection test status on open
      apiStatusRow.classList.add('hidden');
      settingsModal.classList.add('active');
    });
  });

  modalCloseBtn.addEventListener('click', () => {
    settingsModal.classList.remove('active');
  });

  settingsCancelBtn.addEventListener('click', () => {
    settingsModal.classList.remove('active');
  });

  settingsSaveBtn.addEventListener('click', () => {
    saveSettings();
  });

  testApiBtn.addEventListener('click', () => {
    testApiConnection();
  });

  triggerAiClassifyBtn.addEventListener('click', () => {
    runAiCategorization();
  });

  // Initialize
  loadSettings(() => {
    scanBookmarks();
  });
});
