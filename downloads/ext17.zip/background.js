// background.js - Bookmark 5S background runner

chrome.action.onClicked.addListener((tab) => {
  chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") });
});

// Watch bookmark creations
chrome.bookmarks.onCreated.addListener((id, bookmark) => {
  // Let the user know on dashboard if they have it open
  chrome.runtime.sendMessage({ action: 'bookmarkCreated', id, bookmark });
});
