/**
 * license-manager.js
 * 
 * 共通のライセンスおよびトライアル管理ロジック。
 * すべての拡張機能で使い回されます。
 */

const PROXY_SERVER_URL = 'https://wano-license-proxy.a-torisawa.workers.dev'; // 本番デプロイ時に中継サーバーのURLを設定

const TRIAL_DAYS = 14;      // 通常お試し期間（日）
const EXTENSION_DAYS = 7;   // メール登録による延長期間（日）

class LicenseManager {
  /**
   * 初期化：インストール日をローカルストレージに設定
   */
  static async init() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['installTimestamp', 'isPremium', 'emailRegistered'], (result) => {
        const updates = {};
        if (!result.installTimestamp) {
          updates.installTimestamp = Date.now();
        }
        if (Object.keys(updates).length > 0) {
          chrome.storage.local.set(updates, () => {
            resolve(updates.installTimestamp || result.installTimestamp);
          });
        } else {
          resolve(result.installTimestamp);
        }
      });
    });
  }

  /**
   * トライアル状態をチェックする
   * @returns {Promise<{ status: 'trial'|'expired'|'premium', daysLeft: number }>}
   */
  static async checkStatus() {
    await this.init();
    return new Promise((resolve) => {
      chrome.storage.local.get(
        ['installTimestamp', 'isPremium', 'emailRegistered', 'licenseKey'],
        (result) => {
          // 1. すでにプレミアム（プロ版）の場合
          if (result.isPremium) {
            return resolve({ status: 'premium', daysLeft: 9999 });
          }

          const installDate = new Date(result.installTimestamp);
          const now = new Date();
          const msPassed = now.getTime() - installDate.getTime();
          const daysPassed = msPassed / (1000 * 60 * 60 * 24);

          // メール登録があれば延長期間を適用
          const totalTrialDays = result.emailRegistered ? (TRIAL_DAYS + EXTENSION_DAYS) : TRIAL_DAYS;
          const daysLeft = Math.ceil(totalTrialDays - daysPassed);

          if (daysLeft > 0) {
            resolve({ status: 'trial', daysLeft: daysLeft });
          } else {
            resolve({ status: 'expired', daysLeft: 0 });
          }
        }
      );
    });
  }

  /**
   * ライセンスキーの検証
   * @param {string} licenseKey 
   * @returns {Promise<{ success: boolean, message: string }>}
   */
  static async verifyLicense(licenseKey) {
    if (!licenseKey || licenseKey.trim() === '') {
      return { success: false, message: 'ライセンスキーを入力してください。' };
    }

    try {
      const response = await fetch(`${PROXY_SERVER_URL}/api/verify-license`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          license_key: licenseKey.trim(),
          instance_name: 'Chrome Extension'
        })
      });

      const result = await response.json();

      // Lemon Squeezy の検証成功判定
      if (response.ok && result.valid) {
        // --- 商品ID（Product ID）の検証 ---
        const meta = result.meta || {};
        const purchasedProductId = String(meta.product_id || '');

        // window.LicenseConfig が定義されているかチェック
        const config = window.LicenseConfig || {};
        const expectedProductId = String(config.productId || '');
        const allToolsProductId = String(config.allToolsProductId || '');

        // 期待する商品IDまたは全ツールパック商品IDのいずれにも一致しない場合は弾く
        if (expectedProductId && allToolsProductId) {
          if (purchasedProductId !== expectedProductId && purchasedProductId !== allToolsProductId) {
            return { 
              success: false, 
              message: 'このライセンスキーはこの拡張機能には対応していません。(別の製品のキーです)' 
            };
          }
        }

        // 認証成功時にプレミアム状態とインスタンスIDを保存
        const instanceId = result.instance ? result.instance.id : '';
        await new Promise((resolve) => {
          chrome.storage.local.set({
            isPremium: true,
            licenseKey: licenseKey.trim(),
            licenseInstanceId: instanceId
          }, resolve);
        });
        return { success: true, message: 'ライセンス認証に成功しました！プロ版をご利用いただけます。' };
      } else {
        const errorMsg = result.error || '無効なライセンスキーです。';
        return { success: false, message: errorMsg };
      }
    } catch (e) {
      console.error(e);
      return { success: false, message: '認証サーバーとの通信に失敗しました。時間をおいて再度お試しください。' };
    }
  }

  /**
   * メールアドレスの登録（方法③：トライアル延長）
   * @param {string} email 
   * @returns {Promise<{ success: boolean, message: string }>}
   */
  static async registerEmail(email) {
    if (!email || !email.includes('@')) {
      return { success: false, message: '有効なメールアドレスを入力してください。' };
    }

    try {
      const response = await fetch(`${PROXY_SERVER_URL}/api/register-email`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim(), name: 'Trial User' })
      });

      const result = await response.json();

      if (response.ok) {
        await new Promise((resolve) => {
          chrome.storage.local.set({
            emailRegistered: true,
            userEmail: email.trim()
          }, resolve);
        });
        return { success: true, message: `メール登録が完了しました！無料体験期間が ${EXTENSION_DAYS} 日間延長されました。` };
      } else {
        const errorMsg = result.error || '登録に失敗しました。';
        return { success: false, message: errorMsg };
      }
    } catch (e) {
      console.error(e);
      return { success: false, message: '通信に失敗しました。ネット環境を確認してください。' };
    }
  }

  /**
   * ライセンス認証の解除 (PCの紐付け解除)
   * @returns {Promise<{ success: boolean, message: string }>}
   */
  static async deactivateLicense() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['licenseKey', 'licenseInstanceId'], async (result) => {
        const key = result.licenseKey;
        const instanceId = result.licenseInstanceId;

        if (!key) {
          return resolve({ success: false, message: 'アクティブなライセンスキーが見つかりません。' });
        }

        // インスタンスIDがない場合は、ローカル情報だけ削除して終了する
        if (!instanceId) {
          chrome.storage.local.remove(['isPremium', 'licenseKey', 'licenseInstanceId'], () => {
            resolve({ success: true, message: 'ライセンス情報をローカルから削除しました。' });
          });
          return;
        }

        try {
          const response = await fetch(`${PROXY_SERVER_URL}/api/deactivate-license`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              license_key: key,
              instance_id: instanceId
            })
          });

          const resData = await response.json();

          if (response.ok) {
            // ローカルストレージのライセンス情報を削除
            chrome.storage.local.remove(['isPremium', 'licenseKey', 'licenseInstanceId'], () => {
              resolve({ success: true, message: 'ライセンス認証を正常に解除しました。新しいPCで再利用可能です。' });
            });
          } else {
            const errorMsg = resData.error || 'サーバーでの解除処理に失敗しました。';
            resolve({ success: false, message: errorMsg });
          }
        } catch (e) {
          console.error(e);
          resolve({ success: false, message: '解除サーバーとの通信に失敗しました。ネット環境を確認してください。' });
        }
      });
    });
  }
}

// 共通インポートできるようにESモジュールまたはグローバルオブジェクトとして公開
if (typeof module !== 'undefined' && typeof module.exports !== 'undefined') {
  module.exports = LicenseManager;
} else {
  window.LicenseManager = LicenseManager;
}
