



// ============================================
// ふるさと納税一括シミュレーター — Popup JS
// ============================================

document.addEventListener("DOMContentLoaded", () => {
  // Mode Tabs
  const tabSimple = document.getElementById("tab-simple");
  const tabDetail = document.getElementById("tab-detail");
  const simpleGroup = document.getElementById("simple-input-group");
  const detailGroup = document.getElementById("detail-input-group");

  // Simple Inputs
  const incomeSlider = document.getElementById("income-slider");
  const incomeVal = document.getElementById("income-val");
  const familyBtns = document.querySelectorAll(".family-btn");

  // Detailed Inputs
  const taxInput = document.getElementById("tax-input");
  const helpTrigger = document.getElementById("help-trigger");
  const helpBox = document.getElementById("help-box");

  // Output Displays
  const limitAmountDisp = document.getElementById("limit-amount");
  const barSelf = document.getElementById("bar-self");
  const barIncome = document.getElementById("bar-income");
  const barResident = document.getElementById("bar-resident");
  
  const legendSelfVal = document.getElementById("legend-self-val");
  const legendIncomeVal = document.getElementById("legend-income-val");
  const legendResidentVal = document.getElementById("legend-resident-val");

  // Portal values
  const rakutenValDisp = document.getElementById("rakuten-val");
  const furunaviValDisp = document.getElementById("furunavi-val");

  // Combo elements
  const comboTypeSelect = document.getElementById("combo-type-select");
  const comboListContainer = document.getElementById("combo-list-container");
  const comboTotalDisp = document.getElementById("combo-total-amount");
  const comboRemainingDisp = document.getElementById("combo-remaining-limit");

  // 1. Core State
  let state = {
    mode: "simple", // simple | detail
    income: 500,    // 200 - 2000 (ten-thousand yen)
    family: "single", // single | couple | child1 | couple-child1 | couple-child2
    tax: 300000,    // yen
    limitAmount: 0
  };

  // 2. Official Furusato Deduction Lookup Table (MIC guidelines)
  // Format: IncomeKey: [Single/DoubleIncome, Couple, DoubleIncome+Child1, Couple+Child1, Couple+Child2]
  // Indices: 0=single, 1=couple, 2=child1, 3=couple-child1, 4=couple-child2
  const LIMIT_TABLE = {
    300: [28000, 19000, 15000, 11000, 7000],
    400: [42000, 33000, 29000, 25000, 21000],
    500: [61000, 49000, 44000, 40000, 36000],
    600: [77000, 69000, 66000, 60000, 57000],
    700: [108000, 86000, 83000, 78000, 74000],
    800: [129000, 120000, 116000, 110000, 106000],
    900: [152000, 143000, 139000, 133000, 129000],
    1000: [176000, 166000, 162000, 156000, 152000],
    1200: [244000, 234000, 230000, 224000, 220000],
    1500: [389000, 382000, 378000, 372000, 368000],
    2000: [649000, 642000, 638000, 632000, 628000]
  };

  const FAMILY_INDEX_MAP = {
    "single": 0,
    "couple": 1,
    "child1": 2,
    "couple-child1": 3,
    "couple-child2": 4
  };

  // Return Gift Database
  const COMBO_DATABASE = {
    gourmet: [
      { id: "g1", name: "北海道産特大ホタテ玉冷 1kg", price: 12000 },
      { id: "g2", name: "新潟産コシヒカリ 新米 15kg", price: 15000 },
      { id: "g3", name: "極上黒毛和牛カルビ＆ハラミ焼肉セット 1kg", price: 15000 },
      { id: "g4", name: "九州産こだわり豚肉バラエティセット 4kg", price: 10000 },
      { id: "g5", name: "特上いくら醤油漬け 500g", price: 10000 },
      { id: "g6", name: "博多本格牛もつ鍋セット 6人前", price: 8000 }
    ],
    daily: [
      { id: "d1", name: "大容量エリエールティシュー 60箱", price: 15000 },
      { id: "d2", name: "プレミアムトイレットペーパー 96ロール", price: 12000 },
      { id: "d3", name: "アサヒスーパードライ 缶ビール 24本", price: 16000 },
      { id: "d4", name: "アタック抗菌EX 洗剤詰替セット", price: 10000 },
      { id: "d5", name: "強炭酸水プレーン 500ml 48本", price: 8000 }
    ],
    luxury: [
      { id: "l1", name: "極太アブラタラバガニ脚 1kg", price: 25000 },
      { id: "l2", name: "宮崎牛 A5ランク極上サーロイン 400g", price: 20000 },
      { id: "l3", name: "山梨産 厳選シャインマスカット 2房", price: 12000 },
      { id: "l4", name: "クラウンメロン 静岡産 特大極上玉", price: 10000 },
      { id: "l5", name: "三陸産無添加生うに 瓶詰め極上セット", price: 10000 }
    ]
  };

  // 3. Tab Switching
  tabSimple.addEventListener("click", () => {
    switchMode("simple");
  });

  tabDetail.addEventListener("click", () => {
    switchMode("detail");
  });

  function switchMode(mode) {
    state.mode = mode;
    if (mode === "simple") {
      tabSimple.classList.add("active");
      tabDetail.classList.remove("active");
      simpleGroup.classList.add("active");
      detailGroup.classList.remove("active");
    } else {
      tabSimple.classList.remove("active");
      tabDetail.classList.add("active");
      simpleGroup.classList.remove("active");
      detailGroup.classList.add("active");
    }
    calculateLimit();
    saveState();
  }

  // 4. Detailed Help Popover Toggle
  helpTrigger.addEventListener("click", (e) => {
    e.stopPropagation();
    helpBox.classList.toggle("active");
  });

  document.addEventListener("click", () => {
    helpBox.classList.remove("active");
  });

  // 5. Income Slider Change
  incomeSlider.addEventListener("input", (e) => {
    state.income = parseInt(e.target.value);
    incomeVal.textContent = state.income;
    calculateLimit();
    saveState();
  });

  // 6. Family Structure Buttons Change
  familyBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      familyBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      state.family = btn.getAttribute("data-family");
      calculateLimit();
      saveState();
    });
  });

  // 7. Resident Tax input Change
  taxInput.addEventListener("input", (e) => {
    state.tax = Math.max(0, parseInt(e.target.value) || 0);
    calculateLimit();
    saveState();
  });

  // 8. Restore state from local storage on load
  chrome.storage.local.get(["furusatoState"], (data) => {
    if (data && data.furusatoState) {
      const saved = data.furusatoState;
      state.mode = saved.mode || "simple";
      state.income = saved.income || 500;
      state.family = saved.family || "single";
      state.tax = saved.tax !== undefined ? saved.tax : 300000;

      // Hydrate HTML
      incomeSlider.value = state.income;
      incomeVal.textContent = state.income;
      taxInput.value = state.tax;

      familyBtns.forEach(btn => {
        if (btn.getAttribute("data-family") === state.family) {
          btn.classList.add("active");
        } else {
          btn.classList.remove("active");
        }
      });

      switchMode(state.mode);
    } else {
      calculateLimit();
    }
  });

  function saveState() {
    chrome.storage.local.set({ furusatoState: state });
  }

  // 9. Primary Limit Calculations
  function calculateLimit() {
    let limit = 0;
    let taxRate = 0.10; // default estimated tax rate

    if (state.mode === "simple") {
      // Linear Interpolation calculation based on Furusato Lookup table
      limit = calculateSimpleLimit(state.income, state.family);
      
      // Estimate tax rate based on simple income level for visual graph breakdown
      if (state.income < 300) taxRate = 0.05;
      else if (state.income < 500) taxRate = 0.10;
      else if (state.income < 750) taxRate = 0.20;
      else if (state.income < 1000) taxRate = 0.23;
      else if (state.income < 1800) taxRate = 0.33;
      else taxRate = 0.40;
    } else {
      // Detailed Mode: Calculate limit directly from Resident Tax 所得割額
      const residentTax = state.tax;
      
      // 1. Estimate taxable income (課税所得) = 所得割額 / 10%
      const estimatedTaxableIncome = residentTax / 0.10;

      // 2. Determine exact income tax rate (所得税率ブラケット)
      if (estimatedTaxableIncome < 1950000) taxRate = 0.05;
      else if (estimatedTaxableIncome < 3300000) taxRate = 0.10;
      else if (estimatedTaxableIncome < 6950000) taxRate = 0.20;
      else if (estimatedTaxableIncome < 9000000) taxRate = 0.23;
      else if (estimatedTaxableIncome < 18000000) taxRate = 0.33;
      else if (estimatedTaxableIncome < 40000000) taxRate = 0.40;
      else taxRate = 0.45;

      // 3. Tax official formula for maximum Furusato deduction limit
      // Limit = (所得割額 * 0.20) / (0.90 - (所得税率 * 1.021)) + 2000
      if (residentTax > 0) {
        const den = 0.90 - (taxRate * 1.021);
        limit = Math.round((residentTax * 0.20) / den + 2000);
      } else {
        limit = 0;
      }
    }

    // Standard round-down to nearest thousand to be safe
    state.limitAmount = Math.max(0, limit);
    limitAmountDisp.textContent = state.limitAmount.toLocaleString();

    // Update Displays
    updateBreakdownGraph(state.limitAmount, taxRate);
    updatePortals(state.limitAmount);
    renderComboItems();
  }

  // Linear Interpolation helper
  function calculateSimpleLimit(income, family) {
    const fIdx = FAMILY_INDEX_MAP[family];
    const keys = Object.keys(LIMIT_TABLE).map(Number).sort((a,b)=>a-b);
    
    // Bounds check
    if (income <= keys[0]) {
      // Below 300万円, extrapolate down or use floor
      const pct = income / keys[0];
      return Math.round(LIMIT_TABLE[keys[0]][fIdx] * pct);
    }
    if (income >= keys[keys.length - 1]) {
      // Above 2000万円, return max key
      return LIMIT_TABLE[keys[keys.length - 1]][fIdx];
    }

    // Find bounding keys
    let lowerKey = keys[0];
    let upperKey = keys[keys.length - 1];
    
    for (let i = 0; i < keys.length - 1; i++) {
      if (income >= keys[i] && income <= keys[i+1]) {
        lowerKey = keys[i];
        upperKey = keys[i+1];
        break;
      }
    }

    const lowerVal = LIMIT_TABLE[lowerKey][fIdx];
    const upperVal = LIMIT_TABLE[upperKey][fIdx];
    
    // Linear Interpolation formula
    const ratio = (income - lowerKey) / (upperKey - lowerKey);
    return Math.round(lowerVal + (upperVal - lowerVal) * ratio);
  }

  // 10. Graph Breakdown calculations and updates
  function updateBreakdownGraph(limit, taxRate) {
    if (limit <= 2000) {
      // Fallback if limit is zero
      barSelf.style.width = "100%";
      barIncome.style.width = "0%";
      barResident.style.width = "0%";
      legendSelfVal.textContent = limit.toLocaleString();
      legendIncomeVal.textContent = "0";
      legendResidentVal.textContent = "0";
      return;
    }

    // Standard tax refund calculations
    // Self-pay is always 2,000 yen
    const selfPay = 2000;
    
    // Income Tax refund = (Limit - 2,000) * (所得税率 * 1.021)
    const incomeRefund = Math.round((limit - 2000) * (taxRate * 1.021));
    
    // Resident Tax deduction = Limit - 2,000 - Income Tax refund
    const residentDeduct = Math.max(0, limit - selfPay - incomeRefund);

    // Calculate percentage widths for CSS bar
    const selfPct = (selfPay / limit) * 100;
    const incomePct = (incomeRefund / limit) * 100;
    const residentPct = (residentDeduct / limit) * 100;

    // Apply styles
    barSelf.style.width = `${selfPct}%`;
    barIncome.style.width = `${incomePct}%`;
    barResident.style.width = `${residentPct}%`;

    // Set text
    legendSelfVal.textContent = selfPay.toLocaleString();
    legendIncomeVal.textContent = incomeRefund.toLocaleString();
    legendResidentVal.textContent = residentDeduct.toLocaleString();
  }



  // 11. Portal Returns computations
  function updatePortals(limit) {
    // 1. Rakuten (up to 30% points return)
    const rakutenPoints = Math.round(limit * 0.30);
    rakutenValDisp.textContent = rakutenPoints.toLocaleString();

    // 2. Furunavi (up to 15% coins return)
    const furunaviCoins = Math.round(limit * 0.15);
    furunaviValDisp.textContent = furunaviCoins.toLocaleString();
  }

  // 12. Gift Combo Generator
  function renderComboItems() {
    const category = comboTypeSelect.value;
    const items = COMBO_DATABASE[category] || [];
    
    comboListContainer.innerHTML = "";
    
    // Auto-select initial items that fit within the limit
    let currentSum = 0;
    
    items.forEach((item, index) => {
      const shouldSelect = (currentSum + item.price <= state.limitAmount);
      if (shouldSelect) {
        currentSum += item.price;
      }
      
      const itemEl = document.createElement("div");
      itemEl.className = "combo-item";
      itemEl.innerHTML = `
        <div class="combo-left">
          <input type="checkbox" class="combo-checkbox" id="chk-${item.id}" data-price="${item.price}" ${shouldSelect ? 'checked' : ''}>
          <label class="combo-name" for="chk-${item.id}">${item.name}</label>
        </div>
        <span class="combo-price">¥${item.price.toLocaleString()}</span>
      `;
      comboListContainer.appendChild(itemEl);
    });

    // Add change listeners to checkboxes to calculate tracker value
    const checkboxes = comboListContainer.querySelectorAll(".combo-checkbox");
    checkboxes.forEach(chk => {
      chk.addEventListener("change", recalculateComboTotals);
    });

    recalculateComboTotals();
  }

  function recalculateComboTotals() {
    const checkboxes = comboListContainer.querySelectorAll(".combo-checkbox");
    let total = 0;
    
    checkboxes.forEach(chk => {
      if (chk.checked) {
        total += parseInt(chk.getAttribute("data-price"));
      }
    });

    const remaining = state.limitAmount - total;
    
    comboTotalDisp.textContent = `${total.toLocaleString()}円`;
    
    if (remaining < 0) {
      comboRemainingDisp.textContent = `枠超過 -${Math.abs(remaining).toLocaleString()}円`;
      comboRemainingDisp.className = "tracker-val warning";
    } else {
      comboRemainingDisp.textContent = `${remaining.toLocaleString()}円`;
      comboRemainingDisp.className = "tracker-val ok";
    }
  }

  comboTypeSelect.addEventListener("change", renderComboItems);
});
