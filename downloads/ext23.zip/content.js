// ふるさと納税ポータル一括シミュレーター — フローティングパネル
// persistent-panelスキルのパターンに準拠(ドラッグ可能、タブ切替で消えない、✕でのみ閉じる)
(function () {
  // 拡張機能ごとに一意のIDでネームスペースを切る(他拡張機能とのDOM ID衝突防止)
  const NS_ID = "wano-" + chrome.runtime.id;

  function makeElementDraggable(element, handle) {
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";
    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (["INPUT", "BUTTON", "SELECT", "TEXTAREA", "A"].includes(e.target.tagName)) return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      const iframeEl = element.querySelector("iframe");
      if (iframeEl) iframeEl.style.setProperty("pointer-events", "none", "important");

      document.addEventListener("mousemove", dragMove);
      document.addEventListener("mouseup", dragEnd);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;
      newTop = Math.max(0, Math.min(newTop, maxTop));
      newLeft = Math.max(0, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      const iframeEl = element.querySelector("iframe");
      if (iframeEl) iframeEl.style.removeProperty("pointer-events");
      document.removeEventListener("mousemove", dragMove);
      document.removeEventListener("mouseup", dragEnd);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById(NS_ID + "-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "flex" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = NS_ID + "-floating-container";

    const initialLeft = Math.max(10, window.innerWidth - 590);
    container.style.cssText =
      "position:fixed !important; top:32px !important; left:" + initialLeft + "px !important; " +
      "z-index:2147483647 !important; width:560px !important; height:680px !important; max-height:90vh !important; " +
      "background-color:#15110e !important; border:1.5px solid rgba(223,194,153,0.4) !important; border-radius:12px !important; " +
      "box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; " +
      "overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="${NS_ID}-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none; flex-shrink:0;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">💰</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">ふるさと納税ポータル一括シミュレーター</span>
        </div>
        <button id="${NS_ID}-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    const header = container.querySelector("#" + NS_ID + "-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#" + NS_ID + "-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
