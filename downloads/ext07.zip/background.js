// background.js
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ enabled: true });
});

chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local' && changes.enabled !== undefined) {
    const isEnabled = changes.enabled.newValue;
    // メッセージを送って各タブのハイライトを更新させるか、タブをリロードする
    chrome.tabs.query({}, (tabs) => {
      for (const tab of tabs) {
        if (!tab.url.startsWith("chrome://")) {
          chrome.tabs.sendMessage(tab.id, { action: "toggleHighlight", enabled: isEnabled }).catch(() => {});
        }
      }
    });
  }
});
