// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// popup.js - Handles UI interactions in the popup

document.addEventListener('DOMContentLoaded', () => {
  const toggleSwitch = document.getElementById('enableToggle');
  const searchInput = document.getElementById('searchInput');
  const dictList = document.getElementById('dictList');
  
  // Initialize toggle state
  chrome.storage.local.get(['enabled'], (result) => {
    toggleSwitch.checked = result.enabled !== false;
  });

  // Handle toggle change
  toggleSwitch.addEventListener('change', (e) => {
    chrome.storage.local.set({ enabled: e.target.checked });
  });

  // Render dictionary list
  function renderList(filterText = '') {
    dictList.innerHTML = '';
    const lowerFilter = filterText.toLowerCase();
    
    let matchCount = 0;
    
    // Iterate over dictionary entries
    for (const [term, data] of Object.entries(itDictionary)) {
      if (
        term.includes(lowerFilter) || 
        data.en.toLowerCase().includes(lowerFilter) || 
        data.meaning.includes(lowerFilter)
      ) {
        matchCount++;
        
        const itemDiv = document.createElement('div');
        itemDiv.className = 'dict-item';
        
        const termDiv = document.createElement('div');
        termDiv.className = 'dict-item-term';
        termDiv.textContent = term;
        
        const enDiv = document.createElement('div');
        enDiv.className = 'dict-item-en';
        enDiv.textContent = data.en;
        
        const meaningDiv = document.createElement('div');
        meaningDiv.className = 'dict-item-meaning';
        meaningDiv.textContent = data.meaning;
        
        itemDiv.appendChild(termDiv);
        itemDiv.appendChild(enDiv);
        itemDiv.appendChild(meaningDiv);
        
        dictList.appendChild(itemDiv);
      }
    }
    
    if (matchCount === 0) {
      const noResults = document.createElement('div');
      noResults.className = 'no-results';
      noResults.textContent = '見つかりませんでした。';
      dictList.appendChild(noResults);
    }
  }

  // Handle search input
  searchInput.addEventListener('input', (e) => {
    renderList(e.target.value);
  });

  // Initial render
  renderList();
});
