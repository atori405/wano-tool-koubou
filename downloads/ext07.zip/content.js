// content.js - DOM parsing and tooltip handling

let extensionEnabled = true;
let tooltipElement = null;
const dictKeys = Object.keys(itDictionary);
// Create a regex to match any of the dictionary terms
// Sort by length descending to match longer terms first (e.g. "ベストプラクティス" before "ベスト")
const sortedKeys = dictKeys.sort((a, b) => b.length - a.length);
const termRegex = new RegExp(`(${sortedKeys.join('|')})`, 'g');

// Initialize tooltip
function createTooltip() {
  if (document.getElementById('it-dict-tooltip')) return;
  tooltipElement = document.createElement('div');
  tooltipElement.id = 'it-dict-tooltip';
  
  const termSpan = document.createElement('span');
  termSpan.className = 'it-dict-term';
  
  const enSpan = document.createElement('span');
  enSpan.className = 'it-dict-en';
  
  const meaningSpan = document.createElement('span');
  meaningSpan.className = 'it-dict-meaning';
  
  tooltipElement.appendChild(termSpan);
  tooltipElement.appendChild(enSpan);
  tooltipElement.appendChild(meaningSpan);
  
  document.body.appendChild(tooltipElement);
}

// Show tooltip
function showTooltip(event, term) {
  if (!extensionEnabled || !tooltipElement) return;
  
  const dictEntry = itDictionary[term];
  if (!dictEntry) return;

  const termSpan = tooltipElement.querySelector('.it-dict-term');
  const enSpan = tooltipElement.querySelector('.it-dict-en');
  const meaningSpan = tooltipElement.querySelector('.it-dict-meaning');
  
  termSpan.textContent = term;
  enSpan.textContent = dictEntry.en;
  meaningSpan.textContent = dictEntry.meaning;
  
  tooltipElement.classList.add('it-dict-show');
  
  // Position tooltip
  positionTooltip(event);
}

// Position tooltip based on mouse event
function positionTooltip(event) {
  if (!tooltipElement) return;
  
  const tooltipRect = tooltipElement.getBoundingClientRect();
  let left = event.pageX + 15;
  let top = event.pageY + 15;
  
  // Adjust if it goes off screen
  if (left + tooltipRect.width > window.innerWidth + window.scrollX) {
    left = event.pageX - tooltipRect.width - 15;
  }
  if (top + tooltipRect.height > window.innerHeight + window.scrollY) {
    top = event.pageY - tooltipRect.height - 15;
  }
  
  tooltipElement.style.left = `${left}px`;
  tooltipElement.style.top = `${top}px`;
}

// Hide tooltip
function hideTooltip() {
  if (tooltipElement) {
    tooltipElement.classList.remove('it-dict-show');
  }
}

// Parse DOM and wrap terms
function highlightTerms() {
  if (!extensionEnabled) return;
  
  const walker = document.createTreeWalker(
    document.body,
    NodeFilter.SHOW_TEXT,
    {
      acceptNode: function(node) {
        // Skip script, style, textarea, input, and already highlighted elements
        const parent = node.parentNode;
        if (parent && (
            parent.nodeName === 'SCRIPT' || 
            parent.nodeName === 'STYLE' ||
            parent.nodeName === 'TEXTAREA' ||
            parent.nodeName === 'INPUT' ||
            parent.nodeName === 'NOSCRIPT' ||
            parent.classList.contains('it-dict-highlight') ||
            parent.id === 'it-dict-tooltip'
        )) {
          return NodeFilter.FILTER_REJECT;
        }
        if (termRegex.test(node.nodeValue)) {
          return NodeFilter.FILTER_ACCEPT;
        }
        return NodeFilter.FILTER_REJECT;
      }
    },
    false
  );

  const nodesToReplace = [];
  while (walker.nextNode()) {
    nodesToReplace.push(walker.currentNode);
  }

  nodesToReplace.forEach(node => {
    // We need to carefully replace text with HTML
    const text = node.nodeValue;
    // Reset regex index
    termRegex.lastIndex = 0;
    
    // If the node contains the term
    if (termRegex.test(text)) {
      const fragment = document.createDocumentFragment();
      let lastIndex = 0;
      termRegex.lastIndex = 0; // reset again
      
      let match;
      while ((match = termRegex.exec(text)) !== null) {
        // Add preceding text
        if (match.index > lastIndex) {
          fragment.appendChild(document.createTextNode(text.substring(lastIndex, match.index)));
        }
        
        // Add highlighted term
        const span = document.createElement('span');
        span.className = 'it-dict-highlight';
        span.textContent = match[0];
        span.dataset.term = match[0];
        
        // Add events
        span.addEventListener('mouseenter', (e) => showTooltip(e, e.target.dataset.term));
        span.addEventListener('mousemove', (e) => positionTooltip(e));
        span.addEventListener('mouseleave', hideTooltip);
        
        fragment.appendChild(span);
        lastIndex = termRegex.lastIndex;
      }
      
      // Add trailing text
      if (lastIndex < text.length) {
        fragment.appendChild(document.createTextNode(text.substring(lastIndex)));
      }
      
      if (node.parentNode) {
        node.parentNode.replaceChild(fragment, node);
      }
    }
  });
}

// Remove highlights
function removeHighlights() {
  const spans = document.querySelectorAll('span.it-dict-highlight');
  spans.forEach(span => {
    const parent = span.parentNode;
    if (parent) {
      parent.replaceChild(document.createTextNode(span.textContent), span);
      parent.normalize();
    }
  });
  hideTooltip();
}

// Initialize
function init() {
  chrome.storage.local.get(['enabled'], (result) => {
    extensionEnabled = result.enabled !== false; // true by default
    if (extensionEnabled) {
      createTooltip();
      highlightTerms();
    }
  });
}

// Listen for messages from background/popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'toggleHighlight') {
    extensionEnabled = request.enabled;
    if (extensionEnabled) {
      createTooltip();
      highlightTerms();
    } else {
      removeHighlights();
    }
  }
});

// Run init when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

// Debounced DOM mutation observer to handle dynamically loaded content
let mutationTimeout = null;
const observer = new MutationObserver((mutations) => {
  if (!extensionEnabled) return;
  
  // Quick check if we should even process these mutations
  let shouldProcess = false;
  for (const mutation of mutations) {
    if (mutation.addedNodes.length > 0) {
      // Ignore if the added node is our own tooltip
      if (mutation.addedNodes[0].id === 'it-dict-tooltip') continue;
      // Ignore if it's inside our own highlight (prevents infinite loop)
      if (mutation.target.classList && mutation.target.classList.contains('it-dict-highlight')) continue;
      
      shouldProcess = true;
      break;
    }
  }
  
  if (shouldProcess) {
    clearTimeout(mutationTimeout);
    mutationTimeout = setTimeout(() => {
      termRegex.lastIndex = 0;
      highlightTerms();
    }, 1000); // 1s debounce for performance
  }
});

observer.observe(document.body, {
  childList: true,
  subtree: true
});


// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // Add temporary shield to prevent iframe from stealing mouse events during dragging
      const existingShield = document.getElementById("wano-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = "wano-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      // Use getBoundingClientRect() for correct viewport-relative position
      // (element.offsetTop is unreliable for position:fixed elements on scrolled pages)
      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      // Restrict within window boundaries to prevent going offscreen
      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById("wano-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById("wano-universal-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "block" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = "wano-universal-floating-container";
    
    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 440) + "px !important; z-index:2147483647 !important; width:430px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="wano-u-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">Katakana It Dictionary</span>
        </div>
        <button id="wano-u-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#wano-u-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#wano-u-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
