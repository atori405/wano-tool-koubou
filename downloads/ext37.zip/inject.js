// inject.js — MAIN WORLD (YouTube と同じ JS コンテキストで実行)
// manifest.json で "world": "MAIN", "run_at": "document_start" として宣言。
// Chrome が直接注入するため YouTube の CSP の影響を受けない。
//
// 責務:
//   1. キーボードショートカット (D/S/R) の捕捉
//   2. video.playbackRate の直接設定（MAIN World なので確実に反映）
//   3. HUD インジケータの表示
//   4. content.js (ISOLATED World) との双方向通信

(function() {
  "use strict";
  if (window.__wanoSpeedInjected) return;
  window.__wanoSpeedInjected = true;

  var settings = {
    speed: 1.0,
    preservesPitch: true,
    showHUD: true,
    hotkeysEnabled: true
  };

  // --- Video speed application (runs in MAIN world = same as YouTube) ---
  function applySpeed() {
    var videos = document.getElementsByTagName("video");
    for (var i = 0; i < videos.length; i++) {
      var v = videos[i];
      if (Math.abs(v.playbackRate - settings.speed) > 0.01) {
        v.playbackRate = settings.speed;
      }
      if (v.preservesPitch !== settings.preservesPitch) {
        v.preservesPitch = settings.preservesPitch;
      }
      if (v.mozPreservesPitch !== settings.preservesPitch) {
        v.mozPreservesPitch = settings.preservesPitch;
      }
      if (v.webkitPreservesPitch !== settings.preservesPitch) {
        v.webkitPreservesPitch = settings.preservesPitch;
      }
    }
  }

  // Enforce speed every 500ms (catches YouTube ad resets, SPA navigations)
  setInterval(applySpeed, 500);

  // --- HUD indicator ---
  function showHUD(speed) {
    if (!settings.showHUD) return;

    var videos = document.getElementsByTagName("video");
    var videoEl = null;
    for (var i = 0; i < videos.length; i++) {
      if (!videos[i].paused || (videos[i].offsetWidth > 100 && !videoEl)) {
        videoEl = videos[i];
        if (!videos[i].paused) break;
      }
    }
    if (!videoEl) return;

    var container = document.fullscreenElement || document.body;
    if (!container) return;

    var hudId = "wano-video-speed-hud";
    var hud = document.getElementById(hudId);

    // If hud exists but is in a different container, remove it
    if (hud && hud.parentNode !== container) {
      hud.parentNode.removeChild(hud);
      hud = null;
    }

    if (!hud) {
      hud = document.createElement("div");
      hud.id = hudId;
      container.appendChild(hud);
    }

    hud.textContent = "\u26A1 " + Number(speed).toFixed(1) + "x";

    // Inline styles (no reliance on content.css from ISOLATED world)
    hud.style.cssText = [
      "position:absolute",
      "z-index:2147483647",
      "pointer-events:none",
      "background:rgba(21,17,14,0.9)",
      "color:#dfc299",
      "font-family:Outfit,Arial,sans-serif",
      "font-size:22px",
      "font-weight:700",
      "padding:8px 16px",
      "border-radius:8px",
      "border:1.5px solid rgba(223,194,153,0.6)",
      "box-shadow:0 6px 20px rgba(0,0,0,0.6),0 0 12px rgba(223,194,153,0.3)",
      "text-shadow:0 1px 4px rgba(0,0,0,0.8),0 0 6px rgba(223,194,153,0.4)",
      "opacity:1",
      "transition:opacity 0.3s"
    ].join(";");

    var rect = videoEl.getBoundingClientRect();
    if (container === document.fullscreenElement) {
      hud.style.top = "24px";
      hud.style.left = "24px";
    } else {
      var sx = window.pageXOffset || 0;
      var sy = window.pageYOffset || 0;
      hud.style.top = (rect.top + sy + 24) + "px";
      hud.style.left = (rect.left + sx + 24) + "px";
    }

    // Fade out after 1 second
    hud.style.opacity = "1";
    if (window.__wanoHudTimer) clearTimeout(window.__wanoHudTimer);
    window.__wanoHudTimer = setTimeout(function() {
      hud.style.opacity = "0";
    }, 1000);
  }

  // --- Keyboard handler ---
  function isTextInput(el) {
    if (!el) return false;
    var tag = (el.tagName || "").toLowerCase();
    if (tag === "textarea") return true;
    if (el.isContentEditable) return true;
    if (el.getAttribute && el.getAttribute("role") === "textbox") return true;
    if (tag === "input") {
      var t = (el.type || "text").toLowerCase();
      return ["text","password","number","email","search","url","tel",
              "date","datetime-local","month","time","week"].indexOf(t) >= 0;
    }
    return false;
  }

  window.addEventListener("keydown", function(e) {
    if (!settings.hotkeysEnabled) return;
    if (e.isComposing) return;
    if (isTextInput(document.activeElement)) return;

    var code = e.code;
    var newSpeed = settings.speed;
    var changed = false;

    if (code === "KeyD") {
      newSpeed = Math.min(16.0, Math.round((settings.speed + 0.1) * 10) / 10);
      changed = true;
    } else if (code === "KeyS") {
      newSpeed = Math.max(0.1, Math.round((settings.speed - 0.1) * 10) / 10);
      changed = true;
    } else if (code === "KeyR") {
      newSpeed = 1.0;
      changed = true;
    }

    if (changed && Math.abs(newSpeed - settings.speed) > 0.001) {
      e.preventDefault();
      e.stopImmediatePropagation();

      settings.speed = newSpeed;
      applySpeed();
      showHUD(newSpeed);

      // Notify ISOLATED world (content.js) to persist to chrome.storage
      window.postMessage({
        type: "__wano_speed_changed",
        settings: JSON.parse(JSON.stringify(settings))
      }, "*");
    }
  }, true); // capture phase

  // --- Receive settings from ISOLATED world (content.js) ---
  window.addEventListener("message", function(event) {
    if (event.source !== window) return;
    if (!event.data) return;

    if (event.data.type === "__wano_settings_to_main") {
      var s = event.data.settings;
      if (s) {
        settings.speed = s.speed !== undefined ? s.speed : settings.speed;
        settings.preservesPitch = s.preservesPitch !== undefined ? s.preservesPitch : settings.preservesPitch;
        settings.showHUD = s.showHUD !== undefined ? s.showHUD : settings.showHUD;
        settings.hotkeysEnabled = s.hotkeysEnabled !== undefined ? s.hotkeysEnabled : settings.hotkeysEnabled;
        applySpeed();
      }
    }
  });

  // Apply speed as soon as videos appear
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", applySpeed);
  } else {
    applySpeed();
  }
})();
