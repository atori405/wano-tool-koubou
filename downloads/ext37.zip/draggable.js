// Draggable Panel Utility with Dashed Border Guide & Clamping (Never retracts/goes offscreen)
(function() {
  window.makeDraggable = function(element, handleElement) {
    if (!element) return;
    const NS_ID = "wano-" + chrome.runtime.id;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    const handle = handleElement || element;
    
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragMouseDown);

    function dragMouseDown(e) {
      if (["INPUT", "BUTTON", "SELECT", "TEXTAREA", "A"].includes(e.target.tagName)) return;
      e.preventDefault();
      
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // Overlay to prevent iframe from intercepting mouse dragging events
      const shield = document.createElement("div");
      shield.id = NS_ID + "-drag-shield";
      shield.style.cssText = "position:absolute; top:0; left:0; width:100%; height:100%; z-index:999999;";
      element.appendChild(shield);

      document.addEventListener("mouseup", closeDragElement);
      document.addEventListener("mousemove", elementDrag);
    }

    function elementDrag(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      let newTop = element.offsetTop - pos2;
      let newLeft = element.offsetLeft - pos1;

      // Screen boundary clamp
      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 100;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 100;
      
      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
      element.style.setProperty("z-index", "2147483647", "important");
    }

    function closeDragElement() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById(NS_ID + "-drag-shield");
      if (shield) shield.remove();
      
      document.removeEventListener("mouseup", closeDragElement);
      document.removeEventListener("mousemove", elementDrag);
    }
  };
})();
