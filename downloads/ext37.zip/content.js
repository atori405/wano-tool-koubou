﻿// content.js - Smooth Speed Controller (Full Embedded Floating & Production Speed Engine)
(function () {
  "use strict";

  let settings = {
    speed: 1.0,
    preservesPitch: true,
    showHUD: true,
    hotkeysEnabled: true
  };

  // --- 1. Inject Main World Script (YouTube Native Player API & Video Overrides) ---
  function injectMainWorld() {
    if (window.__wanoSpeedMainWorldInjected) return;
    window.__wanoSpeedMainWorldInjected = true;

    function mainWorldScript() {
      let speed = 1.0;
      window.addEventListener("message", (e) => {
        if (e.data && e.data.type === "__WANO_SPEED_UPDATE__") {
          speed = e.data.speed;
          applySpeed();
        }
      });

      function applySpeed() {
        try {
          const ytp = document.getElementById("movie_player") || document.querySelector(".html5-video-player");
          if (ytp && typeof ytp.setPlaybackRate === "function") {
            ytp.setPlaybackRate(speed);
          }
        } catch (err) {}

        const mediaList = document.querySelectorAll("video, audio");
        mediaList.forEach(media => {
          try {
            if (Math.abs(media.playbackRate - speed) > 0.001) {
              media.playbackRate = speed;
            }
          } catch (err) {}
        });
      }
      setInterval(applySpeed, 250);
    }

    const script = document.createElement("script");
    script.textContent = `(${mainWorldScript.toString()})();`;
    (document.head || document.documentElement).appendChild(script);
    script.remove();
  }

  // Direct Speed Application Function to videos on page
  function applySpeedDirect(speedVal) {
    // Post to Main World (for YouTube API)
    window.postMessage({ type: "__WANO_SPEED_UPDATE__", speed: speedVal }, "*");

    // Direct isolated world application
    const mediaElements = document.querySelectorAll("video, audio");
    mediaElements.forEach(media => {
      try {
        if (Math.abs(media.playbackRate - speedVal) > 0.001) {
          media.playbackRate = speedVal;
        }
        if (media.preservesPitch !== settings.preservesPitch) {
          media.preservesPitch = settings.preservesPitch;
        }
        if (media.webkitPreservesPitch !== settings.preservesPitch) {
          media.webkitPreservesPitch = settings.preservesPitch;
        }
        if (media.mozPreservesPitch !== settings.preservesPitch) {
          media.mozPreservesPitch = settings.preservesPitch;
        }
      } catch (e) {}
    });
  }

  // --- 2. Injects/Toggles the Draggable Floating Wrapper Frame ---
  function toggleFloatingPanel() {
    let container = document.getElementById("wano-universal-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "block" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = "wano-universal-floating-container";
    
    // Position fixed top right. No fixed right/left !important to allow smooth free dragging.
    container.style.cssText = `
      position: fixed !important;
      top: 40px !important;
      left: ${Math.max(10, window.innerWidth - 392)}px !important;
      z-index: 2147483647 !important;
      width: 380px !important;
      height: 570px !important;
      background-color: #15110e !important;
      border: 1.5px solid rgba(223, 194, 153, 0.4) !important;
      border-radius: 12px !important;
      box-shadow: 0 10px 45px rgba(0,0,0,0.92) !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    `;

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="wano-u-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">なめらか倍速コントロール</span>
        </div>
        <button id="wano-u-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable (loads latest gold dashed border draggable)
    const header = container.querySelector("#wano-u-drag-header");
    if (window.makeDraggable) {
      window.makeDraggable(container, header);
    }

    container.querySelector("#wano-u-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  // --- 3. Message Listeners ---
  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      } else if (message.action === "setSpeed") {
        settings.speed = message.speed;
        settings.preservesPitch = message.preservesPitch !== undefined ? message.preservesPitch : settings.preservesPitch;
        settings.showHUD = message.showHUD !== undefined ? message.showHUD : settings.showHUD;
        
        applySpeedDirect(settings.speed);
        sendResponse({ status: "success" });
      }
      return true;
    });

    // Load settings from storage initially
    chrome.storage.local.get(["smoothSpeedSettings"], (res) => {
      if (res && res.smoothSpeedSettings) {
        settings = { ...settings, ...res.smoothSpeedSettings };
      }
      applySpeedDirect(settings.speed);
    });

    // Listen for storage changes
    chrome.storage.onChanged.addListener((changes) => {
      if (changes.smoothSpeedSettings) {
        settings = { ...settings, ...changes.smoothSpeedSettings.newValue };
        applySpeedDirect(settings.speed);
      }
    });
  }

  // Continuous Enforcer Loop (ensures speed remains active during dynamic page loads/ads)
  setInterval(() => {
    applySpeedDirect(settings.speed);
  }, 300);

  // Initialize
  injectMainWorld();

})();

