﻿// content.js - Smooth Speed Controller (Full Embedded Floating & Production Speed Engine)
(function () {
  "use strict";

  const NS_ID = "wano-" + chrome.runtime.id;

  let settings = {
    speed: 1.0,
    preservesPitch: true,
    showHUD: true,
    hotkeysEnabled: true
  };

  // --- 1. Inject Main World Script (YouTube Native Player API & Video Overrides) ---
  function injectMainWorld() {
    if (window.__wanoSpeedMainWorldInjected) return;
    window.__wanoSpeedMainWorldInjected = true;

    function mainWorldScript() {
      let speed = 1.0;
      window.addEventListener("message", (e) => {
        if (e.data && e.data.type === "__WANO_SPEED_UPDATE__") {
          speed = e.data.speed;
          applySpeed();
        }
      });

      function applySpeed() {
        try {
          const ytp = document.getElementById("movie_player") || document.querySelector(".html5-video-player");
          if (ytp && typeof ytp.setPlaybackRate === "function") {
            ytp.setPlaybackRate(speed);
          }
        } catch (err) {}

        const mediaList = document.querySelectorAll("video, audio");
        mediaList.forEach(media => {
          try {
            if (Math.abs(media.playbackRate - speed) > 0.001) {
              media.playbackRate = speed;
            }
          } catch (err) {}
        });
      }
      setInterval(applySpeed, 250);
    }

    const script = document.createElement("script");
    script.textContent = `(${mainWorldScript.toString()})();`;
    (document.head || document.documentElement).appendChild(script);
    script.remove();
  }

  // Direct Speed Application Function to videos on page
  function applySpeedDirect(speedVal) {
    // Post to Main World (for YouTube API)
    window.postMessage({ type: "__WANO_SPEED_UPDATE__", speed: speedVal }, "*");

    // Direct isolated world application
    const mediaElements = document.querySelectorAll("video, audio");
    mediaElements.forEach(media => {
      try {
        if (Math.abs(media.playbackRate - speedVal) > 0.001) {
          media.playbackRate = speedVal;
        }
        if (media.preservesPitch !== settings.preservesPitch) {
          media.preservesPitch = settings.preservesPitch;
        }
        if (media.webkitPreservesPitch !== settings.preservesPitch) {
          media.webkitPreservesPitch = settings.preservesPitch;
        }
        if (media.mozPreservesPitch !== settings.preservesPitch) {
          media.mozPreservesPitch = settings.preservesPitch;
        }
      } catch (e) {}
    });
  }

  // --- 2. Injects/Toggles the Draggable Floating Wrapper Frame ---
  function toggleFloatingPanel() {
    let container = document.getElementById(NS_ID + "-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "block" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = NS_ID + "-floating-container";
    
    // Position fixed top right. No fixed right/left !important to allow smooth free dragging.
    container.style.cssText = `
      position: fixed !important;
      top: 40px !important;
      left: ${Math.max(10, window.innerWidth - 392)}px !important;
      z-index: 2147483647 !important;
      width: 380px !important;
      height: 570px !important;
      background-color: #15110e !important;
      border: 1.5px solid rgba(223, 194, 153, 0.4) !important;
      border-radius: 12px !important;
      box-shadow: 0 10px 45px rgba(0,0,0,0.92) !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    `;

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="${NS_ID}-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">なめらか倍速コントロール</span>
        </div>
        <button id="${NS_ID}-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable (loads latest gold dashed border draggable)
    const header = container.querySelector("#" + NS_ID + "-drag-header");
    if (window.makeDraggable) {
      window.makeDraggable(container, header);
    }

    container.querySelector("#" + NS_ID + "-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  // --- Keyboard Shortcuts (D: speed up / S: speed down / R: reset to 1.0x) ---
  // Ported from the formerly-orphaned inject.js: it was never registered in
  // manifest.json's content_scripts and had no dynamic injection path either,
  // so its hotkeys and HUD never ran. Keyboard events and DOM manipulation
  // don't require the MAIN world (unlike overriding a page-owned JS global),
  // so this lives directly in this isolated-world content script instead.
  function isTextInput(el) {
    if (!el) return false;
    const tag = (el.tagName || "").toLowerCase();
    if (tag === "textarea") return true;
    if (el.isContentEditable) return true;
    if (el.getAttribute && el.getAttribute("role") === "textbox") return true;
    if (tag === "input") {
      const t = (el.type || "text").toLowerCase();
      return ["text", "password", "number", "email", "search", "url", "tel",
              "date", "datetime-local", "month", "time", "week"].indexOf(t) >= 0;
    }
    return false;
  }

  window.addEventListener("keydown", (e) => {
    if (!settings.hotkeysEnabled) return;
    if (e.isComposing) return;
    if (isTextInput(document.activeElement)) return;

    let newSpeed = settings.speed;
    let changed = false;

    if (e.code === "KeyD") {
      newSpeed = Math.min(16.0, Math.round((settings.speed + 0.1) * 10) / 10);
      changed = true;
    } else if (e.code === "KeyS") {
      newSpeed = Math.max(0.1, Math.round((settings.speed - 0.1) * 10) / 10);
      changed = true;
    } else if (e.code === "KeyR") {
      newSpeed = 1.0;
      changed = true;
    }

    if (changed && Math.abs(newSpeed - settings.speed) > 0.001) {
      e.preventDefault();
      e.stopImmediatePropagation();

      settings.speed = newSpeed;
      applySpeedDirect(settings.speed);
      showHUD(settings.speed);

      chrome.storage.local.set({ smoothSpeedSettings: settings });
    }
  }, true);

  // --- HUD Indicator (e.g. "⚡ 1.5x"), shown briefly near the active video ---
  function showHUD(speed) {
    if (!settings.showHUD) return;

    const videos = document.querySelectorAll("video");
    let videoEl = null;
    for (const v of videos) {
      if (!v.paused || (v.offsetWidth > 100 && !videoEl)) {
        videoEl = v;
        if (!v.paused) break;
      }
    }
    if (!videoEl) return;

    const container = document.fullscreenElement || document.body;
    if (!container) return;

    const hudId = NS_ID + "-speed-hud";
    let hud = document.getElementById(hudId);

    if (hud && hud.parentNode !== container) {
      hud.parentNode.removeChild(hud);
      hud = null;
    }

    if (!hud) {
      hud = document.createElement("div");
      hud.id = hudId;
      container.appendChild(hud);
    }

    hud.textContent = "⚡ " + Number(speed).toFixed(1) + "x";

    hud.style.cssText = [
      "position:absolute",
      "z-index:2147483647",
      "pointer-events:none",
      "background:rgba(21,17,14,0.9)",
      "color:#dfc299",
      "font-family:Outfit,Arial,sans-serif",
      "font-size:22px",
      "font-weight:700",
      "padding:8px 16px",
      "border-radius:8px",
      "border:1.5px solid rgba(223,194,153,0.6)",
      "box-shadow:0 6px 20px rgba(0,0,0,0.6),0 0 12px rgba(223,194,153,0.3)",
      "text-shadow:0 1px 4px rgba(0,0,0,0.8),0 0 6px rgba(223,194,153,0.4)",
      "opacity:1",
      "transition:opacity 0.3s"
    ].join(";");

    const rect = videoEl.getBoundingClientRect();
    if (container === document.fullscreenElement) {
      hud.style.top = "24px";
      hud.style.left = "24px";
    } else {
      const sx = window.pageXOffset || 0;
      const sy = window.pageYOffset || 0;
      hud.style.top = (rect.top + sy + 24) + "px";
      hud.style.left = (rect.left + sx + 24) + "px";
    }

    hud.style.opacity = "1";
    if (window.__wanoHudTimer) clearTimeout(window.__wanoHudTimer);
    window.__wanoHudTimer = setTimeout(() => {
      hud.style.opacity = "0";
    }, 1000);
  }

  // --- 3. Message Listeners ---
  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      } else if (message.action === "setSpeed") {
        settings.speed = message.speed;
        settings.preservesPitch = message.preservesPitch !== undefined ? message.preservesPitch : settings.preservesPitch;
        settings.showHUD = message.showHUD !== undefined ? message.showHUD : settings.showHUD;
        settings.hotkeysEnabled = message.hotkeysEnabled !== undefined ? message.hotkeysEnabled : settings.hotkeysEnabled;

        applySpeedDirect(settings.speed);
        showHUD(settings.speed);
        sendResponse({ status: "success" });
      }
      return true;
    });

    // Load settings from storage initially
    chrome.storage.local.get(["smoothSpeedSettings"], (res) => {
      if (res && res.smoothSpeedSettings) {
        settings = { ...settings, ...res.smoothSpeedSettings };
      }
      applySpeedDirect(settings.speed);
    });

    // Listen for storage changes
    chrome.storage.onChanged.addListener((changes) => {
      if (changes.smoothSpeedSettings) {
        settings = { ...settings, ...changes.smoothSpeedSettings.newValue };
        applySpeedDirect(settings.speed);
      }
    });
  }

  // Continuous Enforcer Loop (ensures speed remains active during dynamic page loads/ads)
  setInterval(() => {
    applySpeedDirect(settings.speed);
  }, 300);

  // Initialize
  injectMainWorld();

})();

