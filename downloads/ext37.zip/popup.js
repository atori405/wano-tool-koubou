// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

document.addEventListener("DOMContentLoaded", () => {
  // Floating Mode UI logic (Same as original design)
  const speedTextLarge = document.getElementById("speed-text-large");
  const btnMinus = document.getElementById("btn-speed-minus");
  const btnPlus = document.getElementById("btn-speed-plus");
  const presetGrid = document.querySelector(".preset-grid");
  const togglePitch = document.getElementById("toggle-pitch");
  const toggleHud = document.getElementById("toggle-hud");
  const toggleHotkeys = document.getElementById("toggle-hotkeys");
  const statusDot = document.getElementById("status-dot");

  let settings = {
    speed: 1.0,
    preservesPitch: true,
    showHUD: true,
    hotkeysEnabled: true
  };

  if (window.chrome && chrome.storage) {
    chrome.storage.local.get(["smoothSpeedSettings"], (result) => {
      if (result.smoothSpeedSettings) {
        settings = { ...settings, ...result.smoothSpeedSettings };
      }
      applySettingsToUI();
    });

    // Keep the panel in sync when the speed changes from elsewhere
    // (keyboard shortcuts on the page, or another tab).
    chrome.storage.onChanged.addListener((changes) => {
      if (changes.smoothSpeedSettings) {
        settings = { ...settings, ...changes.smoothSpeedSettings.newValue };
        applySettingsToUI();
      }
    });
  }

  function saveSettings() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.set({ smoothSpeedSettings: settings }, () => {
        updateStatusDot();
        notifyActiveTab();
      });
    }
  }

  function notifyActiveTab() {
    // Sends speed change to content.js in active tab
    if (window.chrome && chrome.tabs) {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0] && tabs[0].id) {
          chrome.tabs.sendMessage(tabs[0].id, {
            action: "setSpeed",
            speed: settings.speed,
            preservesPitch: settings.preservesPitch,
            showHUD: settings.showHUD,
            hotkeysEnabled: settings.hotkeysEnabled
          }, () => {
            if (chrome.runtime && chrome.runtime.lastError) { /* ignore */ }
          });
        }
      });
    }

    // In floating mode this popup runs inside an <iframe> embedded in the
    // page, so clicking a button here leaves keyboard focus trapped in that
    // iframe — the page's own keydown listener (D/S/R hotkeys) never sees
    // subsequent keystrokes until focus returns to the page. Hand focus back
    // immediately after handling the click. window.parent.focus() is allowed
    // across the cross-origin boundary even though reading/writing its DOM is not.
    if (window.parent && window.parent !== window) {
      window.parent.focus();
    }
  }

  function applySettingsToUI() {
    if (speedTextLarge) speedTextLarge.textContent = Number(settings.speed).toFixed(1);
    if (togglePitch) togglePitch.checked = settings.preservesPitch;
    if (toggleHud) toggleHud.checked = settings.showHUD;
    if (toggleHotkeys) toggleHotkeys.checked = settings.hotkeysEnabled;

    if (presetGrid) {
      const btns = presetGrid.querySelectorAll(".preset-btn");
      btns.forEach(btn => {
        const val = parseFloat(btn.getAttribute("data-speed"));
        if (Math.abs(val - settings.speed) < 0.01) {
          btn.classList.add("active");
        } else {
          btn.classList.remove("active");
        }
      });
    }
    updateStatusDot();
  }

  function updateStatusDot() {
    if (!statusDot) return;
    if (settings.speed !== 1.0) {
      statusDot.style.backgroundColor = "#dfc299";
      statusDot.style.boxShadow = "0 0 8px #dfc299";
    } else {
      statusDot.style.backgroundColor = "#c3b6ab";
      statusDot.style.boxShadow = "none";
    }
  }

  if (btnPlus) {
    btnPlus.addEventListener("click", () => {
      settings.speed = Math.min(16.0, Math.round((settings.speed + 0.1) * 10) / 10);
      saveSettings();
      applySettingsToUI();
    });
  }

  if (btnMinus) {
    btnMinus.addEventListener("click", () => {
      settings.speed = Math.max(0.1, Math.round((settings.speed - 0.1) * 10) / 10);
      saveSettings();
      applySettingsToUI();
    });
  }

  if (presetGrid) {
    presetGrid.addEventListener("click", (e) => {
      const btn = e.target.closest(".preset-btn");
      if (btn) {
        settings.speed = parseFloat(btn.getAttribute("data-speed"));
        saveSettings();
        applySettingsToUI();
      }
    });
  }

  if (togglePitch) {
    togglePitch.addEventListener("change", (e) => {
      settings.preservesPitch = e.target.checked;
      saveSettings();
    });
  }

  if (toggleHud) {
    toggleHud.addEventListener("change", (e) => {
      settings.showHUD = e.target.checked;
      saveSettings();
    });
  }

  if (toggleHotkeys) {
    toggleHotkeys.addEventListener("change", (e) => {
      settings.hotkeysEnabled = e.target.checked;
      saveSettings();
    });
  }
});
