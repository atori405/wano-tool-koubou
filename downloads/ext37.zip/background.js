const DEFAULT_SETTINGS = {
  speed: 1.0,
  preservesPitch: true,
  showHUD: true,
  hotkeysEnabled: true
};

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["smoothSpeedSettings"], (result) => {
    if (!result.smoothSpeedSettings) {
      chrome.storage.local.set({ smoothSpeedSettings: DEFAULT_SETTINGS }, () => {
        console.log("Smooth Speed Controller default settings initialized.");
      });
    }
  });
});
