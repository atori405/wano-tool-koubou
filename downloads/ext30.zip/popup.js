// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// popup.js - Japanese Gift Calendar
document.addEventListener("DOMContentLoaded", () => {
  // --- Data Definitions ---
  const EVENTS_DEF = [
    { id: "mother", name: "母の日", desc: "お母さんへ感謝を伝える日。フラワーギフトやスイーツが人気。", getNextDate: (yr) => getNthSunday(yr, 5, 2) },
    { id: "father", name: "父の日", desc: "お父さんへ感謝を伝える日。お酒やグルメ、ビジネス小物が定番。", getNextDate: (yr) => getNthSunday(yr, 6, 3) },
    { id: "chugen", name: "お中元", desc: "日頃お世話になっている方々へ夏のご挨拶。ビールやそうめん、涼菓など。", getNextDate: (yr) => new Date(yr, 6, 15) }, // 7/15
    { id: "keiro", name: "敬老の日", desc: "おじいちゃん、おばあちゃんの長寿を祝う日。和菓子や健康グッズなど。", getNextDate: (yr) => getNthMonday(yr, 9, 3) },
    { id: "seibo", name: "お歳暮", desc: "一年の感謝を込めて贈る冬のギフト。ハム、洗剤、洋菓子など。", getNextDate: (yr) => new Date(yr, 11, 10) }, // 12/10
    { id: "christmas", name: "クリスマス", desc: "家族、パートナー、子どもたちへのプレゼント。おもちゃやジュエリー。", getNextDate: (yr) => new Date(yr, 11, 25) },
    { id: "valentine", name: "バレンタインデー", desc: "大切な人やお世話になった人へチョコを贈る日。限定スイーツが目白押し。", getNextDate: (yr) => new Date(yr, 1, 14) } // 2/14
  ];

  // Helper: Get N-th Sunday of a month (1-indexed month)
  function getNthSunday(year, month, n) {
    const d = new Date(year, month - 1, 1);
    let sundayCount = 0;
    while (d.getMonth() === month - 1) {
      if (d.getDay() === 0) { // 0 is Sunday
        sundayCount++;
        if (sundayCount === n) {
          return new Date(d);
        }
      }
      d.setDate(d.getDate() + 1);
    }
    return null;
  }

  // Helper: Get N-th Monday of a month (1-indexed month)
  function getNthMonday(year, month, n) {
    const d = new Date(year, month - 1, 1);
    let mondayCount = 0;
    while (d.getMonth() === month - 1) {
      if (d.getDay() === 1) { // 1 is Monday
        mondayCount++;
        if (mondayCount === n) {
          return new Date(d);
        }
      }
      d.setDate(d.getDate() + 1);
    }
    return null;
  }

  // Calculate actual next event date relative to today
  function getNextEventOccurrence(eventDef) {
    const today = new Date();
    today.setHours(0,0,0,0);
    const currentYear = today.getFullYear();
    
    let targetDate = eventDef.getNextDate(currentYear);
    targetDate.setHours(0,0,0,0);
    
    // If the event has already passed this year, check the next year
    if (targetDate < today) {
      targetDate = eventDef.getNextDate(currentYear + 1);
      targetDate.setHours(0,0,0,0);
    }
    return targetDate;
  }

  // --- State Variables ---
  let todoList = [];
  let notificationSettings = {}; // { eventId: boolean }

  // --- Element Selectors ---
  const tabButtons = document.querySelectorAll(".tab-btn");
  const tabPanels = document.querySelectorAll(".tab-panel");
  const timelineContainer = document.getElementById("events-timeline");
  const salesContainer = document.getElementById("sales-timeline");
  const todoListContainer = document.getElementById("todo-list");
  const todoForm = document.getElementById("todo-form");
  const todoEventSelect = document.getElementById("todo-event");
  const addTodoToggleBtn = document.getElementById("add-todo-toggle-btn");
  const todoCancelBtn = document.getElementById("todo-cancel-btn");
  
  // Progress selectors
  const progressBarFill = document.getElementById("progress-bar-fill");
  const progressPercent = document.getElementById("progress-percent");
  const progressText = document.getElementById("progress-text");

  // --- Tab Switch Logic ---
  tabButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      const targetPanel = btn.getAttribute("data-tab");
      
      tabButtons.forEach(b => b.classList.remove("active"));
      tabPanels.forEach(p => p.classList.remove("active"));
      
      btn.classList.add("active");
      document.getElementById(targetPanel).classList.add("active");
      
      // Save state
      chrome.storage.local.set({ lastActiveTab: targetPanel });
    });
  });

  // Load Tab State
  chrome.storage.local.get(["lastActiveTab"], (result) => {
    if (result.lastActiveTab) {
      const activeBtn = document.querySelector(`.tab-btn[data-tab="${result.lastActiveTab}"]`);
      if (activeBtn) {
        activeBtn.click();
      }
    }
  });

  // --- Event Option Population ---
  function populateEventDropdown() {
    todoEventSelect.innerHTML = "";
    EVENTS_DEF.forEach(ev => {
      const opt = document.createElement("option");
      opt.value = ev.id;
      opt.textContent = ev.name;
      todoEventSelect.appendChild(opt);
    });
  }
  populateEventDropdown();

  // --- Load Storage and Initial Render ---
  function init() {
    chrome.storage.local.get(["todos", "notificationSettings"], (result) => {
      todoList = result.todos || [];
      notificationSettings = result.notificationSettings || {};
      
      // Fill missing notification settings with true by default
      EVENTS_DEF.forEach(ev => {
        if (notificationSettings[ev.id] === undefined) {
          notificationSettings[ev.id] = true;
        }
      });
      
      renderAll();
    });
  }

  function renderAll() {
    renderEvents();
    renderTodos();
    renderSales();
  }

  // --- Render Events Tab ---
  function renderEvents() {
    timelineContainer.innerHTML = "";
    
    // Sort events by upcoming order
    const today = new Date();
    today.setHours(0,0,0,0);
    
    const sortedEvents = EVENTS_DEF.map(ev => {
      const nextDate = getNextEventOccurrence(ev);
      const diffMs = nextDate - today;
      const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
      
      // Calculate todo count
      const evTodos = todoList.filter(t => t.eventId === ev.id);
      const totalTodos = evTodos.length;
      const doneTodos = evTodos.filter(t => t.done).length;
      
      return {
        ...ev,
        nextDate,
        diffDays,
        totalTodos,
        doneTodos
      };
    }).sort((a, b) => a.diffDays - b.diffDays);

    sortedEvents.forEach(ev => {
      const isUrgent = ev.diffDays <= 14;
      const dateStr = `${ev.nextDate.getFullYear()}/${ev.nextDate.getMonth() + 1}/${ev.nextDate.getDate()}`;
      
      const card = document.createElement("div");
      card.className = `event-card ${isUrgent ? 'event-urgent' : ''}`;
      
      // Todo status text
      let todoStatusHtml = "";
      if (ev.totalTodos > 0) {
        const isAllDone = ev.totalTodos === ev.doneTodos;
        todoStatusHtml = `
          <div class="event-status ${isAllDone ? 'completed' : ''}">
            📋 ギフト準備: ${ev.doneTodos}/${ev.totalTodos}件完了
          </div>
        `;
      } else {
        todoStatusHtml = `<div class="event-status">📋 TODO未設定</div>`;
      }

      // Checkbox state for notifications
      const isNotifOn = notificationSettings[ev.id] !== false;

      card.innerHTML = `
        <div class="event-card-header">
          <div class="event-title-group">
            <span class="event-title">${ev.name}</span>
            <span class="event-date">🗓️ ${dateStr}</span>
          </div>
          <div class="event-countdown">
            <span class="countdown-number ${isUrgent ? 'urgent' : ''}">${ev.diffDays}</span>
            <span class="countdown-label">DAYS LEFT</span>
          </div>
        </div>
        <p class="event-description">${ev.desc}</p>
        <div class="event-meta-row">
          ${todoStatusHtml}
          <div class="switch-group" data-id="${ev.id}">
            <span>通知アラーム</span>
            <label class="switch">
              <input type="checkbox" class="notif-toggle" ${isNotifOn ? 'checked' : ''}>
              <span class="slider"></span>
            </label>
          </div>
        </div>
      `;

      // Event toggle listener
      const toggle = card.querySelector(".notif-toggle");
      toggle.addEventListener("change", (e) => {
        notificationSettings[ev.id] = e.target.checked;
        chrome.storage.local.set({ notificationSettings }, () => {
          // Send message to background to re-register alarms
          chrome.runtime.sendMessage({ action: "updateAlarms" });
        });
      });

      timelineContainer.appendChild(card);
    });
  }

  // --- Render TODOs Tab ---
  function renderTodos() {
    todoListContainer.innerHTML = "";
    
    // Progress calculation
    const total = todoList.length;
    const done = todoList.filter(t => t.done).length;
    const percent = total > 0 ? Math.round((done / total) * 100) : 0;
    
    progressBarFill.style.width = `${percent}%`;
    progressPercent.textContent = `${percent}%`;
    
    const undoneCount = total - done;
    if (total === 0) {
      progressText.textContent = "登録されているギフトプランはありません。";
    } else {
      progressText.textContent = `準備中: ${undoneCount}件 / 完了: ${done}件（計 ${total}件）`;
    }

    if (total === 0) {
      todoListContainer.innerHTML = `
        <div class="advisory-box" style="text-align: center; margin-top: 10px;">
          <div class="advisory-text">登録されたTODOがありません。<br>「新規登録」ボタンからギフトプランを追加してください。</div>
        </div>
      `;
      return;
    }

    // Render TODO items
    todoList.forEach((todo, index) => {
      const eventDef = EVENTS_DEF.find(e => e.id === todo.eventId);
      const eventName = eventDef ? eventDef.name : "その他";
      
      const item = document.createElement("div");
      item.className = `todo-item ${todo.done ? 'checked' : ''}`;
      
      const budgetStr = parseInt(todo.budget || 0).toLocaleString();
      
      item.innerHTML = `
        <div class="todo-checkbox-group">
          <input type="checkbox" class="todo-checkbox" ${todo.done ? 'checked' : ''}>
          <div class="todo-details">
            <div class="todo-title-row">
              <span class="todo-gift-name">${todo.gift}</span>
              <span class="todo-recipient-badge">${todo.recipient}</span>
            </div>
            <span class="todo-sub-info">行事: ${eventName} | 予算: ¥${budgetStr}</span>
          </div>
        </div>
        <button class="todo-delete-btn" title="削除">🗑️</button>
      `;

      // Checkbox listener
      const chk = item.querySelector(".todo-checkbox");
      chk.addEventListener("change", (e) => {
        todoList[index].done = e.target.checked;
        saveTodos();
      });

      // Delete listener
      const del = item.querySelector(".todo-delete-btn");
      del.addEventListener("click", () => {
        todoList.splice(index, 1);
        saveTodos();
      });

      todoListContainer.appendChild(item);
    });
  }

  function saveTodos() {
    chrome.storage.local.set({ todos: todoList }, () => {
      renderAll();
    });
  }

  // --- TODO Add Form Events ---
  addTodoToggleBtn.addEventListener("click", () => {
    todoForm.classList.toggle("hidden");
    if (!todoForm.classList.contains("hidden")) {
      addTodoToggleBtn.textContent = "閉じる";
    } else {
      addTodoToggleBtn.textContent = "+ 新規登録";
    }
  });

  todoCancelBtn.addEventListener("click", () => {
    todoForm.reset();
    todoForm.classList.add("hidden");
    addTodoToggleBtn.textContent = "+ 新規登録";
  });

  todoForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const eventId = document.getElementById("todo-event").value;
    const recipient = document.getElementById("todo-recipient").value.trim();
    const gift = document.getElementById("todo-gift").value.trim();
    const budget = document.getElementById("todo-budget").value;

    if (!recipient || !gift) return;

    const newTodo = {
      id: "todo_" + Date.now(),
      eventId,
      recipient,
      gift,
      budget: parseInt(budget) || 0,
      done: false
    };

    todoList.push(newTodo);
    saveTodos();
    
    todoForm.reset();
    todoForm.classList.add("hidden");
    addTodoToggleBtn.textContent = "+ 新規登録";
  });

  // --- Render Sales Calendar Tab ---
  // 以前はここに「今日+3日から5日間」等、開いた日によって毎回変わる完全な
  // 架空の日程を「楽天お買い物マラソン」「Amazonタイムセール祭り」の実際の開催日
  // であるかのように表示していた(コード内コメントに正直に"Dynamic Mock Dates"と
  // 書かれていた)。各社の実際のセール日程は本ツールからは分からないため、
  // 日付の捏造をやめ、各店舗のセール会場ページへの正直なリンクのみを表示する。
  // Yahoo!ショッピングの「5のつく日」だけは毎月5・15・25日に実施される
  // 本物の定例キャンペーンのため、そのまま実際の次回日付を計算して表示する。
  function renderSales() {
    salesContainer.innerHTML = "";

    const today = new Date();

    const salesInfo = [
      {
        platform: "rakuten",
        platformName: "楽天市場",
        title: "お買い物マラソン / スーパーセール",
        desc: "複数ショップ買い回りでポイント倍率が上がる恒例イベント。開催時期は楽天側の発表により変動するため、実際の開催日程は会場ページでご確認ください。",
        dateStr: null,
        url: "https://event.rakuten.co.jp/campaign/point-up/marathon/"
      },
      {
        platform: "amazon",
        platformName: "Amazon",
        title: "タイムセール祭り / ビッグセール",
        desc: "食品や飲料、ギフト用洋菓子などがポイント還元対象になることがあるセール。開催時期はAmazon側の発表により変動するため、実際の開催日程はセールページでご確認ください。",
        dateStr: null,
        url: "https://www.amazon.co.jp/deals"
      },
      {
        platform: "yahoo",
        platformName: "Yahoo!ショッピング",
        title: "ヤフー 5のつく日キャンペーン",
        desc: "毎月5日、15日、25日にPayPay支払いでポイント還元が上乗せされる、実際に毎月開催されている定例キャンペーンです。",
        dateStr: (() => {
          const nextVal = new Date(today);
          for (let i = 0; i < 31; i++) {
            const dateNum = nextVal.getDate();
            if (dateNum === 5 || dateNum === 15 || dateNum === 25) break;
            nextVal.setDate(nextVal.getDate() + 1);
          }
          return `次回: ${nextVal.getMonth() + 1}/${nextVal.getDate()}`;
        })(),
        url: "https://shopping.yahoo.co.jp/promotion/campaign/5days/"
      }
    ];

    salesInfo.forEach(sale => {
      const card = document.createElement("div");
      card.className = "sale-card";

      card.innerHTML = `
        <div class="sale-header">
          <span class="sale-platform ${sale.platform}">${sale.platformName}</span>
          ${sale.dateStr ? `<span class="sale-date-badge">📅 ${sale.dateStr}</span>` : ""}
        </div>
        <div class="sale-title">${sale.title}</div>
        <p class="sale-desc">${sale.desc}</p>
        <button class="sale-link-btn" data-url="${sale.url}">ストアのセール会場を開く ➔</button>
      `;

      card.querySelector(".sale-link-btn").addEventListener("click", () => {
        chrome.tabs.create({ url: sale.url });
      });

      salesContainer.appendChild(card);
    });
  }

  // --- Run Initialization ---
  init();
});
