// background.js - Japanese Gift Calendar Service Worker

const EVENTS_DEF = [
  { id: "mother", name: "母の日", getNextDate: (yr) => getNthSunday(yr, 5, 2) },
  { id: "father", name: "父の日", getNextDate: (yr) => getNthSunday(yr, 6, 3) },
  { id: "chugen", name: "お中元", getNextDate: (yr) => new Date(yr, 6, 15) },
  { id: "keiro", name: "敬老の日", getNextDate: (yr) => getNthMonday(yr, 9, 3) },
  { id: "seibo", name: "お歳暮", getNextDate: (yr) => new Date(yr, 11, 10) },
  { id: "christmas", name: "クリスマス", getNextDate: (yr) => new Date(yr, 11, 25) },
  { id: "valentine", name: "バレンタインデー", getNextDate: (yr) => new Date(yr, 1, 14) }
];

// N-th Sunday calculation
function getNthSunday(year, month, n) {
  const d = new Date(year, month - 1, 1);
  let count = 0;
  while (d.getMonth() === month - 1) {
    if (d.getDay() === 0) {
      count++;
      if (count === n) return new Date(d);
    }
    d.setDate(d.getDate() + 1);
  }
  return null;
}

// N-th Monday calculation
function getNthMonday(year, month, n) {
  const d = new Date(year, month - 1, 1);
  let count = 0;
  while (d.getMonth() === month - 1) {
    if (d.getDay() === 1) {
      count++;
      if (count === n) return new Date(d);
    }
    d.setDate(d.getDate() + 1);
  }
  return null;
}

// Calculate next occurrence date relative to today
function getNextEventOccurrence(eventDef) {
  const today = new Date();
  today.setHours(0,0,0,0);
  const currentYear = today.getFullYear();
  
  let targetDate = eventDef.getNextDate(currentYear);
  targetDate.setHours(0,0,0,0);
  
  if (targetDate < today) {
    targetDate = eventDef.getNextDate(currentYear + 1);
    targetDate.setHours(0,0,0,0);
  }
  return targetDate;
}

// Check calendar dates and fire system notifications if matches (14 days or 7 days left)
function checkEventsAndNotify() {
  chrome.storage.local.get(["todos", "notificationSettings"], (result) => {
    const todos = result.todos || [];
    const settings = result.notificationSettings || {};
    const today = new Date();
    today.setHours(0,0,0,0);

    EVENTS_DEF.forEach(ev => {
      // Check if notification is enabled for this event
      if (settings[ev.id] === false) {
        return; // Disabled by user
      }

      const nextDate = getNextEventOccurrence(ev);
      const diffMs = nextDate - today;
      const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

      // Calculate unfinished tasks
      const evTodos = todos.filter(t => t.eventId === ev.id && !t.done);
      const remainingTasksStr = evTodos.length > 0 ? `（未手配のギフト: ${evTodos.length}件）` : "";

      if (diffDays === 14) {
        showNotification(
          `notif_${ev.id}_14`,
          `${ev.name}まであと2週間（14日前）`,
          `品切れや配送遅延を避けるため、そろそろギフトの手配を始めましょう。${remainingTasksStr}`
        );
      } else if (diffDays === 7) {
        showNotification(
          `notif_${ev.id}_7`,
          `⚠️ ${ev.name}まであと1週間（7日前）`,
          `当日までに届けたい場合は、お急ぎ便などの対応状況を早めに確認しておきましょう。${remainingTasksStr}`
        );
      }
    });
  });
}

// Display system desktop notification
function showNotification(notifId, title, message) {
  chrome.notifications.create(notifId, {
    type: "basic",
    iconUrl: "icons/icon128.png",
    title: title,
    message: message,
    priority: 2
  }, (createdId) => {
    if (chrome.runtime.lastError) {
      console.error("notifications.create failed:", chrome.runtime.lastError.message);
    } else {
      console.log("notifications.create succeeded, id:", createdId);
    }
  });
}

// --- Setup Periodic Alarms ---
function setupDailyAlarm() {
  chrome.alarms.clear("daily_gift_check", () => {
    // Run once every 24 hours (1440 minutes). For debugging/system load, we can also use delayInMinutes.
    chrome.alarms.create("daily_gift_check", {
      delayInMinutes: 1, // run first check after 1 minute
      periodInMinutes: 1440 // check daily
    });
  });
}

chrome.runtime.onInstalled.addListener(() => {
  setupDailyAlarm();
  // Perform initial check on install
  checkEventsAndNotify();
});

chrome.runtime.onStartup.addListener(() => {
  setupDailyAlarm();
});

// Alarm firing listener
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "daily_gift_check") {
    checkEventsAndNotify();
  }
});

// Message relay listener (for popup settings updates or debug triggers)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "updateAlarms") {
    checkEventsAndNotify();
    sendResponse({ status: "checked" });
  } else if (message.action === "triggerDebugTest") {
    // Generate an immediate notification for testing purposes
    showNotification(
      "debug_test_notif",
      "🎋 和のギフト暦 デバッグ通知",
      "年中行事の2週間前・1週間前にこのデスクトップアラームが自動で配信されます。"
    );
    sendResponse({ status: "triggered" });
  }
  return true;
});

// Open tab when notification clicked
chrome.notifications.onClicked.addListener((notificationId) => {
  // Direct to default search page or a specific site
  chrome.tabs.create({ url: "https://www.rakuten.co.jp/" });
});
