// test_sandbox.js
// 拡張機能ページ(chrome-extension://)としてこのファイルを開いた場合、Manifest V3の
// CSPによりHTML内のインラインscript/onclickは実行できない。そのため元々test_sandbox.html
// に直接書かれていたJSをこの外部ファイルに切り出している。

// Simulate searching on actual EC sites to trigger the content script matching rules
function simulateSearch(platform, query) {
  let targetUrl = "";
  if (platform === 'rakuten') {
    targetUrl = `https://search.rakuten.co.jp/search/mall/${encodeURIComponent(query)}/`;
  } else if (platform === 'amazon') {
    targetUrl = `https://www.amazon.co.jp/s?k=${encodeURIComponent(query)}`;
  } else if (platform === 'yahoo') {
    targetUrl = `https://shopping.yahoo.co.jp/search?p=${encodeURIComponent(query)}`;
  }

  if (targetUrl) {
    window.open(targetUrl, '_blank');
  }
}

document.addEventListener("DOMContentLoaded", function () {
  // Wire up the EC site simulator buttons (previously inline onclick=)
  document.querySelectorAll("[data-simulate-platform]").forEach(btn => {
    btn.addEventListener("click", () => {
      simulateSearch(btn.getAttribute("data-simulate-platform"), btn.getAttribute("data-simulate-query"));
    });
  });

  // Trigger background test notification via chrome runtime messaging
  const notifBtn = document.getElementById("trigger-notif-btn");
  if (notifBtn) {
    notifBtn.addEventListener("click", () => {
      if (window.chrome && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ action: "triggerDebugTest" }, (response) => {
          if (chrome.runtime.lastError) {
            alert("拡張機能が読み込まれていないか、メッセージの受信に失敗しました。(" + chrome.runtime.lastError.message + ")");
            return;
          }
          if (response && response.status === 'triggered') {
            alert("システムへデバッグ通知送信を要求しました。画面右下に通知が届くか確認してください。");
          } else {
            alert("拡張機能が読み込まれていないか、メッセージの受信に失敗しました。");
          }
        });
      } else {
        alert("通常のブラウザ表示モードです。デバッグ通知の送信には、拡張機能をchrome://extensionsからデベロッパーとして読み込んでください。");
      }
    });
  }

  // Draggable panels
  const cards = document.querySelectorAll(".card, .panel, .iframe-wrapper");
  cards.forEach((card) => {
    const title = card.querySelector("h2, h1, .card-title, .panel-title");
    if (title && typeof makeDraggable === "function") {
      title.style.userSelect = "none";
      title.title = "✋ ここを掴んで自由な位置へドラッグ移動できます";
      makeDraggable(card, title);
    }
  });
});
