// content.js - Japanese Gift Calendar Content Script

(function () {
  // Prevent double injection
  if (window.hasJapaneseGiftCalendarBanner) return;
  window.hasJapaneseGiftCalendarBanner = true;

  // Session storage check to see if banner was dismissed
  if (sessionStorage.getItem("gift_calendar_banner_dismissed") === "true") {
    return;
  }

  // --- Date Calculations ---
  const EVENTS_DEF = [
    { id: "mother", name: "母の日", getNextDate: (yr) => getNthSunday(yr, 5, 2) },
    { id: "father", name: "父の日", getNextDate: (yr) => getNthSunday(yr, 6, 3) },
    { id: "chugen", name: "お中元", getNextDate: (yr) => new Date(yr, 6, 15) },
    { id: "keiro", name: "敬老の日", getNextDate: (yr) => getNthMonday(yr, 9, 3) },
    { id: "seibo", name: "お歳暮", getNextDate: (yr) => new Date(yr, 11, 10) },
    { id: "christmas", name: "クリスマス", getNextDate: (yr) => new Date(yr, 11, 25) },
    { id: "valentine", name: "バレンタインデー", getNextDate: (yr) => new Date(yr, 1, 14) }
  ];

  function getNthSunday(year, month, n) {
    const d = new Date(year, month - 1, 1);
    let count = 0;
    while (d.getMonth() === month - 1) {
      if (d.getDay() === 0) {
        count++;
        if (count === n) return new Date(d);
      }
      d.setDate(d.getDate() + 1);
    }
    return null;
  }

  function getNthMonday(year, month, n) {
    const d = new Date(year, month - 1, 1);
    let count = 0;
    while (d.getMonth() === month - 1) {
      if (d.getDay() === 1) {
        count++;
        if (count === n) return new Date(d);
      }
      d.setDate(d.getDate() + 1);
    }
    return null;
  }

  function getNextEventOccurrence(eventDef) {
    const today = new Date();
    today.setHours(0,0,0,0);
    const currentYear = today.getFullYear();
    
    let targetDate = eventDef.getNextDate(currentYear);
    targetDate.setHours(0,0,0,0);
    
    if (targetDate < today) {
      targetDate = eventDef.getNextDate(currentYear + 1);
      targetDate.setHours(0,0,0,0);
    }
    return targetDate;
  }

  // --- Main Execution ---
  const today = new Date();
  today.setHours(0,0,0,0);
  
  let targetEvent = null;
  let minDays = 9999;

  EVENTS_DEF.forEach(ev => {
    const nextDate = getNextEventOccurrence(ev);
    const diffMs = nextDate - today;
    const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
    if (diffDays < minDays) {
      minDays = diffDays;
      targetEvent = ev;
    }
  });

  // Only show banner if the closest event is within 14 days
  // Or check if the current query parameter contains gift keywords to suggest reminders anyway
  const urlParams = new URLSearchParams(window.location.search);
  const pageText = (urlParams.get("k") || urlParams.get("q") || urlParams.get("_nkw") || "").toLowerCase();
  const hasGiftKeyword = ["ギフト", "プレゼント", "母の日", "父の日", "お中元", "お歳暮", "敬老の日", "贈り物", "贈答"].some(kw => pageText.includes(kw));

  if (targetEvent && (minDays <= 14 || hasGiftKeyword)) {
    // If we matched because of keyword rather than <= 14 days, targetEvent is still valid but diffDays might be larger
    injectGiftCalendarBanner(targetEvent, minDays);
  }

  // --- Banner Injection with Shadow DOM ---
  function injectGiftCalendarBanner(event, daysLeft) {
    const container = document.createElement("div");
    container.id = "japanese-gift-calendar-inject-root";
    
    // Position fixed at the absolute top of the page
    container.style.position = "fixed";
    container.style.top = "0";
    container.style.left = "0";
    container.style.width = "100%";
    container.style.height = "42px";
    container.style.zIndex = "2147483647"; // Max possible z-index
    container.style.transition = "transform 0.3s ease";
    
    // Create Shadow DOM to encapsulate styling
    const shadow = container.attachShadow({ mode: "open" });
    
    // Add external stylesheet path (which will be content.css)
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = chrome.runtime.getURL("content.css");
    shadow.appendChild(link);

    // Banner Inner HTML
    const banner = document.createElement("div");
    banner.className = `gift-banner-bar ${daysLeft <= 7 ? 'urgent' : ''}`;
    
    let messageHtml = "";
    if (daysLeft <= 7) {
      messageHtml = `⚠️ <b>【配送混雑の警告】</b> <b>${event.name}</b>まであと <b>${daysLeft}日</b>！当日届けに間に合わせるため、今すぐ手配をおすすめします。`;
    } else if (daysLeft <= 14) {
      messageHtml = `⏳ <b>【早期割引・早割】</b> <b>${event.name}</b>まであと <b>${daysLeft}日</b>！14日前までのギフト手配で、品切れや遅延を防ぎお得に購入できます。`;
    } else {
      messageHtml = `🎋 <b>【年中行事リマインダー】</b> 近日の行事は <b>${event.name}</b>（あと ${daysLeft}日）です。ギフトの買い忘れにご注意ください。`;
    }

    banner.innerHTML = `
      <div class="banner-body">
        <span class="banner-icon">🎋</span>
        <div class="banner-text">${messageHtml}</div>
        <button class="banner-btn" id="open-popup-sim">ギフト暦を開く</button>
      </div>
      <button class="banner-close" id="close-banner" title="閉じる">×</button>
    `;

    shadow.appendChild(banner);
    document.documentElement.appendChild(container);

    // Push the body down so the banner doesn't cover search boxes or top navigation
    document.documentElement.style.marginTop = "42px";

    // --- Banner Event Listeners ---
    // Close banner
    shadow.getElementById("close-banner").addEventListener("click", () => {
      container.style.transform = "translateY(-42px)";
      document.documentElement.style.marginTop = "0px";
      sessionStorage.setItem("gift_calendar_banner_dismissed", "true");
      setTimeout(() => {
        container.remove();
      }, 300);
    });

    // Open Action button
    shadow.getElementById("open-popup-sim").addEventListener("click", () => {
      // Direct extension popup cannot be programmatically opened via chrome.action.openPopup() in content scripts easily,
      // so we show a beautiful overlay modal inside this page as an alternative dashboard simulation!
      showInPageDashboard(event, daysLeft);
    });
  }

  // --- Beautiful In-Page Overlay Dashboard ---
  function showInPageDashboard(currentEvent, daysLeft) {
    const overlayId = "japanese-gift-calendar-overlay-root";
    if (document.getElementById(overlayId)) return;

    const overlayContainer = document.createElement("div");
    overlayContainer.id = overlayId;
    overlayContainer.style.position = "fixed";
    overlayContainer.style.top = "0";
    overlayContainer.style.right = "0";
    overlayContainer.style.width = "400px";
    overlayContainer.style.height = "100%";
    overlayContainer.style.zIndex = "2147483647";
    overlayContainer.style.boxShadow = "-5px 0 30px rgba(0,0,0,0.5)";
    overlayContainer.style.transition = "transform 0.3s cubic-bezier(0.16, 1, 0.3, 1)";
    overlayContainer.style.transform = "translateX(400px)";

    const shadow = overlayContainer.attachShadow({ mode: "open" });
    
    // Add stylesheet
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = chrome.runtime.getURL("content.css");
    shadow.appendChild(link);

    const dashboard = document.createElement("div");
    dashboard.className = "inpage-dashboard";
    
    // Load todos for this event
    chrome.storage.local.get(["todos"], (result) => {
      const todos = result.todos || [];
      const evTodos = todos.filter(t => t.eventId === currentEvent.id);
      
      let todoListHtml = "";
      if (evTodos.length > 0) {
        todoListHtml = evTodos.map(t => `
          <div class="dash-todo-item ${t.done ? 'done' : ''}">
            <span class="chk">${t.done ? '✓' : '○'}</span>
            <div class="details">
              <span class="name">${t.gift}</span>
              <span class="rec">宛先: ${t.recipient}</span>
            </div>
            <span class="budget">¥${parseInt(t.budget).toLocaleString()}</span>
          </div>
        `).join("");
      } else {
        todoListHtml = `
          <div class="no-todo-advisory">
            この行事用のギフト計画（TODO）が未登録です。拡張機能のアイコンをクリックして、TODOプランを作成しましょう！
          </div>
        `;
      }

      dashboard.innerHTML = `
        <div class="dash-header">
          <div class="dash-logo">🎋 和のギフト暦</div>
          <button id="close-dash">×</button>
        </div>
        <div class="dash-body">
          <div class="dash-event-banner ${daysLeft <= 7 ? 'urgent' : ''}">
            <div class="title">${currentEvent.name}まで</div>
            <div class="countdown">あと <span class="days">${daysLeft}</span> 日</div>
          </div>

          <div class="dash-section-title">🗓️ 配送とお得手配のアドバイス</div>
          <div class="dash-advisory-card">
            <b>1. 早割セールを利用する</b><br>
            楽天お買い物マラソンやAmazonポイントアップ期間などを活用し、2週間前までに購入すると、通常価格より最大30%お得になります。<br><br>
            <b>2. 配送遅延に備える</b><br>
            特に「母の日」や「お歳暮」の時期は日本中の物流がパンクします。直前注文は指定日に届かないトラブルが頻発するため、1週間前までの配送手配完了を徹底してください。
          </div>

          <div class="dash-section-title">🎁 あなたのギフトTODO (${currentEvent.name})</div>
          <div class="dash-todos-container">
            ${todoListHtml}
          </div>

          <button class="dash-footer-btn" id="go-to-popup-hint">TODOの追加や編集は、拡張機能のアイコン（右上）から行えます</button>
        </div>
      `;

      shadow.appendChild(dashboard);
      document.body.appendChild(overlayContainer);

      // Trigger slide-in
      setTimeout(() => {
        overlayContainer.style.transform = "translateX(0px)";
      }, 50);

      // Close events
      shadow.getElementById("close-dash").addEventListener("click", () => {
        overlayContainer.style.transform = "translateX(400px)";
        setTimeout(() => {
          overlayContainer.remove();
        }, 300);
      });
    });
  }

})();


// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // Add temporary shield to prevent iframe from stealing mouse events during dragging
      const existingShield = document.getElementById("wano-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = "wano-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      // Use getBoundingClientRect() for correct viewport-relative position
      // (element.offsetTop is unreliable for position:fixed elements on scrolled pages)
      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      // Restrict within window boundaries to prevent going offscreen
      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById("wano-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById("wano-universal-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "block" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = "wano-universal-floating-container";
    
    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 452) + "px !important; z-index:2147483647 !important; width:442px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="wano-u-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">Japanese Gift Calendar</span>
        </div>
        <button id="wano-u-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#wano-u-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#wano-u-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
