// background.js - Japanese Font Changer background service worker

const DEFAULT_SETTINGS = {
  enabled: false,
  selectedFont: "noto-serif",
  applyTarget: "all",
  sizeAdjust: 0,
  blacklist: []
};

chrome.runtime.onInstalled.addListener(() => {
  // Initialize default configuration
  chrome.storage.local.get(["fontChangerSettings"], (result) => {
    if (!result.fontChangerSettings) {
      chrome.storage.local.set({ fontChangerSettings: DEFAULT_SETTINGS }, () => {
        console.log("Japanese Font Changer: Default settings initialized.");
      });
    }
  });
});
