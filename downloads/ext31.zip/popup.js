// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window.
            // Pass the original tab's id through so the standalone window can
            // still target the right tab (it becomes its own focused window,
            // so chrome.tabs.query({currentWindow:true}) would otherwise
            // resolve to itself instead of the page the user wants to affect).
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window&tabId=" + tabs[0].id),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// popup.js - Japanese Font Changer settings panel logic with Default Font Card Sync

document.addEventListener("DOMContentLoaded", () => {
  // --- Elements ---
  const enableToggle = document.getElementById("main-enable-toggle");
  const toggleStatusLabel = document.getElementById("toggle-status-label");
  const fontCards = document.querySelectorAll(".font-card");
  const sizeSlider = document.getElementById("font-size-adjust-slider");
  const sizeValLabel = document.getElementById("size-adjust-val");
  const domainInput = document.getElementById("blacklist-domain-input");
  const addBlacklistBtn = document.getElementById("add-blacklist-btn");
  const blacklistContainer = document.getElementById("blacklist-container");
  
  const toggleComposite = document.getElementById("toggle-composite-enable");
  const compositeContainer = document.getElementById("composite-form-container");
  const selCompositeKana = document.getElementById("sel-composite-kana");
  const selCompositeKanji = document.getElementById("sel-composite-kanji");
  const selCompositeAlpha = document.getElementById("sel-composite-alpha");

  const toggleOutmoded = document.getElementById("toggle-outmoded-enable");
  const outmodedStatusCard = document.getElementById("outmoded-status-card");

  const statusDot = document.getElementById("footer-status-dot");
  const statusText = document.getElementById("footer-status-text");

  let currentDomain = "";
  let settings = {
    enabled: false,
    selectedFont: "noto-serif",
    applyTarget: "all",
    sizeAdjust: 0,
    blacklist: [],
    compositeEnabled: false,
    compositeKana: "'Kosugi Maru'",
    compositeKanji: "system-ui",
    compositeAlpha: "'Outfit', sans-serif",
    outmodedEnabled: false
  };

  // In the "mode=window" fail-safe (this popup opened as its own standalone
  // OS window because the in-page floating panel could not be reached), this
  // window becomes the focused window, so chrome.tabs.query({currentWindow:true})
  // would resolve to itself rather than the page the user wants to affect.
  // The originating tab's id is passed explicitly in that case.
  const popupUrlParams = new URLSearchParams(window.location.search);
  const explicitTabId = popupUrlParams.get("tabId");
  let targetTabId = explicitTabId ? parseInt(explicitTabId, 10) : null;

  function withTargetTab(callback) {
    if (targetTabId) {
      chrome.tabs.get(targetTabId, (tab) => {
        callback(chrome.runtime.lastError ? null : tab);
      });
    } else {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const tab = tabs && tabs[0] ? tabs[0] : null;
        targetTabId = tab ? tab.id : null;
        callback(tab);
      });
    }
  }

  // --- 1. Get Current Tab Domain ---
  if (window.chrome && chrome.tabs) {
    withTargetTab((tab) => {
      if (tab && tab.url) {
        try {
          const parsedUrl = new URL(tab.url);
          if (parsedUrl.protocol.startsWith("http")) {
            currentDomain = parsedUrl.hostname;
            domainInput.value = currentDomain;
            checkBlacklistButtonState();
          } else {
            domainInput.value = "適用不可 (システム/ローカルページ)";
            addBlacklistBtn.disabled = true;
            addBlacklistBtn.style.opacity = "0.5";
          }
        } catch (e) {
          console.error("Domain parsing error:", e);
        }
      }
    });
  } else {
    // Sandbox default
    currentDomain = "sandbox.local";
    domainInput.value = currentDomain;
  }

  // --- 2. Load Settings from Storage ---
  function loadSettings() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.get(["fontChangerSettings"], (result) => {
        if (result.fontChangerSettings) {
          settings = { ...settings, ...result.fontChangerSettings };
        }
        applySettingsToUI();
      });
    } else {
      // Sandbox fallback
      const saved = localStorage.getItem("fontChangerSettings");
      if (saved) {
        settings = JSON.parse(saved);
      }
      applySettingsToUI();
    }
  }

  function saveSettings() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.set({ fontChangerSettings: settings }, () => {
        notifyTabs();
      });
    } else {
      localStorage.setItem("fontChangerSettings", JSON.stringify(settings));
      console.log("Sandbox Saved settings:", settings);
    }
    // Parent window postMessage relay for seamless sandbox validation
    if (window.parent && window.parent !== window) {
      window.parent.postMessage({
        action: "updateFontSettings",
        settings: settings
      }, "*");
    }
  }

  // --- 3. Bind Settings to UI Elements ---
  function applySettingsToUI() {
    // Toggle state
    enableToggle.checked = settings.enabled;
    updateStatusIndicator(settings.enabled);

    // Font family card activation
    fontCards.forEach(card => {
      card.classList.remove("active");
      card.style.opacity = settings.compositeEnabled ? "0.4" : "1";
      card.style.pointerEvents = settings.compositeEnabled ? "none" : "auto";
      const fontId = card.getAttribute("data-font");
      
      if (settings.compositeEnabled) {
        return; // If composite is ON, card selection is temporarily grayed out
      }

      if (!settings.enabled) {
        // If extension is disabled, "Default Font" card is active
        if (fontId === "default") {
          card.classList.add("active");
        }
      } else {
        // If enabled, highlight the matching custom font card
        if (fontId === settings.selectedFont) {
          card.classList.add("active");
        }
      }
    });

    // Radio target
    const radio = document.querySelector(`input[name="apply-target"][value="${settings.applyTarget}"]`);
    if (radio) {
      radio.checked = true;
    }

    // Size slider
    sizeSlider.value = settings.sizeAdjust;
    updateSliderLabel(settings.sizeAdjust);

    // Composite Font settings
    toggleComposite.checked = settings.compositeEnabled;
    compositeContainer.style.display = settings.compositeEnabled ? "flex" : "none";
    selCompositeKana.value = settings.compositeKana;
    selCompositeKanji.value = settings.compositeKanji;
    selCompositeAlpha.value = settings.compositeAlpha;

    // Outmoded Highlight settings
    toggleOutmoded.checked = settings.outmodedEnabled;
    outmodedStatusCard.style.display = settings.outmodedEnabled ? "block" : "none";

    // Blacklist list
    renderBlacklist();
    checkBlacklistButtonState();
  }

  function updateStatusIndicator(enabled) {
    if (enabled) {
      toggleStatusLabel.textContent = "有効";
      toggleStatusLabel.style.color = "var(--accent-gold)";
      statusDot.classList.add("active");
      statusText.textContent = "和の書体暦 稼働中";
    } else {
      toggleStatusLabel.textContent = "無効";
      toggleStatusLabel.style.color = "var(--text-muted)";
      statusDot.classList.remove("active");
      statusText.textContent = "和の書体暦 停止中";
    }
  }

  function updateSliderLabel(val) {
    val = parseInt(val);
    if (val === 0) {
      sizeValLabel.textContent = "標準 (0px)";
    } else if (val > 0) {
      sizeValLabel.textContent = `拡大 (+${val}px)`;
    } else {
      sizeValLabel.textContent = `縮小 (${val}px)`;
    }
  }

  // --- 4. Event Listeners ---
  // Main Toggle Switch
  enableToggle.addEventListener("change", (e) => {
    settings.enabled = e.target.checked;
    
    if (settings.enabled) {
      // If turned ON and was set to default, fallback to noto-serif as active
      if (settings.selectedFont === "default") {
        settings.selectedFont = "noto-serif";
      }
    }
    
    updateStatusIndicator(settings.enabled);
    applySettingsToUI();
    saveSettings();
  });

  // Font Selection Cards Clicks
  fontCards.forEach(card => {
    card.addEventListener("click", () => {
      const clickedFont = card.getAttribute("data-font");
      
      if (clickedFont === "default") {
        // Clicking "Default" disables the font override
        settings.enabled = false;
      } else {
        // Clicking any custom font enables the extension
        settings.enabled = true;
        settings.selectedFont = clickedFont;
      }
      
      applySettingsToUI();
      saveSettings();
    });
  });

  // Radio Targets
  const radios = document.querySelectorAll('input[name="apply-target"]');
  radios.forEach(r => {
    r.addEventListener("change", (e) => {
      if (e.target.checked) {
        settings.applyTarget = e.target.value;
        saveSettings();
      }
    });
  });

  // Slider Size Adjust
  sizeSlider.addEventListener("input", (e) => {
    const val = parseInt(e.target.value);
    updateSliderLabel(val);
    settings.sizeAdjust = val;
    saveSettings();
  });

  // Composite Font Listeners
  toggleComposite.addEventListener("change", (e) => {
    settings.compositeEnabled = e.target.checked;
    compositeContainer.style.display = e.target.checked ? "flex" : "none";
    if (e.target.checked) {
      settings.enabled = true;
    }
    applySettingsToUI();
    saveSettings();
  });

  selCompositeKana.addEventListener("change", (e) => {
    settings.compositeKana = e.target.value;
    saveSettings();
  });

  selCompositeKanji.addEventListener("change", (e) => {
    settings.compositeKanji = e.target.value;
    saveSettings();
  });

  selCompositeAlpha.addEventListener("change", (e) => {
    settings.compositeAlpha = e.target.value;
    saveSettings();
  });

  // Outmoded Highlight Listener
  toggleOutmoded.addEventListener("change", (e) => {
    settings.outmodedEnabled = e.target.checked;
    outmodedStatusCard.style.display = e.target.checked ? "block" : "none";
    if (e.target.checked) {
      settings.enabled = true;
    }
    applySettingsToUI();
    saveSettings();
  });

  // Add Current Domain to Blacklist
  addBlacklistBtn.addEventListener("click", () => {
    if (currentDomain && !settings.blacklist.includes(currentDomain)) {
      settings.blacklist.push(currentDomain);
      saveSettings();
      renderBlacklist();
      checkBlacklistButtonState();
    }
  });

  // --- 5. Blacklist Rendering ---
  function renderBlacklist() {
    blacklistContainer.innerHTML = "";
    if (settings.blacklist.length === 0) {
      blacklistContainer.innerHTML = `
        <div style="font-size: 11px; color: var(--text-muted); padding: 6px; text-align: center;">
          除外設定されたサイトはありません。
        </div>
      `;
      return;
    }

    settings.blacklist.forEach(domain => {
      const item = document.createElement("div");
      item.className = "blacklist-item";
      
      item.innerHTML = `
        <span class="blacklist-domain">${domain}</span>
        <button class="blacklist-remove-btn" title="除外解除">×</button>
      `;

      item.querySelector(".blacklist-remove-btn").addEventListener("click", () => {
        settings.blacklist = settings.blacklist.filter(d => d !== domain);
        saveSettings();
        renderBlacklist();
        checkBlacklistButtonState();
      });

      blacklistContainer.appendChild(item);
    });
  }

  function checkBlacklistButtonState() {
    if (!currentDomain || currentDomain.includes("local") || currentDomain === "sandbox.local") {
      return; // Skip sandbox state blocks
    }
    if (settings.blacklist.includes(currentDomain)) {
      addBlacklistBtn.textContent = "除外設定済み";
      addBlacklistBtn.disabled = true;
      addBlacklistBtn.style.opacity = "0.6";
    } else {
      addBlacklistBtn.textContent = "このサイトを除外";
      addBlacklistBtn.disabled = false;
      addBlacklistBtn.style.opacity = "1";
    }
  }

  // --- 6. Notify content scripts in tabs ---
  function notifyTabs() {
    if (window.chrome && chrome.tabs) {
      // Target only the active tab to bypass "tabs" permission constraints and ensure instant loading
      withTargetTab((tab) => {
        if (tab) {
          chrome.tabs.sendMessage(tab.id, {
            action: "updateFontSettings",
            settings: settings
          }, () => {
            // Ignore errors if content script is not loaded yet (e.g. system pages)
            if (chrome.runtime.lastError) {
              // Silent
            }
          });
        }
      });
    }
  }

  // Init panel
  loadSettings();
});
