// content.js - Japanese Font Changer Content Script (Robust Universal Selector Version)

(function () {
  const STYLE_ELEMENT_ID = "japanese-font-changer-injected-style";
  
  const DEFAULT_SETTINGS = {
    enabled: false,
    selectedFont: "noto-serif",
    applyTarget: "all",
    sizeAdjust: 0,
    blacklist: [],
    compositeEnabled: false,
    compositeKana: "'Kosugi Maru'",
    compositeKanji: "system-ui",
    compositeAlpha: "'Outfit', sans-serif",
    outmodedEnabled: false
  };

  const FONT_MAP = {
    "noto-serif": {
      name: "Noto Serif JP",
      importUrl: "https://fonts.googleapis.com/css2?family=Noto+Serif+JP:wght@400;700&display=swap",
      fallback: "serif"
    },
    "klee-one": {
      name: "Klee One",
      importUrl: "https://fonts.googleapis.com/css2?family=Klee+One:wght@400;600&display=swap",
      fallback: "cursive, serif"
    },
    "yuji-syuku": {
      name: "Yuji Syuku",
      importUrl: "https://fonts.googleapis.com/css2?family=Yuji+Syuku&display=swap",
      fallback: "serif"
    },
    "kosugi-maru": {
      name: "Kosugi Maru",
      importUrl: "https://fonts.googleapis.com/css2?family=Kosugi+Maru&display=swap",
      fallback: "sans-serif"
    },
    "dela-gothic": {
      name: "Dela Gothic One",
      importUrl: "https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap",
      fallback: "sans-serif"
    }
  };

  let lastAppliedSettings = null;

  // --- 1. Load Settings and Run ---
  function init() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.get(["fontChangerSettings"], (result) => {
        const settings = result.fontChangerSettings || DEFAULT_SETTINGS;
        lastAppliedSettings = settings;
        applyFontChanger(settings);
      });
    }
  }

  // --- 2. Apply Font Replacement Styles ---
  const OUTMODED_STYLE_ID = "japanese-font-changer-outmoded-style";
  const jaOutmodedRegex = /[國學藝櫻戀鐵變體廣舊顯晝罐鹽①-⑳Ⅰ-Ⅻ㈱㈲㊤㊥㊦㊧㊨℡㍻㍼㍽㍽]/g;

  function applyFontChanger(settings) {
    // Clean up existing style tags first
    removeFontChanger();
    revertOutmodedHighlights();

    // Check enable state
    if (!settings.enabled) return;

    // Check blacklist host match
    const currentHost = window.location.hostname;
    
    // Google Workspace & Development apps have highly sensitive layout, font, and custom icon calculations.
    // Force blacklist them to prevent critical UI breakages (like missing tabs or broken Apps Script editors).
    const isGoogleWorkspace = currentHost.includes("docs.google.com") || 
                              currentHost.includes("mail.google.com") || 
                              currentHost.includes("drive.google.com") ||
                              currentHost.includes("script.google.com") ||
                              currentHost.includes("calendar.google.com") ||
                              currentHost.includes("accounts.google.com");
                              
    if (isGoogleWorkspace || (settings.blacklist && settings.blacklist.includes(currentHost))) {
      return; 
    }

    // Build the dynamic CSS rules
    const styleEl = document.createElement("style");
    styleEl.id = STYLE_ELEMENT_ID;

    // (A) Target Selection Logic
    let targetSelectors = "";
    if (settings.applyTarget === "headings") {
      // Targets only heading tags and their internal text elements
      targetSelectors = `h1, h2, h3, h4, h5, h6, h1 *, h2 *, h3 *, h4 *, h5 *, h6 *`;
    } else if (settings.applyTarget === "body") {
      // Targets main content tags (excludes headings)
      const tags = ["p", "span", "a", "li", "td", "th", "dt", "dd", "input", "select", "textarea", "button", "div"];
      // Also exclude headings explicitly to prevent leak
      targetSelectors = tags.map(tag => `${tag}:not(h1):not(h1 *):not(h2):not(h2 *):not(h3):not(h3 *):not(h4):not(h4 *):not(h5):not(h5 *):not(h6):not(h6 *)`).join(", ");
    } else {
      // Universal Selector: Targets every single element
      targetSelectors = `*`;
    }

    // (B) Font Size Modifier Logic (Using zoom to guarantee scaling across all rem/px defined elements)
    let fontSizeStyle = "";
    const sizeAdjust = parseInt(settings.sizeAdjust || 0);
    if (sizeAdjust !== 0) {
      const scaleFactor = 1 + (sizeAdjust * 0.05); // 5% zoom change per step
      fontSizeStyle = `
        body {
          zoom: ${scaleFactor} !important;
        }
      `;
    }

    // (C) High-Specificity Reset Styles
    const forceResetStyle = `
      pre, code, kbd, samp, var,
      pre *, code *, kbd *, samp *, var * {
        font-family: ui-monospace, SFMono-Regular, Consolas, "Liberation Mono", Menlo, monospace !important;
      }
      .material-icons, .material-icons *,
      .material-icons-outlined, .material-icons-outlined *,
      .material-symbols-outlined, .material-symbols-outlined *,
      [class*="fa-"], [class*="fa-"] *,
      [class*="icon-"], [class*="icon-"] *,
      .glyphicon, .glyphicon *,
      i, i *, svg, svg *, canvas, canvas * {
        font-family: "Material Icons", "Material Icons Outlined", "Material Symbols Outlined", "Font Awesome 6 Free", "Font Awesome 6 Brands", "Font Awesome 5 Free", "Font Awesome 5 Brands", "Fontawesome", "Glyphicons Halflings", inherit !important;
      }
    `;

    // (D) Combine all rules depending on Composite Font status
    let importFontsUrl = "https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;700&family=Noto+Serif+JP:wght@400;700&family=Klee+One:wght@400;600&family=Yuji+Syuku&family=Kosugi+Maru&family=Dela+Gothic+One&family=Outfit:wght@400;700&family=Share+Tech+Mono&display=swap";
    
    let fontCSS = "";
    if (settings.compositeEnabled) {
      const valKana = settings.compositeKana || "'Kosugi Maru'";
      const valKanji = settings.compositeKanji || "system-ui";
      const valAlpha = settings.compositeAlpha || "'Outfit', sans-serif";

      fontCSS = `
        @font-face {
          font-family: 'WabiMainComposite';
          src: local(${valKana});
          unicode-range: U+3040-309F, U+30A0-30FF, U+3001-U+3002;
        }
        @font-face {
          font-family: 'WabiMainComposite';
          src: local(${valKanji});
          unicode-range: U+4E00-9FFF, U+3400-4DBF;
        }
        @font-face {
          font-family: 'WabiMainComposite';
          src: local(${valAlpha});
          unicode-range: U+0020-007E;
        }
        
        ${targetSelectors} {
          font-family: 'WabiMainComposite', sans-serif !important;
        }
      `;
    } else {
      const fontConfig = FONT_MAP[settings.selectedFont];
      if (fontConfig) {
        fontCSS = `
          @import url('${fontConfig.importUrl}');
          
          ${targetSelectors} {
            font-family: '${fontConfig.name}', ${fontConfig.fallback} !important;
          }
        `;
      }
    }

    styleEl.textContent = `
      @import url('${importFontsUrl}');
      ${fontCSS}
      ${fontSizeStyle}
      ${forceResetStyle}
    `;

    insertStyle(styleEl);

    // Apply outmoded highlights if enabled
    if (settings.outmodedEnabled) {
      applyOutmodedHighlighter();
    }
  }

  // --- 3. DOM Placement Helper ---
  function insertStyle(styleEl) {
    const target = document.head || document.getElementsByTagName("head")[0] || document.documentElement;
    if (target) {
      target.appendChild(styleEl);
    }
  }

  // --- 4. Remove Styles & Highlights ---
  function removeFontChanger() {
    const existing = document.getElementById(STYLE_ELEMENT_ID);
    if (existing) {
      existing.remove();
    }
    const outStyle = document.getElementById(OUTMODED_STYLE_ID);
    if (outStyle) {
      outStyle.remove();
    }
  }

  function applyOutmodedHighlighter() {
    // Inject style first
    let outStyle = document.getElementById(OUTMODED_STYLE_ID);
    if (!outStyle) {
      outStyle = document.createElement("style");
      outStyle.id = OUTMODED_STYLE_ID;
      outStyle.innerHTML = `
        .wabi-outmoded-char-hl-page {
          outline: 1.5px dashed #e05a47 !important;
          outline-offset: 1px !important;
          background-color: rgba(224, 90, 71, 0.15) !important;
          border-radius: 2px !important;
          position: relative !important;
          cursor: help !important;
          display: inline !important;
        }
      `;
      insertStyle(outStyle);
    }

    let matchedCount = 0;
    function walk(node) {
      if (node.nodeType === 3) {
        const text = node.nodeValue;
        if (jaOutmodedRegex.test(text)) {
          if (node.parentElement && (node.parentElement.closest("select") || node.parentElement.closest("style") || node.parentElement.closest("script"))) {
            return;
          }

          const span = document.createElement("span");
          span.setAttribute("data-wabi-font-wrap-ref-page", "true");
          
          let html = text.replace(jaOutmodedRegex, (match) => {
            matchedCount++;
            let type = "旧字体";
            if (/[①-⑳Ⅰ-Ⅻ㈱㈲㊤㊥㊦㊧㊨℡㍻]/.test(match)) {
              type = "環境依存文字";
            }
            return `<span class="wabi-outmoded-char-hl-page" title="${type}: 「${match}」">${match}</span>`;
          });

          span.innerHTML = html;
          node.parentNode.replaceChild(span, node);
        }
      } else if (node.nodeType === 1 && node.childNodes) {
        const children = Array.from(node.childNodes);
        children.forEach(child => walk(child));
      }
    }

    walk(document.body);
  }

  function revertOutmodedHighlights() {
    document.querySelectorAll("[data-wabi-font-wrap-ref-page]").forEach(wrap => {
      const parent = wrap.parentNode;
      if (parent) {
        const textNode = document.createTextNode(wrap.textContent);
        parent.replaceChild(textNode, wrap);
      }
    });
  }

  // --- 5. Event & DOM Hooks for Reliable Loading ---
  // Run on initial document_start
  init();

  // Run on DOM ready to catch dynamic SPA additions
  document.addEventListener("DOMContentLoaded", () => {
    if (lastAppliedSettings) {
      applyFontChanger(lastAppliedSettings);
    } else {
      init();
    }
  });

  // Run on window loaded to guarantee final style sheet override
  window.addEventListener("load", () => {
    if (lastAppliedSettings) {
      applyFontChanger(lastAppliedSettings);
    }
  });

  // --- 6. Message Listener (Popup live updates) ---
  if (window.chrome && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "updateFontSettings") {
        lastAppliedSettings = message.settings;
        applyFontChanger(message.settings);
        sendResponse({ status: "applied" });
      }
      return true;
    });
  }
})();


// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  const NS_ID = "wano-" + chrome.runtime.id;

  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // Add temporary shield to prevent iframe from stealing mouse events during dragging
      const existingShield = document.getElementById(NS_ID + "-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = NS_ID + "-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      // Use getBoundingClientRect() for correct viewport-relative position
      // (element.offsetTop is unreliable for position:fixed elements on scrolled pages)
      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      // Restrict within window boundaries to prevent going offscreen
      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById(NS_ID + "-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById(NS_ID + "-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "block" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = NS_ID + "-floating-container";
    
    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 452) + "px !important; z-index:2147483647 !important; width:442px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="${NS_ID}-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">Japanese Font Changer</span>
        </div>
        <button id="${NS_ID}-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#" + NS_ID + "-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#" + NS_ID + "-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
