// content.js - Qiita/Zenn Reader Assist

function initWabiReader() {
  // Determine domain
  const isQiita = location.hostname.includes("qiita.com");
  const isZenn = location.hostname.includes("zenn.dev");
  const isSelfSandbox = location.pathname.includes("42_qiita_zenn_assist") && location.pathname.includes("sandbox");

  // Early return if not matching target domains
  if (!isQiita && !isZenn && !isSelfSandbox) {
    return;
  }

  console.log("💮 Wabi Reader Content Script Booting...");

  // Prevent duplicate initialization
  if (document.getElementById("wabi-reader-sidebar")) {
    return;
  }

  // Determine main article wrapper selectors
  let articleSelector = "";
  if (isQiita) {
    articleSelector = ".article-body, [class*='ArticleBody'], article";
  } else if (isZenn) {
    articleSelector = ".znc, article";
  } else {
    articleSelector = "article, main"; // Fallback for sandbox
  }

  // State Settings
  let currentTheme = "dark";
  let readerMode = "off";

  // Create Sidebar
  const sidebar = document.createElement("div");
  sidebar.id = "wabi-reader-sidebar";
  sidebar.className = "wabi-sidebar-theme-light";
  sidebar.innerHTML = `
    <div class="wabi-sidebar-header">
      <div class="wabi-logo-group">
        <span class="wabi-logo-emoji">💮</span>
        <div class="wabi-logo-texts">
          <span class="wabi-logo-title">快適読書アシスト</span>
          <span class="wabi-logo-subtitle">Zen Reader Assist</span>
        </div>
      </div>
      <button class="wabi-toggle-minimize" id="wabi-btn-minimize" title="サイドバーを折りたたむ">▶</button>
    </div>

    <div class="wabi-sidebar-content">
      <!-- Zen Reader Switch -->
      <div class="wabi-control-card">
        <div class="wabi-control-row">
          <span class="wabi-control-label">🏮 読書モード</span>
          <label class="wabi-switch">
            <input type="checkbox" id="wabi-switch-zen">
            <span class="wabi-slider"></span>
          </label>
        </div>
        <p class="wabi-control-desc">広告やヘッダーを隠し、生成色背景と明朝体で読書に没頭できます。</p>
      </div>

      <!-- Code Themes -->
      <div class="wabi-control-card">
        <span class="wabi-control-label">🖌️ コード配色</span>
        <div class="wabi-theme-selector">
          <button class="wabi-theme-btn active" data-theme="dark" title="墨黒 (すみのくろ - ダーク)">墨黒</button>
          <button class="wabi-theme-btn" data-theme="light" title="白木 (しらき - ライト)">白木</button>
          <button class="wabi-theme-btn" data-theme="indigo" title="藍墨 (あいずみ - 濃紺)">藍墨</button>
        </div>
      </div>

      <!-- Table of Contents -->
      <div class="wabi-toc-section">
        <span class="wabi-toc-title">目次構造</span>
        <div class="wabi-toc-list" id="wabi-toc-list">
          <div class="wabi-toc-empty">目次を読み込み中...</div>
        </div>
      </div>
    </div>
  `;

  // Minimize Handle Button (Tab)
  const sidebarTab = document.createElement("div");
  sidebarTab.id = "wabi-sidebar-tab";
  sidebarTab.className = "hidden";
  sidebarTab.title = "サイドバーを展開";
  sidebarTab.innerHTML = `<span>💮</span><span>目次</span>`;

  document.body.appendChild(sidebar);
  document.body.appendChild(sidebarTab);

  // Toast Notification
  const toast = document.createElement("div");
  toast.id = "wabi-toast";
  toast.textContent = "コードをコピーしました";
  document.body.appendChild(toast);

  // Elements Query
  const btnMinimize = document.getElementById("wabi-btn-minimize");
  const switchZen = document.getElementById("wabi-switch-zen");
  const themeBtns = document.querySelectorAll(".wabi-theme-btn");
  const tocList = document.getElementById("wabi-toc-list");

  // Show Toast
  function showToast(message) {
    toast.textContent = message;
    toast.classList.add("show");
    setTimeout(() => {
      toast.classList.remove("show");
    }, 1500);
  }

  // --- 1. Load Settings from Storage ---
  if (window.chrome && chrome.storage) {
    chrome.storage.local.get(["codeTheme", "readerMode"], (result) => {
      if (result.codeTheme) {
        currentTheme = result.codeTheme;
        applyCodeTheme(currentTheme);
      }
      if (result.readerMode) {
        readerMode = result.readerMode;
        applyReaderMode(readerMode);
      }
    });
  } else {
    // Sandbox defaults
    applyCodeTheme(currentTheme);
    applyReaderMode(readerMode);
  }

  // Apply code theme attribute to body
  function applyCodeTheme(theme) {
    document.body.setAttribute("data-wabi-code-theme", theme);
    themeBtns.forEach(btn => {
      btn.classList.toggle("active", btn.getAttribute("data-theme") === theme);
    });
  }

  // Apply reader mode attribute to body
  function applyReaderMode(mode) {
    document.body.setAttribute("data-wabi-zen-mode", mode);
    switchZen.checked = mode === "on";
  }

  // --- 2. Side Panel Minimize / Maximize Bindings ---
  btnMinimize.addEventListener("click", () => {
    sidebar.classList.add("minimized");
    sidebarTab.classList.remove("hidden");
  });

  sidebarTab.addEventListener("click", () => {
    sidebar.classList.remove("minimized");
    sidebarTab.classList.add("hidden");
  });

  // --- 3. Switch Actions Bindings ---
  switchZen.addEventListener("change", (e) => {
    readerMode = e.target.checked ? "on" : "off";
    applyReaderMode(readerMode);
    if (window.chrome && chrome.storage) {
      chrome.storage.local.set({ readerMode });
    }
  });

  themeBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      currentTheme = btn.getAttribute("data-theme");
      applyCodeTheme(currentTheme);
      if (window.chrome && chrome.storage) {
        chrome.storage.local.set({ codeTheme: currentTheme });
      }
    });
  });

  // --- 4. Build Table of Contents (TOC) & Scroll Tracking ---
  let activeObserver = null;

  function buildTOC() {
    tocList.innerHTML = "";
    const article = document.querySelector(articleSelector);
    if (!article) {
      tocList.innerHTML = `<div class="wabi-toc-empty">記事が見つかりません</div>`;
      return;
    }

    // Query headings in order
    const headings = article.querySelectorAll("h1, h2, h3");
    if (headings.length === 0) {
      tocList.innerHTML = `<div class="wabi-toc-empty">見出しがありません</div>`;
      return;
    }

    const observerOptions = {
      root: null,
      rootMargin: "-80px 0px -60% 0px", // triggers when heading is in upper-mid screen
      threshold: 0
    };

    // Disconnect previous observer if re-building
    if (activeObserver) {
      activeObserver.disconnect();
    }

    // Intersection observer for heading tracking
    activeObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const id = entry.target.id;
          // Deactivate all
          document.querySelectorAll(".wabi-toc-item").forEach(item => {
            item.classList.remove("active");
          });
          // Activate matched
          const activeItem = document.querySelector(`.wabi-toc-item[data-target="${id}"]`);
          if (activeItem) {
            activeItem.classList.add("active");
            // Auto scroll TOC viewport to active element
            activeItem.scrollIntoView({ block: "nearest", behavior: "smooth" });
          }
        }
      });
    }, observerOptions);

    headings.forEach((heading, idx) => {
      // Ensure unique ID for jump link
      if (!heading.id) {
        heading.id = `wabi-h-${idx}`;
      }

      const text = heading.textContent.replace(/#+$/, "").trim(); // clean markdown leftovers
      if (!text) return;

      const level = heading.tagName.toLowerCase(); // h1, h2, h3
      
      const tocItem = document.createElement("div");
      tocItem.className = `wabi-toc-item wabi-toc-${level}`;
      tocItem.setAttribute("data-target", heading.id);
      tocItem.textContent = text;

      // Click to scroll
      tocItem.addEventListener("click", () => {
        heading.scrollIntoView({ behavior: "smooth", block: "start" });
      });

      tocList.appendChild(tocItem);
      
      // Observe heading element
      activeObserver.observe(heading);
    });
  }

  // --- 5. Code Copy Button Injector ---
  function injectCopyButtons() {
    const article = document.querySelector(articleSelector);
    if (!article) return;

    // Qiita and Zenn render code elements in <pre> tags
    const preBlocks = article.querySelectorAll("pre");
    preBlocks.forEach((pre) => {
      // Avoid duplicate injection
      if (pre.querySelector(".wabi-copy-btn") || pre.classList.contains("wabi-copied-pre")) return;
      pre.classList.add("wabi-copied-pre"); // Marker class

      // Ensure block is relative positioned
      if (getComputedStyle(pre).position === "static") {
        pre.style.position = "relative";
      }

      // Create Copy Button
      const copyBtn = document.createElement("button");
      copyBtn.className = "wabi-copy-btn";
      copyBtn.innerHTML = `💾 コピー`;
      copyBtn.title = "ソースコードをコピー";

      copyBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        
        // Extract raw code (excluding the copy button text itself)
        const codeElement = pre.querySelector("code") || pre;
        
        // Clone and remove elements with class wabi-copy-btn to avoid copying button text
        const tempElement = codeElement.cloneNode(true);
        const innerBtn = tempElement.querySelector(".wabi-copy-btn");
        if (innerBtn) innerBtn.remove();
        
        const codeText = tempElement.innerText.trim();

        navigator.clipboard.writeText(codeText).then(() => {
          showToast("コードをクリップボードにコピーしました");
          copyBtn.innerHTML = `✅ コピー完了`;
          copyBtn.classList.add("success");
          setTimeout(() => {
            copyBtn.innerHTML = `💾 コピー`;
            copyBtn.classList.remove("success");
          }, 1500);
        });
      });

      pre.appendChild(copyBtn);
    });
  }

  // Initial Run
  setTimeout(() => {
    buildTOC();
    injectCopyButtons();
  }, 400);

  // Monitor DOM modifications for SPA dynamically loaded codes
  const observer = new MutationObserver(() => {
    injectCopyButtons();
  });
  
  const targetNode = document.querySelector(articleSelector) || document.body;
  observer.observe(targetNode, { childList: true, subtree: true });

  // --- 6. SPA Route/URL Change Observer ---
  let lastHref = location.href;
  setInterval(() => {
    if (location.href !== lastHref) {
      lastHref = location.href;
      // Re-trigger layout scan after URL transition
      setTimeout(() => {
        buildTOC();
        injectCopyButtons();
      }, 600);
    }
  }, 1000);
}

// Bootstrapping
// トライアル期限ゲート: 期限切れなら本体機能を起動せず、控えめな通知だけ出す
function bootWabiReaderWithTrialGate() {
  window.WanoTrialGate.checkTrialActive().then((trialActive) => {
    if (trialActive) {
      initWabiReader();
    } else {
      window.WanoTrialGate.showTrialExpiredNotice("Qiita/Zenn 快適読書アシスト");
    }
  });
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", bootWabiReaderWithTrialGate);
} else {
  bootWabiReaderWithTrialGate();
}
