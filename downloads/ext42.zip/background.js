// background.js - Service Worker for Qiita/Zenn Reader Assist

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["codeTheme", "readerMode"], (result) => {
    const updates = {};
    if (result.codeTheme === undefined) {
      updates.codeTheme = "dark"; // Default theme
    }
    if (result.readerMode === undefined) {
      updates.readerMode = "off"; // Default reader mode is off
    }
    if (Object.keys(updates).length > 0) {
      chrome.storage.local.set(updates);
    }
  });
  console.log("Qiita/Zenn 快適読書アシスト 拡張機能が正常にインストールされました。");
});
