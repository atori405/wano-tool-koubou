// トライアル期限チェック（コンテンツスクリプト用・軽量版）
// この拡張機能はpopup/optionsページを持たず、Webページ上に直接UIを描画するため、
// license-checker.js の全画面ロックは使わず、この拡張機能自身のUIだけを止める。
// TRIAL_DAYS は license/license-manager.js と同じ値に揃えること。
(function () {
  "use strict";
  const TRIAL_DAYS = 14;

  function checkTrialActive() {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(["installTimestamp", "isPremium"], (data) => {
          if (chrome.runtime.lastError) {
            resolve(true);
            return;
          }
          if (data.isPremium) {
            resolve(true);
            return;
          }
          const installTimestamp = data.installTimestamp || Date.now();
          if (!data.installTimestamp) {
            chrome.storage.local.set({ installTimestamp });
          }
          const daysPassed = (Date.now() - installTimestamp) / (1000 * 60 * 60 * 24);
          resolve(daysPassed <= TRIAL_DAYS);
        });
      } catch (e) {
        resolve(true);
      }
    });
  }

  function showTrialExpiredNotice(toolName) {
    if (document.getElementById("wano-trial-expired-badge")) return;
    const badge = document.createElement("div");
    badge.id = "wano-trial-expired-badge";
    badge.style.cssText =
      "position:fixed !important; bottom:16px !important; right:16px !important; " +
      "z-index:2147483647 !important; background:#1c1a17 !important; color:#fdfcfa !important; " +
      "font-family:sans-serif !important; font-size:13px !important; line-height:1.6 !important; " +
      "padding:12px 16px !important; border-radius:6px !important; " +
      "box-shadow:0 8px 24px rgba(0,0,0,0.35) !important; max-width:260px !important;";
    badge.innerHTML =
      "<strong>" + toolName + "</strong><br>無料お試し期間(14日間)が終了しました。" +
      "<br>拡張機能の詳細 &rarr; 拡張機能のオプションからご購入いただけます。";
    document.body.appendChild(badge);
  }

  window.WanoTrialGate = { checkTrialActive, showTrialExpiredNotice };
})();
