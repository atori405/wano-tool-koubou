



// popup.js - Japanese Storage Cleaner & Safeguard

document.addEventListener("DOMContentLoaded", () => {
  // --- 1. Element References ---
  const btnClearAll = document.getElementById("btn-clear-all");
  const chkLocalStorage = document.getElementById("chk-localstorage");
  const chkSessionStorage = document.getElementById("chk-sessionstorage");
  const chkCookies = document.getElementById("chk-cookies");

  const toggleJaSafeguard = document.getElementById("toggle-ja-safeguard");
  
  const presetYahoo = document.getElementById("preset-yahoo");
  const presetTech = document.getElementById("preset-tech");
  const presetDev = document.getElementById("preset-dev");

  const inputCustomDomain = document.getElementById("input-custom-domain");
  const btnAddCustom = document.getElementById("btn-add-custom");
  const customTagsContainer = document.getElementById("custom-whitelist-tags-container");

  const statusReportCard = document.getElementById("status-report-card");
  const reportCookiesCount = document.getElementById("report-cookies-count");
  const reportStorageCount = document.getElementById("report-storage-count");

  let customWhitelist = [];

  // --- 2. Load and Save Configurations ---
  function loadSettings() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.get(["jaSafeguard", "presetYahooVal", "presetTechVal", "presetDevVal", "customWhitelistVal"], (res) => {
        if (res.jaSafeguard !== undefined) toggleJaSafeguard.checked = res.jaSafeguard;
        if (res.presetYahooVal !== undefined) presetYahoo.checked = res.presetYahooVal;
        if (res.presetTechVal !== undefined) presetTech.checked = res.presetTechVal;
        if (res.presetDevVal !== undefined) presetDev.checked = res.presetDevVal;
        if (res.customWhitelistVal !== undefined) {
          customWhitelist = res.customWhitelistVal;
          renderCustomTags();
        }
      });
    } else {
      // Simulator initial mock custom tags
      customWhitelist = ["google.com", "example.co.jp"];
      renderCustomTags();
    }
  }

  function saveSettings() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.set({
        jaSafeguard: toggleJaSafeguard.checked,
        presetYahooVal: presetYahoo.checked,
        presetTechVal: presetTech.checked,
        presetDevVal: presetDev.checked,
        customWhitelistVal: customWhitelist
      });
    }
  }

  // --- 3. Custom Whitelist UI Management ---
  function renderCustomTags() {
    customTagsContainer.innerHTML = "";
    customWhitelist.forEach(domain => {
      const tag = document.createElement("span");
      tag.className = "whitelist-tag";
      tag.innerHTML = `
        ${domain}
        <button type="button" class="remove-tag-btn" data-domain="${domain}">×</button>
      `;
      customTagsContainer.appendChild(tag);
    });

    // Add remove handlers
    document.querySelectorAll(".remove-tag-btn").forEach(btn => {
      btn.addEventListener("click", (e) => {
        const targetDomain = e.target.getAttribute("data-domain");
        customWhitelist = customWhitelist.filter(d => d !== targetDomain);
        renderCustomTags();
        saveSettings();
      });
    });
  }

  btnAddCustom.addEventListener("click", () => {
    const rawVal = inputCustomDomain.value.trim().toLowerCase();
    if (!rawVal) return;
    
    // Simple domain regex validation
    const cleanDomain = rawVal.replace(/^(https?:\/\/)?(www\.)?/, "");
    if (cleanDomain && !customWhitelist.includes(cleanDomain)) {
      customWhitelist.push(cleanDomain);
      renderCustomTags();
      saveSettings();
      inputCustomDomain.value = "";
    }
  });

  inputCustomDomain.addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      btnAddCustom.click();
    }
  });

  // Save on switch changes
  toggleJaSafeguard.addEventListener("change", saveSettings);
  presetYahoo.addEventListener("change", saveSettings);
  presetTech.addEventListener("change", saveSettings);
  presetDev.addEventListener("change", saveSettings);

  // --- 4. Japanese Multibyte Character & Whitelist Rules ---
  function isJapaneseName(str) {
    if (!str) return false;
    try {
      // Decode URL encoded characters first
      const decoded = decodeURIComponent(str);
      // Regex check for Japanese characters: Hiragana, Katakana, Kanji, and fullwidth symbols
      return /[^\x01-\x7E]/.test(decoded);
    } catch (e) {
      // Fallback to basic string regex in case of decoding errors
      return /[^\x01-\x7E]/.test(str);
    }
  }

  function isDomainProtected(domain) {
    if (!domain) return false;
    const cleanDom = domain.toLowerCase();

    // 1. Yahoo Preset Group
    if (presetYahoo.checked) {
      if (cleanDom.endsWith("yahoo.co.jp") || 
          cleanDom.endsWith("yahoojapan.co.jp") || 
          cleanDom.endsWith("yahoo.com") || 
          cleanDom === "yahoo" || 
          cleanDom === "yahoojapan") {
        return true;
      }
    }

    // 2. Tech Preset Group (Qiita, Zenn)
    if (presetTech.checked) {
      if (cleanDom.endsWith("qiita.com") || cleanDom.endsWith("zenn.dev")) {
        return true;
      }
    }

    // 3. Local Dev Presets
    if (presetDev.checked) {
      if (cleanDom === "localhost" || cleanDom === "127.0.0.1" || cleanDom.startsWith("localhost:")) {
        return true;
      }
    }

    // 4. Custom Whitelist Checks
    return customWhitelist.some(whitelistDom => {
      return cleanDom === whitelistDom || cleanDom.endsWith("." + whitelistDom);
    });
  }

  // --- 5. Clean Action Controller ---
  let isConfirmStage = false;
  let confirmTimeout = null;

  btnClearAll.addEventListener("click", () => {
    if (!isConfirmStage) {
      // Step 1: Trigger confirmation state
      isConfirmStage = true;
      btnClearAll.textContent = "⚠️ 本当に実行しますか？";
      btnClearAll.classList.add("confirm-stage");
      
      confirmTimeout = setTimeout(() => {
        // Revert back after 3 seconds if not clicked again
        isConfirmStage = false;
        btnClearAll.innerHTML = '<span class="btn-ripple"></span>一括クリーン実行';
        btnClearAll.classList.remove("confirm-stage");
      }, 3000);
      return;
    }

    // Step 2: Confirmed! Execute clear action
    isConfirmStage = false;
    clearTimeout(confirmTimeout);
    btnClearAll.innerHTML = '<span class="btn-ripple"></span>一括クリーン実行';
    btnClearAll.classList.remove("confirm-stage");

    // Wave ripple animation effect
    const ripple = btnClearAll.querySelector(".btn-ripple");
    if (ripple) {
      ripple.classList.add("animate");
      setTimeout(() => {
        ripple.classList.remove("animate");
      }, 600);
    }

    const targetLocal = chkLocalStorage.checked;
    const targetSession = chkSessionStorage.checked;
    const targetCookies = chkCookies.checked;

    const jaProtected = toggleJaSafeguard.checked;

    if (window.chrome && chrome.tabs) {
      // PROD MODE - Query Active Tab
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (!tabs || !tabs[0]) return;
        const activeTab = tabs[0];
        
        // Parse active URL domain with fallback to avoid system page crashes
        let host = "";
        try {
          if (activeTab.url && 
              !activeTab.url.startsWith("chrome://") && 
              !activeTab.url.startsWith("edge://") && 
              !activeTab.url.startsWith("about:") && 
              !activeTab.url.startsWith("chrome-extension://")) {
            const urlObj = new URL(activeTab.url);
            host = urlObj.hostname;
          }
        } catch (e) {
          host = "";
        }

        // Perform cleaning tasks
        let clearedCookiesCount = 0;
        let clearedStorageCount = 0;

        // Task A: Cookie Clearing
        const handleCookies = (callback) => {
          if (!targetCookies || !host) {
            callback();
            return;
          }

          // Check if domain itself is protected
          if (isDomainProtected(host)) {
            console.log("Domain is protected. Skipping Cookie cleanup for: " + host);
            callback();
            return;
          }

          // Query cookies for this specific domain
          chrome.cookies.getAll({ domain: host }, (cookies) => {
            if (!cookies || cookies.length === 0) {
              callback();
              return;
            }

            let pending = cookies.length;
            let clearedCount = 0;

            cookies.forEach(cookie => {
              const name = cookie.name;
              
              // Skip if jaProtected and key contains multibyte ja characters
              if (jaProtected && isJapaneseName(name)) {
                pending--;
                if (pending === 0) {
                  clearedCookiesCount = clearedCount;
                  callback();
                }
                return;
              }

              // Compute cookie delete URL context
              const protocol = cookie.secure ? "https://" : "http://";
              const cookieUrl = protocol + cookie.domain.replace(/^\./, "") + cookie.path;

              chrome.cookies.remove({ url: cookieUrl, name: name }, (removed) => {
                if (removed) {
                  clearedCount++;
                }
                pending--;
                if (pending === 0) {
                  clearedCookiesCount = clearedCount;
                  callback();
                }
              });
            });
          });
        };

        // Task B: LocalStorage / SessionStorage clearing via executeScript
        const handleStorage = (callback) => {
          if ((!targetLocal && !targetSession) || !host) {
            callback();
            return;
          }

          if (isDomainProtected(host)) {
            console.log("Domain is protected. Skipping WebStorage cleanup for: " + host);
            callback();
            return;
          }

          try {
            chrome.scripting.executeScript({
              target: { tabId: activeTab.id },
              func: cleanWebStorageOnPage,
              args: [targetLocal, targetSession, jaProtected]
            }, (results) => {
              if (results && results[0] && results[0].result) {
                clearedStorageCount = results[0].result;
              }
              callback();
            });
          } catch (e) {
            console.error("Storage scripting injection failed:", e);
            callback();
          }
        };

        // Execute asynchronous sequence
        handleCookies(() => {
          handleStorage(() => {
            // Render outputs with count animation
            renderResults(clearedCookiesCount, clearedStorageCount);
          });
        });

      });
    } else {
      // SIMULATOR MODE (For sandbox.html)
      const demoContainer = document.getElementById("demo-page-container");
      if (demoContainer) {
        // Execute simulated storage removal
        const results = runSimulatedClean(targetLocal, targetSession, targetCookies, jaProtected);
        renderResults(results.cookies, results.storage);
      } else {
        // No simulator target, mock display
        renderResults(14, 8);
      }
    }
  });

  // Page script context for LocalStorage/SessionStorage sanitizing
  function cleanWebStorageOnPage(clearLocal, clearSession, jaSafeguardOn) {
    let clearedCount = 0;

    const cleanStorageObject = (storageObj) => {
      const keys = Object.keys(storageObj);
      keys.forEach(key => {
        // Check if key is Japanese (multibyte characters)
        let isJa = false;
        try {
          const decoded = decodeURIComponent(key);
          isJa = /[^\x01-\x7E]/.test(decoded);
        } catch(e) {
          isJa = /[^\x01-\x7E]/.test(key);
        }

        if (jaSafeguardOn && isJa) {
          // Keep key, protected!
          return;
        }

        storageObj.removeItem(key);
        clearedCount++;
      });
    };

    if (clearLocal) cleanStorageObject(window.localStorage);
    if (clearSession) cleanStorageObject(window.sessionStorage);

    return clearedCount;
  }

  // Simulator cleanup driver
  function runSimulatedClean(clearLocal, clearSession, clearCookies, jaSafeguardOn) {
    let cookiesCleared = 0;
    let storageCleared = 0;

    // 1. Storage cleaning
    const simulatedStorageList = document.querySelectorAll(".simulated-storage-item");
    simulatedStorageList.forEach(item => {
      const type = item.getAttribute("data-storage-type"); // 'local' or 'session'
      const key = item.getAttribute("data-key");
      const isJa = item.getAttribute("data-is-ja") === "true";

      if (type === "local" && !clearLocal) return;
      if (type === "session" && !clearSession) return;

      if (jaSafeguardOn && isJa) {
        // Safe (Japanese key)
        return;
      }

      // Check if domain (sandbox simulate) is protected
      // In simulator, if preset is matched, we protect it
      const presetDomain = item.getAttribute("data-domain") || "";
      if (isDomainProtected(presetDomain)) {
        return; // Safe (Domain protected)
      }

      // Remove from simulator DOM list
      item.remove();
      storageCleared++;
    });

    // 2. Cookie cleaning
    const simulatedCookieList = document.querySelectorAll(".simulated-cookie-item");
    simulatedCookieList.forEach(item => {
      const key = item.getAttribute("data-key");
      const isJa = item.getAttribute("data-is-ja") === "true";
      const domain = item.getAttribute("data-domain") || "";

      if (!clearCookies) return;

      if (jaSafeguardOn && isJa) return; // Protected ja key
      if (isDomainProtected(domain)) return; // Protected domain

      item.remove();
      cookiesCleared++;
    });

    // Toggle simulator empty states if lists are empty
    checkSimulatorEmptyState();

    return {
      cookies: cookiesCleared,
      storage: storageCleared
    };
  }

  function checkSimulatorEmptyState() {
    const listS = document.getElementById("sim-storage-list");
    const listC = document.getElementById("sim-cookie-list");
    
    if (listS && listS.children.length === 0) {
      listS.innerHTML = `<div class="sim-empty-msg">ストレージデータは空です</div>`;
    }
    if (listC && listC.children.length === 0) {
      listC.innerHTML = `<div class="sim-empty-msg">Cookieデータは空です</div>`;
    }
  }

  // Display report counters with subtle count up animations
  function renderResults(cookies, storage) {
    statusReportCard.style.display = "block";
    
    // Animate numbers count
    const animateCount = (el, maxVal) => {
      if (maxVal === 0) {
        el.textContent = "0";
        return;
      }
      let current = 0;
      const duration = 400; // ms
      const stepTime = Math.max(Math.floor(duration / maxVal), 20);
      const timer = setInterval(() => {
        current += Math.ceil(maxVal / 10);
        if (current >= maxVal) {
          current = maxVal;
          clearInterval(timer);
        }
        el.textContent = current;
      }, stepTime);
    };

    animateCount(reportCookiesCount, cookies);
    animateCount(reportStorageCount, storage);
  }

  // Initial Settings Trigger
  loadSettings();
});
