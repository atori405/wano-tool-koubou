// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 400);
            var h = Math.min(screen.availHeight, 660);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window&tabId=" + tabs[0].id),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 400,
          height: 660,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// popup.js - Japanese Storage Cleaner & Safeguard

document.addEventListener("DOMContentLoaded", () => {
  // Wrong-tab fix: when opened as a standalone popup window (mode=window),
  // chrome.tabs.query({currentWindow:true}) would resolve to this window itself,
  // not the original page tab, so use the explicitly passed tabId when present.
  const urlParams = new URLSearchParams(window.location.search);
  const explicitTabId = urlParams.get("tabId") ? parseInt(urlParams.get("tabId"), 10) : null;
  function getTargetTab(callback) {
    if (explicitTabId) {
      chrome.tabs.get(explicitTabId, (tab) => {
        if (chrome.runtime.lastError || !tab) return;
        callback(tab);
      });
    } else {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0]) callback(tabs[0]);
      });
    }
  }

  // --- 1. Element References ---
  const btnClearAll = document.getElementById("btn-clear-all");
  const chkLocalStorage = document.getElementById("chk-localstorage");
  const chkSessionStorage = document.getElementById("chk-sessionstorage");
  const chkCookies = document.getElementById("chk-cookies");

  const toggleJaSafeguard = document.getElementById("toggle-ja-safeguard");
  
  const presetYahoo = document.getElementById("preset-yahoo");
  const presetTech = document.getElementById("preset-tech");
  const presetDev = document.getElementById("preset-dev");

  const inputCustomDomain = document.getElementById("input-custom-domain");
  const btnAddCustom = document.getElementById("btn-add-custom");
  const customTagsContainer = document.getElementById("custom-whitelist-tags-container");

  const statusReportCard = document.getElementById("status-report-card");
  const reportCookiesCount = document.getElementById("report-cookies-count");
  const reportStorageCount = document.getElementById("report-storage-count");
  const btnRestoreBackup = document.getElementById("btn-restore-backup");

  let customWhitelist = [];

  // --- 2. Load and Save Configurations ---
  function loadSettings() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.get(["jaSafeguard", "presetYahooVal", "presetTechVal", "presetDevVal", "customWhitelistVal"], (res) => {
        if (res.jaSafeguard !== undefined) toggleJaSafeguard.checked = res.jaSafeguard;
        if (res.presetYahooVal !== undefined) presetYahoo.checked = res.presetYahooVal;
        if (res.presetTechVal !== undefined) presetTech.checked = res.presetTechVal;
        if (res.presetDevVal !== undefined) presetDev.checked = res.presetDevVal;
        if (res.customWhitelistVal !== undefined) {
          customWhitelist = res.customWhitelistVal;
          renderCustomTags();
        }
      });
    } else {
      // Simulator initial mock custom tags
      customWhitelist = ["google.com", "example.co.jp"];
      renderCustomTags();
    }
  }

  function saveSettings() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.set({
        jaSafeguard: toggleJaSafeguard.checked,
        presetYahooVal: presetYahoo.checked,
        presetTechVal: presetTech.checked,
        presetDevVal: presetDev.checked,
        customWhitelistVal: customWhitelist
      });
    }
  }

  // --- 3. Custom Whitelist UI Management ---
  function renderCustomTags() {
    customTagsContainer.innerHTML = "";
    customWhitelist.forEach(domain => {
      const tag = document.createElement("span");
      tag.className = "whitelist-tag";
      tag.innerHTML = `
        ${domain}
        <button type="button" class="remove-tag-btn" data-domain="${domain}">×</button>
      `;
      customTagsContainer.appendChild(tag);
    });

    // Add remove handlers
    document.querySelectorAll(".remove-tag-btn").forEach(btn => {
      btn.addEventListener("click", (e) => {
        const targetDomain = e.target.getAttribute("data-domain");
        customWhitelist = customWhitelist.filter(d => d !== targetDomain);
        renderCustomTags();
        saveSettings();
      });
    });
  }

  btnAddCustom.addEventListener("click", () => {
    const rawVal = inputCustomDomain.value.trim().toLowerCase();
    if (!rawVal) return;

    // Extract just the hostname, whether the user pasted a full URL, a bare
    // domain, or "www.example.com/some/path" — anything past the host would
    // otherwise never match a real cookie/site domain, silently leaving the
    // "protected" entry non-functional.
    let cleanDomain;
    try {
      const withProtocol = /^https?:\/\//.test(rawVal) ? rawVal : "https://" + rawVal;
      cleanDomain = new URL(withProtocol).hostname.replace(/^www\./, "");
    } catch (e) {
      cleanDomain = rawVal.replace(/^(https?:\/\/)?(www\.)?/, "").split(/[/?#]/)[0];
    }

    if (cleanDomain && !customWhitelist.includes(cleanDomain)) {
      customWhitelist.push(cleanDomain);
      renderCustomTags();
      saveSettings();
      inputCustomDomain.value = "";
    }
  });

  inputCustomDomain.addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      btnAddCustom.click();
    }
  });

  // Save on switch changes
  toggleJaSafeguard.addEventListener("change", saveSettings);
  presetYahoo.addEventListener("change", saveSettings);
  presetTech.addEventListener("change", saveSettings);
  presetDev.addEventListener("change", saveSettings);

  // --- 4. Japanese Multibyte Character & Whitelist Rules ---
  function isJapaneseName(str) {
    if (!str) return false;
    try {
      // Decode URL encoded characters first
      const decoded = decodeURIComponent(str);
      // Regex check for Japanese characters: Hiragana, Katakana, Kanji, and fullwidth symbols
      return /[^\x01-\x7E]/.test(decoded);
    } catch (e) {
      // Fallback to basic string regex in case of decoding errors
      return /[^\x01-\x7E]/.test(str);
    }
  }

  function isDomainProtected(domain) {
    if (!domain) return false;
    const cleanDom = domain.toLowerCase();

    // 1. Yahoo Preset Group
    if (presetYahoo.checked) {
      if (cleanDom.endsWith("yahoo.co.jp") || 
          cleanDom.endsWith("yahoojapan.co.jp") || 
          cleanDom.endsWith("yahoo.com") || 
          cleanDom === "yahoo" || 
          cleanDom === "yahoojapan") {
        return true;
      }
    }

    // 2. Tech Preset Group (Qiita, Zenn)
    if (presetTech.checked) {
      if (cleanDom.endsWith("qiita.com") || cleanDom.endsWith("zenn.dev")) {
        return true;
      }
    }

    // 3. Local Dev Presets
    if (presetDev.checked) {
      if (cleanDom === "localhost" || cleanDom === "127.0.0.1" || cleanDom.startsWith("localhost:")) {
        return true;
      }
    }

    // 4. Custom Whitelist Checks
    return customWhitelist.some(whitelistDom => {
      return cleanDom === whitelistDom || cleanDom.endsWith("." + whitelistDom);
    });
  }

  // --- 5. Clean Action Controller ---
  let isConfirmStage = false;
  let confirmTimeout = null;

  btnClearAll.addEventListener("click", () => {
    if (!isConfirmStage) {
      // Step 1: Trigger confirmation state
      isConfirmStage = true;
      btnClearAll.textContent = "⚠️ 本当に実行しますか？";
      btnClearAll.classList.add("confirm-stage");
      
      confirmTimeout = setTimeout(() => {
        // Revert back after 3 seconds if not clicked again
        isConfirmStage = false;
        btnClearAll.innerHTML = '<span class="btn-ripple"></span>一括クリーン実行';
        btnClearAll.classList.remove("confirm-stage");
      }, 3000);
      return;
    }

    // Step 2: Confirmed! Execute clear action
    isConfirmStage = false;
    clearTimeout(confirmTimeout);
    btnClearAll.innerHTML = '<span class="btn-ripple"></span>一括クリーン実行';
    btnClearAll.classList.remove("confirm-stage");

    // Wave ripple animation effect
    const ripple = btnClearAll.querySelector(".btn-ripple");
    if (ripple) {
      ripple.classList.add("animate");
      setTimeout(() => {
        ripple.classList.remove("animate");
      }, 600);
    }

    const targetLocal = chkLocalStorage.checked;
    const targetSession = chkSessionStorage.checked;
    const targetCookies = chkCookies.checked;

    const jaProtected = toggleJaSafeguard.checked;

    if (window.chrome && chrome.tabs) {
      // PROD MODE - Query Active Tab
      getTargetTab((activeTab) => {
        if (!activeTab) return;

        // Parse active URL domain with fallback to avoid system page crashes
        let host = "";
        try {
          if (activeTab.url && 
              !activeTab.url.startsWith("chrome://") && 
              !activeTab.url.startsWith("edge://") && 
              !activeTab.url.startsWith("about:") && 
              !activeTab.url.startsWith("chrome-extension://")) {
            const urlObj = new URL(activeTab.url);
            host = urlObj.hostname;
          }
        } catch (e) {
          host = "";
        }

        // Perform cleaning tasks
        let clearedCookiesCount = 0;
        let clearedStorageCount = 0;

        // Snapshot of everything actually removed, saved before deletion so
        // "元に戻す" can restore exactly what this run deleted.
        const removedCookiesSnapshot = [];
        let removedLocalSnapshot = {};
        let removedSessionSnapshot = {};

        // Task A: Cookie Clearing
        const handleCookies = (callback) => {
          if (!targetCookies || !host) {
            callback();
            return;
          }

          // Check if domain itself is protected
          if (isDomainProtected(host)) {
            console.log("Domain is protected. Skipping Cookie cleanup for: " + host);
            callback();
            return;
          }

          // Query cookies for this specific domain
          chrome.cookies.getAll({ domain: host }, (cookies) => {
            if (!cookies || cookies.length === 0) {
              callback();
              return;
            }

            let pending = cookies.length;
            let clearedCount = 0;

            cookies.forEach(cookie => {
              const name = cookie.name;

              // Skip if jaProtected and key contains multibyte ja characters
              if (jaProtected && isJapaneseName(name)) {
                pending--;
                if (pending === 0) {
                  clearedCookiesCount = clearedCount;
                  callback();
                }
                return;
              }

              // Compute cookie delete URL context
              const protocol = cookie.secure ? "https://" : "http://";
              const cookieUrl = protocol + cookie.domain.replace(/^\./, "") + cookie.path;

              // Snapshot before removing so it can be restored later
              removedCookiesSnapshot.push({
                url: cookieUrl,
                name: cookie.name,
                value: cookie.value,
                domain: cookie.domain,
                path: cookie.path,
                secure: cookie.secure,
                httpOnly: cookie.httpOnly,
                sameSite: cookie.sameSite,
                expirationDate: cookie.expirationDate,
                storeId: cookie.storeId
              });

              chrome.cookies.remove({ url: cookieUrl, name: name }, (removed) => {
                if (removed) {
                  clearedCount++;
                }
                pending--;
                if (pending === 0) {
                  clearedCookiesCount = clearedCount;
                  callback();
                }
              });
            });
          });
        };

        // Task B: LocalStorage / SessionStorage clearing via executeScript
        const handleStorage = (callback) => {
          if ((!targetLocal && !targetSession) || !host) {
            callback();
            return;
          }

          if (isDomainProtected(host)) {
            console.log("Domain is protected. Skipping WebStorage cleanup for: " + host);
            callback();
            return;
          }

          try {
            chrome.scripting.executeScript({
              target: { tabId: activeTab.id },
              func: cleanWebStorageOnPage,
              args: [targetLocal, targetSession, jaProtected]
            }, (results) => {
              if (results && results[0] && results[0].result) {
                const { removedLocal, removedSession } = results[0].result;
                removedLocalSnapshot = removedLocal || {};
                removedSessionSnapshot = removedSession || {};
                clearedStorageCount = Object.keys(removedLocalSnapshot).length + Object.keys(removedSessionSnapshot).length;
              }
              callback();
            });
          } catch (e) {
            console.error("Storage scripting injection failed:", e);
            callback();
          }
        };

        // Execute asynchronous sequence
        handleCookies(() => {
          handleStorage(() => {
            const hasBackupData = removedCookiesSnapshot.length > 0 ||
              Object.keys(removedLocalSnapshot).length > 0 ||
              Object.keys(removedSessionSnapshot).length > 0;

            if (hasBackupData && window.chrome && chrome.storage) {
              chrome.storage.local.set({
                lastBackup: {
                  host,
                  timestamp: Date.now(),
                  cookies: removedCookiesSnapshot,
                  localStorage: removedLocalSnapshot,
                  sessionStorage: removedSessionSnapshot
                }
              });
            }

            // Render outputs with count animation
            renderResults(clearedCookiesCount, clearedStorageCount, hasBackupData);
          });
        });

      });
    } else {
      // SIMULATOR MODE (For sandbox.html)
      const demoContainer = document.getElementById("demo-page-container");
      if (demoContainer) {
        // Execute simulated storage removal
        const results = runSimulatedClean(targetLocal, targetSession, targetCookies, jaProtected);
        renderResults(results.cookies, results.storage);
      } else {
        // No simulator target, mock display
        renderResults(14, 8);
      }
    }
  });

  // Page script context for LocalStorage/SessionStorage sanitizing.
  // Returns exactly what was removed (not just a count) so the popup can save
  // a restore snapshot before deleting anything.
  function cleanWebStorageOnPage(clearLocal, clearSession, jaSafeguardOn) {
    const removedLocal = {};
    const removedSession = {};

    const cleanStorageObject = (storageObj, removedOut) => {
      const keys = Object.keys(storageObj);
      keys.forEach(key => {
        // Check if key is Japanese (multibyte characters)
        let isJa = false;
        try {
          const decoded = decodeURIComponent(key);
          isJa = /[^\x01-\x7E]/.test(decoded);
        } catch(e) {
          isJa = /[^\x01-\x7E]/.test(key);
        }

        if (jaSafeguardOn && isJa) {
          // Keep key, protected!
          return;
        }

        removedOut[key] = storageObj.getItem(key);
        storageObj.removeItem(key);
      });
    };

    if (clearLocal) cleanStorageObject(window.localStorage, removedLocal);
    if (clearSession) cleanStorageObject(window.sessionStorage, removedSession);

    return { removedLocal, removedSession };
  }

  // Simulator cleanup driver
  function runSimulatedClean(clearLocal, clearSession, clearCookies, jaSafeguardOn) {
    let cookiesCleared = 0;
    let storageCleared = 0;

    // 1. Storage cleaning
    const simulatedStorageList = document.querySelectorAll(".simulated-storage-item");
    simulatedStorageList.forEach(item => {
      const type = item.getAttribute("data-storage-type"); // 'local' or 'session'
      const key = item.getAttribute("data-key");
      const isJa = item.getAttribute("data-is-ja") === "true";

      if (type === "local" && !clearLocal) return;
      if (type === "session" && !clearSession) return;

      if (jaSafeguardOn && isJa) {
        // Safe (Japanese key)
        return;
      }

      // Check if domain (sandbox simulate) is protected
      // In simulator, if preset is matched, we protect it
      const presetDomain = item.getAttribute("data-domain") || "";
      if (isDomainProtected(presetDomain)) {
        return; // Safe (Domain protected)
      }

      // Remove from simulator DOM list
      item.remove();
      storageCleared++;
    });

    // 2. Cookie cleaning
    const simulatedCookieList = document.querySelectorAll(".simulated-cookie-item");
    simulatedCookieList.forEach(item => {
      const key = item.getAttribute("data-key");
      const isJa = item.getAttribute("data-is-ja") === "true";
      const domain = item.getAttribute("data-domain") || "";

      if (!clearCookies) return;

      if (jaSafeguardOn && isJa) return; // Protected ja key
      if (isDomainProtected(domain)) return; // Protected domain

      item.remove();
      cookiesCleared++;
    });

    // Toggle simulator empty states if lists are empty
    checkSimulatorEmptyState();

    return {
      cookies: cookiesCleared,
      storage: storageCleared
    };
  }

  function checkSimulatorEmptyState() {
    const listS = document.getElementById("sim-storage-list");
    const listC = document.getElementById("sim-cookie-list");
    
    if (listS && listS.children.length === 0) {
      listS.innerHTML = `<div class="sim-empty-msg">ストレージデータは空です</div>`;
    }
    if (listC && listC.children.length === 0) {
      listC.innerHTML = `<div class="sim-empty-msg">Cookieデータは空です</div>`;
    }
  }

  // Display report counters with subtle count up animations
  function renderResults(cookies, storage, hasBackupData) {
    statusReportCard.style.display = "block";

    // Animate numbers count
    const animateCount = (el, maxVal) => {
      if (maxVal === 0) {
        el.textContent = "0";
        return;
      }
      let current = 0;
      const duration = 400; // ms
      const stepTime = Math.max(Math.floor(duration / maxVal), 20);
      const timer = setInterval(() => {
        current += Math.ceil(maxVal / 10);
        if (current >= maxVal) {
          current = maxVal;
          clearInterval(timer);
        }
        el.textContent = current;
      }, stepTime);
    };

    animateCount(reportCookiesCount, cookies);
    animateCount(reportStorageCount, storage);

    if (hasBackupData) {
      btnRestoreBackup.style.display = "block";
      btnRestoreBackup.disabled = false;
      btnRestoreBackup.textContent = "↩️ 直前の削除を元に戻す";
    } else {
      btnRestoreBackup.style.display = "none";
    }
  }

  // --- 6. Restore Last Backup ---
  // Restores exactly what the most recent clear removed, for the domain it
  // was removed from. Cookies are re-created with chrome.cookies.set() from
  // the popup context; LocalStorage/SessionStorage keys are re-written via
  // executeScript since only the page itself can write to its own storage.
  function restoreStorageOnPage(localEntries, sessionEntries) {
    Object.keys(localEntries).forEach((key) => {
      window.localStorage.setItem(key, localEntries[key]);
    });
    Object.keys(sessionEntries).forEach((key) => {
      window.sessionStorage.setItem(key, sessionEntries[key]);
    });
    return Object.keys(localEntries).length + Object.keys(sessionEntries).length;
  }

  btnRestoreBackup.addEventListener("click", () => {
    if (!(window.chrome && chrome.storage)) return;

    btnRestoreBackup.disabled = true;
    btnRestoreBackup.textContent = "復元しています...";

    chrome.storage.local.get(["lastBackup"], (res) => {
      const backup = res.lastBackup;
      if (!backup) {
        btnRestoreBackup.textContent = "復元できるデータがありません";
        return;
      }

      queryActiveTabByUrl((activeTab, currentHost) => {
        if (!activeTab || currentHost !== backup.host) {
          btnRestoreBackup.disabled = false;
          btnRestoreBackup.textContent = `⚠️ ${backup.host} を開いた状態で復元してください`;
          return;
        }

        let pendingCookies = backup.cookies.length;
        const finishIfDone = () => {
          if (pendingCookies > 0) return;

          chrome.scripting.executeScript({
            target: { tabId: activeTab.id },
            func: restoreStorageOnPage,
            args: [backup.localStorage || {}, backup.sessionStorage || {}]
          }, () => {
            chrome.storage.local.remove("lastBackup");
            btnRestoreBackup.textContent = "✅ 復元しました";
            setTimeout(() => {
              btnRestoreBackup.style.display = "none";
            }, 2000);
          });
        };

        if (pendingCookies === 0) {
          finishIfDone();
          return;
        }

        backup.cookies.forEach((c) => {
          chrome.cookies.set({
            url: c.url,
            name: c.name,
            value: c.value,
            domain: c.domain,
            path: c.path,
            secure: c.secure,
            httpOnly: c.httpOnly,
            sameSite: c.sameSite,
            expirationDate: c.expirationDate,
            storeId: c.storeId
          }, () => {
            pendingCookies--;
            finishIfDone();
          });
        });
      });
    });
  });

  // Helper: get the active tab plus its parsed hostname (mirrors the host
  // parsing used before clearing, so restore checks the same "current site").
  function queryActiveTabByUrl(callback) {
    getTargetTab((activeTab) => {
      if (!activeTab) {
        callback(null, "");
        return;
      }
      let host = "";
      try {
        if (activeTab.url &&
            !activeTab.url.startsWith("chrome://") &&
            !activeTab.url.startsWith("edge://") &&
            !activeTab.url.startsWith("about:") &&
            !activeTab.url.startsWith("chrome-extension://")) {
          host = new URL(activeTab.url).hostname;
        }
      } catch (e) {
        host = "";
      }
      callback(activeTab, host);
    });
  }

  // On popup open, if a restorable backup exists for the current site, show
  // the restore button right away (so closing/reopening the popup doesn't
  // lose the ability to undo the last clear).
  function checkExistingBackup() {
    if (!(window.chrome && chrome.storage && chrome.tabs)) return;
    chrome.storage.local.get(["lastBackup"], (res) => {
      if (!res.lastBackup) return;
      queryActiveTabByUrl((activeTab, currentHost) => {
        if (currentHost && currentHost === res.lastBackup.host) {
          statusReportCard.style.display = "block";
          reportCookiesCount.textContent = String(res.lastBackup.cookies.length);
          reportStorageCount.textContent = String(
            Object.keys(res.lastBackup.localStorage || {}).length +
            Object.keys(res.lastBackup.sessionStorage || {}).length
          );
          btnRestoreBackup.style.display = "block";
          btnRestoreBackup.disabled = false;
          btnRestoreBackup.textContent = "↩️ 直前の削除を元に戻す";
        }
      });
    });
  }

  // Initial Settings Trigger
  loadSettings();
  checkExistingBackup();
});
