// background.js - Service Worker for Japanese Storage Cleaner

chrome.runtime.onInstalled.addListener(() => {
  console.log("日本語ストレージ一括整理 拡張機能が正常にインストールされました。");
});
