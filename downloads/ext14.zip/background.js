// background.js - Side Panel behavior setup

chrome.runtime.onInstalled.addListener(() => {
  // Configure the extension to open the side panel when the toolbar icon is clicked
  chrome.sidePanel
    .setPanelBehavior({ openPanelOnActionClick: true })
    .catch((error) => console.error("Error setting panel behavior:", error));
});
