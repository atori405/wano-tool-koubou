// sidepanel.js - Shoji Schedule Sidebar Controller

document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const shojiScreen = document.getElementById('shoji-screen');
  const jpDateStr = document.getElementById('jp-date-str');
  const gregorianDateStr = document.getElementById('gregorian-date-str');
  const currentClock = document.getElementById('current-clock');
  const timeGradientHeader = document.getElementById('time-gradient-header');
  const timelineHours = document.getElementById('timeline-hours');
  const eventsList = document.getElementById('events-list');

  // Drawers & Inputs
  const addDrawer = document.getElementById('add-drawer');
  const icalDrawer = document.getElementById('ical-drawer');
  const openAddBtn = document.getElementById('open-add-drawer');
  const closeAddBtn = document.getElementById('close-add-drawer');
  const openIcalBtn = document.getElementById('open-ical-drawer');
  const closeIcalBtn = document.getElementById('close-ical-drawer');
  
  const saveEventBtn = document.getElementById('save-event-btn');
  const syncIcalBtn = document.getElementById('sync-ical-btn');
  const loadMockBtn = document.getElementById('load-mock-btn');
  
  const eventTitleInput = document.getElementById('event-title');
  const eventStartInput = document.getElementById('event-start');
  const eventEndInput = document.getElementById('event-end');
  const eventMemoInput = document.getElementById('event-memo');
  const icalUrlInput = document.getElementById('ical-url');
  const syncStatus = document.getElementById('sync-status');

  // State
  let events = [];
  let currentIcalUrl = "";

  // 1. Shoji Opening Animation (Wood sliding sound + sliding CSS)
  setTimeout(() => {
    shojiScreen.classList.add('open');
    playShojiSlide();
  }, 600);

  // 2. Initialize Calendar Time Rulers
  function initTimeline() {
    timelineHours.innerHTML = '';
    // Show hours 08:00 to 22:00 (15 hours)
    for (let h = 8; h <= 22; h++) {
      const tick = document.createElement('div');
      tick.className = 'hour-tick';
      tick.textContent = `${String(h).padStart(2, '0')}:00`;
      timelineHours.appendChild(tick);
    }
  }

  // Load events and url
  chrome.storage.local.get(['yokomadoEvents', 'yokomadoICSUrl'], (result) => {
    if (result.yokomadoEvents) {
      events = result.yokomadoEvents;
    } else {
      // Default initial mock schedule
      events = getInitialMockEvents();
      chrome.storage.local.set({ yokomadoEvents: events });
    }
    
    if (result.yokomadoICSUrl) {
      icalUrlInput.value = result.yokomadoICSUrl;
      currentIcalUrl = result.yokomadoICSUrl;
    }
    
    renderEvents();
  });

  // Get initial default schedules
  function getInitialMockEvents() {
    const todayStr = getTodayDateString();
    return [
      { id: "mock_1", date: todayStr, title: "朝会・本日のタスク確認", start: "09:00", end: "09:30", memo: "社内全体オンライン朝礼", completed: false },
      { id: "mock_2", date: todayStr, title: "プロジェクト進捗会議", start: "10:00", end: "11:30", memo: "定例会議。進行計画の見直し", completed: false },
      { id: "mock_3", date: todayStr, title: "鈴木様と会食ミーティング", start: "12:00", end: "13:30", memo: "お弁当の予約を確認する", completed: false },
      { id: "mock_4", date: todayStr, title: "企画資料の推敲・提出", start: "15:00", end: "16:30", memo: "原稿用紙換算君を使用すること", completed: false },
      { id: "mock_5", date: todayStr, title: "定時退社・銭湯へ直行", start: "18:00", end: "19:00", memo: "本日もお疲れ様でした！", completed: false }
    ];
  }

  function getTodayDateString() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  }

  // Convert Gregorian numbers to traditional Japanese Kanji
  function numberToKanji(num) {
    const kanjiDigits = ["", "一", "二", "三", "四", "五", "六", "七", "八", "九", "十"];
    if (num <= 10) return kanjiDigits[num];
    if (num < 20) return "十" + kanjiDigits[num % 10];
    if (num < 30) return "二十" + (num % 10 !== 0 ? kanjiDigits[num % 10] : "");
    if (num < 40) return "三十" + (num % 10 !== 0 ? kanjiDigits[num % 10] : "");
    return num.toString(); // Fallback
  }

  // Update Clock and Calendar Header Colors
  function updateClock() {
    const now = new Date();
    
    // Time string
    const hrs = String(now.getHours()).padStart(2, '0');
    const mins = String(now.getMinutes()).padStart(2, '0');
    currentClock.textContent = `${hrs}:${mins}`;

    // Date strings
    const weekdays = ["日", "月", "火", "水", "木", "金", "土"];
    gregorianDateStr.textContent = `${now.getFullYear()}/${String(now.getMonth()+1).padStart(2, '0')}/${String(now.getDate()).padStart(2, '0')} (${weekdays[now.getDay()]})`;

    // Kanji Date: 令和八年 六月二十八日
    // (We hardcode Reiwa 8 representing 2026: 2026 is Reiwa 8)
    const reiwaYear = now.getFullYear() - 2018;
    const yearKanji = reiwaYear === 1 ? "元" : numberToKanji(reiwaYear);
    const monthKanji = numberToKanji(now.getMonth() + 1);
    const dayKanji = numberToKanji(now.getDate());
    jpDateStr.textContent = `令和${yearKanji}年 ${monthKanji}月${dayKanji}日`;

    // Time-of-day gradient shift
    const hour = now.getHours();
    timeGradientHeader.className = ''; // Reset
    
    if (hour >= 6 && hour < 11) {
      timeGradientHeader.style.background = "var(--header-morning)";
    } else if (hour >= 11 && hour < 16) {
      timeGradientHeader.style.background = "var(--header-day)";
    } else if (hour >= 16 && hour < 19) {
      timeGradientHeader.style.background = "var(--header-evening)";
    } else {
      timeGradientHeader.style.background = "var(--header-night)";
      timeGradientHeader.classList.add('night-mode');
    }
  }

  // Generate Events layout on timeline
  function renderEvents() {
    eventsList.innerHTML = '';
    const todayStr = getTodayDateString();

    // Filter today's events
    const todayEvents = events.filter(e => e.date === todayStr);

    if (todayEvents.length === 0) {
      eventsList.innerHTML = '<div class="empty-message">本日の予定は登録されていません。</div>';
      return;
    }

    // Sort by start time
    todayEvents.sort((a, b) => a.start.localeCompare(b.start));

    todayEvents.forEach(evt => {
      const card = document.createElement('div');
      card.className = `event-card ${evt.completed ? 'completed' : ''}`;
      
      // Calculate top offset and height based on hours
      // 08:00 is offset 0
      const startMin = timeToMinutes(evt.start);
      const endMin = timeToMinutes(evt.end);
      const startOffset = Math.max(0, startMin - 8 * 60); // minutes relative to 08:00
      const duration = Math.max(30, endMin - startMin); // minimum 30 minutes height

      // 50px = 1 hour (i.e. 60 minutes) => 50/60 px per minute
      const topOffsetPx = (startOffset / 60) * 50;
      const heightPx = (duration / 60) * 50;

      card.style.top = `${topOffsetPx}px`;
      card.style.height = `${heightPx}px`;

      // Card contents
      const timeSpan = document.createElement('span');
      timeSpan.className = 'event-time';
      timeSpan.textContent = `${evt.start} - ${evt.end}`;
      card.appendChild(timeSpan);

      const titleGroup = document.createElement('div');
      titleGroup.className = 'event-title-group';

      const titleText = document.createElement('span');
      titleText.className = 'event-title';
      titleText.textContent = evt.title;
      titleGroup.appendChild(titleText);

      // Checkbox
      const checkBtn = document.createElement('div');
      checkBtn.className = 'event-check';
      checkBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        evt.completed = !evt.completed;
        
        if (evt.completed) {
          playRin(); // Beautiful chime for completion
        } else {
          playMokugyo(); // Resonant thud for undo
        }
        
        saveAndRender();
      });
      titleGroup.appendChild(checkBtn);
      card.appendChild(titleGroup);

      // Memo (if height allows or hover)
      if (evt.memo && heightPx >= 45) {
        const memoDiv = document.createElement('div');
        memoDiv.className = 'event-memo';
        memoDiv.textContent = evt.memo;
        card.appendChild(memoDiv);
      }

      // Delete action button on hover
      const deleteBtn = document.createElement('button');
      deleteBtn.className = 'delete-event-btn';
      deleteBtn.textContent = '×';
      deleteBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (confirm(`予定「${evt.title}」を削除しますか？`)) {
          events = events.filter(item => item.id !== evt.id);
          playShojiSlide(); // Slide sound on delete
          saveAndRender();
        }
      });
      card.appendChild(deleteBtn);

      eventsList.appendChild(card);
    });
  }

  function timeToMinutes(timeStr) {
    const [h, m] = timeStr.split(':').map(Number);
    return h * 60 + m;
  }

  async function saveAndRender() {
    await chrome.storage.local.set({ yokomadoEvents: events });
    renderEvents();
  }

  // 3. Drawers Interactions
  openAddBtn.addEventListener('click', () => {
    icalDrawer.classList.remove('open');
    addDrawer.classList.add('open');
    playShojiSlide();
  });

  closeAddBtn.addEventListener('click', () => {
    addDrawer.classList.remove('open');
    playShojiSlide();
  });

  openIcalBtn.addEventListener('click', () => {
    addDrawer.classList.remove('open');
    icalDrawer.classList.add('open');
    playShojiSlide();
  });

  closeIcalBtn.addEventListener('click', () => {
    icalDrawer.classList.remove('open');
    playShojiSlide();
  });

  // 4. Save manually added event
  saveEventBtn.addEventListener('click', () => {
    const title = eventTitleInput.value.trim();
    const start = eventStartInput.value;
    const end = eventEndInput.value;
    const memo = eventMemoInput.value.trim();

    if (!title || !start || !end) {
      alert("題名と始刻・終刻を入力してください。");
      return;
    }

    if (start.localeCompare(end) >= 0) {
      alert("始刻は終刻より前の時間に設定してください。");
      return;
    }

    const todayStr = getTodayDateString();
    const newEvent = {
      id: `manual_${Date.now()}`,
      date: todayStr,
      title,
      start,
      end,
      memo,
      completed: false
    };

    events.push(newEvent);
    playMokugyo(); // Play wooden block sound when writing schedule
    
    // Clear inputs and close
    eventTitleInput.value = '';
    eventMemoInput.value = '';
    addDrawer.classList.remove('open');
    
    saveAndRender();
  });

  // 5. ICS / iCal Parser (Custom lightweight logic)
  syncIcalBtn.addEventListener('click', async () => {
    const url = icalUrlInput.value.trim();
    if (!url) {
      alert("iCal（ICS形式）のURLを入力してください。");
      return;
    }

    syncStatus.textContent = "同期中...";
    syncStatus.style.color = "var(--color-susu)";
    
    try {
      const response = await fetch(url);
      if (!response.ok) throw new Error("ネットワーク接続エラー");
      
      const text = await response.text();
      const newEvents = parseICS(text);
      
      if (newEvents.length === 0) {
        syncStatus.textContent = "同期完了：本日・明日の予定なし";
        syncStatus.style.color = "var(--color-matsu)";
      } else {
        // Filter out old external events, merge manual events and new ICS events
        const manualEvents = events.filter(e => !e.id.startsWith('ical_'));
        events = [...manualEvents, ...newEvents];
        
        currentIcalUrl = url;
        await chrome.storage.local.set({ yokomadoICSUrl: url });
        saveAndRender();

        syncStatus.textContent = `同期完了：${newEvents.length}件を読み込みました`;
        syncStatus.style.color = "var(--color-matsu)";
        playRin();
      }
    } catch (e) {
      syncStatus.textContent = `同期失敗：URLを確認してください (${e.message})`;
      syncStatus.style.color = "var(--color-shu)";
      playMokugyo();
    }
  });

  // Demo public ICS loading helper (without network calls)
  loadMockBtn.addEventListener('click', () => {
    syncStatus.textContent = "同期中（ダミーデータ）...";
    
    setTimeout(() => {
      const mockICSText = getMockICSText();
      const newEvents = parseICS(mockICSText);
      
      const manualEvents = events.filter(e => !e.id.startsWith('ical_'));
      events = [...manualEvents, ...newEvents];
      saveAndRender();
      
      syncStatus.textContent = `同期完了：ダミーICS ${newEvents.length}件読込`;
      syncStatus.style.color = "var(--color-matsu)";
      playRin();
    }, 600);
  });

  // Lightweight custom ICS parser
  function parseICS(icsText) {
    const lines = icsText.split(/\r?\n/);
    const parsedEvents = [];
    let currentEvent = null;

    const todayDateStr = getTodayDateString().replace(/-/g, ''); // e.g. 20260628

    lines.forEach(line => {
      const trimmed = line.trim();
      if (trimmed.startsWith("BEGIN:VEVENT")) {
        currentEvent = {};
      } else if (trimmed.startsWith("END:VEVENT")) {
        if (currentEvent && currentEvent.dtstart && currentEvent.summary) {
          // Parse date and times
          // DTSTART format can be: 20260628T100000Z or value=DATE:20260628
          let dateStr = "";
          let timeStr = "09:00";
          let endStr = "10:00";

          // Extract date from DTSTART
          const startMatch = currentEvent.dtstart.match(/(\d{8})/);
          if (startMatch) {
            const d = startMatch[1];
            dateStr = `${d.substring(0,4)}-${d.substring(4,6)}-${d.substring(6,8)}`;
          }

          // Extract hours from DTSTART / DTEND
          const startTimeMatch = currentEvent.dtstart.match(/T(\d{4})/);
          if (startTimeMatch) {
            const t = startTimeMatch[1];
            // Simple UTC to JST converter: add 9 hours (just a helper)
            let hour = parseInt(t.substring(0,2), 10) + 9;
            if (hour >= 24) hour -= 24;
            timeStr = `${String(hour).padStart(2,'0')}:${t.substring(2,4)}`;
          }
          
          if (currentEvent.dtend) {
            const endTimeMatch = currentEvent.dtend.match(/T(\d{4})/);
            if (endTimeMatch) {
              const t = endTimeMatch[1];
              let hour = parseInt(t.substring(0,2), 10) + 9;
              if (hour >= 24) hour -= 24;
              endStr = `${String(hour).padStart(2,'0')}:${t.substring(2,4)}`;
            }
          } else {
            // Default 1 hour duration
            const [sh, sm] = timeStr.split(':').map(Number);
            let eh = sh + 1;
            if (eh >= 24) eh = 23;
            endStr = `${String(eh).padStart(2,'0')}:${String(sm).padStart(2,'0')}`;
          }

          const todayStr = getTodayDateString();
          // Filter to show only today's imported items on timeline
          if (dateStr === todayStr) {
            parsedEvents.push({
              id: `ical_${Date.now()}_${Math.random()}`,
              date: dateStr,
              title: decodeEscapedICSChars(currentEvent.summary),
              start: timeStr,
              end: endStr,
              memo: currentEvent.description ? decodeEscapedICSChars(currentEvent.description) : "外部カレンダー同期件数",
              completed: false
            });
          }
        }
        currentEvent = null;
      } else if (currentEvent) {
        const colonIdx = trimmed.indexOf(':');
        if (colonIdx > 0) {
          const key = trimmed.substring(0, colonIdx).split(';')[0].toUpperCase();
          const val = trimmed.substring(colonIdx + 1);
          
          if (key === "DTSTART") currentEvent.dtstart = val;
          else if (key === "DTEND") currentEvent.dtend = val;
          else if (key === "SUMMARY") currentEvent.summary = val;
          else if (key === "DESCRIPTION") currentEvent.description = val;
        }
      }
    });

    return parsedEvents;
  }

  function decodeEscapedICSChars(str) {
    return str
      .replace(/\\,/g, ',')
      .replace(/\\;/g, ';')
      .replace(/\\n/g, '\n')
      .replace(/\\N/g, '\n')
      .replace(/\\\\/g, '\\');
  }

  // Get a pre-formatted dummy ICS file contents for testing
  function getMockICSText() {
    const today = new Date();
    const yr = today.getFullYear();
    const mo = String(today.getMonth()+1).padStart(2,'0');
    const dy = String(today.getDate()).padStart(2,'0');
    
    // We create UTC time strings that translate to 14:00 and 17:00 JST (+9 hours)
    // 14:00 JST = 05:00 UTC
    // 17:00 JST = 08:00 UTC
    return `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Zen Schedule//ICS Calendar//EN
BEGIN:VEVENT
UID:ical_mock_event_1
DTSTART:${yr}${mo}${dy}T050000Z
DTEND:${yr}${mo}${dy}T060000Z
SUMMARY:【外部】重要プロジェクト成果物の最終審査
DESCRIPTION:仕様書とデザインの確認を行います。
END:VEVENT
BEGIN:VEVENT
UID:ical_mock_event_2
DTSTART:${yr}${mo}${dy}T080000Z
DTEND:${yr}${mo}${dy}T090000Z
SUMMARY:【外部】お客様アンケート集計＆週次報告
DESCRIPTION:アンケート内容をスプレッドシートより参照。
END:VEVENT
END:VCALENDAR`;
  }

  // --- Web Audio API Synth Engines ---
  let audioCtx = null;

  function initAudio() {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
  }

  // Synthesize shoji sliding noise
  function playShojiSlide() {
    try {
      initAudio();
      const now = audioCtx.currentTime;
      
      const bufferSize = audioCtx.sampleRate * 0.45; // 0.45 seconds
      const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      
      const noise = audioCtx.createBufferSource();
      noise.buffer = buffer;
      
      const filter = audioCtx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(600, now);
      filter.frequency.exponentialRampToValueAtTime(150, now + 0.45);
      filter.Q.setValueAtTime(3.0, now);
      
      const gain = audioCtx.createGain();
      gain.gain.setValueAtTime(0.06, now);
      gain.gain.linearRampToValueAtTime(0.001, now + 0.45);
      
      noise.connect(filter);
      filter.connect(gain);
      gain.connect(audioCtx.destination);
      
      noise.start(now);
    } catch (e) {
      console.warn("Sound synthesis blocked or failed:", e);
    }
  }

  // Synthesize wood block Mokugyo
  function playMokugyo() {
    try {
      initAudio();
      const now = audioCtx.currentTime;
      
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(290, now);
      osc.frequency.exponentialRampToValueAtTime(120, now + 0.08);
      
      gain.gain.setValueAtTime(0.7, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
      
      osc.start(now);
      osc.stop(now + 0.08);
    } catch (e) {
      console.warn(e);
    }
  }

  // Synthesize crystal clear Rin bell chime
  function playRin() {
    try {
      initAudio();
      const now = audioCtx.currentTime;
      
      const harmonics = [
        { f: 2000, v: 0.3, d: 2.2 },
        { f: 2003, v: 0.15, d: 2.8 }, // beat frequency
        { f: 3000, v: 0.08, d: 1.2 },
        { f: 4000, v: 0.04, d: 0.8 }
      ];
      
      harmonics.forEach(h => {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        
        osc.type = 'sine';
        osc.frequency.setValueAtTime(h.f, now);
        
        gain.gain.setValueAtTime(h.v, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + h.d);
        
        osc.start(now);
        osc.stop(now + h.d + 0.1);
      });
    } catch (e) {
      console.warn(e);
    }
  }

  // Start logic
  initTimeline();
  updateClock();
  setInterval(updateClock, 1000);
});
