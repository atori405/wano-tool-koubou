// ============================================
// メルカリかんたん出品補助 — Content Script
// ============================================

(function () {
  const loc = window.location.href;

  if (loc.includes("jp.mercari.com/sell/create")) {
    // MERCARI LISTING PAGE: Handle autofill UI injection
    initMercariAutofill();
  } else {
    // EC SITES: Listen for scraping request from popup
    initEcScraper();
  }

  // --- 1. EC Site Scraper Logic ---
  function initEcScraper() {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "scrapeProductInfo") {
        const info = {
          title: getProductTitle(),
          price: getProductPrice(),
          specs: getProductSpecs(),
          url: loc
        };
        sendResponse(info);
      }
      return true;
    });
  }

  function getProductTitle() {
    let title = "";
    if (loc.includes("amazon.co.jp")) {
      title = document.querySelector("#productTitle")?.textContent || "";
    } else if (loc.includes("rakuten.co.jp")) {
      title = document.querySelector(".item_name")?.textContent || document.querySelector("h1")?.textContent || "";
    } else if (loc.includes("shopping.yahoo.co.jp")) {
      title = document.querySelector(".Title_Title__text__") || document.querySelector("h1")?.textContent || "";
      if (typeof title === "object") title = title.textContent || "";
    } else if (loc.includes("yodobashi.com")) {
      title = document.querySelector("#productsKeyWord")?.textContent || document.querySelector("h1")?.textContent || "";
    }

    if (!title) {
      const ogTitle = document.querySelector('meta[property="og:title"]');
      title = ogTitle ? ogTitle.content : document.title;
    }

    return cleanProductTitle(title);
  }

  function cleanProductTitle(title) {
    return title
      .trim()
      .replace(/^\[.*?\]\s*/g, "")
      .replace(/\s*【.*?】/g, "")
      .replace(/\s*［.*?］/g, "")
      .replace(/送料無料|税込|公式|日本国内発送|即納/g, "")
      .substring(0, 60)
      .trim();
  }

  function getProductPrice() {
    let price = "";
    let selectors = [];

    if (loc.includes("amazon.co.jp")) {
      selectors = [".a-price-whole", "#priceBlock_ourPrice", "#priceblock_dealprice", "#corePrice_feature_div .a-price-whole"];
    } else if (loc.includes("rakuten.co.jp")) {
      selectors = ["[class*='price--']", ".price", ".important", "#price-box"];
    } else if (loc.includes("shopping.yahoo.co.jp")) {
      selectors = ["[class*='PriceValue']", "span.elPriceValue", ".c-price"];
    } else if (loc.includes("yodobashi.com")) {
      selectors = [".productPrice", "#unitPrice"];
    }

    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) {
        let cleaned = el.textContent.trim().replace(/[^\d]/g, "");
        if (cleaned) {
          price = "¥" + Number(cleaned).toLocaleString();
          break;
        }
      }
    }
    return price;
  }

  function getProductSpecs() {
    let specs = [];

    if (loc.includes("amazon.co.jp")) {
      // Feature bullets
      const bullets = document.querySelectorAll("#feature-bullets li span.a-list-item");
      bullets.forEach(el => {
        const text = el.textContent.trim();
        if (text && text.length > 5 && !text.includes("無料配送") && !text.includes("返品")) {
          specs.push("・ " + text);
        }
      });
      // Technical specs section fallback if no bullets
      if (specs.length === 0) {
        const rows = document.querySelectorAll(".prodDetTable tr");
        rows.forEach(row => {
          const th = row.querySelector("th");
          const td = row.querySelector("td");
          if (th && td) {
            specs.push(`・ ${th.textContent.trim()}：${td.textContent.trim().replace(/\s+/g, ' ')}`);
          }
        });
      }
    } else if (loc.includes("rakuten.co.jp")) {
      // Table cells
      const table = document.querySelector(".shop_item_table") || document.querySelector("table");
      if (table) {
        table.querySelectorAll("tr").forEach(tr => {
          const th = tr.querySelector("th") || tr.querySelectorAll("td")[0];
          const td = tr.querySelector("td") || tr.querySelectorAll("td")[1];
          if (th && td && th !== td && th.textContent.trim().length < 15) {
            specs.push(`・ ${th.textContent.trim()}：${td.textContent.trim().substring(0, 100)}`);
          }
        });
      }
    } else if (loc.includes("shopping.yahoo.co.jp")) {
      const rows = document.querySelectorAll(".Specification_Specification__ tr, .Specification_Specification__ dl");
      rows.forEach(el => {
        const th = el.querySelector("th, dt");
        const td = el.querySelector("td, dd");
        if (th && td) {
          specs.push(`・ ${th.textContent.trim()}：${td.textContent.trim().substring(0, 100)}`);
        }
      });
    } else if (loc.includes("yodobashi.com")) {
      const table = document.querySelector(".specTable");
      if (table) {
        table.querySelectorAll("tr").forEach(tr => {
          const tds = tr.querySelectorAll("td");
          if (tds.length === 2) {
            specs.push(`・ ${tds[0].textContent.trim()}：${tds[1].textContent.trim()}`);
          }
        });
      }
    }

    // Clean formatting and cap results
    return specs
      .map(s => s.replace(/\s+/g, " ").trim())
      .filter(s => s.length > 3)
      .slice(0, 10)
      .join("\n");
  }

  // --- 2. Mercari Autofill Logic ---
  function initMercariAutofill() {
    // Check storage for saved listing helper data
    chrome.storage.local.get(["lastScrapedListing"], (data) => {
      if (data && data.lastScrapedListing) {
        // Wait for page to fully render inputs
        const intervalId = setInterval(() => {
          const titleInput = document.querySelector('input[name="name"]') || 
                             document.querySelector('input[placeholder*="商品名"]') ||
                             Array.from(document.querySelectorAll('input')).find(el => {
                               const ph = el.placeholder || "";
                               return ph.includes("商品名") || ph.includes("40文字");
                             });

          if (titleInput) {
            clearInterval(intervalId);
            
            // 1. Inject manual helper button (as fallback / re-trigger option)
            injectAutofillButton(data.lastScrapedListing);
            
            // 2. Perform Autofill Automatically (WOW factor!)
            // Slight delay (500ms) to ensure React fields are fully active and bound
            setTimeout(() => {
              performAutofill(data.lastScrapedListing, true); // true = silent automatic run
            }, 500);
          }
        }, 1000);

        // Safety timeout
        setTimeout(() => clearInterval(intervalId), 15000);
      }
    });
  }

  function injectAutofillButton(listingData) {
    if (document.getElementById("mlh-autofill-btn-root")) return;

    const btnContainer = document.createElement("div");
    btnContainer.id = "mlh-autofill-btn-root";
    btnContainer.innerHTML = `
      <div class="mlh-btn-card">
        <span class="mlh-logo">💰</span>
        <div class="mlh-info">
          <span class="mlh-title">出品補助ツール</span>
          <span class="mlh-subtitle">前回の保存データあり</span>
        </div>
        <button class="mlh-autofill-btn" id="mlh-autofill-action">自動入力 ✍️</button>
      </div>
    `;
    document.body.appendChild(btnContainer);

    document.getElementById("mlh-autofill-action").addEventListener("click", () => {
      performAutofill(listingData, false); // false = show alert on failure
    });
  }

  function performAutofill(data, silent = false) {
    // Robust element selector fallback system (scrapes by attribute AND scanned placeholder texts)
    const titleInput = document.querySelector('input[name="name"]') || 
                       document.querySelector('input[placeholder*="商品名"]') ||
                       document.querySelector('input[id*="name"]') ||
                       Array.from(document.querySelectorAll('input')).find(el => {
                         const ph = el.placeholder || "";
                         return ph.includes("商品名") || ph.includes("40文字");
                       });
                       
    const descTextarea = document.querySelector('textarea[name="description"]') || 
                         document.querySelector('textarea[placeholder*="商品の説明"]') ||
                         document.querySelector('textarea[placeholder*="色、素材"]') ||
                         document.querySelector('textarea[placeholder*="素材、重さ"]') ||
                         document.querySelector('textarea[id*="description"]') ||
                         Array.from(document.querySelectorAll('textarea')).find(el => {
                           const ph = el.placeholder || "";
                           return ph.includes("商品の説明") || ph.includes("色、素材") || ph.includes("定価、注意点");
                         });

    let filledCount = 0;

    if (titleInput && data.title) {
      setReactValue(titleInput, data.title);
      filledCount++;
    }
    if (descTextarea && data.description) {
      setReactValue(descTextarea, data.description);
      filledCount++;
    }

    if (filledCount > 0) {
      showToastNotification("商品説明を自動入力しました！✨");
    } else {
      if (!silent) {
        alert("メルカリの入力フィールドが見つかりませんでした。画面がロードされているかご確認ください。");
      }
    }
  }

  // Workaround to bypass React virtual DOM value tracker
  function setReactValue(element, value) {
    const lastValue = element.value;
    element.value = value;
    const event = new Event("input", { bubbles: true });
    
    // React 15/16+ tracker workaround
    const tracker = element._valueTracker;
    if (tracker) {
      tracker.setValue(lastValue);
    }
    element.dispatchEvent(event);
  }

  function showToastNotification(text) {
    const notice = document.createElement("div");
    notice.className = "mlh-notification-toast";
    notice.textContent = text;
    document.body.appendChild(notice);
    
    setTimeout(() => {
      notice.classList.add("mlh-toast-fadeout");
      setTimeout(() => notice.remove(), 500);
    }, 3000);
  }
})();


// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // Add temporary shield to prevent iframe from stealing mouse events during dragging
      const existingShield = document.getElementById("wano-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = "wano-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      // Use getBoundingClientRect() for correct viewport-relative position
      // (element.offsetTop is unreliable for position:fixed elements on scrolled pages)
      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      // Restrict within window boundaries to prevent going offscreen
      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById("wano-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById("wano-universal-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "block" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = "wano-universal-floating-container";
    
    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 512) + "px !important; z-index:2147483647 !important; width:502px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="wano-u-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">Mercari Listing Helper</span>
        </div>
        <button id="wano-u-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#wano-u-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#wano-u-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
