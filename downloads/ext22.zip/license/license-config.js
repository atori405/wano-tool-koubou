/**
 * license-config.js
 * 
 * 拡張機能ごとの個別ライセンス商品ID設定。
 * 自動生成されたファイルです。手動で変更しないでください。
 */
window.LicenseConfig = {
  productId: "1318867",
  allToolsProductId: "1318293",
  singleCheckoutUrl: "https://wafuu-koubou.lemonsqueezy.com/checkout/buy/40708dcf-7bd6-4359-8010-5236b36ef66b",
  bundleCheckoutUrl: "https://wafuu-koubou.lemonsqueezy.com/checkout/buy/d2530690-2049-4779-8a24-0a15c803bb24"
};
