// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// ============================================
// メルカリかんたん出品補助 — Popup Script
// ============================================

document.addEventListener("DOMContentLoaded", () => {
  // Form elements
  const conditionSelect = document.getElementById("item-condition");
  const usageSelect = document.getElementById("item-usage");
  
  // Accessory checkboxes
  const accBody = document.getElementById("acc-body");
  const accBox = document.getElementById("acc-box");
  const accManual = document.getElementById("acc-manual");
  const accCable = document.getElementById("acc-cable");
  const accCharger = document.getElementById("acc-charger");

  // Appeal checkboxes
  const noteSmoke = document.getElementById("note-smoke");
  const noteClean = document.getElementById("note-clean");
  const noteBuy = document.getElementById("note-buy");
  const noteFast = document.getElementById("note-fast");

  // Preview elements
  const titleInput = document.getElementById("mercari-title");
  const descTextarea = document.getElementById("mercari-description");
  const charCounter = document.getElementById("title-char-count");
  const banner = document.getElementById("scraping-status");
  const bannerText = document.getElementById("status-text");

  // Buttons
  const copyTitleBtn = document.getElementById("copy-title-btn");
  const copyDescBtn = document.getElementById("copy-desc-btn");
  const openMercariBtn = document.getElementById("open-mercari-btn");

  // Local state
  let state = {
    scrapedTitle: "",
    scrapedPrice: "",
    scrapedSpecs: "",
    scrapedUrl: ""
  };

  // 1. Initial Scraping Check
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0] || !tabs[0].id) {
      loadHistoryFallback();
      return;
    }

    const url = tabs[0].url || "";
    const isSupportedEc = ["amazon.co.jp", "rakuten.co.jp", "shopping.yahoo.co.jp", "yodobashi.com"].some(domain => url.includes(domain));

    if (isSupportedEc) {
      chrome.tabs.sendMessage(tabs[0].id, { action: "scrapeProductInfo" }, (response) => {
        if (chrome.runtime.lastError || !response) {
          console.warn("EC page details scrape failed. Loading fallback...");
          loadHistoryFallback();
          return;
        }

        // Successfully scraped EC details
        state.scrapedTitle = response.title || "";
        state.scrapedPrice = response.price || "";
        state.scrapedSpecs = response.specs || "";
        state.scrapedUrl = response.url || "";

        // Update banner to success
        banner.className = "status-banner status-success";
        bannerText.textContent = "ECサイトから商品情報を取得しました！";

        updatePreviews();
      });
    } else {
      loadHistoryFallback();
    }
  });

  // Load last saved data from storage if not on an active EC site
  function loadHistoryFallback() {
    chrome.storage.local.get(["lastScrapedListing"], (data) => {
      if (data && data.lastScrapedListing) {
        // Hydrate from previous listing helper session
        banner.className = "status-banner status-success";
        bannerText.textContent = "前回のスクラップ履歴を読み込みました。";
        
        // Recover draft
        titleInput.value = data.lastScrapedListing.title || "";
        descTextarea.value = data.lastScrapedListing.description || "";
        updateCharCounter();
      } else {
        banner.className = "status-banner status-empty";
        bannerText.textContent = "EC商品ページを開くと自動でスペックが読み込まれます。";
        updatePreviews();
      }
    });
  }

  // 2. Real-time Template Synthesizer
  function updatePreviews() {
    // Generate optimized Title (Mercari limit: 40 chars)
    const condition = conditionSelect.value;
    let prefix = "【美品】";
    if (condition.includes("新品")) {
      prefix = "【新品】";
    } else if (condition.includes("未使用に近い")) {
      prefix = "【極美品】";
    } else if (condition.includes("やや傷") || condition.includes("傷")) {
      prefix = "【中古品】";
    }

    const baseTitle = state.scrapedTitle || "商品名";
    let formattedTitle = `${prefix}${baseTitle}`;
    
    // Auto-append tags if space allows
    if (formattedTitle.length < 34) {
      formattedTitle += " 動作確認済";
    }

    // Strict 40 character cap
    titleInput.value = formattedTitle.substring(0, 40);
    updateCharCounter();

    // Assemble Description Template
    const usage = usageSelect.value;
    
    // Compile accessories
    const accessories = [];
    if (accBody.checked) accessories.push(accBody.value);
    if (accBox.checked) accessories.push(accBox.value);
    if (accManual.checked) accessories.push(accManual.value);
    if (accCable.checked) accessories.push(accCable.value);
    if (accCharger.checked) accessories.push(accCharger.value);
    
    const accText = accessories.length > 0 ? accessories.map(a => `・ ${a}`).join("\n") : "・ なし";

    // Compile notes
    const notes = [];
    if (noteSmoke.checked) notes.push(`・ ${noteSmoke.value}`);
    if (noteClean.checked) notes.push(`・ ${noteClean.value}`);
    if (noteBuy.checked) notes.push(`— ${noteBuy.value}`);
    if (noteFast.checked) notes.push(`— ${noteFast.value}`);

    const notesText = notes.join("\n");

    // Scraped specs formatting
    const specBlock = state.scrapedSpecs ? `【製品スペック】\n${state.scrapedSpecs}\n\n` : "";
    const originalPriceBlock = state.scrapedPrice ? `【参考価格】\n・ECサイト販売価格：${state.scrapedPrice}（参考）\n\n` : "";

    // Dynamic hashtags
    const hashtags = generateHashtags(baseTitle);

    const description = 
`ご覧いただきありがとうございます。
整理のため、使用しなくなった以下のアイテムを出品いたします。

【商品名】
${baseTitle}

${originalPriceBlock}${specBlock}【商品の状態】
・状態ランク：${condition}
・使用感詳細：${usage}

【付属品】
${accText}

【特記事項】
${notesText}

何卒よろしくお願いいたします。

${hashtags}`.trim();

    descTextarea.value = description;

    // Cache the generated data in local storage for auto-fill page integration
    chrome.storage.local.set({
      lastScrapedListing: {
        title: titleInput.value,
        description: description
      }
    });
  }

  function generateHashtags(title) {
    const clean = title.replace(/[\[\]【】]/g, " ").replace(/\s+/g, " ").trim();
    const words = clean.split(" ");
    const tags = ["#メルカリ", "#フリマ"];
    
    words.forEach(w => {
      if (w.length > 1 && !w.includes("品") && !w.includes("美品") && !w.includes("確認") && !w.includes("発送")) {
        const hash = "#" + w.replace(/[^\w\dァ-ンヴーぁ-ん亜-熙]/g, "");
        if (hash.length > 2 && !tags.includes(hash)) {
          tags.push(hash);
        }
      }
    });
    
    return tags.slice(0, 5).join(" ");
  }

  function updateCharCounter() {
    const len = titleInput.value.length;
    charCounter.textContent = `${len}/40`;
    if (len >= 40) {
      charCounter.className = "char-count warning";
    } else {
      charCounter.className = "char-count";
    }
  }

  // 3. Form Input Change Listeners
  [conditionSelect, usageSelect].forEach(el => {
    el.addEventListener("change", updatePreviews);
  });

  [accBody, accBox, accManual, accCable, accCharger, noteSmoke, noteClean, noteBuy, noteFast].forEach(el => {
    el.addEventListener("change", updatePreviews);
  });

  titleInput.addEventListener("input", () => {
    updateCharCounter();
    // Save custom modifications
    chrome.storage.local.set({
      lastScrapedListing: {
        title: titleInput.value,
        description: descTextarea.value
      }
    });
  });

  descTextarea.addEventListener("input", () => {
    // Save custom modifications
    chrome.storage.local.set({
      lastScrapedListing: {
        title: titleInput.value,
        description: descTextarea.value
      }
    });
  });

  // 4. Copy-to-Clipboard Functionality
  copyTitleBtn.addEventListener("click", () => {
    navigator.clipboard.writeText(titleInput.value).then(() => {
      showCopyFeedback(copyTitleBtn, "コピー完了");
    });
  });

  copyDescBtn.addEventListener("click", () => {
    navigator.clipboard.writeText(descTextarea.value).then(() => {
      showCopyFeedback(copyDescBtn, "コピー完了");
    });
  });

  function showCopyFeedback(btn, text) {
    const originalText = btn.textContent;
    btn.textContent = text;
    btn.classList.add("btn-copied");
    setTimeout(() => {
      btn.textContent = originalText;
      btn.classList.remove("btn-copied");
    }, 1500);
  }

  // 5. Open Mercari Listing Page
  openMercariBtn.addEventListener("click", () => {
    chrome.tabs.create({ url: "https://jp.mercari.com/sell/create" });
  });
});
