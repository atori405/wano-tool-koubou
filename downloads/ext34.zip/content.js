(() => {
  const OVERLAY_ID = "wano-color-filter-overlay";
  const COLOR_MAP = {
    sakura: "#ffd9e8",  // 桜色 (Sakura pink)
    matcha: "#c5d8a8",  // 抹茶色 (Matcha green)
    kohaku: "#f5b041",  // 琥珀色 (Kohaku amber)
    usufuji: "#c9b8d9", // 薄藤色 (Usufuji pale wisteria purple)
    kaki: "#e67e22"     // 柿色 (Kaki orange-red)
  };

  let activeOverlay = null;
  let currentSettings = null;
  let autoTimer = null;

  // --- 1. Init Overlay ---
  function initOverlay() {
    if (activeOverlay && document.getElementById(OVERLAY_ID)) return;

    let overlay = document.getElementById(OVERLAY_ID);
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = OVERLAY_ID;
      overlay.style.position = "fixed";
      overlay.style.top = "0";
      overlay.style.left = "0";
      overlay.style.right = "0";  // Use edges coordinates instead of 100vw to bypass viewport bugs
      overlay.style.bottom = "0"; // Use edges coordinates instead of 100vh to bypass viewport bugs
      overlay.style.pointerEvents = "none";
      overlay.style.zIndex = "2147483647"; // Max z-index
      overlay.style.display = "none";
      overlay.style.transition = "background-color 0.8s ease, opacity 0.8s ease";
    }

    if (document.body) {
      if (overlay.parentNode !== document.body) {
        document.body.appendChild(overlay);
      }
      activeOverlay = overlay;
    } else {
      // Temporary attach to HTML node if body doesn't exist yet (at document_start)
      if (overlay.parentNode !== document.documentElement) {
        document.documentElement.appendChild(overlay);
      }
      activeOverlay = overlay;

      // Observe DOM to automatically migrate to body as soon as it renders
      const observer = new MutationObserver((mutations, obs) => {
        if (document.body) {
          if (overlay.parentNode !== document.body) {
            document.body.appendChild(overlay);
          }
          obs.disconnect();
        }
      });
      observer.observe(document.documentElement, { childList: true, subtree: true });
    }
  }

  // --- 2. Calculate Auto Settings based on Base Settings and Local Time ---
  function getAutoFilterParams(baseColorKey, baseIntensity, timeOverride) {
    const color = COLOR_MAP[baseColorKey] || COLOR_MAP.matcha;
    let phase = timeOverride || "auto";

    if (phase === "auto") {
      const hour = new Date().getHours();
      if (hour >= 9 && hour < 17) {
        phase = "day";
      } else if (hour >= 17 && hour < 21) {
        phase = "evening";
      } else {
        phase = "night";
      }
    }

    let factor = 1.0;
    if (phase === "day") {
      factor = 0.5;
    } else if (phase === "evening") {
      factor = 1.0;
    } else {
      factor = 1.5;
    }

    let calculatedIntensity = Math.round(baseIntensity * factor);
    // Clamp to valid range [5, 80]
    calculatedIntensity = Math.max(5, Math.min(80, calculatedIntensity));

    return { color, intensity: calculatedIntensity };
  }

  // --- 3. Apply Filter ---
  function applyFilter() {
    if (!activeOverlay) return;

    if (!currentSettings || !currentSettings.enabled) {
      activeOverlay.style.display = "none";
      return;
    }

    const hostname = window.location.hostname.toLowerCase();
    if (isWhitelisted(hostname, currentSettings.whitelist || [])) {
      activeOverlay.style.display = "none";
      return;
    }

    let filterColor = "";
    let filterIntensity = 0;

    const baseColorKey = currentSettings.colorKey || "matcha";
    const baseIntensity = currentSettings.intensity !== undefined ? currentSettings.intensity : 20;

    if (currentSettings.mode === "auto") {
      const override = currentSettings.timeOverride || "auto";
      const params = getAutoFilterParams(baseColorKey, baseIntensity, override);
      filterColor = params.color;
      filterIntensity = params.intensity;
    } else {
      filterColor = COLOR_MAP[baseColorKey] || COLOR_MAP.matcha;
      filterIntensity = baseIntensity;
    }

    activeOverlay.style.backgroundColor = filterColor;
    activeOverlay.style.opacity = (filterIntensity / 100).toString();
    activeOverlay.style.display = "block";
  }

  // --- 4. Helper: Check Whitelist ---
  function isWhitelisted(hostname, whitelist) {
    return whitelist.some(domain => {
      const cleaned = domain.trim().toLowerCase();
      if (!cleaned) return false;
      return hostname === cleaned || hostname.endsWith("." + cleaned);
    });
  }

  // --- 5. Start Auto Update Checker ---
  function startAutoChecker() {
    stopAutoChecker();
    autoTimer = setInterval(() => {
      if (currentSettings && currentSettings.mode === "auto" && currentSettings.enabled) {
        applyFilter();
      }
    }, 60000); // Check once per minute
  }

  function stopAutoChecker() {
    if (autoTimer) {
      clearInterval(autoTimer);
      autoTimer = null;
    }
  }

  // --- 6. Main Flow ---
  initOverlay();

  // Load from Storage
  chrome.storage.local.get(["colorFilterSettings"], (result) => {
    if (result.colorFilterSettings) {
      currentSettings = result.colorFilterSettings;
    } else {
      // Fallback defaults if storage is not yet initialized
      currentSettings = {
        enabled: true,
        mode: "auto",
        colorKey: "matcha",
        intensity: 20,
        whitelist: [],
        timeOverride: "auto"
      };
    }
    applyFilter();
    if (currentSettings.enabled && currentSettings.mode === "auto") {
      startAutoChecker();
    }
  });

  // Watch for Changes
  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === "local" && changes.colorFilterSettings) {
      currentSettings = changes.colorFilterSettings.newValue;
      applyFilter();
      if (currentSettings && currentSettings.mode === "auto" && currentSettings.enabled) {
        startAutoChecker();
      } else {
        stopAutoChecker();
      }
    }
  });

  // Recheck on DOM Loading to make sure overlay stays at the top root element
  document.addEventListener("DOMContentLoaded", () => {
    initOverlay();
    applyFilter();
  });
})();


// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  const NS_ID = "wano-" + chrome.runtime.id;

  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // Add temporary shield to prevent iframe from stealing mouse events during dragging
      const existingShield = document.getElementById(NS_ID + "-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = NS_ID + "-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      // Use getBoundingClientRect() for correct viewport-relative position
      // (element.offsetTop is unreliable for position:fixed elements on scrolled pages)
      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      // Restrict within window boundaries to prevent going offscreen
      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById(NS_ID + "-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById(NS_ID + "-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "block" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = NS_ID + "-floating-container";
    
    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 440) + "px !important; z-index:2147483647 !important; width:430px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="${NS_ID}-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">Japanese Color Filter</span>
        </div>
        <button id="${NS_ID}-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#" + NS_ID + "-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#" + NS_ID + "-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
