const DEFAULT_SETTINGS = {
  enabled: true,
  mode: "auto",           // "auto" or "manual"
  colorKey: "matcha",     // "sakura", "matcha", "kohaku", "usufuji", "kaki"
  intensity: 20,          // 0 to 80 (opacity percent)
  whitelist: [],          // list of domains to exclude
  timeOverride: "auto"    // "auto", "day", "evening", "night"
};

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["colorFilterSettings"], (result) => {
    if (!result.colorFilterSettings) {
      chrome.storage.local.set({ colorFilterSettings: DEFAULT_SETTINGS }, () => {
        console.log("Traditional color filter default settings initialized.");
      });
    }
  });
});
