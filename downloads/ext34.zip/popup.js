// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

document.addEventListener("DOMContentLoaded", () => {
  // Elements
  const masterToggle = document.getElementById("master-toggle");
  const modeAutoBtn = document.getElementById("mode-auto");
  const modeManualBtn = document.getElementById("mode-manual");
  const manualSettingsSection = document.getElementById("manual-settings-section");
  const colorGrid = document.getElementById("color-grid");
  const intensitySlider = document.getElementById("intensity-slider");
  const intensityValue = document.getElementById("intensity-value");
  const addCurrentSiteBtn = document.getElementById("add-current-site-btn");
  const whitelistList = document.getElementById("whitelist-list");
  const statusDot = document.getElementById("status-dot");
  const statusText = document.getElementById("footer-status-text");

  // Time Phase elements
  const timeBtnAuto = document.getElementById("time-btn-auto");
  const timeBtnDay = document.getElementById("time-btn-day");
  const timeBtnEvening = document.getElementById("time-btn-evening");
  const timeBtnNight = document.getElementById("time-btn-night");
  const timeOverrideSection = document.getElementById("time-override-section");

  // State
  let settings = {
    enabled: true,
    mode: "auto",
    colorKey: "matcha",
    intensity: 20,
    whitelist: [],
    timeOverride: "auto"
  };

  let currentTabUrl = "";
  let currentTabHostname = "";

  // --- 1. Get Current Tab URL & Domain ---
  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0]) {
        currentTabUrl = tabs[0].url || "";
        try {
          if (currentTabUrl.startsWith("http")) {
            const urlObj = new URL(currentTabUrl);
            currentTabHostname = urlObj.hostname.toLowerCase();
            addCurrentSiteBtn.innerHTML = `<span>🚫</span> <strong>${currentTabHostname}</strong> を除外`;
          } else {
            addCurrentSiteBtn.disabled = true;
            addCurrentSiteBtn.style.opacity = "0.5";
            addCurrentSiteBtn.innerHTML = "<span>🚫</span> このサイトは除外不可";
          }
        } catch (e) {
          console.error("Error parsing tab URL:", e);
        }
      }
      // Load Settings after tab info is ready to update UI status correctly
      loadSettings();
    });
  } else {
    // Fallback if running outside extension environment (e.g. testing)
    loadSettings();
  }

  // --- 2. Load & Save Settings ---
  function loadSettings() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.get(["colorFilterSettings"], (result) => {
        if (result.colorFilterSettings) {
          settings = { ...settings, ...result.colorFilterSettings };
        }
        applySettingsToUI();
      });
    } else {
      applySettingsToUI();
    }
  }

  function saveSettings() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.set({ colorFilterSettings: settings }, () => {
        updateStatus();
      });
    } else {
      updateStatus();
    }
  }

  // --- 3. UI Synchronization ---
  function applySettingsToUI() {
    // Enabled Toggle
    masterToggle.checked = settings.enabled;

    let activeColorKey = settings.colorKey;
    let activeIntensity = settings.intensity;

    // Mode Buttons
    if (settings.mode === "auto") {
      modeAutoBtn.classList.add("active");
      modeManualBtn.classList.remove("active");
      
      // Allow full control of color and base intensity even during automatic mode.
      manualSettingsSection.style.opacity = "1";
      manualSettingsSection.style.pointerEvents = "auto";
      
      intensitySlider.style.opacity = "1";
      intensitySlider.style.pointerEvents = "auto";

      if (timeOverrideSection) {
        timeOverrideSection.style.opacity = "1";
        timeOverrideSection.style.pointerEvents = "auto";
      }

      // Preview the selected base intensity on the slider directly so the user can control it.
      activeIntensity = settings.intensity;
    } else {
      modeAutoBtn.classList.remove("active");
      modeManualBtn.classList.add("active");
      
      manualSettingsSection.style.opacity = "1";
      manualSettingsSection.style.pointerEvents = "auto";
      
      intensitySlider.style.opacity = "1";
      intensitySlider.style.pointerEvents = "auto";

      if (timeOverrideSection) {
        timeOverrideSection.style.opacity = "0.5";
        timeOverrideSection.style.pointerEvents = "none";
      }
    }

    // Color Choice (Highlight currently active color)
    const cells = colorGrid.querySelectorAll(".theme-cell");
    cells.forEach(cell => {
      if (cell.getAttribute("data-color") === activeColorKey) {
        cell.classList.add("active");
      } else {
        cell.classList.remove("active");
      }
    });

    // Time Override Buttons Choice (Safely check if elements exist)
    if (timeBtnAuto && timeBtnDay && timeBtnEvening && timeBtnNight) {
      const currentOverride = settings.timeOverride || "auto";
      const overrideButtons = [
        { key: "auto", btn: timeBtnAuto },
        { key: "day", btn: timeBtnDay },
        { key: "evening", btn: timeBtnEvening },
        { key: "night", btn: timeBtnNight }
      ];
      overrideButtons.forEach(item => {
        if (item.btn) {
          if (item.key === currentOverride) {
            item.btn.classList.add("active");
          } else {
            item.btn.classList.remove("active");
          }
        }
      });
    }

    // Intensity Slider (Update slider position & percentage badge)
    intensitySlider.value = activeIntensity;
    intensityValue.textContent = `${activeIntensity}%`;

    // Whitelist List
    renderWhitelist();
    updateStatus();
  }

  function renderWhitelist() {
    whitelistList.innerHTML = "";
    const list = settings.whitelist || [];

    if (list.length === 0) {
      whitelistList.innerHTML = `<span class="empty-list-text">除外登録されているサイトはありません。</span>`;
      return;
    }

    list.forEach(domain => {
      const item = document.createElement("div");
      item.className = "whitelist-item";
      item.innerHTML = `
        <span class="whitelist-item-domain" title="${domain}">${domain}</span>
        <span class="whitelist-item-remove" data-domain="${domain}">×</span>
      `;
      whitelistList.appendChild(item);
    });

    // Bind remove event
    whitelistList.querySelectorAll(".whitelist-item-remove").forEach(btn => {
      btn.addEventListener("click", (e) => {
        const domainToRemove = e.target.getAttribute("data-domain");
        settings.whitelist = settings.whitelist.filter(d => d !== domainToRemove);
        saveSettings();
        renderWhitelist();
      });
    });
  }

  function updateStatus() {
    if (!settings.enabled) {
      statusDot.className = "status-dot inactive";
      statusText.textContent = "フィルター停止中";
      return;
    }

    // Check if current site is whitelisted
    const isWhitelisted = settings.whitelist && settings.whitelist.some(domain => {
      const cleaned = domain.trim().toLowerCase();
      if (!cleaned || !currentTabHostname) return false;
      return currentTabHostname === cleaned || currentTabHostname.endsWith("." + cleaned);
    });

    if (isWhitelisted) {
      statusDot.className = "status-dot whitelisted";
      statusText.textContent = "このサイトを除外中";
    } else {
      statusDot.className = "status-dot";
      if (settings.mode === "auto") {
        let phase = settings.timeOverride || "auto";
        let phaseText = "自動判定";
        if (phase === "auto") {
          const hour = new Date().getHours();
          if (hour >= 9 && hour < 17) {
            phase = "day";
            phaseText = "日中(時計)";
          } else if (hour >= 17 && hour < 21) {
            phase = "evening";
            phaseText = "夕方(時計)";
          } else {
            phase = "night";
            phaseText = "夜間(時計)";
          }
        } else {
          if (phase === "day") phaseText = "昼(強制)";
          else if (phase === "evening") phaseText = "夕(強制)";
          else phaseText = "夜(強制)";
        }

        let factor = 1.0;
        if (phase === "day") {
          factor = 0.5;
        } else if (phase === "evening") {
          factor = 1.0;
        } else {
          factor = 1.5;
        }

        const effective = Math.max(5, Math.min(80, Math.round(settings.intensity * factor)));
        statusText.textContent = `自動適用中: ${phaseText} (実効: ${effective}%)`;
      } else {
        statusText.textContent = "手動固定で適用中";
      }
    }
  }

  // --- 4. Event Listeners ---

  // Master Toggle Change
  masterToggle.addEventListener("change", (e) => {
    settings.enabled = e.target.checked;
    saveSettings();
  });

  // Mode Selection
  modeAutoBtn.addEventListener("click", () => {
    settings.mode = "auto";
    saveSettings();
    applySettingsToUI();
  });

  modeManualBtn.addEventListener("click", () => {
    settings.mode = "manual";
    saveSettings();
    applySettingsToUI();
  });

  // Color Selection
  colorGrid.querySelectorAll(".theme-cell").forEach(cell => {
    cell.addEventListener("click", () => {
      settings.colorKey = cell.getAttribute("data-color");
      colorGrid.querySelectorAll(".theme-cell").forEach(c => c.classList.remove("active"));
      cell.classList.add("active");
      saveSettings();
    });
  });

  // Intensity Slider Input
  intensitySlider.addEventListener("input", (e) => {
    settings.intensity = parseInt(e.target.value);
    intensityValue.textContent = `${settings.intensity}%`;
  });

  // Intensity Slider Change (Save on release)
  intensitySlider.addEventListener("change", (e) => {
    settings.intensity = parseInt(e.target.value);
    saveSettings();
  });

  // Time Phase Override Button Changes (Safely register only if elements exist)
  if (timeBtnAuto && timeBtnDay && timeBtnEvening && timeBtnNight) {
    timeBtnAuto.addEventListener("click", () => {
      settings.timeOverride = "auto";
      saveSettings();
      applySettingsToUI();
    });

    timeBtnDay.addEventListener("click", () => {
      settings.timeOverride = "day";
      saveSettings();
      applySettingsToUI();
    });

    timeBtnEvening.addEventListener("click", () => {
      settings.timeOverride = "evening";
      saveSettings();
      applySettingsToUI();
    });

    timeBtnNight.addEventListener("click", () => {
      settings.timeOverride = "night";
      saveSettings();
      applySettingsToUI();
    });
  }

  // Whitelist Current Site
  addCurrentSiteBtn.addEventListener("click", () => {
    if (!currentTabHostname) return;
    if (!settings.whitelist) settings.whitelist = [];

    if (!settings.whitelist.includes(currentTabHostname)) {
      settings.whitelist.push(currentTabHostname);
      saveSettings();
      renderWhitelist();
    }
  });
});
