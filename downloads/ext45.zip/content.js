// content.js - Webpage form auto-fill + Universal Floating Panel Loader
(function () {
  "use strict";

  // 拡張機能ごとに一意なDOM ID接頭辞。同じ仕組みを使う他の拡張機能とのDOM ID衝突を防ぐ。
  const NS_ID = "wano-" + chrome.runtime.id;

  // --- Form field classification ---------------------------------------
  const KEYWORDS = {
    kana: ["kana", "furigana", "フリガナ", "ふりがな", "ヨミガナ", "よみがな", "kananame"],
    zip: ["zip", "postal", "postcode", "郵便番号", "〒"],
    tel: ["tel", "phone", "電話", "でんわ", "携帯"],
    email: ["email", "mail", "メール", "eメール"],
    address: ["address", "addr", "住所", "所在地"],
    company: ["company", "corp", "会社", "法人", "御社名", "会社名"],
    text: ["comment", "message", "description", "memo", "備考", "本文", "メッセージ", "コメント", "ご意見", "ご要望"],
    name: ["name", "氏名", "お名前", "full-name", "fullname", "your-name"]
  };

  function getLabelText(el) {
    let text = "";
    if (el.id) {
      const label = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
      if (label) text += " " + label.textContent;
    }
    const parentLabel = el.closest("label");
    if (parentLabel) text += " " + parentLabel.textContent;
    return text;
  }

  function buildHaystack(el) {
    return [
      el.name, el.id, el.placeholder,
      el.getAttribute("aria-label"), el.getAttribute("autocomplete"),
      getLabelText(el)
    ].filter(Boolean).join(" ").toLowerCase();
  }

  function matchKeywords(haystack, keywords) {
    return keywords.some((kw) => haystack.includes(kw.toLowerCase()));
  }

  // Order matters: check more specific categories before the generic "name" fallback,
  // since e.g. a "company_name" field would otherwise match the broad "name" keyword.
  function classifyField(el) {
    if (el.tagName === "SELECT") return "select";

    const type = (el.type || "text").toLowerCase();
    if (type === "email") return "email";
    if (type === "tel") return "tel";

    const skipTypes = ["hidden", "submit", "button", "reset", "checkbox", "radio", "file", "password", "color", "range", "image"];
    if (skipTypes.includes(type)) return null;

    const haystack = buildHaystack(el);
    if (matchKeywords(haystack, KEYWORDS.kana)) return "kana";
    if (matchKeywords(haystack, KEYWORDS.zip)) return "zip";
    if (matchKeywords(haystack, KEYWORDS.tel)) return "tel";
    if (matchKeywords(haystack, KEYWORDS.email)) return "email";
    if (matchKeywords(haystack, KEYWORDS.address)) return "address";
    if (matchKeywords(haystack, KEYWORDS.company)) return "company";
    if (matchKeywords(haystack, KEYWORDS.text)) return "text";
    if (matchKeywords(haystack, KEYWORDS.name)) return "name";

    // Unclassified textarea -> treat as a generic long-text field.
    if (el.tagName === "TEXTAREA") return "text";

    return null;
  }

  function isFillable(el) {
    if (el.disabled || el.readOnly) return false;
    if (el.offsetParent === null && getComputedStyle(el).position !== "fixed") return false; // hidden
    return true;
  }

  // React-controlled inputs ignore a plain `el.value = x` assignment, so the native
  // property setter + a real input event are needed (same technique as ext43).
  function setNativeValue(el, value) {
    const proto = el.tagName === "TEXTAREA" ? window.HTMLTextAreaElement.prototype
      : el.tagName === "SELECT" ? window.HTMLSelectElement.prototype
      : window.HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(proto, "value");
    if (descriptor && descriptor.set) {
      descriptor.set.call(el, value);
    } else {
      el.value = value;
    }
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function findPrefectureInAddress(address) {
    if (!address) return null;
    return window.WabiDataGen.PREFECTURES.find((p) => address.includes(p.name)) || null;
  }

  function fillSelect(el, record) {
    const pref = findPrefectureInAddress(record.address);
    if (!pref) return false;
    const options = Array.from(el.options || []);
    const match = options.find((opt) => opt.textContent.includes(pref.name) || opt.value.includes(pref.name));
    if (!match) return false;
    setNativeValue(el, match.value);
    return true;
  }

  function fillForm() {
    return new Promise((resolve) => {
      chrome.storage.local.get(["genItems"], (result) => {
        const edgeCase = !!(result.genItems && result.genItems.edgeCase);
        const record = window.WabiDataGen.generateOneRecord({
          name: true, kana: true, address: true, tel: true, email: true, company: true, text: true,
          edgeCase
        });

        const fieldMap = {
          name: record.name,
          kana: record.kana,
          zip: record.zip,
          address: record.address,
          tel: record.tel,
          email: record.email,
          company: record.company,
          text: record.description
        };

        const elements = document.querySelectorAll("input, textarea, select");
        let filledCount = 0;

        elements.forEach((el) => {
          if (!isFillable(el)) return;
          const kind = classifyField(el);
          if (!kind) return;

          if (kind === "select") {
            if (fillSelect(el, record)) filledCount++;
            return;
          }

          const value = fieldMap[kind];
          if (value === undefined) return;
          setNativeValue(el, value);
          filledCount++;
        });

        resolve(filledCount);
      });
    });
  }

  // --- Universal Floating Panel Loader -----------------------------------
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      const existingShield = document.getElementById(NS_ID + "-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = NS_ID + "-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById(NS_ID + "-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById(NS_ID + "-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "flex" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = NS_ID + "-floating-container";

    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 440) + "px !important; z-index:2147483647 !important; width:430px !important; height:680px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="${NS_ID}-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">💮</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">日本語テストデータジェネレーター</span>
        </div>
        <button id="${NS_ID}-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    const header = container.querySelector("#" + NS_ID + "-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#" + NS_ID + "-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  // --- Toast (feedback for the fill-form action) --------------------------
  let toastEl = null;
  let toastTimer = null;
  function showToast(message) {
    if (!toastEl) {
      toastEl = document.createElement("div");
      toastEl.id = NS_ID + "-fill-toast";
      toastEl.style.cssText =
        "position:fixed !important; bottom:16px !important; right:16px !important; " +
        "z-index:2147483647 !important; max-width:320px !important; " +
        "background:#1c1a17 !important; color:#fdfcfa !important; " +
        "font-family:sans-serif !important; font-size:12.5px !important; line-height:1.6 !important; " +
        "padding:10px 14px !important; border-radius:8px !important; " +
        "box-shadow:0 8px 24px rgba(0,0,0,0.35) !important; " +
        "opacity:0 !important; transform:translateY(8px) !important; " +
        "transition:opacity 0.25s, transform 0.25s !important; pointer-events:none !important;";
      document.body.appendChild(toastEl);
    }
    toastEl.textContent = message;
    toastEl.style.setProperty("opacity", "1", "important");
    toastEl.style.setProperty("transform", "translateY(0)", "important");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toastEl.style.setProperty("opacity", "0", "important");
      toastEl.style.setProperty("transform", "translateY(8px)", "important");
    }, 2600);
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
        return true;
      }
      if (message.action === "fillForm") {
        fillForm().then((count) => {
          showToast(count > 0
            ? `${count}件のフォーム項目にテストデータを自動入力しました`
            : "自動入力できるフォーム項目が見つかりませんでした");
          sendResponse({ status: "filled", count });
        });
        return true; // async response
      }
      return true;
    });
  }
})();
