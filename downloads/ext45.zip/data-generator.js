// data-generator.js - shared Japanese dummy-data generation logic
// Used by both popup.js (JSON/CSV/TSV export) and content.js (webpage form auto-fill)
// so both entry points produce data from the same dictionaries and edge-case rules.
(function () {
  "use strict";

  const SURNAMES = [
    "佐藤", "鈴木", "高橋", "田中", "伊藤", "渡辺", "山本", "中村", "小林", "加藤",
    "吉田", "山田", "佐々木", "山口", "松本", "井上", "木村", "林", "斎藤", "清水",
    "山崎", "森", "池田", "橋本", "阿部", "石川", "山下", "中島", "石井", "小川",
    "前田", "岡田", "長谷川", "近藤", "後藤", "飯田", "北村", "関", "荒木", "松井",
    "三浦", "中野", "柴田", "原", "宮崎", "杉山", "上野", "野口", "小島", "藤田"
  ];

  const SURNAME_KANAS = [
    "さとう", "すずき", "たかはし", "たなか", "いとう", "わたなべ", "やまもと", "なかむら", "こばやし", "かとう",
    "よしだ", "やまだ", "ささき", "やまぐち", "まつもと", "いのうえ", "きむら", "はやし", "さいとう", "しみず",
    "やまざき", "もり", "いけだ", "はしもと", "あべ", "いしかわ", "やました", "なかじま", "いしい", "おがわ",
    "まえだ", "おかだ", "はせがわ", "こんどう", "ごとう", "いいだ", "きたむら", "せき", "あらき", "まつい",
    "みうら", "なかの", "しばた", "はら", "みやざき", "すぎやま", "うえの", "のぐち", "こじま", "ふじた"
  ];

  const SURNAME_ROMAJIS = [
    "sato", "suzuki", "takahashi", "tanaka", "ito", "watanabe", "yamamoto", "nakamura", "kobayashi", "kato",
    "yoshida", "yamada", "sasaki", "yamaguchi", "matsumoto", "inoue", "kimura", "hayashi", "saito", "shimizu",
    "yamazaki", "mori", "ikeda", "hashimoto", "abe", "ishikawa", "yamashita", "nakajima", "ishii", "ogawa",
    "maeda", "okada", "hasegawa", "kondo", "goto", "iida", "kitamura", "seki", "araki", "matsui",
    "miura", "nakano", "shibata", "hara", "miyazaki", "sugiyama", "ueno", "noguchi", "kojima", "fujita"
  ];

  const MEN_NAMES = [
    { kanji: "大翔", kana: "ひろと", romaji: "hiroto" },
    { kanji: "蓮", kana: "れん", romaji: "ren" },
    { kanji: "颯太", kana: "そうた", romaji: "sota" },
    { kanji: "陽翔", kana: "はると", romaji: "haruto" },
    { kanji: "悠真", kana: "ゆうま", romaji: "yuma" },
    { kanji: "大和", kana: "やまと", romaji: "yamato" },
    { kanji: "翔", kana: "かける", romaji: "kakeru" },
    { kanji: "陽太", kana: "ひなた", romaji: "hinata" },
    { kanji: "拓海", kana: "たくみ", romaji: "takumi" },
    { kanji: "陸", kana: "りく", romaji: "riku" },
    { kanji: "駿", kana: "しゅん", romaji: "shun" },
    { kanji: "健太", kana: "けんた", romaji: "kenta" },
    { kanji: "翼", kana: "つばさ", romaji: "tsubasa" },
    { kanji: "優太", kana: "ゆうた", romaji: "yuta" },
    { kanji: "太陽", kana: "たいよう", romaji: "taiyo" },
    { kanji: "海斗", kana: "かいと", romaji: "kaito" },
    { kanji: "大介", kana: "だいすけ", romaji: "daisuke" },
    { kanji: "翔太", kana: "しょうた", romaji: "shota" },
    { kanji: "太一", kana: "たいち", romaji: "taichi" },
    { kanji: "哲也", kana: "てつや", romaji: "tetsuya" },
    { kanji: "和也", kana: "かずや", romaji: "kazuya" },
    { kanji: "洋平", kana: "ようへい", romaji: "yohei" },
    { kanji: "直樹", kana: "なおき", romaji: "naoki" },
    { kanji: "真司", kana: "しんじ", romaji: "shinji" },
    { kanji: "康平", kana: "こうへい", romaji: "kohei" },
    { kanji: "達也", kana: "たつや", romaji: "tatsuya" },
    { kanji: "雄大", kana: "ゆうだい", romaji: "yudai" },
    { kanji: "一郎", kana: "いちろう", romaji: "ichiro" },
    { kanji: "健", kana: "けん", romaji: "ken" },
    { kanji: "大輝", kana: "だいき", romaji: "daiki" }
  ];

  const WOMEN_NAMES = [
    { kanji: "陽菜", kana: "ひな", romaji: "hina" },
    { kanji: "結愛", kana: "ゆあ", romaji: "yua" },
    { kanji: "莉子", kana: "りこ", romaji: "riko" },
    { kanji: "芽依", kana: "めい", romaji: "mei" },
    { kanji: "葵", kana: "あおい", romaji: "aoi" },
    { kanji: "結衣", kana: "ゆい", romaji: "yui" },
    { kanji: "咲良", kana: "さくら", romaji: "sakura" },
    { kanji: "美月", kana: "みつき", romaji: "mitsuki" },
    { kanji: "心春", kana: "こはる", romaji: "koharu" },
    { kanji: "愛菜", kana: "まな", romaji: "mana" },
    { kanji: "七海", kana: "ななみ", romaji: "nanami" },
    { kanji: "美優", kana: "みゆう", romaji: "miyu" },
    { kanji: "優花", kana: "ゆうか", romaji: "yuka" },
    { kanji: "杏", kana: "あん", romaji: "an" },
    { kanji: "美結", kana: "みゆ", romaji: "miyu" },
    { kanji: "結菜", kana: "ゆいな", romaji: "yuina" },
    { kanji: "結月", kana: "ゆづき", romaji: "yuzuki" },
    { kanji: "朱莉", kana: "あかり", romaji: "akari" },
    { kanji: "桃花", kana: "ももか", romaji: "momoka" },
    { kanji: "千尋", kana: "ちひろ", romaji: "chihiro" },
    { kanji: "麻衣", kana: "まい", romaji: "mai" },
    { kanji: "彩香", kana: "あやか", romaji: "ayaka" },
    { kanji: "理沙", kana: "りさ", romaji: "risa" },
    { kanji: "瞳", kana: "ひとみ", romaji: "hitomi" },
    { kanji: "恵", kana: "めぐみ", romaji: "megumi" },
    { kanji: "奈々", kana: "なな", romaji: "nana" },
    { kanji: "未来", kana: "みく", romaji: "miku" },
    { kanji: "晴香", kana: "はるか", romaji: "haruka" },
    { kanji: "花", kana: "はな", romaji: "hana" },
    { kanji: "真央", kana: "まお", romaji: "mao" }
  ];

  const PREFECTURES = [
    { name: "東京都", code: "100" },
    { name: "神奈川県", code: "220" },
    { name: "大阪府", code: "530" },
    { name: "愛知県", code: "460" },
    { name: "埼玉県", code: "330" },
    { name: "千葉県", code: "260" },
    { name: "兵庫県", code: "650" },
    { name: "北海道", code: "060" },
    { name: "福岡県", code: "810" },
    { name: "京都府", code: "600" },
    { name: "宮城県", code: "980" },
    { name: "広島県", code: "730" }
  ];

  const CITIES = {
    "東京都": ["新宿区", "渋谷区", "港区", "千代田区", "中央区", "目黒区", "品川区", "世田谷区", "文京区", "武蔵野市"],
    "神奈川県": ["横浜市中区", "横浜市西区", "横浜市港北区", "川崎市中原区", "川崎市高津区", "鎌倉市", "藤沢市"],
    "大阪府": ["大阪市北区", "大阪市中央区", "大阪市西区", "吹田市", "豊中市", "堺市北区", "高槻市"],
    "愛知県": ["名古屋市中区", "名古屋市中村区", "名古屋市千種区", "豊田市", "岡崎市", "一宮市"],
    "埼玉県": ["さいたま市大宮区", "さいたま市浦和区", "川越市", "所沢市", "越谷市"],
    "千葉県": ["千葉市中央区", "船橋市", "松戸市", "市川市", "浦安市"],
    "兵庫県": ["神戸市中央区", "神戸市東灘区", "西宮市", "尼崎市", "姫路市"],
    "北海道": ["札幌市中央区", "札幌市北区", "小樽市", "旭川市", "函館市"],
    "福岡県": ["福岡市博多区", "福岡市中央区", "福岡市早良区", "北九州市小倉北区", "久留米市"],
    "京都府": ["京都市中京区", "京都市下京区", "京都市左京区", "宇治市"],
    "宮城県": ["仙台市青葉区", "仙台市宮城野区", "石巻市", "大崎市"],
    "広島県": ["広島市中区", "広島市南区", "福山市", "呉市"]
  };

  const TOWNS = [
    "本町", "栄町", "旭町", "新町", "緑町", "南町", "北町", "東町", "西宿", "桜ヶ丘",
    "高砂", "平和台", "大手町", "西新宿", "元町", "海岸通", "美咲が丘", "泉町", "山手町"
  ];

  const BUILDINGS = [
    "和沙レジデンス 302号室", "雅ガーデンヒルズ 501", "山吹荘 2号室", "セゾン西新宿 1004",
    "グランハイツ港町 201", "青海波タワー 32階", "萌黄コーポ 102", "エステート白木 403",
    "藤紫コート 1102", "藍墨ビルディング 8F", "日の出マンション 505", "メゾン・ド・匠 103"
  ];

  const COMPANY_PREFIXES = ["株式会社", "合同会社", "有限会社"];
  const COMPANY_SUFFIXES = ["システムズ", "テクノロジー", "ソリューションズ", "テック", "フーズ", "開発"];
  const COMPANY_NAMES = ["和沙", "山吹", "青海波", "萌黄", "大和", "扶桑", "ミヤビ", "ツムギ", "匠", "流星", "双葉", "日向"];

  const DUMMY_LOREM_PHRASES = [
    "吾輩は猫である。名前はまだ無い。どこで生れたかとんと見当がつかぬ。",
    "親譲りの無鉄砲で小供の時から損ばかりしている。",
    "メロスは激怒した。必ず、かの邪智暴虐の王を除かなければならぬと決意した。",
    "国境の長いトンネルを抜けると雪国であった。夜の底が白くなった。",
    "祇園精舎の鐘の声、諸行無常の響きあり。沙羅双樹の花の色、盛者必衰の理をあらわす。",
    "静かに開いた扉の向こうには、かつて見たこともないほど澄み切った青い空が広がっていた。",
    "昨日の課題を今日に持ち越さず、一歩ずつ確実なコードを積み重ねることこそが、エンジニアの美徳である。",
    "テストデータは正確で美しくあるべきだ。それがシステムの堅牢性を測る最初の鏡となるのだから。",
    "川のせせらぎを聞きながら、緑豊かな日本の白木机に向かってコーディングする時間は、格別の贅沢である。",
    "山吹色の夕日が沈む頃、開発室のモニターには成功を示すグリーンのテストログが流れていた。",
    "初心を忘れず、常にユーザーの立場になってプロダクトを磨き上げる姿勢が、素晴らしい体験を生み出す鍵となる。",
    "古池や蛙飛びこむ水の音。静寂の中に響くその一瞬の波紋のように、小さな改善が大きなインパクトを生む。"
  ];

  function getRandomEl(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  // Edge-case injection helper (abnormal validation data)
  function applyEdgeCase(text, type, edgeCaseEnabled) {
    if (!edgeCaseEnabled) return text;

    const r = Math.random();
    if (r > 0.45) return text; // 45% probability to inject edge case

    if (type === "name") {
      const caseType = getRandomInt(0, 3);
      if (caseType === 0) {
        return text.replace("佐藤", "髙橋").replace("鈴木", "﨑田");
      } else if (caseType === 1) {
        return "ﾀﾛｳ " + text;
      } else if (caseType === 2) {
        return text + " １２３";
      } else {
        return text + " ㈱";
      }
    } else if (type === "kana") {
      const caseType = getRandomInt(0, 1);
      if (caseType === 0) {
        return text.replace("さとう", "ｻﾄｳ").replace("すずき", "ｽｽﾞｷ");
      } else {
        return text + " （かぶ）";
      }
    } else if (type === "address") {
      const caseType = getRandomInt(0, 2);
      if (caseType === 0) {
        return text.replace(/-/g, "－");
      } else if (caseType === 1) {
        return text.replace("302号室", "①0②号室").replace("501", "⑤〇①");
      } else {
        return text.replace(/[0-9]/g, s => String.fromCharCode(s.charCodeAt(0) + 0xFEE0));
      }
    } else if (type === "tel") {
      const caseType = getRandomInt(0, 2);
      if (caseType === 0) {
        return text.replace(/[0-9]/g, s => String.fromCharCode(s.charCodeAt(0) + 0xFEE0));
      } else if (caseType === 1) {
        return text.replace(/-/g, "");
      } else {
        return "  " + text + "  ";
      }
    } else if (type === "email") {
      const caseType = getRandomInt(0, 2);
      if (caseType === 0) {
        return text.replace("@", "＠");
      } else if (caseType === 1) {
        return text.replace(/\.com|\.jp|\.net/g, "");
      } else {
        return text + "<script>alert(1)</script>";
      }
    } else if (type === "company") {
      const caseType = getRandomInt(0, 1);
      if (caseType === 0) {
        return text.replace("株式会社", "㍿").replace("合同会社", "㈲");
      } else {
        return "超巨大グローバルマルチメディアエンターテインメントテクノロジーソリューションズ株式会社";
      }
    }

    return text;
  }

  // items: {name, kana, address, tel, email, company, text, edgeCase} booleans
  function generateOneRecord(items) {
    items = items || {};
    const record = {};

    const isMan = Math.random() > 0.5;
    const namePool = isMan ? MEN_NAMES : WOMEN_NAMES;
    const chosenNameObj = getRandomEl(namePool);

    const surnameIdx = getRandomInt(0, SURNAMES.length - 1);
    const surname = SURNAMES[surnameIdx];
    const surnameKana = SURNAME_KANAS[surnameIdx];
    const surnameRomaji = SURNAME_ROMAJIS[surnameIdx];

    const edgeCase = !!items.edgeCase;

    if (items.name) {
      record.name = applyEdgeCase(`${surname} ${chosenNameObj.kanji}`, "name", edgeCase);
    }

    if (items.kana) {
      record.kana = applyEdgeCase(`${surnameKana} ${chosenNameObj.kana}`, "kana", edgeCase);
    }

    if (items.address) {
      const prefObj = getRandomEl(PREFECTURES);
      const cities = CITIES[prefObj.name];
      const city = getRandomEl(cities);
      const town = getRandomEl(TOWNS);
      const block = `${getRandomInt(1, 8)}-${getRandomInt(1, 20)}-${getRandomInt(1, 15)}`;
      const building = getRandomEl(BUILDINGS);

      const postal4 = getRandomInt(1000, 9999);

      record.zip = `${prefObj.code}-${postal4}`; // Approximate zip code (not a real postal lookup)
      record.address = applyEdgeCase(`${prefObj.name}${city}${town}${block} ${building}`, "address", edgeCase);
    }

    if (items.tel) {
      const isMobile = Math.random() > 0.4;
      let rawTel = "";
      if (isMobile) {
        const prefix = getRandomEl(["090", "080", "070"]);
        rawTel = `${prefix}-${getRandomInt(1000, 9999)}-${getRandomInt(1000, 9999)}`;
      } else {
        const areaCode = getRandomEl(["03", "06", "052", "092"]);
        rawTel = `${areaCode}-${getRandomInt(100, 9999)}-${getRandomInt(1000, 9999)}`;
      }
      record.tel = applyEdgeCase(rawTel, "tel", edgeCase);
    }

    if (items.email) {
      const domain = getRandomEl(["example.com", "wabisabi.jp", "test-mail.co.jp", "demo-data.net"]);
      const rawEmail = `${chosenNameObj.romaji}.${surnameRomaji}${getRandomInt(10, 99)}@${domain}`;
      record.email = applyEdgeCase(rawEmail, "email", edgeCase);
    }

    if (items.company) {
      const baseName = getRandomEl(COMPANY_NAMES);
      const isPrefix = Math.random() > 0.4;
      let rawCompany = "";
      if (isPrefix) {
        const prefix = getRandomEl(COMPANY_PREFIXES);
        rawCompany = `${prefix}${baseName}`;
      } else {
        const suffix = getRandomEl(COMPANY_SUFFIXES);
        rawCompany = `${baseName}${suffix}`;
      }
      record.company = applyEdgeCase(rawCompany, "company", edgeCase);
    }

    if (items.text) {
      // "長文" なので短すぎないよう、常に複数文・かつ重複の少ない構成にする
      const sentencesCount = getRandomInt(4, 7);
      const pool = DUMMY_LOREM_PHRASES.slice();
      const chosenPhrases = [];
      for (let i = 0; i < sentencesCount; i++) {
        if (pool.length === 0) pool.push(...DUMMY_LOREM_PHRASES);
        const idx = getRandomInt(0, pool.length - 1);
        chosenPhrases.push(pool.splice(idx, 1)[0]);
      }
      record.description = chosenPhrases.join(" ");
    }

    return record;
  }

  window.WabiDataGen = {
    PREFECTURES,
    generateOneRecord,
    getRandomInt,
    getRandomEl
  };
})();
