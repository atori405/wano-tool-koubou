// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 720);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window&tabId=" + tabs[0].id),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 720,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// popup.js - Japanese Test Data Generator Core

document.addEventListener("DOMContentLoaded", () => {
  // --- 1. Japanese dummy dictionaries live in data-generator.js (shared with content.js) ---

  // --- 2. Element Selectors ---
  const checkName = document.getElementById("check-name");
  const checkKana = document.getElementById("check-kana");
  const checkAddress = document.getElementById("check-address");
  const checkTel = document.getElementById("check-tel");
  const checkEmail = document.getElementById("check-email");
  const checkCompany = document.getElementById("check-company");
  const checkText = document.getElementById("check-text");
  const checkEdgeCase = document.getElementById("check-edge-case");
  
  const rangeCount = document.getElementById("range-count");
  const inputCount = document.getElementById("input-count");
  const selectFormat = document.getElementById("select-format");
  const btnGenerate = document.getElementById("btn-generate");
  
  const previewSection = document.getElementById("preview-section");
  const dataPreview = document.getElementById("data-preview");
  const btnCopy = document.getElementById("btn-copy");
  const btnDownload = document.getElementById("btn-download");
  const btnFillForm = document.getElementById("btn-fill-form");
  const toast = document.getElementById("wabi-toast");

  function showToast(message) {
    toast.textContent = message;
    toast.classList.add("show");
    setTimeout(() => toast.classList.remove("show"), 1800);
  }

  // --- Fill the active page's form fields via content.js ---
  btnFillForm.addEventListener("click", () => {
    if (!(window.chrome && chrome.tabs)) return;

    const urlParams = new URLSearchParams(window.location.search);
    const explicitTabId = urlParams.get("tabId");

    function sendFillMessage(tabId) {
      chrome.tabs.sendMessage(tabId, { action: "fillForm" }, (response) => {
        if (chrome.runtime.lastError) {
          showToast("このページでは自動入力を実行できませんでした");
          return;
        }
        if (response && typeof response.count === "number") {
          showToast(response.count > 0
            ? `${response.count}件のフォーム項目に自動入力しました`
            : "自動入力できるフォーム項目が見つかりませんでした");
        }
      });
    }

    if (explicitTabId) {
      // Standalone popup window (mode=window) is its own window, so
      // currentWindow-based queries would resolve to itself, not the original page.
      chrome.tabs.get(parseInt(explicitTabId, 10), (tab) => {
        if (chrome.runtime.lastError || !tab) return;
        sendFillMessage(tab.id);
      });
    } else {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0] && tabs[0].id) sendFillMessage(tabs[0].id);
      });
    }
  });

  let currentGeneratedData = []; // Store raw array for export

  // --- 3. Configuration Save/Load ---
  function loadConfig() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.get(["genCount", "genFormat", "genItems"], (result) => {
        if (result.genCount !== undefined) {
          inputCount.value = result.genCount;
          rangeCount.value = Math.min(result.genCount, 100);
        }
        if (result.genFormat) {
          selectFormat.value = result.genFormat;
        }
        if (result.genItems) {
          checkName.checked = !!result.genItems.name;
          checkKana.checked = !!result.genItems.kana;
          checkAddress.checked = !!result.genItems.address;
          checkTel.checked = !!result.genItems.tel;
          checkEmail.checked = !!result.genItems.email;
          checkCompany.checked = !!result.genItems.company;
          checkText.checked = !!result.genItems.text;
          checkEdgeCase.checked = !!result.genItems.edgeCase;
        }
      });
    }
  }

  function saveConfig() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.set({
        genCount: parseInt(inputCount.value) || 10,
        genFormat: selectFormat.value,
        genItems: {
          name: checkName.checked,
          kana: checkKana.checked,
          address: checkAddress.checked,
          tel: checkTel.checked,
          email: checkEmail.checked,
          company: checkCompany.checked,
          text: checkText.checked,
          edgeCase: checkEdgeCase.checked
        }
      });
    }
  }

  // --- 4. Record Generation (delegates to shared data-generator.js) ---
  function generateOneRecord() {
    return window.WabiDataGen.generateOneRecord({
      name: checkName.checked,
      kana: checkKana.checked,
      address: checkAddress.checked,
      tel: checkTel.checked,
      email: checkEmail.checked,
      company: checkCompany.checked,
      text: checkText.checked,
      edgeCase: checkEdgeCase.checked
    });
  }

  // --- 5. Data Serializers ---
  function convertToCSV(dataArr, delimiter) {
    if (dataArr.length === 0) return "";
    
    const headers = Object.keys(dataArr[0]);
    const lines = [];
    
    // Header line
    lines.push(headers.join(delimiter));
    
    // Values
    dataArr.forEach(row => {
      const values = headers.map(header => {
        let val = row[header] || "";
        // Escape double quotes and surround with quotes
        val = val.toString().replace(/"/g, '""');
        return `"${val}"`;
      });
      lines.push(values.join(delimiter));
    });
    
    return lines.join("\r\n");
  }

  function serializeData(dataArr, format) {
    if (format === "json") {
      return JSON.stringify(dataArr, null, 2);
    } else if (format === "csv") {
      return convertToCSV(dataArr, ",");
    } else if (format === "tsv") {
      return convertToCSV(dataArr, "\t");
    }
    return "";
  }

  // --- 6. Generation Action Trigger ---
  btnGenerate.addEventListener("click", () => {
    const count = parseInt(inputCount.value) || 10;
    const format = selectFormat.value;

    // Check if at least one checkbox is checked
    const anyChecked = checkName.checked || checkKana.checked || checkAddress.checked || 
                       checkTel.checked || checkEmail.checked || checkCompany.checked || checkText.checked;
    
    if (!anyChecked) {
      alert("出力する項目を少なくとも1つ選択してください。");
      return;
    }

    // Generate records
    const records = [];
    for (let i = 0; i < count; i++) {
      records.push(generateOneRecord());
    }

    currentGeneratedData = records;

    // Serialize & Display
    const serialized = serializeData(records, format);
    dataPreview.textContent = serialized;
    
    // Unhide preview box
    previewSection.style.display = "flex";

    // Set download button extensions mapping
    if (format === "json") {
      btnDownload.innerHTML = `<span>📥</span> ファイル保存 (.json)`;
    } else if (format === "csv") {
      btnDownload.innerHTML = `<span>📥</span> ファイル保存 (.csv)`;
    } else if (format === "tsv") {
      btnDownload.innerHTML = `<span>📥</span> ファイル保存 (.tsv)`;
    }

    saveConfig();
  });

  // --- 7. Copy Action ---
  btnCopy.addEventListener("click", () => {
    const text = dataPreview.textContent;
    navigator.clipboard.writeText(text).then(() => {
      // Show toast
      toast.textContent = "データをクリップボードにコピーしました";
      toast.classList.add("show");
      setTimeout(() => {
        toast.classList.remove("show");
      }, 1500);

      // Simple feedback
      const prevText = btnCopy.innerHTML;
      btnCopy.innerHTML = "<span>✅</span> コピー完了";
      btnCopy.classList.add("success");
      setTimeout(() => {
        btnCopy.innerHTML = prevText;
        btnCopy.classList.remove("success");
      }, 1500);
    });
  });

  // --- 8. File Downloader ---
  btnDownload.addEventListener("click", () => {
    const format = selectFormat.value;
    const content = dataPreview.textContent;
    
    let mimeType = "application/json";
    let filename = "test-data.json";

    if (format === "csv") {
      mimeType = "text/csv";
      filename = "test-data.csv";
    } else if (format === "tsv") {
      mimeType = "text/tab-separated-values";
      filename = "test-data.tsv";
    }

    const blob = new Blob([content], { type: `${mimeType};charset=utf-8;` });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", filename);
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    // Show toast
    toast.textContent = `${filename} を保存しました`;
    toast.classList.add("show");
    setTimeout(() => {
      toast.classList.remove("show");
    }, 1500);
  });

  // Range count slider and input number synchronization
  rangeCount.addEventListener("input", () => {
    inputCount.value = rangeCount.value;
    saveConfig();
  });

  inputCount.addEventListener("input", () => {
    let val = parseInt(inputCount.value);
    if (isNaN(val) || val < 1) val = 1;
    if (val > 1000) val = 1000;
    inputCount.value = val;
    rangeCount.value = Math.min(val, 100);
    saveConfig();
  });

  selectFormat.addEventListener("change", () => {
    // If preview is active, re-serialize immediately for better usability
    if (currentGeneratedData.length > 0) {
      const format = selectFormat.value;
      const serialized = serializeData(currentGeneratedData, format);
      dataPreview.textContent = serialized;

      if (format === "json") {
        btnDownload.innerHTML = `<span>📥</span> ファイル保存 (.json)`;
      } else if (format === "csv") {
        btnDownload.innerHTML = `<span>📥</span> ファイル保存 (.csv)`;
      } else if (format === "tsv") {
        btnDownload.innerHTML = `<span>📥</span> ファイル保存 (.tsv)`;
      }
    }
    saveConfig();
  });

  // Quick Presets Event Handlers
  document.querySelectorAll(".wabi-mini-preset-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const preset = btn.getAttribute("data-preset");
      if (preset === "users") {
        rangeCount.value = 15;
        inputCount.value = 15;
        selectFormat.value = "json";
        checkName.checked = true;
        checkKana.checked = true;
        checkAddress.checked = false;
        checkTel.checked = true;
        checkEmail.checked = true;
        checkCompany.checked = false;
        checkText.checked = false;
        checkEdgeCase.checked = false;
      } else if (preset === "labels") {
        rangeCount.value = 5;
        inputCount.value = 5;
        selectFormat.value = "csv";
        checkName.checked = true;
        checkKana.checked = false;
        checkAddress.checked = true;
        checkTel.checked = true;
        checkEmail.checked = false;
        checkCompany.checked = false;
        checkText.checked = false;
        checkEdgeCase.checked = false;
      } else if (preset === "lorem") {
        rangeCount.value = 3;
        inputCount.value = 3;
        selectFormat.value = "json";
        checkName.checked = true;
        checkKana.checked = false;
        checkAddress.checked = false;
        checkTel.checked = false;
        checkEmail.checked = false;
        checkCompany.checked = true;
        checkText.checked = true;
        checkEdgeCase.checked = false;
      }
      saveConfig();
      btnGenerate.click(); // Automatically trigger data generation for instant preview!
    });
  });

  // Checkbox config change auto-save
  [checkName, checkKana, checkAddress, checkTel, checkEmail, checkCompany, checkText, checkEdgeCase].forEach(chk => {
    chk.addEventListener("change", saveConfig);
  });

  // Init
  loadConfig();
});
