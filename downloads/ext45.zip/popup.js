



// popup.js - Japanese Test Data Generator Core

document.addEventListener("DOMContentLoaded", () => {
  // --- 1. Japanese Dummy Dictionaries ---
  const SURNAMES = [
    "佐藤", "鈴木", "高橋", "田中", "伊藤", "渡辺", "山本", "中村", "小林", "加藤", 
    "吉田", "山田", "佐々木", "山口", "松本", "井上", "木村", "林", "斎藤", "清水", 
    "山崎", "森", "池田", "橋本", "阿部", "石川", "山下", "中島", "石井", "小川", 
    "前田", "岡田", "長谷川", "近藤", "後藤", "飯田", "北村", "関", "荒木", "松井", 
    "三浦", "中野", "柴田", "原", "宮崎", "杉山", "上野", "野口", "小島", "藤田"
  ];

  const SURNAME_KANAS = [
    "さとう", "すずき", "たかはし", "たなか", "いとう", "わたなべ", "やまもと", "なかむら", "こばやし", "かとう",
    "よしだ", "やまだ", "ささき", "やまぐち", "まつもと", "いのうえ", "きむら", "はやし", "さいとう", "しみず",
    "やまざき", "もり", "いけだ", "hashimoto", "あべ", "いしかわ", "yamashita", "なかじま", "いしい", "おがわ",
    "まえだ", "おかだ", "はせがわ", "こんどう", "ごとう", "いいだ", "きたむら", "せき", "あらき", "まつい",
    "みうら", "なかの", "しばた", "はら", "みやざき", "すぎやま", "うえの", "のぐち", "こじま", "ふじた"
  ];

  const SURNAME_ROMAJIS = [
    "sato", "suzuki", "takahashi", "tanaka", "ito", "watanabe", "yamamoto", "nakamura", "kobayashi", "kato",
    "yoshida", "yamada", "sasaki", "yamaguchi", "matsumoto", "inoue", "kimura", "hayashi", "saito", "shimizu",
    "yamazaki", "mori", "ikeda", "hashimoto", "abe", "ishikawa", "yamashita", "nakajima", "ishii", "ogawa",
    "maeda", "okada", "hasegawa", "kondo", "goto", "iida", "kitamura", "seki", "araki", "matsui",
    "miura", "nakano", "shibata", "hara", "miyazaki", "sugiyama", "ueno", "noguchi", "kojima", "fujita"
  ];

  const MEN_NAMES = [
    { kanji: "大翔", kana: "ひろと", romaji: "hiroto" },
    { kanji: "蓮", kana: "れん", romaji: "ren" },
    { kanji: "颯太", kana: "そうた", romaji: "sota" },
    { kanji: "陽翔", kana: "はると", romaji: "haruto" },
    { kanji: "悠真", kana: "ゆうま", romaji: "yuma" },
    { kanji: "大和", kana: "やまと", romaji: "yamato" },
    { kanji: "翔", kana: "かける", romaji: "kakeru" },
    { kanji: "陽太", kana: "ひなた", romaji: "hinata" },
    { kanji: "拓海", kana: "たくみ", romaji: "takumi" },
    { kanji: "陸", kana: "りく", romaji: "riku" },
    { kanji: "駿", kana: "しゅん", romaji: "shun" },
    { kanji: "健太", kana: "けんた", romaji: "kenta" },
    { kanji: "翼", kana: "つばさ", romaji: "tsubasa" },
    { kanji: "優太", kana: "ゆうた", romaji: "yuta" },
    { kanji: "太陽", kana: "たいよう", romaji: "taiyo" },
    { kanji: "海斗", kana: "かいと", romaji: "kaito" },
    { kanji: "大介", kana: "だいすけ", romaji: "daisuke" },
    { kanji: "翔太", kana: "しょうた", romaji: "shota" },
    { kanji: "太一", kana: "たいち", romaji: "taichi" },
    { kanji: "哲也", kana: "てつや", romaji: "tetsuya" },
    { kanji: "和也", kana: "かずや", romaji: "kazuya" },
    { kanji: "洋平", kana: "ようへい", romaji: "yohei" },
    { kanji: "直樹", kana: "なおき", romaji: "naoki" },
    { kanji: "真司", kana: "しんじ", romaji: "shinji" },
    { kanji: "康平", kana: "こうへい", romaji: "kohei" },
    { kanji: "達也", kana: "たつや", romaji: "tatsuya" },
    { kanji: "雄大", kana: "ゆうだい", romaji: "yudai" },
    { kanji: "一郎", kana: "いちろう", romaji: "ichiro" },
    { kanji: "健", kana: "けん", romaji: "ken" },
    { kanji: "大輝", kana: "だいき", romaji: "daiki" }
  ];

  const WOMEN_NAMES = [
    { kanji: "陽菜", kana: "ひな", romaji: "hina" },
    { kanji: "結愛", kana: "ゆあ", romaji: "yua" },
    { kanji: "莉子", kana: "りこ", romaji: "riko" },
    { kanji: "芽依", kana: "めい", romaji: "mei" },
    { kanji: "葵", kana: "あおい", romaji: "aoi" },
    { kanji: "結衣", kana: "ゆい", romaji: "yui" },
    { kanji: "咲良", kana: "さくら", romaji: "sakura" },
    { kanji: "美月", kana: "みつき", romaji: "mitsuki" },
    { kanji: "心春", kana: "こはる", romaji: "koharu" },
    { kanji: "愛菜", kana: "まな", romaji: "mana" },
    { kanji: "七海", kana: "ななみ", romaji: "nanami" },
    { kanji: "美優", kana: "みゆう", romaji: "miyu" },
    { kanji: "優花", kana: "ゆうか", romaji: "yuka" },
    { kanji: "杏", kana: "あん", romaji: "an" },
    { kanji: "美結", kana: "みゆ", romaji: "miyu" },
    { kanji: "結菜", kana: "ゆいな", romaji: "yuina" },
    { kanji: "結月", kana: "ゆづき", romaji: "yuzuki" },
    { kanji: "朱莉", kana: "あかり", romaji: "akari" },
    { kanji: "桃花", kana: "ももか", romaji: "momoka" },
    { kanji: "千尋", kana: "ちひろ", romaji: "chihiro" },
    { kanji: "麻衣", kana: "まい", romaji: "mai" },
    { kanji: "彩香", kana: "あやか", romaji: "ayaka" },
    { kanji: "理沙", kana: "りさ", romaji: "risa" },
    { kanji: "瞳", kana: "ひとみ", romaji: "hitomi" },
    { kanji: "恵", kana: "めぐみ", romaji: "megumi" },
    { kanji: "奈々", kana: "なな", romaji: "nana" },
    { kanji: "未来", kana: "みく", romaji: "miku" },
    { kanji: "晴香", kana: "はるか", romaji: "haruka" },
    { kanji: "花", kana: "はな", romaji: "hana" },
    { kanji: "真央", kana: "まお", romaji: "mao" }
  ];

  const PREFECTURES = [
    { name: "東京都", code: "100" },
    { name: "神奈川県", code: "220" },
    { name: "大阪府", code: "530" },
    { name: "愛知県", code: "460" },
    { name: "埼玉県", code: "330" },
    { name: "千葉県", code: "260" },
    { name: "兵庫県", code: "650" },
    { name: "北海道", code: "060" },
    { name: "福岡県", code: "810" },
    { name: "京都府", code: "600" },
    { name: "宮城県", code: "980" },
    { name: "広島県", code: "730" }
  ];

  const CITIES = {
    "東京都": ["新宿区", "渋谷区", "港区", "千代田区", "中央区", "目黒区", "品川区", "世田谷区", "文京区", "武蔵野市"],
    "神奈川県": ["横浜市中区", "横浜市西区", "横浜市港北区", "川崎市中原区", "川崎市高津区", "鎌倉市", "藤沢市"],
    "大阪府": ["大阪市北区", "大阪市中央区", "大阪市西区", "吹田市", "豊中市", "堺市北区", "高槻市"],
    "愛知県": ["名古屋市中区", "名古屋市中村区", "名古屋市千種区", "豊田市", "岡崎市", "一宮市"],
    "埼玉県": ["さいたま市大宮区", "さいたま市浦和区", "川越市", "所沢市", "越谷市"],
    "千葉県": ["千葉市中央区", "船橋市", "松戸市", "市川市", "浦安市"],
    "兵庫県": ["神戸市中央区", "神戸市東灘区", "西宮市", "尼崎市", "姫路市"],
    "北海道": ["札幌市中央区", "札幌市北区", "小樽市", "旭川市", "函館市"],
    "福岡県": ["福岡市博多区", "福岡市中央区", "福岡市早良区", "北九州市小倉北区", "久留米市"],
    "京都府": ["京都市中京区", "京都市下京区", "京都市左京区", "宇治市"],
    "宮城県": ["仙台市青葉区", "仙台市宮城野区", "石巻市", "大崎市"],
    "広島県": ["広島市中区", "広島市南区", "福山市", "呉市"]
  };

  const TOWNS = [
    "本町", "栄町", "旭町", "新町", "緑町", "南町", "北町", "東町", "西宿", "桜ヶ丘", 
    "高砂", "平和台", "大手町", "西新宿", "元町", "海岸通", "美咲が丘", "泉町", "山手町"
  ];

  const BUILDINGS = [
    "和沙レジデンス 302号室", "雅ガーデンヒルズ 501", "山吹荘 2号室", "セゾン西新宿 1004", 
    "グランハイツ港町 201", "青海波タワー 32階", "萌黄コーポ 102", "エステート白木 403",
    "藤紫コート 1102", "藍墨ビルディング 8F", "日の出マンション 505", "メゾン・ド・匠 103"
  ];

  const COMPANY_PREFIXES = ["株式会社", "合同会社", "有限会社"];
  const COMPANY_SUFFIXES = ["システムズ", "テクノロジー", "ソリューションズ", "テック", "フーズ", "開発"];
  const COMPANY_NAMES = ["和沙", "山吹", "青海波", "萌黄", "大和", "扶桑", "ミヤビ", "ツムギ", "匠", "流星", "双葉", "日向"];

  const DUMMY_LOREM_PHRASES = [
    "吾輩は猫である。名前はまだ無い。どこで生れたかとんと見当がつかぬ。",
    "親譲りの無鉄砲で小供の時から損ばかりしている。",
    "メロスは激怒した。必ず、かの邪智暴虐の王を除かなければならぬと決意した。",
    "国境の長いトンネルを抜けると雪国であった。夜の底が白くなった。",
    "祇園精舎の鐘の声、諸行無常の響きあり。沙羅双樹の花の色、盛者必衰の理をあらわす。",
    "静かに開いた扉の向こうには、かつて見たこともないほど澄み切った青い空が広がっていた。",
    "昨日の課題を今日に持ち越さず、一歩ずつ確実なコードを積み重ねることこそが、エンジニアの美徳である。",
    "テストデータは正確で美しくあるべきだ。それがシステムの堅牢性を測る最初の鏡となるのだから。",
    "川のせせらぎを聞きながら、緑豊かな日本の白木机に向かってコーディングする時間は、格別の贅沢である。",
    "山吹色の夕日が沈む頃、開発室のモニターには成功を示すグリーンのテストログが流れていた。",
    "初心を忘れず、常にユーザーの立場になってプロダクトを磨き上げる姿勢が、素晴らしい体験を生み出す鍵となる。",
    "古池や蛙飛びこむ水の音。静寂の中に響くその一瞬の波紋のように、小さな改善が大きなインパクトを生む。"
  ];

  // --- 2. Element Selectors ---
  const checkName = document.getElementById("check-name");
  const checkKana = document.getElementById("check-kana");
  const checkAddress = document.getElementById("check-address");
  const checkTel = document.getElementById("check-tel");
  const checkEmail = document.getElementById("check-email");
  const checkCompany = document.getElementById("check-company");
  const checkText = document.getElementById("check-text");
  const checkEdgeCase = document.getElementById("check-edge-case");
  
  const rangeCount = document.getElementById("range-count");
  const inputCount = document.getElementById("input-count");
  const selectFormat = document.getElementById("select-format");
  const btnGenerate = document.getElementById("btn-generate");
  
  const previewSection = document.getElementById("preview-section");
  const dataPreview = document.getElementById("data-preview");
  const btnCopy = document.getElementById("btn-copy");
  const btnDownload = document.getElementById("btn-download");
  const toast = document.getElementById("wabi-toast");

  let currentGeneratedData = []; // Store raw array for export

  // --- 3. Configuration Save/Load ---
  function loadConfig() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.get(["genCount", "genFormat", "genItems"], (result) => {
        if (result.genCount !== undefined) {
          inputCount.value = result.genCount;
          rangeCount.value = Math.min(result.genCount, 100);
        }
        if (result.genFormat) {
          selectFormat.value = result.genFormat;
        }
        if (result.genItems) {
          checkName.checked = !!result.genItems.name;
          checkKana.checked = !!result.genItems.kana;
          checkAddress.checked = !!result.genItems.address;
          checkTel.checked = !!result.genItems.tel;
          checkEmail.checked = !!result.genItems.email;
          checkCompany.checked = !!result.genItems.company;
          checkText.checked = !!result.genItems.text;
          checkEdgeCase.checked = !!result.genItems.edgeCase;
        }
      });
    }
  }

  function saveConfig() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.set({
        genCount: parseInt(inputCount.value) || 10,
        genFormat: selectFormat.value,
        genItems: {
          name: checkName.checked,
          kana: checkKana.checked,
          address: checkAddress.checked,
          tel: checkTel.checked,
          email: checkEmail.checked,
          company: checkCompany.checked,
          text: checkText.checked,
          edgeCase: checkEdgeCase.checked
        }
      });
    }
  }

  // --- 4. Mock Helpers ---
  function getRandomEl(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  // Edge-case injection helper (abnormal validation data)
  function applyEdgeCase(text, type) {
    if (!checkEdgeCase.checked) return text;
    
    const r = Math.random();
    if (r > 0.45) return text; // 45% probability to inject edge case
    
    if (type === "name") {
      const caseType = getRandomInt(0, 3);
      if (caseType === 0) {
        return text.replace("佐藤", "髙橋").replace("鈴木", "﨑田");
      } else if (caseType === 1) {
        return "ﾀﾛｳ " + text;
      } else if (caseType === 2) {
        return text + " １２３";
      } else {
        return text + " ㈱";
      }
    } else if (type === "kana") {
      const caseType = getRandomInt(0, 1);
      if (caseType === 0) {
        return text.replace("さとう", "ｻﾄｳ").replace("すずき", "ｽｽﾞｷ");
      } else {
        return text + " （かぶ）";
      }
    } else if (type === "address") {
      const caseType = getRandomInt(0, 2);
      if (caseType === 0) {
        return text.replace(/-/g, "－");
      } else if (caseType === 1) {
        return text.replace("302号室", "①0②号室").replace("501", "⑤〇①");
      } else {
        return text.replace(/[0-9]/g, s => String.fromCharCode(s.charCodeAt(0) + 0xFEE0));
      }
    } else if (type === "tel") {
      const caseType = getRandomInt(0, 2);
      if (caseType === 0) {
        return text.replace(/[0-9]/g, s => String.fromCharCode(s.charCodeAt(0) + 0xFEE0));
      } else if (caseType === 1) {
        return text.replace(/-/g, "");
      } else {
        return "  " + text + "  ";
      }
    } else if (type === "email") {
      const caseType = getRandomInt(0, 2);
      if (caseType === 0) {
        return text.replace("@", "＠");
      } else if (caseType === 1) {
        return text.replace(/\.com|\.jp|\.net/g, "");
      } else {
        return text + "<script>alert(1)</script>";
      }
    } else if (type === "company") {
      const caseType = getRandomInt(0, 1);
      if (caseType === 0) {
        return text.replace("株式会社", "㍿").replace("合同会社", "㈲");
      } else {
        return "超巨大グローバルマルチメディアエンターテインメントテクノロジーソリューションズ株式会社";
      }
    }
    
    return text;
  }

  function generateOneRecord() {
    const record = {};
    
    // Choose gender randomly
    const isMan = Math.random() > 0.5;
    const namePool = isMan ? MEN_NAMES : WOMEN_NAMES;
    const chosenNameObj = getRandomEl(namePool);
    
    // Pick surname
    const surnameIdx = getRandomInt(0, SURNAMES.length - 1);
    const surname = SURNAMES[surnameIdx];
    const surnameKana = SURNAME_KANAS[surnameIdx];
    const surnameRomaji = SURNAME_ROMAJIS[surnameIdx];

    // 1. Name
    if (checkName.checked) {
      record.name = applyEdgeCase(`${surname} ${chosenNameObj.kanji}`, "name");
    }

    // 2. Kana
    if (checkKana.checked) {
      record.kana = applyEdgeCase(`${surnameKana} ${chosenNameObj.kana}`, "kana");
    }

    // 3. Address (Japanese format)
    if (checkAddress.checked) {
      const prefObj = getRandomEl(PREFECTURES);
      const cities = CITIES[prefObj.name];
      const city = getRandomEl(cities);
      const town = getRandomEl(TOWNS);
      const block = `${getRandomInt(1, 8)}-${getRandomInt(1, 20)}-${getRandomInt(1, 15)}`;
      const building = getRandomEl(BUILDINGS);
      
      const postal3 = getRandomInt(100, 999);
      const postal4 = getRandomInt(1000, 9999);
      
      record.zip = `${prefObj.code}-${postal4}`; // Approximate zip code
      record.address = applyEdgeCase(`${prefObj.name}${city}${town}${block} ${building}`, "address");
    }

    // 4. Telephone
    if (checkTel.checked) {
      const isMobile = Math.random() > 0.4;
      let rawTel = "";
      if (isMobile) {
        const prefix = getRandomEl(["090", "080", "070"]);
        rawTel = `${prefix}-${getRandomInt(1000, 9999)}-${getRandomInt(1000, 9999)}`;
      } else {
        const areaCode = getRandomEl(["03", "06", "052", "092"]);
        rawTel = `${areaCode}-${getRandomInt(100, 9999)}-${getRandomInt(1000, 9999)}`;
      }
      record.tel = applyEdgeCase(rawTel, "tel");
    }

    // 5. Email
    if (checkEmail.checked) {
      const domain = getRandomEl(["example.com", "wabisabi.jp", "test-mail.co.jp", "demo-data.net"]);
      const rawEmail = `${chosenNameObj.romaji}.${surnameRomaji}${getRandomInt(10, 99)}@${domain}`;
      record.email = applyEdgeCase(rawEmail, "email");
    }

    // 6. Company
    if (checkCompany.checked) {
      const baseName = getRandomEl(COMPANY_NAMES);
      const isPrefix = Math.random() > 0.4;
      let rawCompany = "";
      if (isPrefix) {
        const prefix = getRandomEl(COMPANY_PREFIXES);
        rawCompany = `${prefix}${baseName}`;
      } else {
        const suffix = getRandomEl(COMPANY_SUFFIXES);
        rawCompany = `${baseName}${suffix}`;
      }
      record.company = applyEdgeCase(rawCompany, "company");
    }

    // 7. Long text (Lorem Ipsum JP)
    if (checkText.checked) {
      const sentencesCount = getRandomInt(1, 3);
      const chosenPhrases = [];
      for (let i = 0; i < sentencesCount; i++) {
        chosenPhrases.push(getRandomEl(DUMMY_LOREM_PHRASES));
      }
      record.description = chosenPhrases.join(" ");
    }

    return record;
  }

  // --- 5. Data Serializers ---
  function convertToCSV(dataArr, delimiter) {
    if (dataArr.length === 0) return "";
    
    const headers = Object.keys(dataArr[0]);
    const lines = [];
    
    // Header line
    lines.push(headers.join(delimiter));
    
    // Values
    dataArr.forEach(row => {
      const values = headers.map(header => {
        let val = row[header] || "";
        // Escape double quotes and surround with quotes
        val = val.toString().replace(/"/g, '""');
        return `"${val}"`;
      });
      lines.push(values.join(delimiter));
    });
    
    return lines.join("\r\n");
  }

  function serializeData(dataArr, format) {
    if (format === "json") {
      return JSON.stringify(dataArr, null, 2);
    } else if (format === "csv") {
      return convertToCSV(dataArr, ",");
    } else if (format === "tsv") {
      return convertToCSV(dataArr, "\t");
    }
    return "";
  }

  // --- 6. Generation Action Trigger ---
  btnGenerate.addEventListener("click", () => {
    const count = parseInt(inputCount.value) || 10;
    const format = selectFormat.value;

    // Check if at least one checkbox is checked
    const anyChecked = checkName.checked || checkKana.checked || checkAddress.checked || 
                       checkTel.checked || checkEmail.checked || checkCompany.checked || checkText.checked;
    
    if (!anyChecked) {
      alert("出力する項目を少なくとも1つ選択してください。");
      return;
    }

    // Generate records
    const records = [];
    for (let i = 0; i < count; i++) {
      records.push(generateOneRecord());
    }

    currentGeneratedData = records;

    // Serialize & Display
    const serialized = serializeData(records, format);
    dataPreview.textContent = serialized;
    
    // Unhide preview box
    previewSection.style.display = "flex";

    // Set download button extensions mapping
    if (format === "json") {
      btnDownload.innerHTML = `<span>📥</span> ファイル保存 (.json)`;
    } else if (format === "csv") {
      btnDownload.innerHTML = `<span>📥</span> ファイル保存 (.csv)`;
    } else if (format === "tsv") {
      btnDownload.innerHTML = `<span>📥</span> ファイル保存 (.tsv)`;
    }

    saveConfig();
  });

  // --- 7. Copy Action ---
  btnCopy.addEventListener("click", () => {
    const text = dataPreview.textContent;
    navigator.clipboard.writeText(text).then(() => {
      // Show toast
      toast.textContent = "データをクリップボードにコピーしました";
      toast.classList.add("show");
      setTimeout(() => {
        toast.classList.remove("show");
      }, 1500);

      // Simple feedback
      const prevText = btnCopy.innerHTML;
      btnCopy.innerHTML = "<span>✅</span> コピー完了";
      btnCopy.classList.add("success");
      setTimeout(() => {
        btnCopy.innerHTML = prevText;
        btnCopy.classList.remove("success");
      }, 1500);
    });
  });

  // --- 8. File Downloader ---
  btnDownload.addEventListener("click", () => {
    const format = selectFormat.value;
    const content = dataPreview.textContent;
    
    let mimeType = "application/json";
    let filename = "test-data.json";

    if (format === "csv") {
      mimeType = "text/csv";
      filename = "test-data.csv";
    } else if (format === "tsv") {
      mimeType = "text/tab-separated-values";
      filename = "test-data.tsv";
    }

    const blob = new Blob([content], { type: `${mimeType};charset=utf-8;` });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", filename);
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    // Show toast
    toast.textContent = `${filename} を保存しました`;
    toast.classList.add("show");
    setTimeout(() => {
      toast.classList.remove("show");
    }, 1500);
  });

  // Range count slider and input number synchronization
  rangeCount.addEventListener("input", () => {
    inputCount.value = rangeCount.value;
    saveConfig();
  });

  inputCount.addEventListener("input", () => {
    let val = parseInt(inputCount.value);
    if (isNaN(val) || val < 1) val = 1;
    if (val > 1000) val = 1000;
    inputCount.value = val;
    rangeCount.value = Math.min(val, 100);
    saveConfig();
  });

  selectFormat.addEventListener("change", () => {
    // If preview is active, re-serialize immediately for better usability
    if (currentGeneratedData.length > 0) {
      const format = selectFormat.value;
      const serialized = serializeData(currentGeneratedData, format);
      dataPreview.textContent = serialized;

      if (format === "json") {
        btnDownload.innerHTML = `<span>📥</span> ファイル保存 (.json)`;
      } else if (format === "csv") {
        btnDownload.innerHTML = `<span>📥</span> ファイル保存 (.csv)`;
      } else if (format === "tsv") {
        btnDownload.innerHTML = `<span>📥</span> ファイル保存 (.tsv)`;
      }
    }
    saveConfig();
  });

  // Quick Presets Event Handlers
  document.querySelectorAll(".wabi-mini-preset-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const preset = btn.getAttribute("data-preset");
      if (preset === "users") {
        rangeCount.value = 15;
        inputCount.value = 15;
        selectFormat.value = "json";
        checkName.checked = true;
        checkKana.checked = true;
        checkAddress.checked = false;
        checkTel.checked = true;
        checkEmail.checked = true;
        checkCompany.checked = false;
        checkText.checked = false;
        checkEdgeCase.checked = false;
      } else if (preset === "labels") {
        rangeCount.value = 5;
        inputCount.value = 5;
        selectFormat.value = "csv";
        checkName.checked = true;
        checkKana.checked = false;
        checkAddress.checked = true;
        checkTel.checked = true;
        checkEmail.checked = false;
        checkCompany.checked = false;
        checkText.checked = false;
        checkEdgeCase.checked = false;
      } else if (preset === "lorem") {
        rangeCount.value = 3;
        inputCount.value = 3;
        selectFormat.value = "json";
        checkName.checked = true;
        checkKana.checked = false;
        checkAddress.checked = false;
        checkTel.checked = false;
        checkEmail.checked = false;
        checkCompany.checked = true;
        checkText.checked = true;
        checkEdgeCase.checked = false;
      }
      saveConfig();
      btnGenerate.click(); // Automatically trigger data generation for instant preview!
    });
  });

  // Checkbox config change auto-save
  [checkName, checkKana, checkAddress, checkTel, checkEmail, checkCompany, checkText, checkEdgeCase].forEach(chk => {
    chk.addEventListener("change", saveConfig);
  });

  // Init
  loadConfig();
});
