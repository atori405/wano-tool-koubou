// background.js - Service Worker for Japanese Test Data Generator

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["genCount", "genFormat", "genItems"], (result) => {
    const updates = {};
    if (result.genCount === undefined) {
      updates.genCount = 10; // Default count is 10
    }
    if (result.genFormat === undefined) {
      updates.genFormat = "json"; // Default format is JSON
    }
    if (result.genItems === undefined) {
      // Default enabled items
      updates.genItems = {
        name: true,
        kana: true,
        address: true,
        tel: true,
        email: true,
        company: false,
        text: false
      };
    }
    if (Object.keys(updates).length > 0) {
      chrome.storage.local.set(updates);
    }
  });
  console.log("日本語テストデータジェネレーター 拡張機能が正常にインストールされました。");
});
