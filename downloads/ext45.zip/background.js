// background.js - Service Worker for Japanese Test Data Generator

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["genCount", "genFormat", "genItems"], (result) => {
    const updates = {};
    if (result.genCount === undefined) {
      updates.genCount = 10; // Default count is 10
    }
    if (result.genFormat === undefined) {
      updates.genFormat = "json"; // Default format is JSON
    }
    if (result.genItems === undefined) {
      // Default enabled items
      updates.genItems = {
        name: true,
        kana: true,
        address: true,
        tel: true,
        email: true,
        company: false,
        text: false
      };
    }
    if (Object.keys(updates).length > 0) {
      chrome.storage.local.set(updates);
    }
  });
  console.log("日本語テストデータジェネレーター 拡張機能が正常にインストールされました。");
});

// Alt+Shift+F ショートカット: 現在のアクティブタブのフォームに自動入力する
chrome.commands.onCommand.addListener((command) => {
  if (command !== "fill-form") return;
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs && tabs[0] && tabs[0].id) {
      chrome.tabs.sendMessage(tabs[0].id, { action: "fillForm" }, () => {
        void chrome.runtime.lastError; // ignore: no content script on this page (e.g. chrome:// pages)
      });
    }
  });
});
