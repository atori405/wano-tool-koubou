// --- Content Script for Selection Slang Translation ---

let selectionTranslationEnabled = true;
let currentFloatingButton = null;
let currentFloatingTooltip = null;

// Initialize state from storage
chrome.storage.local.get({ selection_translation_enabled: true }, (result) => {
  selectionTranslationEnabled = result.selection_translation_enabled;
});

// Listen for updates from popup
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "local" && changes.selection_translation_enabled) {
    selectionTranslationEnabled = changes.selection_translation_enabled.newValue;
    if (!selectionTranslationEnabled) {
      removeFloatingUI();
    }
  }
});

// Event: Text Selection Check
document.addEventListener("mouseup", (e) => {
  if (!selectionTranslationEnabled) return;
  
  // Ignore event if clicking inside our own components to avoid clearing/recreating loops
  const path = e.composedPath();
  const clickedSelf = path.some(el => 
    el.id === "slang-trans-button-host" || 
    el.id === "slang-trans-tooltip-host"
  );
  if (clickedSelf) return;

  // Give it a tiny delay to ensure selection API is updated
  setTimeout(() => {
    handleSelection(e);
  }, 10);
});

// Close UI on click outside
document.addEventListener("mousedown", (e) => {
  // If clicking inside our components, don't dismiss
  const path = e.composedPath();
  const clickedSelf = path.some(el => 
    el.id === "slang-trans-button-host" || 
    el.id === "slang-trans-tooltip-host"
  );
  if (clickedSelf) return;
  
  removeFloatingUI();
});

// Keydown listener for escape
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    removeFloatingUI();
  }
});

function handleSelection(e) {
  const selection = window.getSelection();
  const selectedText = selection.toString().trim().toLowerCase();
  
  if (!selectedText || selectedText.length > 50) {
    return; // Ignore empty or too long selections
  }
  
  // Clean punctuation from selected text for matching
  const cleanedText = selectedText.replace(/^[.,\/#!$%\^&\*;:{}=\-_`~()?"'’]+|[.,\/#!$%\^&\*;:{}=\-_`~()?"'’]+$/g, "");
  
  // Find slang in dictionary (exact match or word contains)
  const matchedSlang = SLANG_DICTIONARY.find(item => {
    return item.word.toLowerCase() === cleanedText || 
           item.word.toLowerCase() === selectedText;
  });
  
  if (!matchedSlang) return;
  
  // Get selection coordinate bounding rect
  if (selection.rangeCount === 0) return;
  const range = selection.getRangeAt(0);
  const rect = range.getBoundingClientRect();
  
  if (rect.width === 0 || rect.height === 0) return;
  
  // Create floating trigger button
  createFloatingButton(rect, matchedSlang);
}

function createFloatingButton(rect, slang) {
  removeFloatingUI(); // clear old ones
  
  const host = document.createElement("div");
  host.id = "slang-trans-button-host";
  host.style.position = "absolute";
  // Shift the button 18px to the left of the center to prevent overlap with standard centered helper tools
  host.style.left = `${window.scrollX + rect.left + rect.width / 2 - 32}px`;
  host.style.top = `${window.scrollY + rect.top - 36}px`;
  host.style.zIndex = "2147483647"; // Absolute maximum z-index priority
  
  // Shadow DOM for style isolation
  const shadow = host.attachShadow({ mode: "open" });
  
  const button = document.createElement("button");
  button.className = "floating-trigger";
  button.innerHTML = `
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
      <path d="M10 8h4"/>
      <path d="M12 8v6"/>
    </svg>
  `;
  
  const style = document.createElement("style");
  style.textContent = `
    .floating-trigger {
      width: 28px;
      height: 28px;
      border-radius: 50%;
      background: linear-gradient(135deg, #c026d3, #db2777);
      border: 2px solid #ffffff;
      color: #ffffff;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 10px rgba(217, 70, 239, 0.4);
      transition: all 0.15s cubic-bezier(0.4, 0, 0.2, 1);
      padding: 5px;
    }
    .floating-trigger:hover {
      transform: scale(1.15);
      box-shadow: 0 6px 14px rgba(217, 70, 239, 0.6);
      background: linear-gradient(135deg, #d946ef, #ec4899);
    }
    .floating-trigger svg {
      width: 100%;
      height: 100%;
    }
  `;
  
  shadow.appendChild(style);
  shadow.appendChild(button);
  document.body.appendChild(host);
  currentFloatingButton = host;
  
  // Stop mousedown/mouseup propagation to prevent other extensions' global listeners from triggering selection clears
  button.addEventListener("mousedown", (e) => {
    e.stopPropagation();
  });
  button.addEventListener("mouseup", (e) => {
    e.stopPropagation();
  });
  
  button.addEventListener("click", (e) => {
    e.stopPropagation();
    e.preventDefault();
    createFloatingTooltip(rect, slang);
    host.remove();
    currentFloatingButton = null;
  });
}

function createFloatingTooltip(rect, slang) {
  removeFloatingUI(); // clear old ones
  
  const host = document.createElement("div");
  host.id = "slang-trans-tooltip-host";
  host.style.position = "absolute";
  host.style.zIndex = "2147483645";
  
  // Positioning: Place below selection, or above if there's no room below
  const tooltipWidth = 320;
  const leftPos = Math.max(10, Math.min(window.innerWidth - tooltipWidth - 20, rect.left + rect.width / 2 - tooltipWidth / 2));
  
  host.style.left = `${window.scrollX + leftPos}px`;
  
  // Decide top pos
  const spaceBelow = window.innerHeight - rect.bottom;
  const tooltipHeight = 220; // approximate
  if (spaceBelow > tooltipHeight + 20) {
    host.style.top = `${window.scrollY + rect.bottom + 10}px`;
  } else {
    host.style.top = `${window.scrollY + rect.top - tooltipHeight - 10}px`;
  }
  
  const shadow = host.attachShadow({ mode: "open" });
  
  const card = document.createElement("div");
  card.className = "tooltip-card";
  card.innerHTML = `
    <div class="header">
      <div class="word-info">
        <span class="word">${slang.word}</span>
        <span class="literal">（直訳: ${slang.literal}）</span>
      </div>
      <button class="close-btn" aria-label="閉じる">×</button>
    </div>
    
    <div class="content">
      <div class="translation-row">
        <span class="label">ネットスラング訳</span>
        <span class="japanese">${slang.japanese}</span>
      </div>
      
      <div class="detail-section">
        <span class="label">意味</span>
        <p class="desc">${slang.meaning}</p>
      </div>

      <div class="detail-section">
        <span class="label">文化的背景・ミーム</span>
        <p class="desc origin-desc">${slang.origin}</p>
      </div>

      <div class="detail-section">
        <span class="label">例文</span>
        <p class="example-en">“${slang.example}”</p>
        <p class="example-jp">（${slang.exampleJp}）</p>
      </div>
    </div>
  `;
  
  const style = document.createElement("style");
  style.textContent = `
    .tooltip-card {
      width: 320px;
      background: rgba(15, 23, 42, 0.95);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(217, 70, 239, 0.4);
      border-radius: 12px;
      color: #f1f5f9;
      font-family: 'Noto Sans JP', sans-serif;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.5), 0 0 15px rgba(217, 70, 239, 0.15);
      overflow: hidden;
      display: flex;
      flex-direction: column;
      animation: zoomIn 0.2s cubic-bezier(0.34, 1.56, 0.64, 1);
    }
    
    @keyframes zoomIn {
      from { transform: scale(0.9); opacity: 0; }
      to { transform: scale(1); opacity: 1; }
    }
    
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: rgba(24, 24, 37, 0.9);
      padding: 10px 14px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    }
    
    .word-info {
      display: flex;
      flex-direction: column;
    }
    
    .word {
      font-size: 15px;
      font-weight: 700;
      color: #d946ef;
    }
    
    .literal {
      font-size: 10px;
      color: #94a3b8;
      margin-top: 1px;
    }
    
    .close-btn {
      background: none;
      border: none;
      color: #94a3b8;
      font-size: 20px;
      cursor: pointer;
      padding: 2px 6px;
      border-radius: 4px;
      transition: all 0.15s;
      line-height: 1;
    }
    
    .close-btn:hover {
      color: #ef4444;
      background: rgba(239, 68, 68, 0.1);
    }
    
    .content {
      padding: 12px 14px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      max-height: 240px;
      overflow-y: auto;
    }
    
    /* Scrollbar */
    .content::-webkit-scrollbar {
      width: 4px;
    }
    .content::-webkit-scrollbar-track {
      background: transparent;
    }
    .content::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.15);
      border-radius: 2px;
    }

    .label {
      font-size: 9px;
      font-weight: 700;
      text-transform: uppercase;
      color: #94a3b8;
      letter-spacing: 0.5px;
      margin-bottom: 2px;
      display: block;
    }
    
    .translation-row {
      background: rgba(217, 70, 239, 0.1);
      border-left: 3px solid #d946ef;
      padding: 6px 10px;
      border-radius: 4px;
    }
    
    .japanese {
      font-size: 13px;
      font-weight: 700;
      color: #d946ef;
    }
    
    .detail-section {
      display: flex;
      flex-direction: column;
    }
    
    .desc {
      font-size: 11px;
      line-height: 1.5;
      color: #e2e8f0;
      margin: 0;
    }
    
    .origin-desc {
      color: #cbd5e1;
    }
    
    .example-en {
      font-size: 11px;
      font-weight: 500;
      color: #38bdf8;
      font-style: italic;
      margin: 0;
    }
    
    .example-jp {
      font-size: 10px;
      color: #94a3b8;
      margin: 2px 0 0 0;
    }
  `;
  
  shadow.appendChild(style);
  shadow.appendChild(card);
  document.body.appendChild(host);
  currentFloatingTooltip = host;
  
  // Stop mousedown/mouseup propagation inside the tooltip to prevent click-away issues
  card.addEventListener("mousedown", (e) => {
    e.stopPropagation();
  });
  card.addEventListener("mouseup", (e) => {
    e.stopPropagation();
  });
  
  // Bind close action
  card.querySelector(".close-btn").addEventListener("click", (e) => {
    e.stopPropagation();
    removeFloatingUI();
  });
}

function removeFloatingUI() {
  if (currentFloatingButton) {
    currentFloatingButton.remove();
    currentFloatingButton = null;
  }
  if (currentFloatingTooltip) {
    currentFloatingTooltip.remove();
    currentFloatingTooltip = null;
  }
}


// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // Add temporary shield to prevent iframe from stealing mouse events during dragging
      const existingShield = document.getElementById("wano-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = "wano-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      // Use getBoundingClientRect() for correct viewport-relative position
      // (element.offsetTop is unreliable for position:fixed elements on scrolled pages)
      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      // Restrict within window boundaries to prevent going offscreen
      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById("wano-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById("wano-universal-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "block" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = "wano-universal-floating-container";
    
    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 452) + "px !important; z-index:2147483647 !important; width:442px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="wano-u-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">Foreign Slang Translator</span>
        </div>
        <button id="wano-u-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#wano-u-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#wano-u-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
