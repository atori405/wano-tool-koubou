// --- English Slang Dictionary with Japanese Slang Equivalents and Cultural Background ---
const SLANG_DICTIONARY = [
  {
    word: "no cap",
    literal: "帽子なし",
    japanese: "ガチで / マジで / 嘘偽りなく",
    meaning: "「嘘じゃない」「本当に」という意味。「cap」には「嘘をつく」という意味があり、それを否定（no）しています。",
    origin: "アトランタを中心とする米ヒップホップ文化（トラップ・ミュージック）から広まりました。SNSや日常会話で自分の発言の信頼性を強調する際に使われます。",
    example: "That movie was amazing, no cap.",
    exampleJp: "あの映画マジで神だった、ガチで。"
  },
  {
    word: "touch grass",
    literal: "芝生に触る",
    japanese: "現実を見ろ / 外の空気を吸え / ネットばっかしてないで外に出ろ",
    meaning: "パソコンやスマホ画面ばかり見て、ネット空間の些細な争いや妄想に熱中している人に対し、外に出て現実世界（芝生に触る）に戻るように促す皮肉表現です。",
    origin: "Twitter（現X）やRedditなどのオタク・ゲーマーコミュニティ発祥。ネット依存症のユーザーを冷やかすための定番ミームです。",
    example: "You've been arguing about this game for 10 hours. Go touch grass.",
    exampleJp: "このゲームについて10時間もレスバしてるじゃん。ちょっとは現実を見ろよ。"
  },
  {
    word: "rent free",
    literal: "家賃無料で（脳内に）住む",
    japanese: "脳内を占領する / 頭から離れない / 執着する",
    meaning: "特定の人物や出来事が、自分の意図に反して頭から離れず、常に考え続けてしまっている状態を指します（脳内のスペースを家賃も払わずに占有されているという比喩）。",
    origin: "スポーツ選手がライバルを挑発する言葉から広まり、今ではSNSで「アンチが嫌いな相手について一日中考えている状態」を揶揄する言葉として定着しました。",
    example: "That argument is living rent free in your head.",
    exampleJp: "あの時のレスバ、まだ脳内を占領してるんだな（気にしてるんだな）。"
  },
  {
    word: "simp",
    literal: "マヌケ / 単細胞",
    japanese: "貢ぎ厨 / ガチ恋勢 / 信者 / 盲目的なファン",
    meaning: "好きな相手（インフルエンサーや気になる異性）に気に入られたい一心で、見返りもないのに過剰にお金や時間を貢いだり、盲目的に擁護したりする人を指します。",
    origin: "元々は1980年代のラップで「シンプルな（単純な）マヌケ」として使われていましたが、2020年頃にTikTokやTwitchのライブ配信コミュニティを通じて現在の意味で大流行しました。",
    example: "Stop simping for that streamer, she doesn't even know you exist.",
    exampleJp: "あの配信者に貢ぐのはやめろよ、君の存在すら認識してないぞ。"
  },
  {
    word: "slay",
    literal: "殺害する / 滅ぼす",
    japanese: "優勝 / 最高 / 神がかってる / 圧倒する",
    meaning: "何かに圧倒的に成功している状態、あるいは服装やパフォーマンスが素晴らしくて周りを圧倒している状態を絶賛する言葉です。",
    origin: "1970〜80年代の黒人やラテン系のLGBTQ+によるボール・カルチャー（ドラァグクイーンたちのダンス・ファッションイベント）から発祥し、ポップアイコンのBeyoncéなどの曲を通じて一般に広まりました。",
    example: "Your outfit tonight slays!",
    exampleJp: "今夜のあんたのコーデ、まじで優勝してる！"
  },
  {
    word: "stan",
    literal: "スタン（人名）",
    japanese: "推す / 限界オタク / 熱狂的ファン",
    meaning: "特定の芸能人やキャラクター、インフルエンサーを狂信的に支持する「熱狂的ファン（ストーカー＋ファン）」のこと、または「強く推す」という動詞としても使われます。",
    origin: "ラッパーのエミネム（Eminem）が2000年に発表したヒット曲『Stan』が由来。執拗にファンレターを送り最終的に悲劇を起こす狂信的なファン「スタン」の名前が一般名詞化しました。",
    example: "I absolutely stan this group.",
    exampleJp: "このグループ、まじで推せる（限界オタクレベルで好き）。"
  },
  {
    word: "ratio",
    literal: "比率",
    japanese: "論破 / リプ欄の大炎上 / 評価の逆転",
    meaning: "X（旧Twitter）などで、元投稿の「いいね（Like）」や「リツイート」の数よりも、批判的な「返信（Reply）」や「引用」の比率（ratio）が圧倒的に上回る現象。実質的な「大炎上・大論破」を指します。",
    origin: "Twitter黎明期のユーザー行動分析から生まれた用語。今ではリプ欄にただ「Ratio」とだけ書き込み、元発言の不人気さを可視化するネットスラングとして使われます。",
    example: "His hot take got ratioed so hard.",
    exampleJp: "彼の的外れな主張、リプ欄で大炎上（論破）されてたよ。"
  },
  {
    word: "based",
    literal: "塩基性の / 基礎のある",
    japanese: "ブレない / 我が道を行く / イケてる（意見）",
    meaning: "周囲の目や批判を一切気にせず、自分の信念や意見を貫く姿勢。特にネット上で議論を巻き起こすような本音をズバッと言った人に対して賛辞を送る言葉です。",
    origin: "元々は麻薬中毒者を指す蔑称「basehead」でしたが、ラッパーのLil Bが「自分のありのままを愛するイケてる姿勢」としてポジティブに再定義し、ネットミーム化しました。",
    example: "His opinion on this topic is so based.",
    exampleJp: "この件に対する彼の意見、まじでブレてなくてイケてる。"
  },
  {
    word: "mid",
    literal: "真ん中の / 中間の",
    japanese: "ビミョー / 可もなく不可もなく / 凡作",
    meaning: "「普通」「平均的」であるものの、期待値に届かず「退屈」「そこまで良くない」とネガティブに評価する表現です。",
    origin: "元々はアメリカの医療用大麻の等級で「中級（良くも悪くもない）」を指した言葉でしたが、TikTokなどで音楽やアニメ、料理などを「過大評価されている凡作」と評するスラングになりました。",
    example: "That new anime is just mid, to be honest.",
    exampleJp: "正直、あの新作アニメはかなりビミョー（普通以下）だわ。"
  },
  {
    word: "iykyk",
    literal: "あなたが知っているなら知っている",
    japanese: "わかる人にはわかる / 身内ネタ / 知らんけど（ニュアンス違い）",
    meaning: "「If You Know, You Know（わかる人にはわかる）」の略語。特定のコミュニティの秘密、隠語、インサイド・ジョークを投稿する際のハッシュタグや文末の添え言葉です。",
    origin: "メッセージアプリの略語からTikTokやInstagramのキャプションとして大流行。限定的な情報であることを暗に示して帰属意識を高める効果があります。",
    example: "Last night was crazy #iykyk",
    exampleJp: "昨日の夜はマジでやばかった（わかる人にはわかるよね）"
  },
  {
    word: "goat",
    literal: "ヤギ",
    japanese: "史上最強 / ネ申 / レジェンド",
    meaning: "「Greatest Of All Time（史上最高）」の頭文字をとった略語。スポーツ、音楽、ゲームなどあらゆる分野で「史上最強の存在」を指す最上級の賛辞です。",
    origin: "ボクシングの伝説ラシード・アリ（ムハマド・アリ）の愛称から普及。ネット上では「G.O.A.T.」またはヤギの絵文字（🐐）だけで表現されることが多いです。",
    example: "Messi is the absolute GOAT of football.",
    exampleJp: "メッシはサッカー界におけるガチの神（史上最強）だ。"
  },
  {
    word: "sus",
    literal: "サスペンド",
    japanese: "黒（怪しい） / クロ / 挙動不審 / チート臭い",
    meaning: "「Suspicious（疑わしい、怪しい）」の略語。何かが嘘っぽかったり、人狼ゲームなどで裏切り者の気配を感じたりした時に使われます。",
    origin: "宇宙人狼ゲーム『Among Us』のプレイヤー同士のチャットで、素早く「怪しいやつ」を指名するために大流行し、日常スラングとして定着しました。",
    example: "That account looks a bit sus.",
    exampleJp: "あのアカウント、ちょっと怪しい（サクラ/スパムっぽい）な。"
  },
  {
    word: "flex",
    literal: "（筋肉を）曲げる",
    japanese: "イキる / 自慢する / ドヤる",
    meaning: "自分の財力、地位、所有物、あるいはスキルなどを周囲に見せびらかし、自慢・誇示する行為を指します。",
    origin: "ボディビルダーが筋肉をアピールするポーズ（flexing）から転じ、ヒップホップ歌詞の中で高級車や宝飾品を見せびらかすスラングになり、SNS全体へ普及しました。",
    example: "He bought a luxury watch just to flex.",
    exampleJp: "あいつ、ただイキる（自慢する）ために高級時計を買ったんだぜ。"
  },
  {
    word: "cringe",
    literal: "身をすくめる / すくむ",
    japanese: "痛い / 黒歴史 / 共感性羞恥 / 見てられない",
    meaning: "他人の恥ずかしい言動、あるいは時代遅れの言動を見て、こちらが恥ずかしくなったり引いてしまったりする感情（共感性羞恥）を指します。",
    origin: "掲示板Redditの「r/cringe」やYouTubeの「Cringe Compilation（痛いシーンまとめ）」から世界的に定着したネット必須ワードです。",
    example: "His old TikTok videos are so cringe.",
    exampleJp: "あいつの昔のTikTok動画、痛すぎて見てられない（黒歴史）。"
  },
  {
    word: "copium",
    literal: "コピウム（造語）",
    japanese: "現実逃避 / 現実逃避用の精神安定剤 / 負け惜しみ",
    meaning: "「Cope（対処する、乗り切る）」と「Opium（阿片・麻薬）」を組み合わせた合成語。ゲームの敗北や応援チームの落選など、受け入れがたい現実から逃避するための「都合の良い自己正当化・言い訳」を指します。",
    origin: "画像掲示板4chanで生まれ、TwitchやRedditでゲーム実況者やファンが言い訳している姿を「コピウムを吸っている」と風刺する絵文字（ペペ・ザ・フロッグが酸素マスクを吸う画像）と共に爆発的に広まりました。",
    example: "He claims he lost due to lag, that's pure copium.",
    exampleJp: "「回線遅延のせいで負けた」だって。それ、ただの現実逃避（負け惜しみ）だろ。"
  },
  {
    word: "glow up",
    literal: "輝く成長",
    japanese: "あか抜ける / 劇的なビジュアルの成長",
    meaning: "年月を経て、外見（髪型、服装、体型など）や雰囲気が劇的に垢抜け、魅力的かつ大人っぽく成長することを意味します。",
    origin: "「grow up（成長する）」をもじった言葉。SNS上の「before / after」画像を投稿するチャレンジ（#GlowUpChallenge）で世界的トレンドになりました。",
    example: "She had a major glow up after high school.",
    exampleJp: "彼女、高校を卒業してからめちゃくちゃ垢抜けたよね。"
  },
  {
    word: "main character energy",
    literal: "主人公のエネルギー",
    japanese: "主人公補正 / 圧倒的な存在感 / 自分大好き人間",
    meaning: "映画の主人公のように周囲を引きつけるオーラや自信に満ち溢れている状態。良くも悪くも「自分が世界の中心にいるかのように振る舞う人」に対しても使われます。",
    origin: "TikTokで「自分の人生の主人公として堂々と生きる姿」を演出する動画トレンド（#MainCharacterEnergy）から誕生したネットミームです。",
    example: "She walked into the room with major main character energy.",
    exampleJp: "彼女、まるで世界の主人公かのような圧倒的オーラで部屋に入ってきたよ。"
  },
  {
    word: "ate",
    literal: "食べた",
    japanese: "完全勝利 / 完璧にやり遂げた / 大成功した",
    meaning: "パフォーマンスやファッション、仕事などが完璧であり、完全に場を支配して「賞賛をすべて平らげた」と絶賛するスラング。「left no crumbs（パンくず一つ残さなかった＝完璧）」と併用されます。",
    origin: "黒人のドラァグ・ボール文化やヒップホップから発祥し、SNS（特にK-POPファンやダンスファンの間）で神がかったステージを褒め称える際に浸透しました。",
    example: "She absolutely ate that dance performance.",
    exampleJp: "彼女、あのダンスパフォーマンス完璧にやり遂げたな（完全勝利）。"
  },
  {
    word: "sheesh",
    literal: "シィーシュ（感嘆詞）",
    japanese: "うわぁ！ / マジかよ！ / やば！",
    meaning: "驚き、興奮、呆れ、あるいは他人の高級な持ち物やスキルをからかい半分で賞賛する際の感嘆詞です。",
    origin: "古くからある表現ですが、TikTokで高音の声を出しながら両腕の関節（血流を指すポーズ）を叩くポーズ（Ice in my veins）をセットにした動画が大流行し、Z世代のシンボル的ネットスラングになりました。",
    example: "He just scored a goal from half-court? Sheesh!",
    exampleJp: "ハーフコートからシュート決めたの？やば！マジかよ！"
  },
  {
    word: "tea",
    literal: "お茶",
    japanese: "ゴシップ / 噂話 / 裏事情 / 暴露ネタ",
    meaning: "スキャンダル、ゴシップ、あるいは他人のゴシップやドラマの真相についての話。「spill the tea（お茶をこぼす＝暴露する、裏事情を話す）」というフレーズで非常によく使われます。",
    origin: "1990年代の黒人ドラァグクイーン文化発祥。お茶を飲みながら親しい友人同士でゴシップ話に花を咲かせる様子が語源とされています。",
    example: "Come on, spill the tea! What happened between them?",
    exampleJp: "ねえ、早くゴシップ（裏事情）を暴露してよ！彼らの間に何があったの？"
  },
  {
    word: "salty",
    literal: "塩辛い",
    japanese: "へそを曲げる / イライラする / 悔しがる",
    meaning: "些細なことで不機嫌になったり、ゲームで負けて悔しさから八つ当たりしたり、皮肉を言ったりする様子を指します。",
    origin: "元々はアメリカの船乗りのスラング（海の塩水にかかってイライラしている様子）でしたが、格闘ゲームなどの対戦ゲームコミュニティで「負け惜しみを言うプレイヤー」を指すスラングとして定番化しました。",
    example: "He is just salty because he lost the match.",
    exampleJp: "あいつはマッチに負けて、ただイライラ（へそを曲げて）してるだけだよ。"
  },
  {
    word: "ghost",
    literal: "幽霊",
    japanese: "音信不通になる / 既読無視（フェードアウト） / バックれる",
    meaning: "それまで仲良く連絡を取り合っていた相手（特にマッチングアプリやSNS）からの連絡を、何の前触れもなく突然すべて断ち、幽霊のように姿を消す行為です。",
    origin: "2010年代半ばのマッチングアプリ（Tinderなど）の普及に伴い、関係の断絶を最も手軽に行う手段として言葉が定着しました。",
    example: "We had a great first date, but then he ghosted me.",
    exampleJp: "最初のデートはすごく楽しかったのに、その後彼と音信不通（フェードアウト）になっちゃった。"
  },
  {
    word: "valid",
    literal: "有効な",
    japanese: "アリ / 納得 / わかる / まとも",
    meaning: "誰かの意見や行動、あるいはファッションなどが「十分価値がある」「理にかなっている」「承認できる（アリだ）」と認める表現です。",
    origin: "SNS上の「Is this valid?（これってアリ？）」というネットミームから。若者の間で、他人の服装や趣味を承認・絶賛するカジュアルな評価ワードとして使われています。",
    example: "Your reason for quitting the job is completely valid.",
    exampleJp: "仕事を辞める君の理由は、完全にアリ（納得できる）だよ。"
  },
  {
    word: "extra",
    literal: "余分な",
    japanese: "やりすぎ / イタい / 大げさ / クドい",
    meaning: "必要以上に大げさだったり、おせっかいだったり、自己主張が激しすぎて周囲から「やりすぎで引く」と思われる言動・態度を指します。",
    origin: "アメリカの黒人英語（AAVE）から一般化したスラング。ドラマチックすぎる人間や、過剰に着飾る態度をからかう際に使用されます。",
    example: "She was crying so loudly over a small scratch. She is so extra.",
    exampleJp: "小さな擦り傷であんなに大泣きするなんて。彼女ほんと大げさ（やりすぎ）だよね。"
  },
  {
    word: "cap",
    literal: "帽子",
    japanese: "嘘 / ハッタリ / ガセ",
    meaning: "「嘘」や「大げさなハッタリ」のこと。「no cap」の反対。SNSでは、嘘だと思う発言に対して「Cap（嘘だ）」とリプライしたり、帽子の絵文字（🧢）だけで反論したりします。",
    origin: "ヒップホップ文化の古い俗語で「相手を上回る（cap）」＝「大口をたたく/嘘を言う」がルーツ。TikTokなどの若者世代でリバイバルヒットしました。",
    example: "He claims he is a millionaire? That's cap.",
    exampleJp: "自分が大富豪だって言ってるの？それガセ（嘘）だよ。"
  }
];

// Ensure module exports work if referenced in Node environment (like tests), but fall back to global for web browser
if (typeof module !== "undefined" && module.exports) {
  module.exports = SLANG_DICTIONARY;
}
