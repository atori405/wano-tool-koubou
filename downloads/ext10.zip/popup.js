// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  function openFallbackWindow() {
    // Fail-safe: Open popup.html as a draggable Chrome popup window
    var w = Math.min(screen.availWidth, 420);
    var h = Math.min(screen.availHeight, 620);
    var left = Math.round((screen.availWidth - w) / 2);
    var top = Math.round((screen.availHeight - h) / 4);
    chrome.windows.create({
      url: chrome.runtime.getURL("popup.html?mode=window"),
      type: "popup",
      width: w,
      height: h,
      left: left,
      top: top,
      focused: true
    });
  }

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        var tabId = tabs[0].id;
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabId, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Content script is likely stale/missing on this tab (e.g. the tab was
            // already open before the extension was installed/updated). Re-inject it
            // on demand and retry once before falling back to a separate OS window
            // (the separate-window fallback can vanish and never reappear).
            if (chrome.scripting) {
              chrome.scripting.executeScript({
                target: { tabId: tabId },
                files: ["draggable.js", "content.js"]
              }, function() {
                if (chrome.runtime.lastError) {
                  openFallbackWindow();
                  window.close();
                  return;
                }
                chrome.tabs.sendMessage(tabId, { action: "toggleFloatingPanel" }, function(response2) {
                  if (chrome.runtime.lastError || !response2 || response2.status !== "toggled") {
                    openFallbackWindow();
                  }
                  window.close();
                });
              });
              return;
            }
            openFallbackWindow();
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// --- Popup Javascript for Foreign Slang Translator ---

document.addEventListener("DOMContentLoaded", () => {
  // Elements
  const themeToggle = document.getElementById("theme-toggle");
  const tabs = document.querySelectorAll(".nav-tab");
  const tabContents = document.querySelectorAll(".tab-content");
  
  const toggleHover = document.getElementById("toggle-hover-translation");
  const searchInput = document.getElementById("slang-search-input");
  const detailCard = document.getElementById("slang-detail-card");
  const listCount = document.getElementById("slang-list-count");
  const listViewport = document.getElementById("slang-list-viewport");
  
  // Quiz Elements
  const quizIntroCard = document.getElementById("quiz-intro-card");
  const quizGameCard = document.getElementById("quiz-game-card");
  const quizResultCard = document.getElementById("quiz-result-card");
  const btnStartQuiz = document.getElementById("btn-start-quiz");
  const btnNextQuestion = document.getElementById("btn-next-question");
  const btnRestartQuiz = document.getElementById("btn-restart-quiz");
  const quizQnum = document.getElementById("quiz-qnum");
  const quizScore = document.getElementById("quiz-score");
  const quizQuestionWord = document.getElementById("quiz-question-word");
  const quizQuestionLiteral = document.getElementById("quiz-question-literal");
  const quizOptionsContainer = document.getElementById("quiz-options-container");
  const quizFeedbackBox = document.getElementById("quiz-feedback-box");
  const quizFeedbackResult = document.getElementById("quiz-feedback-result");
  const quizFeedbackCorrect = document.getElementById("quiz-feedback-correct");
  const quizFeedbackExplanation = document.getElementById("quiz-feedback-explanation");
  const finalScore = document.getElementById("final-score");
  const scoreRatingTitle = document.getElementById("score-rating-title");
  const scoreRatingDesc = document.getElementById("score-rating-desc");
  
  const toast = document.getElementById("toast");

  // State Variables
  let activeSlang = null;
  let quizQuestions = [];
  let currentQuestionIndex = 0;
  let currentScore = 0;
  let quizSelectedOptionIndex = null;

  // --- 1. Theme Toggle Logic ---
  const activeTheme = localStorage.getItem("theme") || "dark";
  if (activeTheme === "light") {
    document.body.classList.remove("dark-theme");
    document.body.classList.add("light-theme");
    themeToggle.querySelector(".sun-icon").style.display = "none";
    themeToggle.querySelector(".moon-icon").style.display = "block";
  } else {
    document.body.classList.remove("light-theme");
    document.body.classList.add("dark-theme");
    themeToggle.querySelector(".sun-icon").style.display = "block";
    themeToggle.querySelector(".moon-icon").style.display = "none";
  }

  themeToggle.addEventListener("click", () => {
    if (document.body.classList.contains("dark-theme")) {
      document.body.classList.remove("dark-theme");
      document.body.classList.add("light-theme");
      themeToggle.querySelector(".sun-icon").style.display = "none";
      themeToggle.querySelector(".moon-icon").style.display = "block";
      localStorage.setItem("theme", "light");
    } else {
      document.body.classList.remove("light-theme");
      document.body.classList.add("dark-theme");
      themeToggle.querySelector(".sun-icon").style.display = "block";
      themeToggle.querySelector(".moon-icon").style.display = "none";
      localStorage.setItem("theme", "dark");
    }
  });

  // --- 2. Navigation Tab Switcher ---
  tabs.forEach(tab => {
    tab.addEventListener("click", () => {
      tabs.forEach(t => t.classList.remove("active"));
      tabContents.forEach(tc => tc.classList.remove("active"));

      tab.classList.add("active");
      const targetTab = tab.getAttribute("data-tab");
      document.getElementById(targetTab).classList.add("active");
    });
  });

  // --- 3. Selection Hover Feature Toggle Sync ---
  if (typeof chrome !== "undefined" && chrome.storage) {
    chrome.storage.local.get({ selection_translation_enabled: true }, (result) => {
      toggleHover.checked = result.selection_translation_enabled;
    });

    toggleHover.addEventListener("change", () => {
      chrome.storage.local.set({ selection_translation_enabled: toggleHover.checked }, () => {
        showToast(toggleHover.checked ? "ホバー翻訳をONにしました" : "ホバー翻訳をOFFにしました");
      });
    });
  }

  // --- 4. Slang Search & List Population ---
  function renderSlangList(filter = "") {
    listViewport.innerHTML = "";
    const query = filter.trim().toLowerCase();
    
    const filtered = SLANG_DICTIONARY.filter(item => {
      return item.word.toLowerCase().includes(query) ||
             item.japanese.toLowerCase().includes(query) ||
             item.meaning.toLowerCase().includes(query);
    });

    listCount.textContent = `${filtered.length}語`;

    if (filtered.length === 0) {
      listViewport.innerHTML = `
        <div class="empty-detail-state">
          <p>一致するスラングはありません。</p>
        </div>
      `;
      return;
    }

    filtered.forEach(item => {
      const slangItem = document.createElement("div");
      slangItem.className = "slang-item";
      if (activeSlang && activeSlang.word === item.word) {
        slangItem.style.borderColor = "var(--accent)";
      }
      
      slangItem.innerHTML = `
        <div class="slang-item-left">
          <span class="slang-item-word">${item.word}</span>
          <span class="slang-item-jp">${item.japanese}</span>
        </div>
        <span class="slang-item-arrow">→</span>
      `;
      
      slangItem.addEventListener("click", () => {
        loadSlangDetails(item);
        // Highlight active item in list
        document.querySelectorAll(".slang-item").forEach(el => el.style.borderColor = "var(--border)");
        slangItem.style.borderColor = "var(--accent)";
      });
      
      listViewport.appendChild(slangItem);
    });
  }

  // Text-To-Speech (Listen pronunciation)
  function speakSlang(word) {
    if (!window.speechSynthesis) {
      showToast("発音機能はお使いのブラウザで非対応です。");
      return;
    }
    window.speechSynthesis.cancel(); // stop previous
    const utterance = new SpeechSynthesisUtterance(word);
    utterance.lang = "en-US";
    window.speechSynthesis.speak(utterance);
  }

  function loadSlangDetails(slang) {
    activeSlang = slang;
    
    detailCard.innerHTML = `
      <div class="detail-header">
        <div class="detail-word-group">
          <span class="detail-word">${slang.word}</span>
          <span class="detail-literal">直訳: ${slang.literal}</span>
        </div>
        <button class="btn-speak" id="btn-speak-slang">
          <span>🔊 発音</span>
        </button>
      </div>

      <div class="detail-section">
        <span class="detail-label">ネットスラング訳</span>
        <div class="detail-japanese-row">
          <span class="detail-japanese">${slang.japanese}</span>
        </div>
      </div>

      <div class="detail-section">
        <span class="detail-label">意味・ニュアンス</span>
        <p class="detail-desc">${slang.meaning}</p>
      </div>

      <div class="detail-section">
        <span class="detail-label">文化的背景・ミームの起源</span>
        <p class="detail-origin">${slang.origin}</p>
      </div>

      <div class="detail-section">
        <span class="detail-label">使用例</span>
        <span class="detail-example-en">“${slang.example}”</span>
        <span class="detail-example-jp">（${slang.exampleJp}）</span>
      </div>
    `;

    document.getElementById("btn-speak-slang").addEventListener("click", () => {
      speakSlang(slang.word);
    });
  }

  // Handle Search Input
  searchInput.addEventListener("input", (e) => {
    renderSlangList(e.target.value);
  });

  // Load first item as default on load
  if (SLANG_DICTIONARY.length > 0) {
    loadSlangDetails(SLANG_DICTIONARY[0]);
    renderSlangList();
  }

  // --- 5. Interactive Slang Quiz Logic ---
  function startQuiz() {
    quizIntroCard.classList.add("hidden");
    quizResultCard.classList.add("hidden");
    quizGameCard.classList.remove("hidden");
    
    currentScore = 0;
    currentQuestionIndex = 0;
    
    // Shuffle and pick 10 words
    const shuffled = [...SLANG_DICTIONARY].sort(() => 0.5 - Math.random());
    quizQuestions = shuffled.slice(0, 10);
    
    loadQuizQuestion();
  }

  function loadQuizQuestion() {
    quizFeedbackBox.classList.add("hidden");
    quizSelectedOptionIndex = null;
    
    const question = quizQuestions[currentQuestionIndex];
    
    // Progress and scores
    quizQnum.textContent = `第 ${currentQuestionIndex + 1} / 10 問`;
    quizScore.textContent = `スコア: ${currentScore}`;
    
    quizQuestionWord.textContent = question.word;
    quizQuestionLiteral.textContent = `直訳: ${question.literal}`;
    
    // Generate Options: 1 correct, 3 random wrong ones
    const correctOption = question.japanese;
    const wrongOptions = [];
    
    const wrongPool = SLANG_DICTIONARY.filter(item => item.word !== question.word).map(item => item.japanese);
    const shuffledWrongPool = wrongPool.sort(() => 0.5 - Math.random());
    
    // Pick unique wrong options
    for (let opt of shuffledWrongPool) {
      if (wrongOptions.length >= 3) break;
      if (!wrongOptions.includes(opt) && opt !== correctOption) {
        wrongOptions.push(opt);
      }
    }
    
    // Combine and shuffle options
    const allOptions = [correctOption, ...wrongOptions].sort(() => 0.5 - Math.random());
    
    // Populate Buttons
    quizOptionsContainer.innerHTML = "";
    allOptions.forEach((option, idx) => {
      const button = document.createElement("button");
      button.className = "quiz-opt-btn";
      button.textContent = `${idx + 1}. ${option}`;
      
      button.addEventListener("click", () => {
        if (quizSelectedOptionIndex !== null) return; // already answered
        handleAnswerSelection(idx, option, correctOption, question);
      });
      
      quizOptionsContainer.appendChild(button);
    });

    // Reset next button text
    btnNextQuestion.querySelector("#next-btn-text").textContent = currentQuestionIndex === 9 ? "結果発表へ" : "次の問題へ";
  }

  function handleAnswerSelection(index, chosenOption, correctOption, question) {
    quizSelectedOptionIndex = index;
    const optionButtons = quizOptionsContainer.querySelectorAll(".quiz-opt-btn");
    
    // Disable all options
    optionButtons.forEach(btn => btn.disabled = true);
    
    const isCorrect = chosenOption === correctOption;
    if (isCorrect) {
      currentScore++;
      optionButtons[index].classList.add("correct");
      quizFeedbackResult.textContent = "🎉 正解！";
      quizFeedbackResult.className = "feedback-result correct-text";
    } else {
      optionButtons[index].classList.add("incorrect");
      // Find and highlight correct answer
      optionButtons.forEach(btn => {
        if (btn.textContent.includes(correctOption)) {
          btn.classList.add("correct");
        }
      });
      quizFeedbackResult.textContent = "😢 不正解...";
      quizFeedbackResult.className = "feedback-result incorrect-text";
    }

    quizFeedbackCorrect.textContent = `正解: ${correctOption}`;
    quizFeedbackExplanation.innerHTML = `<strong>解説:</strong> ${question.meaning}<br><br><strong>文化的背景:</strong> ${question.origin}`;
    
    quizFeedbackBox.classList.remove("hidden");
    quizFeedbackBox.scrollIntoView({ behavior: "smooth" });
  }

  btnNextQuestion.addEventListener("click", () => {
    currentQuestionIndex++;
    if (currentQuestionIndex < 10) {
      loadQuizQuestion();
    } else {
      showQuizResults();
    }
  });

  function showQuizResults() {
    quizGameCard.classList.add("hidden");
    quizResultCard.classList.remove("hidden");
    
    finalScore.textContent = currentScore;
    
    // Ratings
    if (currentScore === 10) {
      scoreRatingTitle.textContent = "👑 パーフェクト！ネイティブ級スラングマスター";
      scoreRatingDesc.textContent = "あなたは海外のネット空間に完璧に溶け込んでいます！RedditやTwitchでの発言も完璧に理解できています。";
    } else if (currentScore >= 7) {
      scoreRatingTitle.textContent = "🔥 かなりのスラングオタク！";
      scoreRatingDesc.textContent = "海外のSNSや掲示板、YouTubeのコメント欄を全く不自由なく読み解ける高いスラングレベルです！";
    } else if (currentScore >= 4) {
      scoreRatingTitle.textContent = "🌱 スラング初級〜中級レベル";
      scoreRatingDesc.textContent = "基本的なネットスラングは理解できています。最新のミームに触れてさらにボキャブラリーを増やしましょう！";
    } else {
      scoreRatingTitle.textContent = "🧐 これから頑張りましょう！";
      scoreRatingDesc.textContent = "まだ聞き慣れない表現が多かったようです。辞書検索タブやホバー翻訳機能を使って、少しずつ覚えていきましょう！";
    }
  }

  btnStartQuiz.addEventListener("click", startQuiz);
  btnRestartQuiz.addEventListener("click", startQuiz);

  // --- 6. Toast Notification ---
  function showToast(message) {
    toast.textContent = message;
    toast.classList.remove("hidden");
    setTimeout(() => {
      toast.classList.add("hidden");
    }, 2000);
  }
});
