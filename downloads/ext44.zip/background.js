// background.js - Service Worker for Easy API Tester

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["apiHistory", "modeType"], (result) => {
    const updates = {};
    if (result.apiHistory === undefined) {
      updates.apiHistory = []; // Empty history stack
    }
    if (result.modeType === undefined) {
      updates.modeType = "direct"; // Default mode is direct fetch
    }
    if (Object.keys(updates).length > 0) {
      chrome.storage.local.set(updates);
    }
  });
  console.log("やさしいAPIテスター 拡張機能が正常にインストールされました。");
});
