// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 680);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 680,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// popup.js - Easy API Tester Engine

document.addEventListener("DOMContentLoaded", () => {
  // --- 1. HTTP Status Dictionary (Gentle Explanations) ---
  const STATUS_EXPLANATIONS = {
    // 2xx Success
    200: "成功 (OK) - リクエストが正常に完了しました。要求されたデータが正しく返されています。",
    201: "作成完了 (Created) - リクエストが成功し、新しいデータ（リソース）がサーバー上に正常に作成されました。",
    204: "無応答 (No Content) - リクエストは成功しましたが、返却するデータ（ボディ）はありません。",
    
    // 3xx Redirection
    301: "恒久的な移動 (Moved Permanently) - 指定されたURLは新しい場所に変更されました。自動的に転送される可能性があります。",
    302: "一時的な移動 (Found) - 指定されたURLは一時的に別の場所に移っています。",
    
    // 4xx Client Errors
    400: "不正な要求 (Bad Request) - 送信したデータの書き方（JSONの文法やパラメータ）に誤りがあります。入力値を確認してください。",
    401: "未認証 (Unauthorized) - アクセスするために必要なログイン情報やトークン（Authorization等）がありません、または無効です。",
    403: "禁止 (Forbidden) - このURLへのアクセス権限がありません。管理者設定やAPIキーの有効性を確認してください。",
    404: "未検出 (Not Found) - 指定されたURL（エンドポイント）が見つかりません。アドレスの綴りやパスが正しいか確認してください。",
    405: "許可されないメソッド (Method Not Allowed) - 指定されたURLに対して、このHTTPメソッド（GETやPOSTなど）は使用できません。",
    
    // 5xx Server Errors
    500: "サーバー内エラー (Internal Server Error) - 接続先のサーバー内部で何らかのバグやプログラム障害が発生しています。",
    502: "不正ゲートウェイ (Bad Gateway) - サーバーへの通信の途中にいるプロキシ（ゲートウェイ）が異常な応答を返しました。",
    503: "サービス利用不可 (Service Unavailable) - 接続先サーバーがメンテナンス中か、またはアクセス集中により一時的に応答できません。",
    504: "タイムアウト (Gateway Timeout) - 接続先サーバーからの応答が制限時間内に返ってきませんでした。"
  };

  // --- 2. Element References ---
  const selectMethod = document.getElementById("select-method");
  const selectMode = document.getElementById("select-mode");
  const inputUrl = document.getElementById("input-url");
  const btnSend = document.getElementById("btn-send");
  
  const reqHeaders = document.getElementById("req-headers");
  const reqBody = document.getElementById("req-body");
  
  const responseContainer = document.getElementById("response-container");
  const statusBadge = document.getElementById("response-status-badge");
  const timeBadge = document.getElementById("response-time-badge");
  const explanationText = document.getElementById("response-explanation-text");
  
  const responseBodyPre = document.getElementById("response-body-pre");
  const responseHeadersPre = document.getElementById("response-headers-pre");
  const loader = document.getElementById("wabi-loader");

  // --- 3. Storage Load/Save ---
  function loadConfig() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.get(["lastUrl", "lastMethod", "lastMode", "lastReqHeaders", "lastReqBody"], (result) => {
        if (result.lastUrl) inputUrl.value = result.lastUrl;
        if (result.lastMethod) selectMethod.value = result.lastMethod;
        if (result.lastMode) selectMode.value = result.lastMode;
        if (result.lastReqHeaders) reqHeaders.value = result.lastReqHeaders;
        if (result.lastReqBody) reqBody.value = result.lastReqBody;
      });
    }
  }

  function saveConfig() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.set({
        lastUrl: inputUrl.value,
        lastMethod: selectMethod.value,
        lastMode: selectMode.value,
        lastReqHeaders: reqHeaders.value,
        lastReqBody: reqBody.value
      });
    }
  }

  // --- 4. Tab Routing Controllers ---
  function initTabs() {
    document.querySelectorAll(".wabi-tab-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const container = btn.parentElement;
        const targetId = btn.getAttribute("data-target");

        // Deactivate all sibling buttons
        container.querySelectorAll(".wabi-tab-btn").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");

        // Toggle pane visibility
        let nextSibling = container.nextElementSibling;
        while (nextSibling && !nextSibling.classList.contains("wabi-tab-container")) {
          if (nextSibling.classList.contains("wabi-tab-pane")) {
            nextSibling.classList.toggle("active", nextSibling.id === targetId);
          }
          nextSibling = nextSibling.nextElementSibling;
        }
      });
    });
  }

  // --- 5. Mock Server Simulator Logic ---
  function executeMockRequest(method, url, headersStr, bodyStr, callback) {
    const startTime = performance.now();
    
    // Simulate server latency
    setTimeout(() => {
      const endTime = performance.now();
      const duration = Math.round(endTime - startTime);
      
      let status = 200;
      let statusText = "OK";
      let resData = null;
      let resHeaders = {
        "content-type": "application/json; charset=utf-8",
        "x-powered-by": "WabiSabiMockServer",
        "cache-control": "no-cache"
      };

      const normalizedUrl = url.trim().toLowerCase();

      if (normalizedUrl.includes("/users/1")) {
        if (method === "GET") {
          status = 200;
          statusText = "OK";
          resData = {
            id: 1,
            name: "和沙 太郎",
            email: "taro.wasa@wabisabi.dev",
            role: "リードエンジニア",
            status: "アクティブ",
            created_at: "2026-04-01T12:00:00Z"
          };
        } else if (method === "DELETE") {
          status = 200;
          statusText = "OK";
          resData = {
            success: true,
            message: "ユーザー ID: 1 のデータを完全に削除しました。"
          };
        } else {
          status = 405;
          statusText = "Method Not Allowed";
          resData = { error: "MethodNotAllowed", message: "このURLにそのメソッドは許可されていません。" };
        }
      } else if (normalizedUrl.includes("/users")) {
        if (method === "POST") {
          let parsedBody = {};
          try {
            parsedBody = JSON.parse(bodyStr || "{}");
          } catch(e) {}

          status = 201;
          statusText = "Created";
          resData = {
            success: true,
            message: "新規ユーザー情報を正常にデータベースに登録しました。",
            inserted_id: 142,
            data: {
              name: parsedBody.name || "名称未設定",
              email: parsedBody.email || "mail@example.com",
              created_at: new Date().toISOString()
            }
          };
        } else {
          status = 400;
          statusText = "Bad Request";
          resData = { error: "BadRequest", message: "GET /users/1 などの個別IDを指定するか、POSTで作成を行ってください。" };
        }
      } else if (normalizedUrl.includes("/error")) {
        status = 500;
        statusText = "Internal Server Error";
        resData = {
          error: "DatabaseConnectionException",
          message: "接続上限に達したため、データベースへのアクセスプールを確保できませんでした。"
        };
      } else {
        // Fallback 404
        status = 404;
        statusText = "Not Found";
        resData = {
          error: "NotFound",
          message: `接続先URL: ${url} はモックサーバー上に登録されていません。`
        };
      }

      callback({
        status,
        statusText,
        duration,
        headers: resHeaders,
        body: JSON.stringify(resData, null, 2)
      });

    }, 450); // 450ms dynamic latency
  }

  // --- 6. Direct HTTP Request Logic ---
  function executeDirectRequest(method, url, headersStr, bodyStr, callback) {
    const startTime = performance.now();
    
    // Set AbortController for 6-second timeout to prevent infinite loader spinner
    const controller = new AbortController();
    const timeoutId = setTimeout(() => {
      controller.abort();
    }, 6000);
    
    // Parse input headers
    const headers = new Headers();
    const headerLines = headersStr.split("\n");
    headerLines.forEach(line => {
      const parts = line.split(":");
      if (parts.length >= 2) {
        const key = parts[0].trim();
        const val = parts.slice(1).join(":").trim();
        if (key) headers.append(key, val);
      }
    });

    const requestOptions = {
      method: method,
      headers: headers,
      signal: controller.signal
    };

    if (method !== "GET" && method !== "HEAD" && bodyStr.trim()) {
      requestOptions.body = bodyStr;
    }

    fetch(url, requestOptions)
      .then(response => {
        clearTimeout(timeoutId); // Clear timeout since request succeeded
        const endTime = performance.now();
        const duration = Math.round(endTime - startTime);

        // Read response headers
        const resHeaders = {};
        response.headers.forEach((val, key) => {
          resHeaders[key] = val;
        });

        response.text().then(text => {
          callback({
            status: response.status,
            statusText: response.statusText,
            duration: duration,
            headers: resHeaders,
            body: text
          });
        });
      })
      .catch(error => {
        clearTimeout(timeoutId); // Clear timeout since request failed
        const endTime = performance.now();
        const duration = Math.round(endTime - startTime);
        
        let errorMsg = error.message;
        let isTimeout = error.name === "AbortError";
        if (isTimeout) {
          errorMsg = "接続先からの応答が制限時間（6秒）を超過したため、タイムアウトしました。";
        }
        
        // Render network error / CORS blocker block or Timeout
        callback({
          status: isTimeout ? 504 : 0,
          statusText: isTimeout ? "Gateway Timeout" : "Network Error / CORS Blocked",
          duration: duration,
          headers: {},
          body: JSON.stringify({
            error: isTimeout ? "TIMEOUT" : "CORS_OR_NETWORK_FAILURE",
            message: isTimeout 
              ? "リクエストがタイムアウトしました。" 
              : "通信に失敗しました。CORSエラー（ドメイン跨ぎの制限）が発生しているか、オフライン状態の可能性があります。",
            details: errorMsg,
            advice: isTimeout
              ? "URLが正しいか、または接続先のサーバーが正常に起動しているかご確認ください。"
              : "外部サイトと直接通信する際は、サーバー側がCORSヘッダー（Access-Control-Allow-Origin）を許可している必要があります。動作テストを行いたい場合は、通信モードを『モック通信』に切り替えて送信してください。"
          }, null, 2)
        });
      });
  }

  // --- 7. Response Formatter and UI Updates ---
  function formatJSONHtml(jsonText) {
    try {
      const obj = JSON.parse(jsonText);
      return JSON.stringify(obj, null, 2);
    } catch (e) {
      // Return raw string if not JSON
      return jsonText;
    }
  }

  function displayResponse(result) {
    loader.style.display = "none";
    responseContainer.style.display = "flex";

    // Set Status Badge
    statusBadge.textContent = `${result.status} ${result.statusText}`;
    
    // Adjust colors based on status code
    statusBadge.className = "status-badge"; // clear previous
    if (result.status >= 200 && result.status < 300) {
      statusBadge.classList.add("status-200"); // Green
    } else if (result.status >= 300 && result.status < 500) {
      statusBadge.classList.add("status-400"); // Orange
    } else {
      statusBadge.classList.add("status-500"); // Red
    }

    // Set Time
    timeBadge.textContent = `${result.duration} ms`;

    // Set Gentle Explanation
    const explanation = STATUS_EXPLANATIONS[result.status] || 
      (result.status === 0 ? "通信失敗 - セキュリティ制限（CORS）によってブラウザが接続を拒否したか、相手サーバーがダウンしています。" : "その他のステータス - 解説が見つかりません。");
    explanationText.textContent = explanation;

    // Set Body Pre
    responseBodyPre.textContent = formatJSONHtml(result.body);

    // Set Headers Pre
    let headersContent = "";
    for (const [key, val] of Object.entries(result.headers)) {
      headersContent += `${key}: ${val}\n`;
    }
    responseHeadersPre.textContent = headersContent || "(空のヘッダー)";
  }

  // --- 8. Event Handlers ---
  btnSend.addEventListener("click", () => {
    const method = selectMethod.value;
    const mode = selectMode.value;
    const url = inputUrl.value.trim();
    const headersStr = reqHeaders.value;
    const bodyStr = reqBody.value;

    if (!url) {
      alert("URLを入力してください。");
      return;
    }

    // Save configurations
    saveConfig();

    // Show loading
    responseContainer.style.display = "none";
    loader.style.display = "flex";

    // Trigger communication engine
    if (mode === "mock") {
      executeMockRequest(method, url, headersStr, bodyStr, displayResponse);
    } else {
      executeDirectRequest(method, url, headersStr, bodyStr, displayResponse);
    }
  });

  // Handle auto url mapping suggestions when changing method
  selectMethod.addEventListener("change", () => {
    const method = selectMethod.value;
    const currentUrl = inputUrl.value.trim();
    
    // Automatically switch preset mock routes for demo clarity
    if (currentUrl.startsWith("https://mock.wabi-api.dev/")) {
      if (method === "POST") {
        inputUrl.value = "https://mock.wabi-api.dev/users";
      } else {
        inputUrl.value = "https://mock.wabi-api.dev/users/1";
      }
    } else if (currentUrl.startsWith("https://httpbin.org/")) {
      inputUrl.value = `https://httpbin.org/${method.toLowerCase()}`;
    }
    saveConfig();
  });

  // Handle mode switches
  selectMode.addEventListener("change", () => {
    const mode = selectMode.value;
    const method = selectMethod.value;
    if (mode === "mock") {
      if (method === "POST") {
        inputUrl.value = "https://mock.wabi-api.dev/users";
      } else {
        inputUrl.value = "https://mock.wabi-api.dev/users/1";
      }
    } else {
      inputUrl.value = `https://httpbin.org/${method.toLowerCase()}`;
    }
    saveConfig();
  });

  // Init
  initTabs();
  loadConfig();
});
