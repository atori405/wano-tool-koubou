// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window.
            // Pass the original tab's id through so the standalone window can
            // still target the right tab (it becomes its own focused window,
            // so chrome.tabs.query({currentWindow:true}) would otherwise
            // resolve to itself instead of the page the user wants to affect).
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window&tabId=" + tabs[0].id),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

document.addEventListener('DOMContentLoaded', () => {
  // --- State ---
  let currentTheme = 'light';
  let tokenizerInstance = null;

  // --- Theme Toggle ---
  const themeToggle = document.getElementById('theme-toggle');
  const sunIcon = themeToggle.querySelector('.sun-icon');
  const moonIcon = themeToggle.querySelector('.moon-icon');

  const applyTheme = (theme) => {
    if (theme === 'dark') {
      document.body.classList.remove('light-theme');
      document.body.classList.add('dark-theme');
      sunIcon.style.display = 'none';
      moonIcon.style.display = 'block';
    } else {
      document.body.classList.remove('dark-theme');
      document.body.classList.add('light-theme');
      sunIcon.style.display = 'block';
      moonIcon.style.display = 'none';
    }
    currentTheme = theme;
    localStorage.setItem('furigana-theme', theme);
  };

  const savedTheme = localStorage.getItem('furigana-theme') || 'light';
  applyTheme(savedTheme);

  themeToggle.addEventListener('click', () => {
    applyTheme(currentTheme === 'light' ? 'dark' : 'light');
  });

  // --- Tab Navigation ---
  const navTabs = document.querySelectorAll('.nav-tab');
  const tabContents = document.querySelectorAll('.tab-content');

  navTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const targetTab = tab.getAttribute('data-tab');
      navTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      tabContents.forEach(content => {
        if (content.id === targetTab) {
          content.classList.add('active');
        } else {
          content.classList.remove('active');
        }
      });
    });
  });

  // --- Toast ---
  const toast = document.getElementById('toast');
  const triggerToast = (msg) => {
    toast.textContent = msg;
    toast.classList.remove('hidden');
    setTimeout(() => {
      toast.classList.add('hidden');
    }, 2000);
  };

  // --- Elements ---
  const selectLevel = document.getElementById('select-level');
  const btnInject = document.getElementById('btn-inject');
  const btnRemove = document.getElementById('btn-remove');
  const previewInput = document.getElementById('preview-input');
  const previewOutput = document.getElementById('preview-output');

  // Determine which tab "ページにルビを振る"/"ルビを消去" should actually act on.
  // In the "mode=window" fail-safe (this popup opened as its own standalone
  // OS window because the in-page floating panel could not be reached), this
  // window becomes the focused window, so chrome.tabs.query({currentWindow:true})
  // would resolve to itself rather than the page the user wants to affect.
  // The originating tab's id is passed explicitly in that case.
  const popupUrlParams = new URLSearchParams(window.location.search);
  const explicitTabId = popupUrlParams.get('tabId');
  let targetTabId = explicitTabId ? parseInt(explicitTabId, 10) : null;

  function withTargetTab(callback) {
    if (targetTabId) {
      chrome.tabs.get(targetTabId, (tab) => {
        callback(chrome.runtime.lastError ? null : tab);
      });
    } else {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const tab = tabs && tabs[0] ? tabs[0] : null;
        targetTabId = tab ? tab.id : null;
        callback(tab);
      });
    }
  }

  // Grade level Kanji definitions
  const grade1_3 = "一右雨円王音下火花貝学気九休玉金空月犬見五口校左三山子四糸字耳七車手十出女小上森人水正生青夕石赤千川先早草足村大男竹中虫町天田土二日入年白八百文木本名目立力林六引羽雲園遠何科夏家歌画回会海絵外角楽活間丸岩顔汽記帰弓牛魚京強教近兄形計元言原戸古午後語工公広交光考行高黄合谷国黒今才細作算止市矢姉思紙寺自時室社弱首秋週春書少場色食心新親図数西声星晴切雪船線前組走多太体台地池知茶昼長鳥朝直通弟店点電刀冬当東答頭同道読内南肉馬売買麦半番父風分聞米歩母方北毎妹万明鳴毛門夜野友用曜来里理話悪安暗医委意育員院飲運泳駅央横屋温化荷界開階寒感漢館岸起期客究急級宮球去橋業曲局銀区苦具君係軽血決研県庫湖向幸港号根祭皿仕死使始指歯詩次事持式実写者主守取酒受州拾終習集住重宿所暑助昭消商章勝乗植申身神真深進世整昔全相送想息速族他打対待代第題炭短談着注柱丁帳調追定庭笛鉄転都度投豆島湯登等動童農波配倍箱畑発反坂板皮悲美鼻筆氷表秒病品負部服福物平返勉放味命面問役薬由油有遊予羊洋葉陽様落流旅両緑礼列練路和";
  const jouyou = "亜哀挨愛曖悪握圧扱宛嵐安案暗以衣位囲医依委威為畏胃尉異移萎偉椅彙意違維慰遺緯域育一壱逸茨芋引印因咽姻員院水陰飲隠韻右宇羽雨唄鬱畝浦運雲永泳英映栄営詠影鋭衛易疫益液駅悦越謁閲円延沿炎怨宴媛援園煙猿遠鉛塩演縁艶汚王凹央応往押旺欧殴桜翁奥横岡屋億憶臆虞乙俺卸音恩温穏下化火加可仮何花佳価果河苛科架夏家荷華菓貨渦過嫁暇禍靴寡歌箇稼課蚊牙瓦我画芽賀雅餓介回灰会快戒改怪拐悔海界皆械絵開階塊楷解潰壊懐諧貝外劾害崖涯街慨蓋該概骸垣柿各角拡革格核殻郭覚較隔閣確獲嚇穫学岳楽額顎掛潟括活喝渇割艸滑褐轄且株釜鎌刈干刊甘汗缶完肝官冠巻看陥乾勘患貫寒喚堪換敢棺款間閑勧寛幹感漢慣管関歓監緩憾還館環簡観韓艦鑑丸含岸岩玩眼頑顔願企伎危机気岐希忌汽奇祈季紀軌既記起飢鬼帰基寄規亀喜幾揮期棋貴棄毀旗器畿輝機騎技宜偽欺義疑儀戯擬犠議菊吉喫詰却客脚逆虐九久及弓丘旧休吸朽臼求究泣急級糾宮球給嗅窮牛去巨居拒拠挙虚許距魚御漁凶共叫狂京享供協況峡挟狭恐恭胸脅強教郷境橋矯鏡競響驚仰暁業凝曲局極玉巾斤均近金菌勤琴筋人禁緊錦謹襟吟銀区句苦駆具心愚空偶遇隅串屈掘窟熊繰君訓勲薫軍郡群兄刑形系径茎係型契計恵啓掲渓経蛍敬景軽傾携継詣慶憬禾憩警鶏芸迎鯨隙劇撃激桁欠穴血決結傑潔月犬件見券肩建研県倹兼剣拳軒健険圏堅検嫌献絹遣権憲賢謙鍵繭顕験懸元幻玄言弦限原現舷減源厳己戸古呼固股虎孤弧故枯個庫湖雇誇鼓錮顧五互午呉後娯悟碁語誤護口工公勾孔功巧広甲交光向后好江考行坑孝抗攻更効幸拘肯侯厚恒洪皇紅荒郊香候校耕航貢降高康控梗黄喉慌港硬絞項溝鉱構綱酵稿興衡鋼講購乞号合拷剛傲豪克告谷刻国黒穀酷獄骨駒込頃今困昆恨根婚混痕紺魂墾懇左佐沙査砂唆差詐鎖座挫才再災妻采砕宰栽彩採済祭斎細菜最裁債催塞歳載際埼在材剤財罪崎作削昨柵索策酢搾錯咲冊札刷刹拶殺察撮擦雑皿三山参桟蚕惨産傘散算酸賛残斬暫士子支止氏仕史司四市矢旨死糸至伺志私使刺始姉枝祉肢姿思指施師恣紙脂視紫詞歯嗣試詩資飼誌雌摯賜諮示字寺次耳自似児事侍治持時滋慈辞磁食璽鹿式識軸七𠮟失室疾執湿嫉漆質実芝写社車舎者射捨赦斜煮遮謝邪蛇勺尺借酌釈爵若弱寂手主守朱取狩首殊珠酒腫種趣寿受呪授需儒樹収囚州舟秀周宗拾秋臭修袖終羞習週就衆集愁酬醜蹴襲十汁充住柔重従渋銃獣縦叔祝宿淑粛縮塾熟出述術俊春瞬旬巡盾准殉純循順準潤遵処初所書庶暑署緒諸女如助序叙徐除小升少召匠床抄肖尚招承昇松沼昭宵将消症祥称笑唱商渉章紹訟勝掌晶焼焦硝粧詔証象傷奨照詳彰障憧衝賞償礁鐘上丈冗条状乗城浄剰常情場畳蒸縄壌嬢錠譲醸色拭植殖飾触嘱織職辱尻申伸臣芯身辛侵信津神唇娠振浸真針深紳進森診寝慎新審震薪親刃仁尽迅甚陣尋腎須図吹垂炊帥粋衰推酔遂睡穂錘随髄枢崇数据杉裾寸瀬是井世正生成西声制姓征性青斉政星牲省凄逝清盛婿晴勢聖誠精製誓静請整醒税夕斥石赤昔析席脊隻惜戚責跡積績籍切折拙窃接設雪摂節説舌絶千川仙占先宣専泉浅洗染扇栓旋船戦羨腺践箋銭銑潜線遷選薦繊鮮全前善然禅漸膳繕狙阻祖租素措粗組疎訴塑辵礎双壮早争走奏相荘草送倉捜挿桑巣掃曹曽爽窓創喪痩葬装僧想層総遭槽踪操燥霜騒藻造像増憎蔵贈臓即束足促則息捉速側測俗族属賊続卒率存村孫尊損他多汰打妥唾堕惰駄太対体耐待怠胎退帯泰堆袋逮替貸隊滞態戴大代台第題滝宅択沢卓拓託濯諾濁但達脱奪棚誰丹旦担単炭胆探淡短嘆端綻誕鍛団男段断弾暖談壇地池知値恥致遅痴稚置緻竹畜逐蓄築秩窒茶着嫡中仲虫沖宙忠抽注昼柱衷酎鋳駐著貯丁弔庁兆町長挑帳張彫眺釣頂鳥朝脹貼超腸跳徴潮澄調聴懲直勅沈珍朕陳賃鎮追椎墜通痛塚漬坪爪鶴低呈廷弟定底抵邸亭貞帝訂庭逓停偵堤提程艇締諦泥的笛摘滴適敵迭哲鉄徹撤天典店点展添転土田伝殿電斗吐妬徒途都渡塗奴努度怒刀冬灯当投豆東到逃倒凍唐島桃討透党悼盗陶塔搭棟湯痘登答等筒統稲踏糖頭謄藤闘騰同洞胴動堂童道働銅導瞳峠匿特得督徳篤毒独読栃凸突届屯豚頓貪鈍曇丼那奈内梨鍋南軟難二尼弐匂肉虹日入乳尿任妊忍認寧熱年念捻粘燃悩納能脳農濃把波派破覇馬婆罵拝杯背肺俳配排敗廃輩売倍梅培陪媒買賠白伯拍泊迫舶博薄麦漠縛爆箱畑肌八鉢発髪伐抜罰閥反半氾犯帆汎伴判坂阪板版班畔般販斑飯搬煩頒範繁藩晩番蛮盤比皮妃否批彼披肥非卑飛疲秘被悲扉費碑罷避尾眉美備微鼻膝肘匹必泌筆姫百氷表俵票評漂標苗秒病描猫品浜貧賓頻敏瓶不夫父付布扶府怖阜附訃負赴浮婦符富普腐敷膚賦譜侮武部舞封風伏服副幅復福腹複覆払沸仏物粉紛雰噴墳憤奮分文聞丙平兵併並柄陛閉塀幣弊米壁璧癖別蔑片辺返変偏遍編弁便勉歩保哺捕補舗母募墓慕暮簿方包芳邦奉宝抱放法泡胞俸倣峰砲崩訪報蜂豊飽褒縫亡乏忙坊妨忘防房肪某冒剖紡望傍帽棒貿貌暴膨謀頁北木朴牧睦僕墨撲没勃堀本奔翻凡盆麻摩磨魔毎妹枚昧埋幕膜枕又末抹万満慢漫未味魅岬密蜜脈妙民眠矛務無夢霧娘名命明迷冥盟銘鳴滅免面綿麺茂模毛妄盲耗猛網目黙門紋問匁冶夜野弥厄役約訳薬躍闇由油喩愉諭輸癒唯友有勇幽悠郵湧裕遊雄誘憂融優与予余誉預幼用羊妖洋要容庸揚揺葉陽溶腰様瘍踊窯養擁謡曜抑沃浴欲翌翼ラ裸羅来雷頼絡落酪辣乱卵覧濫藍欄吏利里理痢裏履璃離陸立律慄略柳流留竜粒隆硫侶旅虜慮両良料涼猟陵量僚領寮療瞭糧力緑林厘倫輪隣臨瑠涙累塁類令礼冷励戻例鈴零霊隷齢麗暦歴列劣烈裂恋連廉練錬呂炉賂路露老労弄郎朗浪廊楼漏籠六録麓論和話賄脇惑枠湾腕";

  const toHiragana = (katakana) => {
    return katakana.replace(/[\u30a1-\u30f6]/g, (match) => {
      return String.fromCharCode(match.charCodeAt(0) - 0x60);
    });
  };

  const getRubyHtml = (surface, readingKana) => {
    const reading = toHiragana(readingKana);

    // If surface is all kanji, wrap the whole thing (with ES6 /u flag for surrogate pairs)
    if (surface.match(/^[\u{4e00}-\u{9faf}\u{3400}-\u{4dbf}\u{20000}-\u{2fa1f}]+$/u)) {
      return `<ruby>${surface}<rt>${reading}</rt></ruby>`;
    }

    // Okurigana match from tail
    let sIndex = surface.length - 1;
    let rIndex = reading.length - 1;
    while (sIndex >= 0 && rIndex >= 0 && surface[sIndex] === reading[rIndex]) {
      sIndex--;
      rIndex--;
    }

    // Okurigana match from head
    let sHead = 0;
    let rHead = 0;
    while (sHead <= sIndex && rHead <= rIndex && surface[sHead] === reading[rHead]) {
      sHead++;
      rHead++;
    }

    const leadPart = surface.slice(0, sHead);
    const middleKanji = surface.slice(sHead, sIndex + 1);
    const middleReading = reading.slice(rHead, rIndex + 1);
    const okuriPart = surface.slice(sIndex + 1);

    if (middleKanji.match(/[\u{4e00}-\u{9faf}\u{3400}-\u{4dbf}\u{20000}-\u{2fa1f}]/u)) {
      return `${leadPart}<ruby>${middleKanji}<rt>${middleReading}</rt></ruby>${okuriPart}`;
    }

    return `<ruby>${surface}<rt>${reading}</rt></ruby>`;
  };

  const shouldApplyRuby = (surface, selectLevel) => {
    // ES6 /u flag supports surrogate pairs
    const kanjiChars = surface.match(/[\u{4e00}-\u{9faf}\u{3400}-\u{4dbf}\u{20000}-\u{2fa1f}]/gu);
    if (!kanjiChars) return false;

    if (selectLevel === 'elementary_low') {
      return true; // Apply to all Kanji
    }

    if (selectLevel === 'elementary_high') {
      // Filter out Grade 1-3 Kanji
      return kanjiChars.some(char => !grade1_3.includes(char));
    }

    if (selectLevel === 'junior_high') {
      // Filter out Jouyou Kanji
      return kanjiChars.some(char => !jouyou.includes(char));
    }

    if (selectLevel === 'jlpt_n3') {
      // Filter out Grade 1-3 Kanji (covering JLPT N4/N5 basics)
      return kanjiChars.some(char => !grade1_3.includes(char));
    }

    return false;
  };

  // Local popup tokenizer builder
  const getTokenizer = (callback) => {
    if (tokenizerInstance) {
      callback(null, tokenizerInstance);
      return;
    }

    if (!window.kuromoji) {
      callback(new Error("Kuromoji library not loaded."), null);
      return;
    }

    const dicPath = chrome.runtime.getURL("dict/");
    window.kuromoji.builder({ dicPath: dicPath }).build((err, tokenizer) => {
      if (err) {
        callback(err, null);
      } else {
        tokenizerInstance = tokenizer;
        callback(null, tokenizer);
      }
    });
  };

  // Local popup preview generator
  const updatePreview = () => {
    const text = previewInput.value;
    const level = selectLevel.value;

    if (!text.trim()) {
      previewOutput.textContent = '';
      return;
    }

    getTokenizer((err, tokenizer) => {
      if (err) {
        const errMsg = err.message || err.type || (typeof err === 'object' ? JSON.stringify(err) : String(err));
        previewOutput.innerHTML = `<span style="color: var(--accent); font-size: 11px;">ルビ用辞書の初期化に失敗しました。詳細: ${errMsg}</span>`;
        return;
      }

      let html = "";
      const tokens = tokenizer.tokenize(text);

      tokens.forEach(token => {
        const surface = token.surface_form;
        const reading = token.reading;

        if (reading && shouldApplyRuby(surface, level)) {
          html += getRubyHtml(surface, reading);
        } else {
          html += surface;
        }
      });

      previewOutput.innerHTML = html.replace(/\n/g, '<br>');
    });
  };

  previewInput.addEventListener('input', updatePreview);
  selectLevel.addEventListener('change', updatePreview);

  // Active page injection triggers
  btnInject.addEventListener('click', () => {
    const level = selectLevel.value;

    if (chrome.tabs && chrome.scripting) {
      withTargetTab((activeTab) => {
        if (!activeTab || !activeTab.id || !activeTab.url || activeTab.url.startsWith('chrome://') || activeTab.url.startsWith('chrome-extension://')) {
          triggerToast('通常のウェブページ上で実行してください！');
          return;
        }

        btnInject.disabled = true;
        btnInject.querySelector('span').textContent = 'ルビ処理中...';

        // 1. Inject kuromoji.js library
        chrome.scripting.executeScript({
          target: { tabId: activeTab.id },
          files: ['lib/kuromoji.js']
        }, () => {
          // 2. Inject content.js
          chrome.scripting.executeScript({
            target: { tabId: activeTab.id },
            files: ['content.js']
          }, () => {
            // 3. Trigger inject function
            chrome.scripting.executeScript({
              target: { tabId: activeTab.id },
              func: (level) => {
                if (window.furiganaScript) {
                  window.furiganaScript.inject(level, (err) => {
                    if (err) console.error("Furigana script execution error:", err);
                  });
                }
              },
              args: [level]
            }, () => {
              btnInject.disabled = false;
              btnInject.querySelector('span').textContent = 'ページにルビを振る';
              triggerToast('ルビ振りを完了しました！');
            });
          });
        });
      });
    } else {
      triggerToast('開発モード: ポップアップのプレビューをご確認ください！');
    }
  });

  btnRemove.addEventListener('click', () => {
    if (chrome.tabs && chrome.scripting) {
      withTargetTab((activeTab) => {
        if (!activeTab || !activeTab.id || !activeTab.url || activeTab.url.startsWith('chrome://') || activeTab.url.startsWith('chrome-extension://')) {
          triggerToast('通常のウェブページ上で実行してください！');
          return;
        }

        chrome.scripting.executeScript({
          target: { tabId: activeTab.id },
          func: () => {
            if (window.furiganaScript) {
              window.furiganaScript.remove();
            }
          }
        }, () => {
          triggerToast('ルビを消去しました。');
        });
      });
    } else {
      triggerToast('開発モード: ルビをクリアしました。');
    }
  });

  // Initial preview render
  updatePreview();
});
