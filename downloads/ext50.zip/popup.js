// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window&tabId=" + tabs[0].id),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// ============================================
// 文字化けレスキュー — Popup Logic
// ============================================

document.addEventListener("DOMContentLoaded", () => {
  // Wrong-tab fix: when opened as a standalone popup window (mode=window),
  // chrome.tabs.query({currentWindow:true}) would resolve to this window itself,
  // not the original page tab, so use the explicitly passed tabId when present.
  const urlParams = new URLSearchParams(window.location.search);
  const explicitTabId = urlParams.get("tabId") ? parseInt(urlParams.get("tabId"), 10) : null;

  const btnAuto = document.getElementById("btn-auto");
  const btnSjis = document.getElementById("btn-sjis");
  const btnEuc = document.getElementById("btn-euc");
  const btnGb18030 = document.getElementById("btn-gb18030");
  const btnEuckr = document.getElementById("btn-euckr");
  const btnRevert = document.getElementById("btn-revert");
  const btnRegisterAuto = document.getElementById("btn-register-auto");
  const btnUnregisterAuto = document.getElementById("btn-unregister-auto");
  const autoRescueStatus = document.getElementById("auto-rescue-status");
  const statusText = document.getElementById("status-text");

  let lastUsedEncoding = "auto";

  function getActiveTab(callback) {
    if (explicitTabId) {
      chrome.tabs.get(explicitTabId, (tab) => {
        if (chrome.runtime.lastError || !tab) {
          callback(null);
          return;
        }
        callback(tab);
      });
      return;
    }
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0] && tabs[0].id) {
        callback(tabs[0]);
      } else {
        callback(null);
      }
    });
  }

  function sendRescueMessage(encoding) {
    lastUsedEncoding = encoding;
    statusText.textContent = "修復処理を実行中...";
    statusText.style.color = "#ffb74d";

    getActiveTab((tab) => {
      if (!tab) {
        statusText.textContent = "エラー：タブが見つかりません";
        statusText.style.color = "#ff5252";
        return;
      }
      chrome.tabs.sendMessage(tab.id, { action: "rescueEncoding", encoding }, (response) => {
        if (chrome.runtime.lastError || !response || response.status !== "processing") {
          statusText.textContent = "エラー：実行できません";
          statusText.style.color = "#ff5252";
        } else {
          statusText.textContent = "修復が完了しました！";
          statusText.style.color = "#2ecc71";
          setTimeout(() => {
            statusText.textContent = "レスキュー待機中";
            statusText.style.color = "";
          }, 3000);
        }
      });
    });
  }

  if (btnAuto) {
    btnAuto.addEventListener("click", () => sendRescueMessage("auto"));
  }
  if (btnSjis) {
    btnSjis.addEventListener("click", () => sendRescueMessage("shift_jis"));
  }
  if (btnEuc) {
    btnEuc.addEventListener("click", () => sendRescueMessage("euc-jp"));
  }
  if (btnGb18030) {
    btnGb18030.addEventListener("click", () => sendRescueMessage("gb18030"));
  }
  if (btnEuckr) {
    btnEuckr.addEventListener("click", () => sendRescueMessage("euc-kr"));
  }

  if (btnRevert) {
    btnRevert.addEventListener("click", () => {
      statusText.textContent = "再読み込み中...";
      getActiveTab((tab) => {
        if (tab) {
          chrome.tabs.reload(tab.id);
          window.close();
        }
      });
    });
  }

  // --- Domain Auto-Rescue Registration ---
  function refreshAutoRescueStatus() {
    getActiveTab((tab) => {
      if (!tab) return;
      chrome.tabs.sendMessage(tab.id, { action: "getAutoRescueStatus" }, (response) => {
        if (chrome.runtime.lastError || !response) return;
        if (response.encoding) {
          autoRescueStatus.textContent = `✅ このサイトは登録済みです（${response.encoding === "auto" ? "自動判定" : response.encoding}）`;
        } else {
          autoRescueStatus.textContent = "このサイトは自動修復リストに登録されていません。";
        }
      });
    });
  }

  if (btnRegisterAuto) {
    btnRegisterAuto.addEventListener("click", () => {
      getActiveTab((tab) => {
        if (!tab) return;
        chrome.tabs.sendMessage(tab.id, { action: "registerAutoRescue", encoding: lastUsedEncoding }, () => {
          refreshAutoRescueStatus();
        });
      });
    });
  }

  if (btnUnregisterAuto) {
    btnUnregisterAuto.addEventListener("click", () => {
      getActiveTab((tab) => {
        if (!tab) return;
        chrome.tabs.sendMessage(tab.id, { action: "unregisterAutoRescue" }, () => {
          refreshAutoRescueStatus();
        });
      });
    });
  }

  refreshAutoRescueStatus();
});
