// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// ============================================
// 文字化けレスキュー — Popup Logic
// ============================================

document.addEventListener("DOMContentLoaded", () => {
  const btnSjis = document.getElementById("btn-sjis");
  const btnEuc = document.getElementById("btn-euc");
  const btnRevert = document.getElementById("btn-revert");
  const statusText = document.getElementById("status-text");

  function sendRescueMessage(encoding) {
    statusText.textContent = "修復処理を実行中...";
    statusText.style.color = "#ffb74d";

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0] && tabs[0].id) {
        chrome.tabs.sendMessage(tabs[0].id, { action: "rescueEncoding", encoding }, (response) => {
          if (chrome.runtime.lastError || !response || response.status !== "processing") {
            statusText.textContent = "エラー：実行できません";
            statusText.style.color = "#ff5252";
          } else {
            statusText.textContent = "修復が完了しました！";
            statusText.style.color = "#2ecc71";
            setTimeout(() => {
              statusText.textContent = "レスキュー待機中";
              statusText.style.color = "";
            }, 3000);
          }
        });
      } else {
        statusText.textContent = "エラー：タブが見つかりません";
        statusText.style.color = "#ff5252";
      }
    });
  }

  if (btnSjis) {
    btnSjis.addEventListener("click", () => sendRescueMessage("shift_jis"));
  }
  if (btnEuc) {
    btnEuc.addEventListener("click", () => sendRescueMessage("euc-jp"));
  }
  
  if (btnRevert) {
    btnRevert.addEventListener("click", () => {
      statusText.textContent = "再読み込み中...";
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0] && tabs[0].id) {
          chrome.tabs.reload(tabs[0].id);
          window.close();
        }
      });
    });
  }
});
