// content.js - Mojibake Rescue Content Script
(function () {
  "use strict";

  const NS_ID = "wano-" + chrome.runtime.id;

  // Candidate encodings tried by auto-detection, in no particular priority
  // order (the scoring heuristic below picks the best-fitting one).
  const AUTO_DETECT_ENCODINGS = ["shift_jis", "euc-jp", "gb18030", "euc-kr"];

  // --- 1. Message Listener for Rescue Operations ---
  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "rescueEncoding" && message.encoding) {
        if (message.encoding === "auto") {
          autoDetectAndRescue().then(() => sendResponse({ status: "processing" }));
        } else {
          rescuePageEncoding(message.encoding);
          sendResponse({ status: "processing" });
        }
      } else if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      } else if (message.action === "registerAutoRescue") {
        setAutoRescueForCurrentDomain(message.encoding);
        sendResponse({ status: "registered" });
      } else if (message.action === "unregisterAutoRescue") {
        setAutoRescueForCurrentDomain(null);
        sendResponse({ status: "unregistered" });
      } else if (message.action === "getAutoRescueStatus") {
        getAutoRescueForCurrentDomain((encoding) => sendResponse({ encoding }));
        return true; // async response
      }
      return true;
    });
  }

  // 実際にページを再取得し、指定エンコーディングでデコードした文字列を返す
  // （書き換えは呼び出し側が行う — auto-detect はまず候補を比較する必要があるため）。
  async function fetchAndDecode(encoding, fatal) {
    const url = window.location.href;
    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
      }
    });
    if (!response.ok) {
      throw new Error("HTTP error! Status: " + response.status);
    }
    const buffer = await response.arrayBuffer();
    const decoder = new TextDecoder(encoding, { fatal: !!fatal });
    return decoder.decode(new Uint8Array(buffer));
  }

  function rewriteDocument(decodedHtml) {
    document.open();
    document.write(decodedHtml);
    document.close();
  }

  /**
   * 現在のページの元のバイナリデータを再取得し、
   * 指定されたエンコーディングでデコードしてドキュメントを上書きします。
   */
  async function rescuePageEncoding(encoding) {
    try {
      const decodedHtml = await fetchAndDecode(encoding, false);
      rewriteDocument(decodedHtml);
      console.log("文字化けレスキュー: " + encoding + " での再デコード修復に成功しました。");
    } catch (error) {
      console.error("文字化けレスキューの実行に失敗しました:", error);
      alert("ページの再取得と修復に失敗しました。CORSポリシー制限、または認証が必要なページの可能性があります。");
    }
  }

  // 候補エンコーディングをそれぞれ厳格モード（fatal: true）で試し、
  // 不正なバイト列としてエラーになったものは除外する。複数成功した場合は、
  // 日本語・中国語・韓国語の実際の文字が最も多く含まれるものを採用する
  // （AIではなく、単純な文字種カウントによるヒューリスティック判定）。
  function scoreDecodedText(text) {
    const hiragana = (text.match(/[ぁ-ん]/g) || []).length;
    const katakana = (text.match(/[ァ-ヶー]/g) || []).length;
    const kanji = (text.match(/[一-鿿]/g) || []).length;
    const hangul = (text.match(/[가-힣]/g) || []).length;
    const replacementChars = (text.match(/�/g) || []).length;
    // Hiragana/katakana/hangul are strong, near-unique signals for their
    // languages (they essentially never appear by decoding a DIFFERENT
    // encoding's bytes by coincidence). Kanji/Han ideographs overlap between
    // Japanese and Chinese and are common false-positive bait for permissive
    // encodings like GB18030, which rarely throws even on garbage input, so
    // they're weighted far lower.
    return (hiragana + katakana + hangul) * 10 + kanji - replacementChars * 50;
  }

  async function detectBestEncoding() {
    let bestEncoding = null;
    let bestScore = -Infinity;
    let bestText = null;

    for (const encoding of AUTO_DETECT_ENCODINGS) {
      try {
        const text = await fetchAndDecode(encoding, true); // fatal: throws on invalid byte sequences
        const score = scoreDecodedText(text);
        if (score > bestScore) {
          bestScore = score;
          bestEncoding = encoding;
          bestText = text;
        }
      } catch (e) {
        // This encoding produced an invalid byte sequence for this content - skip it.
      }
    }

    // Fallback: no candidate decoded cleanly in fatal mode (e.g. genuinely
    // mixed/corrupted bytes) - fall back to a lenient Shift_JIS decode so
    // something is still shown rather than nothing.
    if (!bestEncoding) {
      const text = await fetchAndDecode("shift_jis", false);
      return { encoding: "shift_jis", text };
    }
    return { encoding: bestEncoding, text: bestText };
  }

  async function autoDetectAndRescue() {
    try {
      const { encoding, text } = await detectBestEncoding();
      rewriteDocument(text);
      console.log("文字化けレスキュー: 自動判定により " + encoding + " と推定し修復しました。");
    } catch (error) {
      console.error("文字化けレスキュー（自動判定）の実行に失敗しました:", error);
      alert("ページの再取得と修復に失敗しました。CORSポリシー制限、または認証が必要なページの可能性があります。");
    }
  }

  // --- ドメイン自動修復登録 ---
  function setAutoRescueForCurrentDomain(encoding) {
    if (!(typeof chrome !== "undefined" && chrome.storage)) return;
    const host = window.location.hostname;
    chrome.storage.local.get(["autoRescueDomains"], (res) => {
      const map = res.autoRescueDomains || {};
      if (encoding) {
        map[host] = encoding;
      } else {
        delete map[host];
      }
      chrome.storage.local.set({ autoRescueDomains: map });
    });
  }

  function getAutoRescueForCurrentDomain(callback) {
    if (!(typeof chrome !== "undefined" && chrome.storage)) {
      callback(null);
      return;
    }
    const host = window.location.hostname;
    chrome.storage.local.get(["autoRescueDomains"], (res) => {
      const map = res.autoRescueDomains || {};
      callback(map[host] || null);
    });
  }

  // ページ読み込み時、このドメインが自動修復リストに登録されていれば、
  // ボタン操作なしで自動的に修復を実行する。
  function checkAutoRescueOnLoad() {
    getAutoRescueForCurrentDomain((encoding) => {
      if (!encoding) return;
      if (encoding === "auto") {
        autoDetectAndRescue();
      } else {
        rescuePageEncoding(encoding);
      }
    });
  }
  checkAutoRescueOnLoad();

  // --- 2. Universal Floating Panel Loader ---
  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      const existingShield = document.getElementById(NS_ID + "-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = NS_ID + "-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById(NS_ID + "-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById(NS_ID + "-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "flex" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = NS_ID + "-floating-container";

    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 452) + "px !important; z-index:2147483647 !important; width:442px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="${NS_ID}-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">🚨</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">文字化けレスキュー</span>
        </div>
        <button id="${NS_ID}-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#" + NS_ID + "-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#" + NS_ID + "-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }
})();
