// background.js - Mojibake Rescue background service worker

chrome.runtime.onInstalled.addListener(() => {
  console.log("文字化けレスキュー 拡張機能が正常にインストールされました。");
});
