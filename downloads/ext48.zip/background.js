// background.js - Service Worker for Visual CSS Grid / Genkouyoushi Checker

chrome.runtime.onInstalled.addListener(() => {
  console.log("視覚的CSSグリッド確認君 拡張機能が正常にインストールされました。");
});

// Listen for action click to inject the floating panel
chrome.action.onClicked.addListener((tab) => {
  if (!tab.url.startsWith("chrome://") && !tab.url.startsWith("edge://")) {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });
  }
});
