// background.js - Service Worker for Visual CSS Grid / Genkouyoushi Checker

chrome.runtime.onInstalled.addListener(() => {
  console.log("視覚的CSSグリッド確認君 拡張機能が正常にインストールされました。");
});

// Listen for action click to toggle the floating panel.
// There is no default_popup, so this is the only entry point into the UI:
// try messaging the already-running content script first (fast path for
// pages that loaded after install), and if nothing responds (e.g. the
// extension was just installed/updated and this tab's content script never
// ran), inject content.js fresh and then send the toggle message.
chrome.action.onClicked.addListener((tab) => {
  if (!tab.id || !tab.url || tab.url.startsWith("chrome://") || tab.url.startsWith("edge://")) return;

  chrome.tabs.sendMessage(tab.id, { action: "toggleFloatingPanel" }, (response) => {
    if (chrome.runtime.lastError || !response || response.status !== "toggled") {
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      }, () => {
        if (chrome.runtime.lastError) return;
        chrome.tabs.sendMessage(tab.id, { action: "toggleFloatingPanel" });
      });
    }
  });
});
