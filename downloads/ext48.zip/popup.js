// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// popup.js - Visual CSS Grid / Genkouyoushi Checker Core

document.addEventListener("DOMContentLoaded", () => {
  // --- 1. Element References ---
  const toggleGrid = document.getElementById("toggle-grid");
  const inputGridSize = document.getElementById("input-grid-size");
  const gridSizeVal = document.getElementById("grid-size-val");
  
  const toggleInspector = document.getElementById("toggle-inspector");
  const toggleWrapDebug = document.getElementById("toggle-wrap-debug");
  
  const wrapReportSection = document.getElementById("wrap-report-section");
  const wrapErrorCount = document.getElementById("wrap-error-count");
  const wrapErrorList = document.getElementById("wrap-error-list");

  // --- 2. Shared Helpers to query active tab ---
  function queryActiveTab(callback) {
    if (window.chrome && chrome.tabs) {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0]) {
          callback(tabs[0]);
        }
      });
    } else {
      callback(null); // Simulator mode
    }
  }

  // --- 3. Grid Controls Logic ---
  function updateGridState() {
    const isEnabled = toggleGrid.checked;
    const size = parseInt(inputGridSize.value);
    gridSizeVal.textContent = size;
    saveConfig();

    queryActiveTab((tab) => {
      if (tab) {
        // Extension mode
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: setPageGridState,
          args: [isEnabled, size]
        });
      } else {
        // Simulator mode
        const demoPage = document.getElementById("demo-page-container");
        if (demoPage) {
          applyLocalGridState(demoPage, isEnabled, size);
        }
      }
    });
  }

  // Injected function for tab grid overlay
  function setPageGridState(enabled, size) {
    let grid = document.getElementById("wabi-genkou-grid-overlay");
    if (!enabled) {
      if (grid) grid.remove();
      return;
    }

    if (!grid) {
      grid = document.createElement("div");
      grid.id = "wabi-genkou-grid-overlay";
      grid.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; pointer-events:none; z-index:99998; opacity:0.85; transition: background-size 0.1s;";
      document.body.appendChild(grid);
    }

    // Genkouyoushi-style grid: vertical and horizontal lines creating cells
    // We use moegi color for grid lines (raised opacity to 0.4 for clear visibility)
    grid.style.backgroundImage = `
      linear-gradient(rgba(170, 207, 83, 0.4) 1px, transparent 1px),
      linear-gradient(90deg, rgba(170, 207, 83, 0.4) 1px, transparent 1px)
    `;
    grid.style.backgroundSize = `${size}px ${size}px`;
  }

  function applyLocalGridState(container, enabled, size) {
    let grid = container.querySelector("#wabi-genkou-grid-overlay-local");
    if (!enabled) {
      if (grid) grid.remove();
      return;
    }

    if (!grid) {
      grid = document.createElement("div");
      grid.id = "wabi-genkou-grid-overlay-local";
      grid.style.cssText = "position:absolute; top:0; left:0; width:100%; height:100%; pointer-events:none; z-index:10; opacity:0.85; border-radius:10px;";
      container.style.position = "relative";
      container.appendChild(grid);
    }

    grid.style.backgroundImage = `
      linear-gradient(rgba(170, 207, 83, 0.4) 1px, transparent 1px),
      linear-gradient(90deg, rgba(170, 207, 83, 0.4) 1px, transparent 1px)
    `;
    grid.style.backgroundSize = `${size}px ${size}px`;
  }

  // --- 4. Hover Inspector Spacing Logic ---
  function updateInspectorState() {
    const isEnabled = toggleInspector.checked;
    saveConfig();

    queryActiveTab((tab) => {
      if (tab) {
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: setPageInspectorState,
          args: [isEnabled]
        });
      } else {
        // Simulator mode
        const demoPage = document.getElementById("demo-page-container");
        if (demoPage) {
          setLocalInspectorState(demoPage, isEnabled);
        }
      }
    });
  }

  // Injected spacing inspector
  function setPageInspectorState(enabled) {
    const HIGHLIGHT_ID = "wabi-spacing-highlighter-block";
    const TOOLTIP_ID = "wabi-spacing-tooltip-block";
    
    // Clear previous
    const cleanUp = () => {
      const h = document.getElementById(HIGHLIGHT_ID);
      const t = document.getElementById(TOOLTIP_ID);
      if (h) h.remove();
      if (t) t.remove();
      document.querySelectorAll("[data-wabi-inspecting]").forEach(el => {
        el.removeAttribute("data-wabi-inspecting");
      });
    };
    cleanUp();

    if (!enabled) {
      document.removeEventListener("mousemove", handleInspectMove);
      return;
    }

    // Inject CSS block for inspector guides
    let styleBlock = document.getElementById("wabi-inspector-styles-prod");
    if (!styleBlock) {
      styleBlock = document.createElement("style");
      styleBlock.id = "wabi-inspector-styles-prod";
      styleBlock.innerHTML = `
        #wabi-spacing-highlighter-block {
          position: absolute;
          pointer-events: none !important;
          z-index: 99999;
          box-sizing: border-box;
          border: 1px solid rgba(187, 188, 222, 0.6);
        }
        .wabi-spacing-margin-guide {
          position: absolute;
          background-color: rgba(170, 207, 83, 0.28); /* Moegi for Margin */
          box-sizing: border-box;
          pointer-events: none !important;
        }
        .wabi-spacing-padding-guide {
          position: absolute;
          background-color: rgba(187, 188, 222, 0.32); /* Wisteria for Padding */
          box-sizing: border-box;
          pointer-events: none !important;
        }
        #wabi-spacing-tooltip-block {
          position: absolute;
          background-color: rgba(12, 14, 18, 0.95);
          border: 1.5px solid #bbbcde;
          color: #e1e2f0;
          font-family: monospace;
          font-size: 11px;
          padding: 6px 10px;
          border-radius: 4px;
          pointer-events: none !important;
          z-index: 100000;
          box-shadow: 0 4px 15px rgba(0,0,0,0.5);
          line-height: 1.4;
        }
      `;
      document.head.appendChild(styleBlock);
    }

    function handleInspectMove(e) {
      const el = e.target;
      if (!el || el === document.documentElement || el === document.body) return;
      
      // Strict guard check to prevent inspecting the highlight overlay boxes themselves
      if (el.classList.contains("wabi-spacing-margin-guide") || 
          el.classList.contains("wabi-spacing-padding-guide") ||
          el.closest(`#${HIGHLIGHT_ID}`) || 
          el.closest(`#${TOOLTIP_ID}`) ||
          el.id === HIGHLIGHT_ID ||
          el.id === TOOLTIP_ID) {
        return;
      }

      // Skip extension overlay elements
      if (el.id && (el.id.startsWith("wabi-") || el.className.includes("wabi-"))) return;

      // Avoid marking multiple times
      if (el.hasAttribute("data-wabi-inspecting")) return;
      
      // Clear previous
      document.querySelectorAll("[data-wabi-inspecting]").forEach(item => {
        item.removeAttribute("data-wabi-inspecting");
      });
      el.setAttribute("data-wabi-inspecting", "true");

      const rect = el.getBoundingClientRect();
      const style = window.getComputedStyle(el);

      const pTop = parseFloat(style.paddingTop);
      const pRight = parseFloat(style.paddingRight);
      const pBottom = parseFloat(style.paddingBottom);
      const pLeft = parseFloat(style.paddingLeft);

      const mTop = parseFloat(style.marginTop);
      const mRight = parseFloat(style.marginRight);
      const mBottom = parseFloat(style.marginBottom);
      const mLeft = parseFloat(style.marginLeft);

      let container = document.getElementById(HIGHLIGHT_ID);
      if (!container) {
        container = document.createElement("div");
        container.id = HIGHLIGHT_ID;
        document.body.appendChild(container);
      }
      container.innerHTML = "";

      const scrollY = window.scrollY;
      const scrollX = window.scrollX;
      
      const elX = rect.left + scrollX;
      const elY = rect.top + scrollY;

      container.style.top = `${elY - mTop}px`;
      container.style.left = `${elX - mLeft}px`;
      container.style.width = `${rect.width + mLeft + mRight}px`;
      container.style.height = `${rect.height + mTop + mBottom}px`;

      const wTotal = rect.width + mLeft + mRight;
      const hTotal = rect.height + mTop + mBottom;

      const drawBox = (x, y, w, h, cls) => {
        if (w <= 0 || h <= 0) return;
        const box = document.createElement("div");
        box.className = cls;
        box.style.left = `${x}px`;
        box.style.top = `${y}px`;
        box.style.width = `${w}px`;
        box.style.height = `${h}px`;
        box.style.pointerEvents = "none";
        container.appendChild(box);
      };

      // Margins
      drawBox(0, 0, wTotal, mTop, "wabi-spacing-margin-guide");
      drawBox(0, hTotal - mBottom, wTotal, mBottom, "wabi-spacing-margin-guide");
      drawBox(0, mTop, mLeft, rect.height, "wabi-spacing-margin-guide");
      drawBox(wTotal - mRight, mTop, mRight, rect.height, "wabi-spacing-margin-guide");

      // Paddings
      drawBox(mLeft, mTop, rect.width, pTop, "wabi-spacing-padding-guide");
      drawBox(mLeft, mTop + rect.height - pBottom, rect.width, pBottom, "wabi-spacing-padding-guide");
      drawBox(mLeft, mTop + pTop, pLeft, rect.height - pTop - pBottom, "wabi-spacing-padding-guide");
      drawBox(mLeft + rect.width - pRight, mTop + pTop, pRight, rect.height - pTop - pBottom, "wabi-spacing-padding-guide");

      let tooltip = document.getElementById(TOOLTIP_ID);
      if (!tooltip) {
        tooltip = document.createElement("div");
        tooltip.id = TOOLTIP_ID;
        document.body.appendChild(tooltip);
      }
      
      const tag = el.tagName.toLowerCase();
      const clsName = el.className ? `.${el.className.split(" ").join(".")}` : "";
      
      tooltip.innerHTML = `
        <div style="font-weight:bold; color:#bbbcde; margin-bottom:4px;">&lt;${tag}${clsName.slice(0, 30)}&gt;</div>
        <div>Size: ${rect.width.toFixed(0)} × ${rect.height.toFixed(0)} px</div>
        <div style="color:#aacf53; margin-top:2px;">Margin: ${mTop}/${mRight}/${mBottom}/${mLeft} px</div>
        <div style="color:#bbbcde;">Padding: ${pTop}/${pRight}/${pBottom}/${pLeft} px</div>
      `;

      tooltip.style.left = `${elX}px`;
      tooltip.style.top = `${Math.max(elY - mTop - 70, 10)}px`;
    }

    document.addEventListener("mousemove", handleInspectMove);
  }

  // Local simulator hover inspector implementation
  let localInspectHandler = null;
  function setLocalInspectorState(container, enabled) {
    const HIGHLIGHT_ID = "wabi-spacing-highlighter-block-local";
    const TOOLTIP_ID = "wabi-spacing-tooltip-block-local";

    const cleanUp = () => {
      const h = container.querySelector(`#${HIGHLIGHT_ID}`);
      const t = container.querySelector(`#${TOOLTIP_ID}`);
      if (h) h.remove();
      if (t) t.remove();
      container.querySelectorAll("[data-wabi-inspecting]").forEach(el => {
        el.removeAttribute("data-wabi-inspecting");
      });
    };
    cleanUp();

    if (!enabled) {
      if (localInspectHandler) {
        container.removeEventListener("mousemove", localInspectHandler);
        localInspectHandler = null;
      }
      return;
    }

    localInspectHandler = (e) => {
      const el = e.target;
      if (!el || el === container) return;
      
      // Strict guard check for local simulator
      if (el.classList.contains("wabi-spacing-margin-guide") || 
          el.classList.contains("wabi-spacing-padding-guide") ||
          el.closest(`#${HIGHLIGHT_ID}`) || 
          el.closest(`#${TOOLTIP_ID}`) ||
          el.id === HIGHLIGHT_ID ||
          el.id === TOOLTIP_ID) {
        return;
      }

      if (el.id && el.id.startsWith("wabi-")) return;
      if (el.hasAttribute("data-wabi-inspecting")) return;

      container.querySelectorAll("[data-wabi-inspecting]").forEach(item => {
        item.removeAttribute("data-wabi-inspecting");
      });
      el.setAttribute("data-wabi-inspecting", "true");

      const rect = el.getBoundingClientRect();
      const parentRect = container.getBoundingClientRect();
      const style = window.getComputedStyle(el);

      const pTop = parseFloat(style.paddingTop);
      const pRight = parseFloat(style.paddingRight);
      const pBottom = parseFloat(style.paddingBottom);
      const pLeft = parseFloat(style.paddingLeft);

      const mTop = parseFloat(style.marginTop);
      const mRight = parseFloat(style.marginRight);
      const mBottom = parseFloat(style.marginBottom);
      const mLeft = parseFloat(style.marginLeft);

      let highlight = container.querySelector(`#${HIGHLIGHT_ID}`);
      if (!highlight) {
        highlight = document.createElement("div");
        highlight.id = HIGHLIGHT_ID;
        highlight.style.cssText = "position:absolute; pointer-events:none !important; z-index:100; box-sizing:border-box; border:1px solid rgba(187,188,222,0.6);";
        container.appendChild(highlight);
      }
      highlight.innerHTML = "";

      const elX = rect.left - parentRect.left;
      const elY = rect.top - parentRect.top;

      highlight.style.top = `${elY - mTop}px`;
      highlight.style.left = `${elX - mLeft}px`;
      highlight.style.width = `${rect.width + mLeft + mRight}px`;
      highlight.style.height = `${rect.height + mTop + mBottom}px`;

      const wTotal = rect.width + mLeft + mRight;
      const hTotal = rect.height + mTop + mBottom;

      const drawBox = (x, y, w, h, bg, cls) => {
        if (w <= 0 || h <= 0) return;
        const box = document.createElement("div");
        box.className = cls;
        box.style.cssText = `position:absolute; left:${x}px; top:${y}px; width:${w}px; height:${h}px; background-color:${bg}; box-sizing:border-box; pointer-events:none !important;`;
        highlight.appendChild(box);
      };

      // Margins (moegi)
      const mBg = "rgba(170, 207, 83, 0.28)";
      drawBox(0, 0, wTotal, mTop, mBg, "wabi-spacing-margin-guide");
      drawBox(0, hTotal - mBottom, wTotal, mBottom, mBg, "wabi-spacing-margin-guide");
      drawBox(0, mTop, mLeft, rect.height, mBg, "wabi-spacing-margin-guide");
      drawBox(wTotal - mRight, mTop, mRight, rect.height, mBg, "wabi-spacing-margin-guide");

      // Paddings (wisteria)
      const pBg = "rgba(187, 188, 222, 0.32)";
      drawBox(mLeft, mTop, rect.width, pTop, pBg, "wabi-spacing-padding-guide");
      drawBox(mLeft, mTop + rect.height - pBottom, rect.width, pBottom, pBg, "wabi-spacing-padding-guide");
      drawBox(mLeft, mTop + pTop, pLeft, rect.height - pTop - pBottom, pBg, "wabi-spacing-padding-guide");
      drawBox(mLeft + rect.width - pRight, mTop + pTop, pRight, rect.height - pTop - pBottom, pBg, "wabi-spacing-padding-guide");

      // Tooltip
      let tooltip = container.querySelector(`#${TOOLTIP_ID}`);
      if (!tooltip) {
        tooltip = document.createElement("div");
        tooltip.id = TOOLTIP_ID;
        tooltip.style.cssText = "position:absolute; background-color:rgba(12,14,18,0.95); border:1.5px solid #bbbcde; color:#e1e2f0; font-family:monospace; font-size:10px; padding:6px 8px; border-radius:4px; pointer-events:none !important; z-index:101; box-shadow:0 4px 12px rgba(0,0,0,0.5); line-height:1.35;";
        container.appendChild(tooltip);
      }

      tooltip.innerHTML = `
        <div style="font-weight:bold; color:#bbbcde; margin-bottom:3px;">&lt;${el.tagName.toLowerCase()}&gt;</div>
        <div>Size: ${rect.width.toFixed(0)} × ${rect.height.toFixed(0)} px</div>
        <div style="color:#aacf53; margin-top:2px;">Margin: ${mTop}/${mRight}/${mBottom}/${mLeft} px</div>
        <div style="color:#bbbcde;">Padding: ${pTop}/${pRight}/${pBottom}/${pLeft} px</div>
      `;

      tooltip.style.left = `${elX}px`;
      tooltip.style.top = `${Math.max(elY - mTop - 65, 5)}px`;
    };

    container.addEventListener("mousemove", localInspectHandler);
  }

  // --- 5. Japanese Wrap Debugger Logic ---
  function updateWrapDebuggerState() {
    const isEnabled = toggleWrapDebug.checked;
    saveConfig();

    if (!isEnabled) {
      wrapReportSection.style.display = "none";
      queryActiveTab((tab) => {
        if (tab) {
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: cleanPageWrapWarnings
          });
        } else {
          cleanLocalWrapWarnings();
        }
      });
      return;
    }

    queryActiveTab((tab) => {
      if (tab) {
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: scanPageWrapIssues
        }, (results) => {
          if (results && results[0] && results[0].result) {
            displayWrapIssues(results[0].result);
          }
        });
      } else {
        const errors = scanLocalWrapIssues();
        displayWrapIssues(errors);
      }
    });
  }

  // Page scanning script for tab context
  function scanPageWrapIssues() {
    const errors = [];
    const textNodes = document.querySelectorAll("p, span, div, li, a, h1, h2, h3, h4, h5, h6");
    let counter = 0;

    textNodes.forEach(el => {
      // Analyze text containers
      if (el.children.length === 0 && el.textContent.trim().length > 3) {
        const text = el.textContent.trim();
        const style = window.getComputedStyle(el);
        const rect = el.getBoundingClientRect();
        
        // 1. Skip tiny elements
        if (rect.width < 30 || rect.height < 10) return;

        const wordBreak = style.wordBreak;
        const lineBreak = style.lineBreak;
        const overflowWrap = style.overflowWrap;
        const whiteSpace = style.whiteSpace;
        const width = parseFloat(style.width);

        let isIssue = false;
        let reason = "";
        let recommendation = "";

        // Check A: English text overflow due to default break logic (Normal break misses half-width words)
        // If element is small and contains mixed alphanumeric long strings without breaking
        const hasLongEnglishWord = /[A-Za-z0-9_]{15,}/.test(text);
        if (hasLongEnglishWord && wordBreak === "normal" && overflowWrap === "normal" && whiteSpace !== "nowrap") {
          // Check if actual overflow occurred or text is close to container edge
          if (el.scrollWidth > rect.width + 2) {
            isIssue = true;
            reason = "英数字の長い文字列が、折り返し設定不適合により右端を突き破ってはみ出ています。";
            recommendation = "CSSに <code>word-break: break-all;</code> または <code>overflow-wrap: break-word;</code> を適用してください。";
          }
        }

        // Check B: Excessive whitespace due to strict line break or normal wrapping with long words
        // If there's an empty gap on the right margin larger than 2 characters size
        const charSize = parseFloat(style.fontSize) || 16;
        if (rect.width > 60 && wordBreak === "normal") {
          // Simple visual heuristic check: if scrollWidth is normal but right side has too much empty space on wrapped lines
          // We look for elements with long text wrapping that leaves huge empty spaces on the right side
          const hasKinsokuChars = /[、。っッゃャゅュょョ]/.test(text);
          if (hasKinsokuChars && lineBreak === "strict") {
            // Heuristic for strict kinsoku wrap error: too much right padding visually
            // Usually occurs when text alignment is not justified and strict kinsoku pushes punctuation to next line
            if (style.textAlign !== "justify") {
              // Mark element to review
              isIssue = true;
              reason = "日本語の行頭禁則処理（、や小さな「つ」等）により、右端に不自然な巨大な余白スペースが発生しています。";
              recommendation = "CSSに <code>text-align: justify;</code> または <code>line-break: normal;</code> を適用してください。";
            }
          }
        }

        if (isIssue) {
          counter++;
          const id = `wabi-wrap-err-${counter}`;
          el.setAttribute("data-wabi-wrap-err-id", id);
          el.classList.add("wabi-wrap-highlighted-element");

          errors.push({
            id,
            tagName: el.tagName.toLowerCase(),
            text: text.slice(0, 35) + (text.length > 35 ? "..." : ""),
            reason,
            recommendation,
            selector: el.className ? `.${el.className.split(" ").join(".")}` : ""
          });
        }
      }
    });

    return errors;
  }

  function cleanPageWrapWarnings() {
    document.querySelectorAll("[data-wabi-wrap-err-id]").forEach(el => {
      el.classList.remove("wabi-wrap-highlighted-element");
      el.removeAttribute("data-wabi-wrap-err-id");
    });
  }

  // Local simulator version of wrapper scanner
  function scanLocalWrapIssues() {
    const container = document.getElementById("demo-page-container");
    if (!container) return [];

    const errors = [];
    const textNodes = container.querySelectorAll(".wrap-issue-target");
    let counter = 0;

    textNodes.forEach(el => {
      counter++;
      const id = `wabi-wrap-err-${counter}`;
      el.setAttribute("data-wabi-wrap-err-id", id);
      el.classList.add("wabi-wrap-highlighted-element");

      const type = el.getAttribute("data-wrap-type");
      let reason = "折り返し不備が検出されました。";
      let recommendation = "CSSを調整してください。";

      if (type === "overflow") {
        reason = "長い半角英数字（URLなど）が折り返されず、テキストボックスの枠線を突き破ってはみ出しています。";
        recommendation = "CSSに <code>word-break: break-all;</code> または <code>overflow-wrap: break-word;</code> を設定してください。";
      } else if (type === "gap") {
        reason = "行頭禁則処理（小さな「つ」や句読点）が働いたため、右端に約3文字分の不自然な巨大余白が生じています。";
        recommendation = "読みやすさと均等割付のために、CSSに <code>text-align: justify; text-justify: inter-ideograph;</code> を適用してください。";
      }

      errors.push({
        id,
        tagName: el.tagName.toLowerCase(),
        text: el.textContent.trim().slice(0, 35) + "...",
        reason,
        recommendation,
        selector: el.className ? `.${el.className.split(" ").filter(c => c !== "wrap-issue-target" && c !== "wabi-wrap-highlighted-element").join(".")}` : ""
      });
    });

    return errors;
  }

  function cleanLocalWrapWarnings() {
    const container = document.getElementById("demo-page-container");
    if (!container) return;
    container.querySelectorAll("[data-wabi-wrap-err-id]").forEach(el => {
      el.classList.remove("wabi-wrap-highlighted-element");
      el.removeAttribute("data-wabi-wrap-err-id");
    });
  }

  // Render scan outputs inside popup
  function displayWrapIssues(errors) {
    wrapReportSection.style.display = "flex";
    wrapErrorCount.textContent = `${errors.length}件`;
    wrapErrorList.innerHTML = "";

    if (errors.length === 0) {
      wrapErrorList.innerHTML = `<div class="wrap-success-box">🎉 日本語の折り返しや禁則による目立ったレイアウト崩れは検出されませんでした！</div>`;
      return;
    }

    errors.forEach(err => {
      const card = document.createElement("div");
      card.className = "wrap-error-card";
      card.innerHTML = `
        <div class="wrap-error-header">
          <span class="wrap-error-tag">&lt;${err.tagName}${err.selector.slice(0, 20)}&gt;</span>
          <span class="wrap-error-id-badge">ID: ${err.id}</span>
        </div>
        <div class="wrap-error-body">
          <div class="wrap-error-text">「${escapeHTML(err.text)}」</div>
          <div class="wrap-error-reason"><strong>原因:</strong> ${err.reason}</div>
          <div class="wrap-error-recommend"><strong>推奨:</strong> ${err.recommendation}</div>
        </div>
      `;

      card.addEventListener("click", () => {
        const targetId = err.id;
        queryActiveTab((tab) => {
          if (tab) {
            chrome.scripting.executeScript({
              target: { tabId: tab.id },
              func: function(id) {
                const el = document.querySelector(`[data-wabi-wrap-err-id="${id}"]`);
                if (el) {
                  el.scrollIntoView({ behavior: "smooth", block: "center" });
                  el.classList.add("focus-pulse-blue");
                  setTimeout(() => {
                    el.classList.remove("focus-pulse-blue");
                  }, 2000);
                }
              },
              args: [targetId]
            });
          } else {
            // Simulator local scroll
            const targetEl = document.querySelector(`#demo-page-container [data-wabi-wrap-err-id="${targetId}"]`);
            if (targetEl) {
              targetEl.scrollIntoView({ behavior: "smooth", block: "center" });
              targetEl.classList.add("focus-pulse-blue");
              setTimeout(() => {
                targetEl.classList.remove("focus-pulse-blue");
              }, 2000);
            }
          }
        });
      });

      wrapErrorList.appendChild(card);
    });
  }

  function escapeHTML(str) {
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  // --- 6. Configuration AutoSave / Load ---
  function loadConfig() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.get(["gridEnabled", "gridSize", "inspectorEnabled", "wrapDebugEnabled"], (res) => {
        if (res.gridEnabled !== undefined) {
          toggleGrid.checked = res.gridEnabled;
        }
        if (res.gridSize !== undefined) {
          inputGridSize.value = res.gridSize;
        }
        if (res.inspectorEnabled !== undefined) {
          toggleInspector.checked = res.inspectorEnabled;
        }
        if (res.wrapDebugEnabled !== undefined) {
          toggleWrapDebug.checked = res.wrapDebugEnabled;
        }
        updateGridState();
        updateInspectorState();
        updateWrapDebuggerState();
      });
    } else {
      updateGridState();
    }
  }

  function saveConfig() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.set({
        gridEnabled: toggleGrid.checked,
        gridSize: parseInt(inputGridSize.value),
        inspectorEnabled: toggleInspector.checked,
        wrapDebugEnabled: toggleWrapDebug.checked
      });
    }
  }

  // --- 7. Event Listeners ---
  toggleGrid.addEventListener("change", updateGridState);
  
  // Update numerical text immediately on drag, but only re-render the heavy grid lines on drag-end (change)
  inputGridSize.addEventListener("input", () => {
    gridSizeVal.textContent = inputGridSize.value;
  });
  inputGridSize.addEventListener("change", updateGridState);
  
  // Quick Preset badges for grid size
  document.querySelectorAll(".preset-badge-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const size = btn.getAttribute("data-size");
      inputGridSize.value = size;
      gridSizeVal.textContent = size;
      updateGridState();
    });
  });

  toggleInspector.addEventListener("change", updateInspectorState);
  toggleWrapDebug.addEventListener("change", updateWrapDebuggerState);

  // Init
  loadConfig();
});
