



document.addEventListener('DOMContentLoaded', () => {
  // --- State Variables ---
  let currentTheme = 'light';
  let activeTab = 'tab-convert';

  // --- Element Selectors ---
  const themeToggle = document.getElementById('theme-toggle');
  const sunIcon = themeToggle.querySelector('.sun-icon');
  const moonIcon = themeToggle.querySelector('.moon-icon');
  const navTabs = document.querySelectorAll('.nav-tab');
  const tabContents = document.querySelectorAll('.tab-content');

  // Tab 1: Converter Elements
  const inputCasual = document.getElementById('input-casual');
  const clearInputBtn = document.getElementById('clear-input');
  const selectKeigoLevel = document.getElementById('select-keigo-level');
  const btnConvert = document.getElementById('btn-convert');
  const resultContainer = document.getElementById('result-container');
  const badgeLevel = document.getElementById('badge-level');
  const outputKeigo = document.getElementById('output-keigo');
  const btnCopy = document.getElementById('btn-copy');

  // Tab 2: Templates Elements
  const selectTempCat = document.getElementById('select-temp-cat');
  const selectTempTemplate = document.getElementById('select-temp-template');
  const dynamicFields = document.getElementById('dynamic-fields');
  const outputTemplate = document.getElementById('output-template');
  const btnCopyTemp = document.getElementById('btn-copy-temp');

  // Tab 3: Quiz Elements
  const quizQuestion = document.getElementById('quiz-question');
  const quizOptions = document.getElementById('quiz-options');
  const quizFeedback = document.getElementById('quiz-feedback');

  // Toast
  const toast = document.getElementById('toast');

  // --- Theme Toggle Logic ---
  const applyTheme = (theme) => {
    if (theme === 'dark') {
      document.body.classList.remove('light-theme');
      document.body.classList.add('dark-theme');
      sunIcon.style.display = 'none';
      moonIcon.style.display = 'block';
    } else {
      document.body.classList.remove('dark-theme');
      document.body.classList.add('light-theme');
      sunIcon.style.display = 'block';
      moonIcon.style.display = 'none';
    }
    currentTheme = theme;
    localStorage.setItem('keigo-theme', theme);
  };

  // Check saved theme or default
  const savedTheme = localStorage.getItem('keigo-theme') || 'light';
  applyTheme(savedTheme);

  themeToggle.addEventListener('click', () => {
    applyTheme(currentTheme === 'light' ? 'dark' : 'light');
  });

  // --- Tab Navigation ---
  navTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const targetTab = tab.getAttribute('data-tab');
      
      // Update tab active state
      navTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      // Update tab content active state
      tabContents.forEach(content => {
        if (content.id === targetTab) {
          content.classList.add('active');
        } else {
          content.classList.remove('active');
        }
      });

      activeTab = targetTab;

      // Special trigger if switching to templates to ensure it's generated
      if (activeTab === 'tab-templates') {
        updateTemplateOutput();
      }
    });
  });

  // --- Tab 1: Converter Logic ---

  // Clear Input Button
  clearInputBtn.addEventListener('click', () => {
    inputCasual.value = '';
    resultContainer.classList.add('hidden');
    inputCasual.focus();
  });

  // Heuristic Keigo Dictionary & Rule Engine
  const keigoRules = {
    verbs: [
      {
        casual: '言う',
        replace: {
          all: { text: 'おっしゃる', mark: 'おっしゃいます' },
          teinei: { text: '言います', mark: '言います' },
          business: { text: '申し上げる', mark: '申し上げます' },
          superior: { text: 'おっしゃる', mark: 'おっしゃいます' }
        }
      },
      {
        casual: '言った',
        replace: {
          all: { text: 'おっしゃいました', mark: 'おっしゃいました' },
          teinei: { text: '言いました', mark: '言いました' },
          business: { text: '申し上げました', mark: '申し上げました' },
          superior: { text: 'おっしゃいました', mark: 'おっしゃいました' }
        }
      },
      {
        casual: '行く',
        replace: {
          all: { text: '伺う', mark: '伺います' },
          teinei: { text: '行きます', mark: '行きます' },
          business: { text: '伺う', mark: '伺います' },
          superior: { text: 'いらっしゃる', mark: 'いらっしゃいます' }
        }
      },
      {
        casual: '行った',
        replace: {
          all: { text: '伺いました', mark: '伺いました' },
          teinei: { text: '行きました', mark: '行きました' },
          business: { text: '伺いました', mark: '伺いました' },
          superior: { text: 'いらっしゃいました', mark: 'いらっしゃいました' }
        }
      },
      {
        casual: 'する',
        replace: {
          all: { text: 'いたす', mark: 'いたします' },
          teinei: { text: 'します', mark: 'します' },
          business: { text: 'いたす', mark: 'いたします' },
          superior: { text: 'なさる', mark: 'なさいます' }
        }
      },
      {
        casual: 'した',
        replace: {
          all: { text: 'いたしました', mark: 'いたしました' },
          teinei: { text: 'しました', mark: 'しました' },
          business: { text: 'いたしました', mark: 'いたしました' },
          superior: { text: 'なさいました', mark: 'なさいました' }
        }
      },
      {
        casual: '食べる',
        replace: {
          all: { text: 'いただく', mark: 'いただきます' },
          teinei: { text: '食べます', mark: '食べます' },
          business: { text: 'いただく', mark: 'いただきます' },
          superior: { text: '召し上がる', mark: '召し上がります' }
        }
      },
      {
        casual: '来る',
        replace: {
          all: { text: 'お越しになる', mark: 'お越しになります' },
          teinei: { text: '来ます', mark: '来ます' },
          business: { text: '参る', mark: '参ります' },
          superior: { text: 'いらっしゃる', mark: 'いらっしゃいます' }
        }
      },
      {
        casual: '来た',
        replace: {
          all: { text: 'お越しになりました', mark: 'お越しになりました' },
          teinei: { text: '来ました', mark: '来ました' },
          business: { text: '参りました', mark: '参りました' },
          superior: { text: 'いらっしゃいました', mark: 'いらっしゃいました' }
        }
      },
      {
        casual: '見る',
        replace: {
          all: { text: '拝見する', mark: '拝見します' },
          teinei: { text: '見ます', mark: '見ます' },
          business: { text: '拝見する', mark: '拝見します' },
          superior: { text: 'ご覧になる', mark: 'ご覧になります' }
        }
      },
      {
        casual: '見た',
        replace: {
          all: { text: '拝見しました', mark: '拝見しました' },
          teinei: { text: '見ました', mark: '見ました' },
          business: { text: '拝見しました', mark: '拝見しました' },
          superior: { text: 'ご覧になりました', mark: 'ご覧になりました' }
        }
      },
      {
        casual: '聞く',
        replace: {
          all: { text: '伺う', mark: '伺います' },
          teinei: { text: '聞きます', mark: '聞きます' },
          business: { text: '伺う・拝聴する', mark: '伺います' },
          superior: { text: 'お聞きになる', mark: 'お聞きになります' }
        }
      },
      {
        casual: 'もらう',
        replace: {
          all: { text: 'いただく', mark: 'いただきます' },
          teinei: { text: 'もらいます', mark: 'もらいます' },
          business: { text: '頂戴する', mark: '頂戴いたします' },
          superior: { text: 'お受け取りになる', mark: 'お受け取りになります' }
        }
      },
      {
        casual: 'もらった',
        replace: {
          all: { text: 'いただきました', mark: 'いただきました' },
          teinei: { text: 'もらいました', mark: 'もらいました' },
          business: { text: '頂戴いたしました', mark: '頂戴いたしました' },
          superior: { text: 'お受け取りになりました', mark: 'お受け取りになりました' }
        }
      },
      {
        casual: 'あげる',
        replace: {
          all: { text: '差し上げる', mark: '差し上げます' },
          teinei: { text: 'あげます', mark: 'あげます' },
          business: { text: '差し上げる', mark: '差し上げます' },
          superior: { text: 'お渡しになる', mark: 'お渡しになります' }
        }
      },
      {
        casual: '知っている',
        replace: {
          all: { text: '存じている', mark: '存じております' },
          teinei: { text: '知っています', mark: '知っています' },
          business: { text: '存じ上げている', mark: '存じ上げております' },
          superior: { text: 'ご存知である', mark: 'ご存知です' }
        }
      },
      {
        casual: '知らない',
        replace: {
          all: { text: '存じ上げない', mark: '存じ上げません' },
          teinei: { text: '知りません', mark: '知りません' },
          business: { text: '存じ上げない', mark: '存じ上げません' },
          superior: { text: 'ご存知ない', mark: 'ご存知ありません' }
        }
      },
      {
        casual: '会う',
        replace: {
          all: { text: 'お目にかかる', mark: 'お目にかかります' },
          teinei: { text: '会います', mark: '会います' },
          business: { text: 'お目にかかる', mark: 'お目にかかります' },
          superior: { text: 'お会いになる', mark: 'お会いになります' }
        }
      },
      {
        casual: '伝える',
        replace: {
          all: { text: '申し伝える', mark: '申し伝えます' },
          teinei: { text: '伝えます', mark: '伝えます' },
          business: { text: '申し伝える', mark: '申し伝えます' },
          superior: { text: 'お伝えになる', mark: 'お伝えになります' }
        }
      },
      {
        casual: '見せる',
        replace: {
          all: { text: 'ご覧に入れる', mark: 'ご覧に入れます' },
          teinei: { text: '見せます', mark: '見せます' },
          business: { text: 'お目に掛ける', mark: 'お目に掛けます' },
          superior: { text: 'お見せになる', mark: 'お見せになります' }
        }
      },
      {
        casual: 'くれる',
        replace: {
          all: { text: 'くださる', mark: 'くださいます' },
          teinei: { text: 'くれます', mark: 'くれます' },
          business: { text: 'くださる', mark: 'くださいます' },
          superior: { text: 'くださる', mark: 'くださいます' }
        }
      },
      {
        casual: '持っていく',
        replace: {
          all: { text: 'お持ちする', mark: 'お持ちします' },
          teinei: { text: '持っていきます', mark: '持っていきます' },
          business: { text: '持参いたす', mark: '持参いたします' },
          superior: { text: 'お持ちする', mark: 'お持ちします' }
        }
      },
      {
        casual: '持っていった',
        replace: {
          all: { text: 'お持ちしました', mark: 'お持ちしました' },
          teinei: { text: '持っていきました', mark: '持っていきました' },
          business: { text: '持参いたしました', mark: '持参いたしました' },
          superior: { text: 'お持ちしました', mark: 'お持ちしました' }
        }
      },
      {
        casual: '持ってくる',
        replace: {
          all: { text: 'お持ちする', mark: 'お持ちします' },
          teinei: { text: '持ってきます', mark: '持ってきます' },
          business: { text: '持参いたす', mark: '持参いたします' },
          superior: { text: 'お持ちする', mark: 'お持ちします' }
        }
      },
      {
        casual: '持ってきた',
        replace: {
          all: { text: 'お持ちしました', mark: 'お持ちしました' },
          teinei: { text: '持ってきました', mark: '持ってきました' },
          business: { text: '持参いたしました', mark: '持参いたしました' },
          superior: { text: 'お持ちしました', mark: 'お持ちしました' }
        }
      }
    ],
    phrases: [
      { casual: '明日', replace: '明日（みょうにち）' },
      { casual: '昨日', replace: '昨日（さくじつ）' },
      { casual: '今日', replace: '本日' },
      { casual: 'さっき', replace: '先ほど' },
      { casual: 'あとで', replace: '後ほど' },
      { casual: 'だめ', replace: 'いたしかねます' },
      { casual: 'いいよ', replace: '差し支えございません' },
      { casual: 'いいです', replace: '差し支えございません' },
      { casual: 'ごめん', replace: '大変申し訳ございません' },
      { casual: 'すみません', replace: '大変申し訳ございません' },
      { casual: 'よろしく', replace: 'よろしくお願い申し上げます' },
      { casual: 'どうする？', replace: 'いかがなさいますか？' },
      { casual: 'わからない', replace: 'わかりかねます' },
      { casual: 'わかった', replace: 'かしこまりました' }
    ]
  };

  btnConvert.addEventListener('click', () => {
    const text = inputCasual.value.trim();
    if (!text) return;

    // Loading Animation Effect
    btnConvert.classList.add('loading');
    btnConvert.innerHTML = '<span>変換中...</span>';

    setTimeout(() => {
      const mode = selectKeigoLevel.value;
      let convertedText = text;
      
      // Perform replace
      // Verbs Replacement
      keigoRules.verbs.forEach(item => {
        const replacement = item.replace[mode] || item.replace['all'];
        const regex = new RegExp(item.casual, 'g');
        if (convertedText.match(regex)) {
          convertedText = convertedText.replace(regex, `<mark>${replacement.mark}</mark>`);
        }
      });

      // Phrases Replacement
      keigoRules.phrases.forEach(item => {
        const regex = new RegExp(item.casual, 'g');
        if (convertedText.match(regex)) {
          convertedText = convertedText.replace(regex, `<mark>${item.replace}</mark>`);
        }
      });

      // Basic sentence ending conversion (if it ends with だ, です/ます conversion)
      // e.g., だね -> ですね, だよ -> です
      if (mode === 'teinei' || mode === 'all' || mode === 'business' || mode === 'superior') {
        // Casual sentence pattern replacements
        const endingRules = [
          { c: /だよ/g, r: 'です' },
          { c: /だね/g, r: 'ですね' },
          { c: /るよ/g, r: 'ります' },
          { c: /ないよ/g, r: 'ません' },
          { c: /てね/g, r: 'てください' },
          { c: /て！/g, r: 'てください。' },
          { c: /しますね/g, r: 'いたします' },
          { c: /送るね/g, r: '送付いたします' }
        ];

        endingRules.forEach(rule => {
          if (convertedText.match(rule.c)) {
            convertedText = convertedText.replace(rule.c, `<mark>${rule.r}</mark>`);
          }
        });
      }

      // If nothing replaced, append a polite form suffix helper
      if (convertedText === text) {
        convertedText = `${text}。ご連絡ありがとうございます。引き続きどうぞよろしくお願い申し上げます。`;
      }

      // Display Badge Level
      let badgeLabel = 'バランス';
      if (mode === 'teinei') badgeLabel = '丁寧語';
      if (mode === 'business') badgeLabel = '社外ビジネス';
      if (mode === 'superior') badgeLabel = '社内上司向け';

      badgeLevel.textContent = badgeLabel;
      outputKeigo.innerHTML = convertedText;

      // Reveal Results
      resultContainer.classList.remove('hidden');

      // Reset Button State
      btnConvert.classList.remove('loading');
      btnConvert.innerHTML = `
        <span>変換する</span>
        <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <line x1="5" y1="12" x2="19" y2="12"/>
          <polyline points="12,5 19,12 12,19"/>
        </svg>
      `;
    }, 400); // Small delay to simulate intelligence
  });

  // Copy Buttons
  const triggerToast = () => {
    toast.classList.remove('hidden');
    setTimeout(() => {
      toast.classList.add('hidden');
    }, 2000);
  };

  btnCopy.addEventListener('click', () => {
    // Copy content of output (stripping HTML marks)
    const textToCopy = outputKeigo.innerText || outputKeigo.textContent;
    navigator.clipboard.writeText(textToCopy).then(triggerToast);
  });

  // --- Tab 2: Templates Logic ---

  const templatesData = {
    greeting: [
      {
        id: 'greet_new',
        name: '新規のご挨拶メール',
        fields: [
          { id: 'recipient_company', label: '相手の会社名', placeholder: '株式会社〇〇' },
          { id: 'recipient_name', label: '相手の名前', placeholder: '鈴木様' },
          { id: 'sender_company', label: '自社名', placeholder: '株式会社ABC' },
          { id: 'sender_name', label: '自分の名前', placeholder: '田中太郎' },
          { id: 'business_type', label: '事業概要・用件', placeholder: '新規SaaSツールのご紹介' }
        ],
        template: (f) => `${f.recipient_company || '株式会社〇〇'}\n${f.recipient_name || '鈴木様'}\n\n突然のご連絡にて失礼いたします。\n${f.sender_company || '株式会社ABC'}の${f.sender_name || '田中太郎'}と申します。\n\n弊社は、現在${f.business_type || '新規SaaSツールのご紹介'}を展開しております。\n本日は、貴社の業務効率化の一助となればと思い、ご挨拶を兼ねてご連絡いたしました。\n\nご多忙の折、大変恐縮ではございますが、一度情報交換の機会をいただけますと幸いでございます。\n何卒よろしくお願い申し上げます。\n\n----------------------------\n${f.sender_company || '株式会社ABC'}\n${f.sender_name || '田中太郎'}`
      },
      {
        id: 'greet_regular',
        name: '普段の定期連絡',
        fields: [
          { id: 'recipient_company', label: '相手の会社名', placeholder: '株式会社〇〇' },
          { id: 'recipient_name', label: '相手の名前', placeholder: '鈴木様' },
          { id: 'sender_company', label: '自社名', placeholder: '株式会社ABC' },
          { id: 'sender_name', label: '自分の名前', placeholder: '田中太郎' }
        ],
        template: (f) => `${f.recipient_company || '株式会社〇〇'}\n${f.recipient_name || '鈴木様'}\n\nいつも大変お世話になっております。\n${f.sender_company || '株式会社ABC'}の${f.sender_name || '田中太郎'}でございます。\n\n先日はお時間をいただき誠にありがとうございました。\n現在の進捗状況について共有させていただきます。\n引き続きよろしくお願い申し上げます。`
      }
    ],
    request: [
      {
        id: 'req_doc',
        name: '資料確認の依頼',
        fields: [
          { id: 'recipient_name', label: '相手の名前', placeholder: '鈴木様' },
          { id: 'doc_name', label: '資料名', placeholder: 'お見積書・ご提案資料' },
          { id: 'deadline', label: '確認期限', placeholder: '今週金曜日（〇日）15:00まで' },
          { id: 'sender_name', label: '自分の名前', placeholder: '田中太郎' }
        ],
        template: (f) => `${f.recipient_name || '鈴木様'}\n\nお疲れ様です。${f.sender_name || '田中'}です。\n\nご作成いただきました「${f.doc_name || 'お見積書・ご提案資料'}」の件でご連絡いたしました。\n内容を確認いたしましたので、一部修正点をお送りします。\n\nお忙しいところ恐れ入りますが、${f.deadline || '今週金曜日（〇日）15:00'}までに一度ご査収の上、ご返信をいただけますと幸いです。\n何卒よろしくお願い申し上げます。`
      }
    ],
    apology: [
      {
        id: 'apology_delay',
        name: '納期・返信遅延のお詫び',
        fields: [
          { id: 'recipient_name', label: '相手の名前', placeholder: '鈴木様' },
          { id: 'delay_item', label: '遅れた内容', placeholder: 'お見積書の送付' },
          { id: 'reason', label: '遅延の理由', placeholder: '社内確認に時間を要したため' },
          { id: 'sender_name', label: '自分の名前', placeholder: '田中太郎' }
        ],
        template: (f) => `${f.recipient_name || '鈴木様'}\n\nいつも大変お世話になっております。${f.sender_name || '田中'}でございます。\n\nかねてよりご依頼いただいておりました「${f.delay_item || 'お見積書の送付'}」につきまして、ご連絡が遅くなり大変申し訳ございません。\n\n${f.reason || '社内確認に時間を要したため'}、送付が遅れてしまいました。\n貴社をお待たせすることとなり、深くお詫び申し上げます。\n\n資料を本メールに添付いたしますので、ご査収いただけますと幸いです。\n今後はこのようなことがないよう、管理の徹底に努めてまいります。\n何卒ご容赦いただけますようお願い申し上げます。`
      }
    ],
    report: [
      {
        id: 'report_complete',
        name: '作業完了の報告',
        fields: [
          { id: 'recipient_name', label: '相手の名前', placeholder: '鈴木様' },
          { id: 'task_name', label: '作業内容', placeholder: 'バグ修正およびテストサーバーへのデプロイ' },
          { id: 'sender_name', label: '自分の名前', placeholder: '田中太郎' }
        ],
        template: (f) => `${f.recipient_name || '鈴木様'}\n\nお疲れ様です。${f.sender_name || '田中'}です。\n\nご依頼いただいておりました「${f.task_name || 'バグ修正およびテストサーバーへのデプロイ'}」が完了いたしましたのでご報告いたします。\n\nこちらで動作検証を行い、正常に稼働することを確認済みです。\nお手数ですが、お時間のある際にテスト環境にてご確認をいただけますでしょうか。\n\n問題がなければ本番環境への移行を進めてまいります。\nよろしくお願いいたします。`
      }
    ],
    schedule: [
      {
        id: 'schedule_adjust',
        name: '打ち合わせ日程調整',
        fields: [
          { id: 'recipient_name', label: '相手の名前', placeholder: '鈴木様' },
          { id: 'purpose', label: '面談の目的', placeholder: '新規プロジェクトのキックオフミーティング' },
          { id: 'date_option_1', label: '候補日 1', placeholder: '7月3日（月）14:00〜15:00' },
          { id: 'date_option_2', label: '候補日 2', placeholder: '7月4日（火）10:00〜11:00' },
          { id: 'date_option_3', label: '候補日 3', placeholder: '7月5日（水）終日' },
          { id: 'sender_name', label: '自分の名前', placeholder: '田中太郎' }
        ],
        template: (f) => `${f.recipient_name || '鈴木様'}\n\nいつも大変お世話になっております。${f.sender_name || '田中'}です。\n\n本日は「${f.purpose || '新規プロジェクトのキックオフミーティング'}」に向けた日程調整のご連絡です。\n30分〜1時間程度のお時間をいただきたく存じますが、以下の候補日よりご都合のよい日時をご教示いただけますでしょうか。\n\n【候補日時】\n1. ${f.date_option_1 || '7月3日（月）14:00〜15:00'}\n2. ${f.date_option_2 || '7月4日（火）10:00〜11:00'}\n3. ${f.date_option_3 || '7月5日（水）終日'}\n\nもし上記でご都合が合わない場合は、大変お手数ですがご都合のよい日程を複数ご提示いただけますと幸いです。\n何卒よろしくお願い申し上げます。`
      }
    ]
  };

  const populateTemplates = () => {
    const category = selectTempCat.value;
    const templates = templatesData[category] || [];
    
    selectTempTemplate.innerHTML = '';
    templates.forEach(t => {
      const option = document.createElement('option');
      option.value = t.id;
      option.textContent = t.name;
      selectTempTemplate.appendChild(option);
    });

    setupDynamicFields();
  };

  const setupDynamicFields = () => {
    const category = selectTempCat.value;
    const templateId = selectTempTemplate.value;
    const templateObj = (templatesData[category] || []).find(t => t.id === templateId);

    dynamicFields.innerHTML = '';
    if (!templateObj) return;

    templateObj.fields.forEach(field => {
      const formGroup = document.createElement('div');
      formGroup.className = 'form-group';

      const label = document.createElement('label');
      label.className = 'input-label';
      label.textContent = field.label;

      const input = document.createElement('input');
      input.className = 'custom-input template-variable';
      input.type = 'text';
      input.id = `field-${field.id}`;
      input.placeholder = field.placeholder;
      input.setAttribute('data-id', field.id);

      input.addEventListener('input', updateTemplateOutput);

      formGroup.appendChild(label);
      formGroup.appendChild(input);
      dynamicFields.appendChild(formGroup);
    });

    updateTemplateOutput();
  };

  function updateTemplateOutput() {
    const category = selectTempCat.value;
    const templateId = selectTempTemplate.value;
    const templateObj = (templatesData[category] || []).find(t => t.id === templateId);

    if (!templateObj) {
      outputTemplate.textContent = '';
      return;
    }

    const values = {};
    templateObj.fields.forEach(field => {
      const input = document.getElementById(`field-${field.id}`);
      values[field.id] = input ? input.value : '';
    });

    const rendered = templateObj.template(values);
    outputTemplate.textContent = rendered;
  }

  selectTempCat.addEventListener('change', populateTemplates);
  selectTempTemplate.addEventListener('change', setupDynamicFields);

  btnCopyTemp.addEventListener('click', () => {
    const textToCopy = outputTemplate.innerText || outputTemplate.textContent;
    navigator.clipboard.writeText(textToCopy).then(triggerToast);
  });

  // Init templates
  populateTemplates();

  // --- Tab 3: Quiz Logic ---

  const quizData = [
    {
      question: '取引先に対して、自分の会社の社長を紹介する時に使う敬語表現として、正しいものはどれ？',
      options: [
        { text: '「弊社社長の〇〇がおっしゃいました」', correct: false },
        { text: '「弊社社長の〇〇が申しておりました」', correct: true },
        { text: '「弊社社長の〇〇様が申されました」', correct: false }
      ],
      explanation: '自社の人間の行動を他社の人に伝える際は、たとえ社長であっても「謙譲語（言う→申す）」を使い、役職名の「社長」を呼び捨てまたは「社長の〇〇」と紹介します。社外に向けて自社の人間に「様」や「おっしゃる（尊敬語）」を使うのは間違いです。'
    },
    {
      question: '「明日伺います」のより改まったビジネス表現は？',
      options: [
        { text: '「明日（あした）いらっしゃいます」', correct: false },
        { text: '「明日（みょうにち）参ります」', correct: false },
        { text: '「明日（みょうにち）お伺いいたします」', correct: true }
      ],
      explanation: '相手の元へ行く（訪問する）へりくだった表現は「お伺いいたします（謙譲語）」です。「参ります」も謙譲語ですが、「行く」という意味の単なるへりくだりです。また、「あした」よりも「みょうにち」のほうがビジネス文書においてふさわしい言葉遣いとなります。'
    },
    {
      question: 'メールで「わかりました」と伝える際、取引先に対して使う最も適切な表現はどれ？',
      options: [
        { text: '「了解いたしました」', correct: false },
        { text: '「かしこまりました」', correct: true },
        { text: '「了承いたしました」', correct: false }
      ],
      explanation: '「了解いたしました」や「了承いたしました」は、同僚や目下の人に対して使うことが多く、社外の取引先や目上の人には「かしこまりました」や「承知いたしました」を使うのが最もマナーに沿った敬語です。'
    }
  ];

  let currentQuizIndex = 0;

  const loadQuiz = () => {
    const quiz = quizData[currentQuizIndex];
    quizQuestion.textContent = quiz.question;
    quizOptions.innerHTML = '';
    quizFeedback.classList.add('hidden');
    quizFeedback.className = 'quiz-feedback hidden';

    quiz.options.forEach((opt, idx) => {
      const btn = document.createElement('button');
      btn.className = 'quiz-opt-btn';
      btn.textContent = opt.text;
      btn.addEventListener('click', () => handleQuizAnswer(idx));
      quizOptions.appendChild(btn);
    });
  };

  const handleQuizAnswer = (selectedIndex) => {
    const quiz = quizData[currentQuizIndex];
    const optionButtons = quizOptions.querySelectorAll('.quiz-opt-btn');
    
    // Disable all options after click
    optionButtons.forEach(btn => btn.disabled = true);

    const isCorrect = quiz.options[selectedIndex].correct;
    
    // Style answers
    optionButtons.forEach((btn, idx) => {
      if (quiz.options[idx].correct) {
        btn.classList.add('correct');
      } else if (idx === selectedIndex) {
        btn.classList.add('incorrect');
      }
    });

    // Show Feedback
    quizFeedback.textContent = (isCorrect ? '⭕️ 正解です！ ' : '❌ 残念、不正解です。 ') + quiz.explanation;
    quizFeedback.classList.remove('hidden');
    quizFeedback.classList.add(isCorrect ? 'correct-feedback' : 'incorrect-feedback');

    // Add "Next Question" helper button after a delay
    setTimeout(() => {
      if (!document.getElementById('btn-next-quiz')) {
        const nextBtn = document.createElement('button');
        nextBtn.id = 'btn-next-quiz';
        nextBtn.className = 'primary-btn';
        nextBtn.style.marginTop = '12px';
        nextBtn.style.width = '100%';
        nextBtn.textContent = '次の問題へ';
        nextBtn.addEventListener('click', () => {
          currentQuizIndex = (currentQuizIndex + 1) % quizData.length;
          loadQuiz();
        });
        quizFeedback.appendChild(nextBtn);
      }
    }, 600);
  };

  // Init Quiz
  loadQuiz();
});
