// content.js - 敬語ビジネス作成アシスタント の常設ページ内パネル
// ツールバーアイコンのクリックで表示/非表示を切り替える、ドラッグ移動できる
// 独立パネルです。ネイティブのブラウザ拡張ポップアップは、コピー先アプリに
// 切り替えた瞬間に自動で閉じてしまう仕様(拡張機能側では回避不可)のため、
// 通常のDOM要素としてページ上に直接差し込むことで解決しています。
// 影響範囲は Shadow DOM 内 + このコンテナ要素だけに限定し、閲覧中のページ
// 本体には一切手を加えません。

(function () {
  'use strict';
  if (window.__wanoExt01Injected) return;
  window.__wanoExt01Injected = true;

  var container = null;
  var shadow = null;

  chrome.runtime.onMessage.addListener(function (msg) {
    if (msg && msg.action === 'toggleWidget') {
      toggleWidget();
    }
  });

  function toggleWidget() {
    try {
      if (container) {
        removeWidget();
      } else {
        createWidget();
      }
    } catch (e) {
      console.error('[wano-ext01] toggleWidget failed:', e);
    }
  }

  function removeWidget() {
    if (container) { container.remove(); }
    container = null;
    shadow = null;
  }

  function createWidget() {
    container = document.createElement('div');
    container.id = 'wano-ext01-widget-root';
    container.style.cssText = 'position:fixed; top:20px; right:20px; z-index:2147483647; width:360px; font-size:13px;';
    document.body.appendChild(container);
    shadow = container.attachShadow({ mode: 'open' });
    shadow.innerHTML = baseTemplate();
    document.body.appendChild(container);
    wireBase();
    wireConvertTab();
    wireTemplatesTab();
    wireQuizTab();
    if (window.makeDraggable) {
      window.makeDraggable(container, shadow.querySelector('#drag-handle'));
    }
    applyLicenseGate();
  }

  function $(sel) { return shadow.querySelector(sel); }
  function $all(sel) { return shadow.querySelectorAll(sel); }

  // ========================= Shell / Template =========================
  function baseTemplate() {
    return (
      '<style>' + baseCSS() + '</style>' +
      '<div class="wano-panel" id="wano-panel">' +
        '<div class="head" id="drag-handle">' +
          '<span class="head-title"><span class="dot">敬</span> 敬語ビジネス作成アシスタント</span>' +
          '<button class="close-btn" id="close-btn" title="閉じる">✕</button>' +
        '</div>' +
        '<div id="trial-banner-slot"></div>' +
        '<div class="tabs">' +
          '<button class="tab-btn active" data-tab="tab-convert">敬語変換</button>' +
          '<button class="tab-btn" data-tab="tab-templates">定型文</button>' +
          '<button class="tab-btn" data-tab="tab-guide">敬語解説</button>' +
        '</div>' +
        '<div class="tab-content active" id="tab-convert">' +
          '<label class="field-label">変換したい文章（カジュアル・雑な表現）</label>' +
          '<div class="textarea-wrap">' +
            '<textarea id="input-casual" placeholder="例：明日行くよ。書類も持っていくね。"></textarea>' +
            '<button class="clear-btn" id="clear-input" title="入力をクリア">✕</button>' +
          '</div>' +
          '<label class="field-label">敬語レベル</label>' +
          '<select id="select-keigo-level" class="select-input">' +
            '<option value="all" selected>バランス重視 (丁寧・尊敬・謙譲)</option>' +
            '<option value="teinei">丁寧語 (です・ます調)</option>' +
            '<option value="business">社外向け (謙譲表現多め)</option>' +
            '<option value="superior">社内上司向け (尊敬表現多め)</option>' +
          '</select>' +
          '<button class="primary-btn full" id="btn-convert"><span>変換する</span> →</button>' +
          '<div class="result hidden" id="result-container">' +
            '<div class="result-head"><span>変換後のビジネス文章</span><span class="badge" id="badge-level">ビジネス</span></div>' +
            '<div class="output-box" id="output-keigo"></div>' +
            '<button class="secondary-btn full" id="btn-copy">📋 コピーする</button>' +
          '</div>' +
        '</div>' +
        '<div class="tab-content" id="tab-templates">' +
          '<label class="field-label">カテゴリ選択</label>' +
          '<select id="select-temp-cat" class="select-input">' +
            '<option value="greeting">挨拶・自己紹介</option>' +
            '<option value="request">依頼・相談</option>' +
            '<option value="apology">お詫び・謝罪</option>' +
            '<option value="report">報告・共有</option>' +
            '<option value="schedule">日程調整</option>' +
          '</select>' +
          '<label class="field-label">定型文テンプレート</label>' +
          '<select id="select-temp-template" class="select-input"></select>' +
          '<div id="dynamic-fields"></div>' +
          '<div class="result" id="temp-result-container">' +
            '<div class="result-head"><span>生成されたメール文章</span></div>' +
            '<div class="output-box pre" id="output-template"></div>' +
            '<button class="secondary-btn full" id="btn-copy-temp">📋 コピーする</button>' +
          '</div>' +
        '</div>' +
        '<div class="tab-content" id="tab-guide">' +
          '<div class="guide-intro"><h4>日本の美しい敬語の基本</h4><p>相手との関係性や場面に応じて、正しく敬語を使い分けることがビジネスマナーの第一歩です。</p></div>' +
          '<div class="guide-card sonkei"><div class="guide-tag">尊</div><div><b>尊敬語 (Sonkeigo)</b><p>相手の行動や状態を高めて、敬意を表す言葉。主語は「相手」になります。</p><span class="guide-ex">例：「行く」→「いらっしゃる」</span></div></div>' +
          '<div class="guide-card kenjou"><div class="guide-tag">謙</div><div><b>謙譲語 (Kenjougo)</b><p>自分をへりくだることで、相対的に相手を高める言葉。主語は「自分」になります。</p><span class="guide-ex">例：「行く」→「伺う・参る」</span></div></div>' +
          '<div class="guide-card teinei"><div class="guide-tag">丁</div><div><b>丁寧語 (Teineigo)</b><p>聞き手に対して直接敬意を表す言葉づかい。「〜です」「〜ます」「〜でございます」。</p><span class="guide-ex">例：「行く」→「行きます」</span></div></div>' +
          '<div class="quiz-card">' +
            '<div class="quiz-head"><span class="quiz-badge">ミニクイズ</span><h4 id="quiz-question">Loading...</h4></div>' +
            '<div id="quiz-options" class="quiz-options"></div>' +
            '<div id="quiz-feedback" class="quiz-feedback hidden"></div>' +
          '</div>' +
        '</div>' +
        '<div class="toast hidden" id="toast">コピーしました！</div>' +
      '</div>'
    );
  }

  function baseCSS() {
    return (
      ':host{all:initial;}' +
      '*{box-sizing:border-box; font-family:-apple-system,BlinkMacSystemFont,"Hiragino Sans","Yu Gothic",sans-serif;}' +
      '.wano-panel{background:#fff; border-radius:14px; box-shadow:0 12px 32px rgba(0,0,0,.2); border:1px solid #e5e7eb; overflow:hidden; color:#111827;}' +
      '.head{cursor:move; display:flex; align-items:center; justify-content:space-between; padding:10px 12px; background:linear-gradient(135deg,#7c6cf0,#5f4bd6); color:#fff;}' +
      '.head-title{font-size:13px; font-weight:700; display:flex; align-items:center; gap:6px;}' +
      '.dot{background:rgba(255,255,255,.25); border-radius:50%; width:18px; height:18px; display:inline-flex; align-items:center; justify-content:center; font-size:11px;}' +
      '.close-btn{cursor:pointer; background:rgba(255,255,255,.25); border:none; color:#fff; width:22px; height:22px; border-radius:6px; font-size:13px; line-height:1;}' +
      '.close-btn:hover{background:rgba(255,255,255,.4);}' +
      '#trial-banner-slot:empty{display:none;}' +
      '.tabs{display:flex; gap:4px; padding:8px 10px 0;}' +
      '.tab-btn{flex:1; background:#f3f4f6; border:none; border-radius:8px; padding:7px 6px; font-size:11.5px; font-weight:700; color:#111827; cursor:pointer;}' +
      '.tab-btn.active{background:#5f4bd622; color:#4c3bc4;}' +
      '.tab-content{display:none; padding:12px; max-height:70vh; overflow-y:auto;}' +
      '.tab-content.active{display:block;}' +
      '.field-label{display:block; font-size:11px; font-weight:700; color:#111827; margin:10px 0 5px;}' +
      '.field-label:first-child{margin-top:0;}' +
      '.textarea-wrap{position:relative;}' +
      'textarea{width:100%; min-height:80px; resize:vertical; border:1px solid #e5e7eb; border-radius:10px; padding:10px 28px 10px 10px; font-size:12.5px; line-height:1.6; color:#111827;}' +
      '.clear-btn{position:absolute; top:8px; right:8px; background:#f3f4f6; border:none; border-radius:50%; width:20px; height:20px; font-size:11px; cursor:pointer; color:#111827;}' +
      '.select-input{width:100%; border:1px solid #e5e7eb; border-radius:8px; padding:8px; font-size:12px; color:#111827; background:#fff;}' +
      '.primary-btn{background:linear-gradient(135deg,#7c6cf0,#5f4bd6); color:#fff; border:none; border-radius:10px; padding:9px 16px; font-size:12.5px; font-weight:700; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:6px;}' +
      '.primary-btn.full{width:100%; margin-top:10px;}' +
      '.secondary-btn{background:#f3f4f6; color:#111827; border:1px solid #e5e7eb; border-radius:10px; padding:8px 14px; font-size:12px; font-weight:700; cursor:pointer;}' +
      '.secondary-btn.full{width:100%; margin-top:8px;}' +
      '.result{margin-top:14px; border-top:1px solid #f3f4f6; padding-top:12px;}' +
      '.result.hidden{display:none;}' +
      '.result-head{display:flex; align-items:center; justify-content:space-between; margin-bottom:8px; font-size:11.5px; font-weight:700; color:#111827;}' +
      '.badge{background:#5f4bd622; color:#4c3bc4; font-size:10.5px; font-weight:700; padding:2px 8px; border-radius:999px;}' +
      '.output-box{background:#f9fafb; border:1px solid #e5e7eb; border-radius:10px; padding:10px; font-size:12.5px; line-height:1.7; color:#111827;}' +
      '.output-box.pre{white-space:pre-wrap;}' +
      '.output-box mark{background:#fde68a; padding:0 2px; border-radius:3px;}' +
      '#dynamic-fields .field-label{margin-top:8px;}' +
      '#dynamic-fields input{width:100%; border:1px solid #e5e7eb; border-radius:8px; padding:7px 8px; font-size:12px; color:#111827;}' +
      '.guide-intro{margin-bottom:10px;}' +
      '.guide-intro h4{margin:0 0 4px; font-size:13px;}' +
      '.guide-intro p{margin:0; font-size:11.5px; color:#111827; line-height:1.6;}' +
      '.guide-card{display:flex; gap:10px; border:1px solid #e5e7eb; border-radius:10px; padding:10px; margin-bottom:8px; align-items:flex-start;}' +
      '.guide-tag{flex:none; width:26px; height:26px; border-radius:8px; background:#5f4bd622; color:#4c3bc4; display:flex; align-items:center; justify-content:center; font-weight:800; font-size:13px;}' +
      '.guide-card b{font-size:12px;}' +
      '.guide-card p{margin:3px 0; font-size:11.5px; color:#111827; line-height:1.5;}' +
      '.guide-ex{font-size:11px; color:#4c3bc4; font-weight:600;}' +
      '.quiz-card{margin-top:12px; border:1px solid #e5e7eb; border-radius:10px; padding:12px; background:#f9fafb;}' +
      '.quiz-head{margin-bottom:8px;}' +
      '.quiz-badge{display:inline-block; background:#5f4bd622; color:#4c3bc4; font-size:10px; font-weight:700; padding:2px 8px; border-radius:999px; margin-bottom:6px;}' +
      '.quiz-head h4{margin:0; font-size:12.5px; line-height:1.5;}' +
      '.quiz-options{display:flex; flex-direction:column; gap:6px;}' +
      '.quiz-opt-btn{text-align:left; border:1px solid #e5e7eb; background:#fff; border-radius:8px; padding:8px 10px; font-size:11.5px; cursor:pointer; color:#111827;}' +
      '.quiz-opt-btn:hover{border-color:#5f4bd6;}' +
      '.quiz-opt-btn.correct{border-color:#0f9d78; background:#0f9d7822; font-weight:700;}' +
      '.quiz-opt-btn.incorrect{border-color:#e11d48; background:#e11d4822;}' +
      '.quiz-feedback{margin-top:8px; font-size:11.5px; line-height:1.6; padding:8px; border-radius:8px;}' +
      '.quiz-feedback.correct-feedback{background:#0f9d7822; color:#0b6b53;}' +
      '.quiz-feedback.incorrect-feedback{background:#e11d4822; color:#9f1239;}' +
      '.toast{position:absolute; bottom:10px; left:50%; transform:translateX(-50%); background:#111827; color:#fff; font-size:11px; padding:6px 14px; border-radius:999px;}' +
      '.toast.hidden{display:none;}' +
      '.hidden{display:none;}' +
      '.lock-screen{padding:24px 18px; text-align:center; background:linear-gradient(135deg,#0f172a,#1e1b4b); color:#f8fafc;}' +
      '.lock-screen h3{font-size:14px; color:#f59e0b; margin:0 0 8px;}' +
      '.lock-screen p{font-size:11.5px; color:#94a3b8; line-height:1.6; margin:0 0 14px;}' +
      '.lock-screen button{background:#d97706; color:#fff; border:none; border-radius:8px; padding:9px 16px; font-size:12px; font-weight:600; cursor:pointer;}'
    );
  }

  function wireBase() {
    $('#close-btn').addEventListener('click', removeWidget);
    $all('.tab-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        $all('.tab-btn').forEach(function (b) { b.classList.remove('active'); });
        $all('.tab-content').forEach(function (c) { c.classList.remove('active'); });
        btn.classList.add('active');
        $('#' + btn.dataset.tab).classList.add('active');
        if (btn.dataset.tab === 'tab-templates') updateTemplateOutput();
      });
    });
  }

  function triggerToast() {
    var toast = $('#toast');
    toast.classList.remove('hidden');
    setTimeout(function () { toast.classList.add('hidden'); }, 2000);
  }

  // ========================= Tab 1: 敬語変換 =========================
  var keigoRules = {
    // 注意: このツールは常に「話し手自身の行為」を変換する前提(プレースホルダーの
    // 「明日行くよ。書類も持っていくね。」も一人称)。そのため「社内上司向け」で
    // あっても、自分の行為には尊敬語(いらっしゃる・なさる 等、相手を高める言葉)は
    // 使えず、必ず謙譲語(伺う・いたす 等、自分をへりくだる言葉)を使うのが正しい。
    // 以前はsuperior列に尊敬語が入っており、自分の行為を尊敬語で表現する誤りがあった
    // ため、businessと同じ謙譲語に統一した(「くれる」「持っていく」系は元々相手側の
    // 動作を表すため尊敬語のままで正しい)。
    verbs: [
      { casual: '言う', replace: { all: { mark: 'おっしゃいます' }, teinei: { mark: '言います' }, business: { mark: '申し上げます' }, superior: { mark: '申し上げます' } } },
      { casual: '言った', replace: { all: { mark: 'おっしゃいました' }, teinei: { mark: '言いました' }, business: { mark: '申し上げました' }, superior: { mark: '申し上げました' } } },
      { casual: '行く', replace: { all: { mark: '伺います' }, teinei: { mark: '行きます' }, business: { mark: '伺います' }, superior: { mark: '伺います' } } },
      { casual: '行った', replace: { all: { mark: '伺いました' }, teinei: { mark: '行きました' }, business: { mark: '伺いました' }, superior: { mark: '伺いました' } } },
      { casual: 'する', replace: { all: { mark: 'いたします' }, teinei: { mark: 'します' }, business: { mark: 'いたします' }, superior: { mark: 'いたします' } } },
      { casual: 'した', replace: { all: { mark: 'いたしました' }, teinei: { mark: 'しました' }, business: { mark: 'いたしました' }, superior: { mark: 'いたしました' } } },
      { casual: '食べる', replace: { all: { mark: 'いただきます' }, teinei: { mark: '食べます' }, business: { mark: 'いただきます' }, superior: { mark: 'いただきます' } } },
      { casual: '来る', replace: { all: { mark: 'お越しになります' }, teinei: { mark: '来ます' }, business: { mark: '参ります' }, superior: { mark: '参ります' } } },
      { casual: '来た', replace: { all: { mark: 'お越しになりました' }, teinei: { mark: '来ました' }, business: { mark: '参りました' }, superior: { mark: '参りました' } } },
      { casual: '見る', replace: { all: { mark: '拝見します' }, teinei: { mark: '見ます' }, business: { mark: '拝見します' }, superior: { mark: '拝見します' } } },
      { casual: '見た', replace: { all: { mark: '拝見しました' }, teinei: { mark: '見ました' }, business: { mark: '拝見しました' }, superior: { mark: '拝見しました' } } },
      { casual: '聞く', replace: { all: { mark: '伺います' }, teinei: { mark: '聞きます' }, business: { mark: '伺います' }, superior: { mark: '伺います' } } },
      { casual: 'もらう', replace: { all: { mark: 'いただきます' }, teinei: { mark: 'もらいます' }, business: { mark: '頂戴いたします' }, superior: { mark: '頂戴いたします' } } },
      { casual: 'もらった', replace: { all: { mark: 'いただきました' }, teinei: { mark: 'もらいました' }, business: { mark: '頂戴いたしました' }, superior: { mark: '頂戴いたしました' } } },
      { casual: 'あげる', replace: { all: { mark: '差し上げます' }, teinei: { mark: 'あげます' }, business: { mark: '差し上げます' }, superior: { mark: '差し上げます' } } },
      { casual: '知っている', replace: { all: { mark: '存じております' }, teinei: { mark: '知っています' }, business: { mark: '存じ上げております' }, superior: { mark: '存じ上げております' } } },
      { casual: '知らない', replace: { all: { mark: '存じ上げません' }, teinei: { mark: '知りません' }, business: { mark: '存じ上げません' }, superior: { mark: '存じ上げません' } } },
      { casual: '会う', replace: { all: { mark: 'お目にかかります' }, teinei: { mark: '会います' }, business: { mark: 'お目にかかります' }, superior: { mark: 'お目にかかります' } } },
      { casual: '伝える', replace: { all: { mark: '申し伝えます' }, teinei: { mark: '伝えます' }, business: { mark: '申し伝えます' }, superior: { mark: '申し伝えます' } } },
      { casual: '見せる', replace: { all: { mark: 'ご覧に入れます' }, teinei: { mark: '見せます' }, business: { mark: 'お目に掛けます' }, superior: { mark: 'お目に掛けます' } } },
      { casual: 'くれる', replace: { all: { mark: 'くださいます' }, teinei: { mark: 'くれます' }, business: { mark: 'くださいます' }, superior: { mark: 'くださいます' } } },
      { casual: '持っていく', replace: { all: { mark: 'お持ちします' }, teinei: { mark: '持っていきます' }, business: { mark: '持参いたします' }, superior: { mark: 'お持ちします' } } },
      { casual: '持っていった', replace: { all: { mark: 'お持ちしました' }, teinei: { mark: '持っていきました' }, business: { mark: '持参いたしました' }, superior: { mark: 'お持ちしました' } } },
      { casual: '持ってくる', replace: { all: { mark: 'お持ちします' }, teinei: { mark: '持ってきます' }, business: { mark: '持参いたします' }, superior: { mark: 'お持ちします' } } },
      { casual: '持ってきた', replace: { all: { mark: 'お持ちしました' }, teinei: { mark: '持ってきました' }, business: { mark: '持参いたしました' }, superior: { mark: 'お持ちしました' } } }
    ],
    phrases: [
      { casual: '明日', replace: '明日（みょうにち）' },
      { casual: '昨日', replace: '昨日（さくじつ）' },
      { casual: '今日', replace: '本日' },
      { casual: 'さっき', replace: '先ほど' },
      { casual: 'あとで', replace: '後ほど' },
      { casual: 'だめ', replace: 'いたしかねます' },
      { casual: 'いいよ', replace: '差し支えございません' },
      { casual: 'いいです', replace: '差し支えございません' },
      { casual: 'ごめん', replace: '大変申し訳ございません' },
      { casual: 'すみません', replace: '大変申し訳ございません' },
      { casual: 'よろしく', replace: 'よろしくお願い申し上げます' },
      { casual: 'どうする？', replace: 'いかがなさいますか？' },
      { casual: 'わからない', replace: 'わかりかねます' },
      { casual: 'わかった', replace: 'かしこまりました' }
    ]
  };

  function wireConvertTab() {
    var inputCasual = $('#input-casual');
    var clearBtn = $('#clear-input');
    var selectLevel = $('#select-keigo-level');
    var btnConvert = $('#btn-convert');
    var resultContainer = $('#result-container');
    var badgeLevel = $('#badge-level');
    var outputKeigo = $('#output-keigo');
    var btnCopy = $('#btn-copy');

    clearBtn.addEventListener('click', function () {
      inputCasual.value = '';
      resultContainer.classList.add('hidden');
    });

    btnConvert.addEventListener('click', function () {
      var text = inputCasual.value.trim();
      if (!text) return;

      var mode = selectLevel.value;
      var convertedText = text;

      keigoRules.verbs.forEach(function (item) {
        var replacement = item.replace[mode] || item.replace.all;
        var regex = new RegExp(item.casual, 'g');
        if (convertedText.match(regex)) {
          convertedText = convertedText.replace(regex, '<mark>' + replacement.mark + '</mark>');
        }
      });

      keigoRules.phrases.forEach(function (item) {
        var regex = new RegExp(item.casual, 'g');
        if (convertedText.match(regex)) {
          convertedText = convertedText.replace(regex, '<mark>' + item.replace + '</mark>');
        }
      });

      if (mode === 'teinei' || mode === 'all' || mode === 'business' || mode === 'superior') {
        var endingRules = [
          { c: /だよ/g, r: 'です' },
          { c: /だね/g, r: 'ですね' },
          { c: /るよ/g, r: 'ります' },
          { c: /ないよ/g, r: 'ません' },
          { c: /てね/g, r: 'てください' },
          { c: /て！/g, r: 'てください。' },
          { c: /しますね/g, r: 'いたします' },
          { c: /送るね/g, r: '送付いたします' }
        ];
        endingRules.forEach(function (rule) {
          if (convertedText.match(rule.c)) {
            convertedText = convertedText.replace(rule.c, '<mark>' + rule.r + '</mark>');
          }
        });

        // 動詞辞書で語尾を敬語に変換しても、元の文末にあった「よ」「ね」等の
        // 話し言葉の終助詞はそのまま残ってしまう(例:「持っていきますね」の「ね」)。
        // 個別の単語知識では網羅しきれないため、句点等の直前に来る場合は一律で除去する。
        convertedText = convertedText.replace(/(よ|ね|わ|ぞ|ぜ)(?=。|、|！|？|」|$)/g, '');
      }

      if (convertedText === text) {
        convertedText = text + '。ご連絡ありがとうございます。引き続きどうぞよろしくお願い申し上げます。';
      }

      var badgeLabel = 'バランス';
      if (mode === 'teinei') badgeLabel = '丁寧語';
      if (mode === 'business') badgeLabel = '社外ビジネス';
      if (mode === 'superior') badgeLabel = '社内上司向け';

      badgeLevel.textContent = badgeLabel;
      outputKeigo.innerHTML = convertedText;
      resultContainer.classList.remove('hidden');
    });

    btnCopy.addEventListener('click', function () {
      var textToCopy = outputKeigo.innerText || outputKeigo.textContent;
      navigator.clipboard.writeText(textToCopy).then(triggerToast);
    });
  }

  // ========================= Tab 2: 定型文 =========================
  var templatesData = {
    greeting: [
      { id: 'greet_new', name: '新規のご挨拶メール', fields: [
        { id: 'recipient_company', label: '相手の会社名', placeholder: '株式会社〇〇' },
        { id: 'recipient_name', label: '相手の名前', placeholder: '鈴木様' },
        { id: 'sender_company', label: '自社名', placeholder: '株式会社ABC' },
        { id: 'sender_name', label: '自分の名前', placeholder: '田中太郎' },
        { id: 'business_type', label: '事業概要・用件', placeholder: '新規SaaSツールのご紹介' }
      ], template: function (f) {
        return (f.recipient_company || '株式会社〇〇') + '\n' + (f.recipient_name || '鈴木様') + '\n\n突然のご連絡にて失礼いたします。\n' + (f.sender_company || '株式会社ABC') + 'の' + (f.sender_name || '田中太郎') + 'と申します。\n\n弊社は、現在' + (f.business_type || '新規SaaSツールのご紹介') + 'を展開しております。\n本日は、貴社の業務効率化の一助となればと思い、ご挨拶を兼ねてご連絡いたしました。\n\nご多忙の折、大変恐縮ではございますが、一度情報交換の機会をいただけますと幸いでございます。\n何卒よろしくお願い申し上げます。\n\n----------------------------\n' + (f.sender_company || '株式会社ABC') + '\n' + (f.sender_name || '田中太郎');
      } },
      { id: 'greet_regular', name: '普段の定期連絡', fields: [
        { id: 'recipient_company', label: '相手の会社名', placeholder: '株式会社〇〇' },
        { id: 'recipient_name', label: '相手の名前', placeholder: '鈴木様' },
        { id: 'sender_company', label: '自社名', placeholder: '株式会社ABC' },
        { id: 'sender_name', label: '自分の名前', placeholder: '田中太郎' }
      ], template: function (f) {
        return (f.recipient_company || '株式会社〇〇') + '\n' + (f.recipient_name || '鈴木様') + '\n\nいつも大変お世話になっております。\n' + (f.sender_company || '株式会社ABC') + 'の' + (f.sender_name || '田中太郎') + 'でございます。\n\n先日はお時間をいただき誠にありがとうございました。\n現在の進捗状況について共有させていただきます。\n引き続きよろしくお願い申し上げます。';
      } }
    ],
    request: [
      { id: 'req_doc', name: '資料確認の依頼', fields: [
        { id: 'recipient_name', label: '相手の名前', placeholder: '鈴木様' },
        { id: 'doc_name', label: '資料名', placeholder: 'お見積書・ご提案資料' },
        { id: 'deadline', label: '確認期限', placeholder: '今週金曜日（〇日）15:00まで' },
        { id: 'sender_name', label: '自分の名前', placeholder: '田中太郎' }
      ], template: function (f) {
        return (f.recipient_name || '鈴木様') + '\n\nお疲れ様です。' + (f.sender_name || '田中') + 'です。\n\nご作成いただきました「' + (f.doc_name || 'お見積書・ご提案資料') + '」の件でご連絡いたしました。\n内容を確認いたしましたので、一部修正点をお送りします。\n\nお忙しいところ恐れ入りますが、' + (f.deadline || '今週金曜日（〇日）15:00') + 'までに一度ご査収の上、ご返信をいただけますと幸いです。\n何卒よろしくお願い申し上げます。';
      } }
    ],
    apology: [
      { id: 'apology_delay', name: '納期・返信遅延のお詫び', fields: [
        { id: 'recipient_name', label: '相手の名前', placeholder: '鈴木様' },
        { id: 'delay_item', label: '遅れた内容', placeholder: 'お見積書の送付' },
        { id: 'reason', label: '遅延の理由', placeholder: '社内確認に時間を要したため' },
        { id: 'sender_name', label: '自分の名前', placeholder: '田中太郎' }
      ], template: function (f) {
        return (f.recipient_name || '鈴木様') + '\n\nいつも大変お世話になっております。' + (f.sender_name || '田中') + 'でございます。\n\nかねてよりご依頼いただいておりました「' + (f.delay_item || 'お見積書の送付') + '」につきまして、ご連絡が遅くなり大変申し訳ございません。\n\n' + (f.reason || '社内確認に時間を要したため') + '、送付が遅れてしまいました。\n貴社をお待たせすることとなり、深くお詫び申し上げます。\n\n資料を本メールに添付いたしますので、ご査収いただけますと幸いです。\n今後はこのようなことがないよう、管理の徹底に努めてまいります。\n何卒ご容赦いただけますようお願い申し上げます。';
      } }
    ],
    report: [
      { id: 'report_complete', name: '作業完了の報告', fields: [
        { id: 'recipient_name', label: '相手の名前', placeholder: '鈴木様' },
        { id: 'task_name', label: '作業内容', placeholder: 'バグ修正およびテストサーバーへのデプロイ' },
        { id: 'sender_name', label: '自分の名前', placeholder: '田中太郎' }
      ], template: function (f) {
        return (f.recipient_name || '鈴木様') + '\n\nお疲れ様です。' + (f.sender_name || '田中') + 'です。\n\nご依頼いただいておりました「' + (f.task_name || 'バグ修正およびテストサーバーへのデプロイ') + '」が完了いたしましたのでご報告いたします。\n\nこちらで動作検証を行い、正常に稼働することを確認済みです。\nお手数ですが、お時間のある際にテスト環境にてご確認をいただけますでしょうか。\n\n問題がなければ本番環境への移行を進めてまいります。\nよろしくお願いいたします。';
      } }
    ],
    schedule: [
      { id: 'schedule_adjust', name: '打ち合わせ日程調整', fields: [
        { id: 'recipient_name', label: '相手の名前', placeholder: '鈴木様' },
        { id: 'purpose', label: '面談の目的', placeholder: '新規プロジェクトのキックオフミーティング' },
        { id: 'date_option_1', label: '候補日 1', placeholder: '7月3日（月）14:00〜15:00' },
        { id: 'date_option_2', label: '候補日 2', placeholder: '7月4日（火）10:00〜11:00' },
        { id: 'date_option_3', label: '候補日 3', placeholder: '7月5日（水）終日' },
        { id: 'sender_name', label: '自分の名前', placeholder: '田中太郎' }
      ], template: function (f) {
        return (f.recipient_name || '鈴木様') + '\n\nいつも大変お世話になっております。' + (f.sender_name || '田中') + 'です。\n\n本日は「' + (f.purpose || '新規プロジェクトのキックオフミーティング') + '」に向けた日程調整のご連絡です。\n30分〜1時間程度のお時間をいただきたく存じますが、以下の候補日よりご都合のよい日時をご教示いただけますでしょうか。\n\n【候補日時】\n1. ' + (f.date_option_1 || '7月3日（月）14:00〜15:00') + '\n2. ' + (f.date_option_2 || '7月4日（火）10:00〜11:00') + '\n3. ' + (f.date_option_3 || '7月5日（水）終日') + '\n\nもし上記でご都合が合わない場合は、大変お手数ですがご都合のよい日程を複数ご提示いただけますと幸いです。\n何卒よろしくお願い申し上げます。';
      } }
    ]
  };

  function updateTemplateOutput() {
    var category = $('#select-temp-cat').value;
    var templateId = $('#select-temp-template').value;
    var templateObj = (templatesData[category] || []).find(function (t) { return t.id === templateId; });
    var outputTemplate = $('#output-template');
    if (!templateObj) { outputTemplate.textContent = ''; return; }

    var values = {};
    templateObj.fields.forEach(function (field) {
      var input = $('#field-' + field.id);
      values[field.id] = input ? input.value : '';
    });
    outputTemplate.textContent = templateObj.template(values);
  }

  function setupDynamicFields() {
    var category = $('#select-temp-cat').value;
    var templateId = $('#select-temp-template').value;
    var templateObj = (templatesData[category] || []).find(function (t) { return t.id === templateId; });
    var dynamicFields = $('#dynamic-fields');
    dynamicFields.innerHTML = '';
    if (!templateObj) return;

    templateObj.fields.forEach(function (field) {
      var label = document.createElement('label');
      label.className = 'field-label';
      label.textContent = field.label;
      var input = document.createElement('input');
      input.type = 'text';
      input.id = 'field-' + field.id;
      input.placeholder = field.placeholder;
      input.addEventListener('input', updateTemplateOutput);
      dynamicFields.appendChild(label);
      dynamicFields.appendChild(input);
    });
    updateTemplateOutput();
  }

  function populateTemplates() {
    var category = $('#select-temp-cat').value;
    var templates = templatesData[category] || [];
    var selectTemplate = $('#select-temp-template');
    selectTemplate.innerHTML = '';
    templates.forEach(function (t) {
      var option = document.createElement('option');
      option.value = t.id;
      option.textContent = t.name;
      selectTemplate.appendChild(option);
    });
    setupDynamicFields();
  }

  function wireTemplatesTab() {
    $('#select-temp-cat').addEventListener('change', populateTemplates);
    $('#select-temp-template').addEventListener('change', setupDynamicFields);
    $('#btn-copy-temp').addEventListener('click', function () {
      var outputTemplate = $('#output-template');
      var textToCopy = outputTemplate.innerText || outputTemplate.textContent;
      navigator.clipboard.writeText(textToCopy).then(triggerToast);
    });
    populateTemplates();
  }

  // ========================= Tab 3: 敬語解説クイズ =========================
  var quizData = [
    {
      question: '取引先に対して、自分の会社の社長を紹介する時に使う敬語表現として、正しいものはどれ？',
      options: [
        { text: '「弊社社長の〇〇がおっしゃいました」', correct: false },
        { text: '「弊社社長の〇〇が申しておりました」', correct: true },
        { text: '「弊社社長の〇〇様が申されました」', correct: false }
      ],
      explanation: '自社の人間の行動を他社の人に伝える際は、たとえ社長であっても「謙譲語（言う→申す）」を使い、役職名の「社長」を呼び捨てまたは「社長の〇〇」と紹介します。社外に向けて自社の人間に「様」や「おっしゃる（尊敬語）」を使うのは間違いです。'
    },
    {
      question: '「明日伺います」のより改まったビジネス表現は？',
      options: [
        { text: '「明日（あした）いらっしゃいます」', correct: false },
        { text: '「明日（みょうにち）参ります」', correct: false },
        { text: '「明日（みょうにち）お伺いいたします」', correct: true }
      ],
      explanation: '相手の元へ行く（訪問する）へりくだった表現は「お伺いいたします（謙譲語）」です。「参ります」も謙譲語ですが、「行く」という意味の単なるへりくだりです。また、「あした」よりも「みょうにち」のほうがビジネス文書においてふさわしい言葉遣いとなります。'
    },
    {
      question: 'メールで「わかりました」と伝える際、取引先に対して使う最も適切な表現はどれ？',
      options: [
        { text: '「了解いたしました」', correct: false },
        { text: '「かしこまりました」', correct: true },
        { text: '「了承いたしました」', correct: false }
      ],
      explanation: '「了解いたしました」や「了承いたしました」は、同僚や目下の人に対して使うことが多く、社外の取引先や目上の人には「かしこまりました」や「承知いたしました」を使うのが最もマナーに沿った敬語です。'
    }
  ];
  var currentQuizIndex = 0;

  function loadQuiz() {
    var quiz = quizData[currentQuizIndex];
    $('#quiz-question').textContent = quiz.question;
    var quizOptions = $('#quiz-options');
    quizOptions.innerHTML = '';
    var feedback = $('#quiz-feedback');
    feedback.className = 'quiz-feedback hidden';

    quiz.options.forEach(function (opt, idx) {
      var btn = document.createElement('button');
      btn.className = 'quiz-opt-btn';
      btn.textContent = opt.text;
      btn.addEventListener('click', function () { handleQuizAnswer(idx); });
      quizOptions.appendChild(btn);
    });
  }

  function handleQuizAnswer(selectedIndex) {
    var quiz = quizData[currentQuizIndex];
    var optionButtons = $all('.quiz-opt-btn');
    optionButtons.forEach(function (btn) { btn.disabled = true; });

    var isCorrect = quiz.options[selectedIndex].correct;
    optionButtons.forEach(function (btn, idx) {
      if (quiz.options[idx].correct) btn.classList.add('correct');
      else if (idx === selectedIndex) btn.classList.add('incorrect');
    });

    var feedback = $('#quiz-feedback');
    feedback.textContent = (isCorrect ? '⭕️ 正解です！ ' : '❌ 残念、不正解です。 ') + quiz.explanation;
    feedback.classList.remove('hidden');
    feedback.classList.add(isCorrect ? 'correct-feedback' : 'incorrect-feedback');

    setTimeout(function () {
      if ($('#btn-next-quiz')) return;
      var nextBtn = document.createElement('button');
      nextBtn.id = 'btn-next-quiz';
      nextBtn.className = 'primary-btn full';
      nextBtn.textContent = '次の問題へ';
      nextBtn.addEventListener('click', function () {
        currentQuizIndex = (currentQuizIndex + 1) % quizData.length;
        loadQuiz();
      });
      feedback.appendChild(nextBtn);
    }, 600);
  }

  function wireQuizTab() {
    loadQuiz();
  }

  // ========================= ライセンス / トライアル =========================
  // license-checker.js は「popup.html全体をロックする」実装(document.body全体を
  // 対象にする)なので、そのままでは閲覧中のページ本体を巻き込んでしまう。
  // ここではパネルの Shadow DOM 内だけをロック/バナー表示の対象にする。
  function applyLicenseGate() {
    if (typeof LicenseManager === 'undefined') return;
    LicenseManager.checkStatus().then(function (status) {
      if (!shadow) return;
      if (status.status === 'expired') {
        lockPanel();
      } else if (status.status === 'trial') {
        showTrialBanner(status.daysLeft);
      }
    });
  }

  function lockPanel() {
    var panel = $('#wano-panel');
    var head = panel.querySelector('.head');
    Array.prototype.forEach.call(panel.children, function (child) {
      if (child !== head) child.remove();
    });
    var lock = document.createElement('div');
    lock.className = 'lock-screen';
    lock.innerHTML =
      '<h3>🔒 無料体験期間が終了しました</h3>' +
      '<p>この機能を引き続きご利用いただくには、ライセンスキーの入力、またはメールアドレスの登録（無料期間の延長）が必要です。</p>' +
      '<button id="open-license-btn">ライセンスを設定する</button>';
    panel.appendChild(lock);
    lock.querySelector('#open-license-btn').addEventListener('click', function () {
      chrome.runtime.sendMessage({ action: 'openOptionsPage' });
    });
  }

  function showTrialBanner(daysLeft) {
    var slot = $('#trial-banner-slot');
    slot.innerHTML =
      '<div style="background:#1e293b;color:#94a3b8;padding:6px 12px;font-size:11px;display:flex;justify-content:space-between;align-items:center;">' +
        '<span>無料体験中（残り ' + daysLeft + ' 日）</span>' +
        '<a href="#" id="upgrade-link" style="color:#f59e0b;text-decoration:none;font-weight:700;">プロ版へ有効化 ➔</a>' +
      '</div>';
    slot.querySelector('#upgrade-link').addEventListener('click', function (e) {
      e.preventDefault();
      chrome.runtime.sendMessage({ action: 'openOptionsPage' });
    });
  }
})();
