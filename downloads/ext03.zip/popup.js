// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  function openFallbackWindow() {
    // Fail-safe: Open popup.html as a draggable Chrome popup window
    var w = Math.min(screen.availWidth, 460);
    var h = Math.min(screen.availHeight, 640);
    var left = Math.round((screen.availWidth - w) / 2);
    var top = Math.round((screen.availHeight - h) / 4);
    chrome.windows.create({
      url: chrome.runtime.getURL("popup.html?mode=window"),
      type: "popup",
      width: w,
      height: h,
      left: left,
      top: top,
      focused: true
    });
  }

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        var tabId = tabs[0].id;
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabId, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Content script is likely stale/missing on this tab (e.g. the tab was
            // already open before the extension was installed/updated). Re-inject it
            // on demand and retry once before falling back to a separate OS window
            // (the separate-window fallback can vanish and never reappear).
            if (chrome.scripting) {
              chrome.scripting.executeScript({
                target: { tabId: tabId },
                files: ["draggable.js", "content.js"]
              }, function() {
                if (chrome.runtime.lastError) {
                  openFallbackWindow();
                  window.close();
                  return;
                }
                chrome.tabs.sendMessage(tabId, { action: "toggleFloatingPanel" }, function(response2) {
                  if (chrome.runtime.lastError || !response2 || response2.status !== "toggled") {
                    openFallbackWindow();
                  }
                  window.close();
                });
              });
              return;
            }
            openFallbackWindow();
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 460,
          height: 640,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

document.addEventListener('DOMContentLoaded', () => {
  // --- State ---
  let currentTheme = 'light';

  // --- Theme Toggle ---
  const themeToggle = document.getElementById('theme-toggle');
  const sunIcon = themeToggle.querySelector('.sun-icon');
  const moonIcon = themeToggle.querySelector('.moon-icon');

  const applyTheme = (theme) => {
    if (theme === 'dark') {
      document.body.classList.remove('light-theme');
      document.body.classList.add('dark-theme');
      sunIcon.style.display = 'none';
      moonIcon.style.display = 'block';
    } else {
      document.body.classList.remove('dark-theme');
      document.body.classList.add('light-theme');
      sunIcon.style.display = 'block';
      moonIcon.style.display = 'none';
    }
    currentTheme = theme;
    localStorage.setItem('reply-theme', theme);
  };

  const savedTheme = localStorage.getItem('reply-theme') || 'light';
  applyTheme(savedTheme);

  themeToggle.addEventListener('click', () => {
    applyTheme(currentTheme === 'light' ? 'dark' : 'light');
  });

  // --- Tab Navigation ---
  const navTabs = document.querySelectorAll('.nav-tab');
  const tabContents = document.querySelectorAll('.tab-content');

  navTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const targetTab = tab.getAttribute('data-tab');
      navTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      tabContents.forEach(content => {
        if (content.id === targetTab) {
          content.classList.add('active');
        } else {
          content.classList.remove('active');
        }
      });
    });
  });

  // --- Toast Notification helper ---
  const toast = document.getElementById('toast');
  const triggerToast = () => {
    toast.classList.remove('hidden');
    setTimeout(() => {
      toast.classList.add('hidden');
    }, 2000);
  };

  // --- Tab 1: Smart Reply Logic ---
  const inputMessage = document.getElementById('input-message');
  const clearInputBtn = document.getElementById('clear-input');
  const selectRelation = document.getElementById('select-relation');
  const intentBtns = document.querySelectorAll('.intent-btn');
  const replyResultContainer = document.getElementById('reply-result-container');
  const badgeIntent = document.getElementById('badge-intent');
  const outputReply = document.getElementById('output-reply');
  const btnCopyReply = document.getElementById('btn-copy-reply');

  clearInputBtn.addEventListener('click', () => {
    inputMessage.value = '';
    replyResultContainer.classList.add('hidden');
    inputMessage.focus();
  });

  // Dynamic Reply Matrix
  const replyTemplates = {
    client: {
      agree: {
        normal: 'かしこまりました。ご連絡いただきました件、承知いたしました。\n引き続きよろしくお願い申し上げます。',
        schedule: 'ご提示いただきました日程で調整させていただきたく存じます。\n当日はどうぞよろしくお願い申し上げます。',
        doc: 'ご依頼の資料を確認いたしました。内容につきまして、こちらで問題ございません。\nご準備いただき誠にありがとうございました。'
      },
      decline: {
        normal: '大変恐縮ではございますが、あいにくその件につきましては対応いたしかねます。\nご期待に沿えず誠に申し訳ございませんが、何卒ご理解賜りますようお願い申し上げます。',
        schedule: '大変申し訳ございません。あいにくその日は終日外出の予定が入っており、対応が難しく存じます。\n恐れ入りますが、別の日程をご指定いただくことは可能でしょうか。',
        doc: 'せっかくのご提案ではございますが、現在の予算およびスケジュールの都合上、今回は見送らせていただきたく存じます。\n悪しからずご了承いただけますようお願い申し上げます。'
      },
      pending: {
        normal: 'ご連絡ありがとうございます。ただいま担当部署にて詳細を確認中でございます。\n確認が取れ次第、早急にご返信いたしますので、今しばらくお待ちください。',
        schedule: 'ご連絡ありがとうございます。来週のスケジュールを確認し、本日中に改めてご連絡差し上げます。\n少々お時間をいただけますでしょうか。',
        doc: '資料をお送りいただきありがとうございます。一度社内で目を通し、追って検討結果を共有させていただきます。\nよろしくお願い申し上げます。'
      },
      thanks: {
        normal: 'お忙しいところ、ご丁寧にご連絡いただき誠にありがとうございました。\n今後とも変わらぬお引き立てを賜りますよう、お願い申し上げます。',
        schedule: 'お忙しい中、お打ち合わせの日程をご調整いただき誠にありがとうございました。\n当日を楽しみにしております。',
        doc: '迅速に資料をご送付いただき、誠にありがとうございました。\n早速内容を確認させていただきます。'
      }
    },
    boss: {
      agree: {
        normal: 'かしこまりました。ご指示通りに進めさせていただきます。\nよろしくお願いいたします。',
        schedule: 'ご連絡ありがとうございます。15時からの会議、承知いたしました。\n参加させていただきます。',
        doc: '共有いただいた資料を確認いたしました。こちらの内容で進めて問題ございません。\nご準備ありがとうございました。'
      },
      decline: {
        normal: '申し訳ございません。他の業務との兼ね合いにより、今回の対応は難しい状況です。\n恐れ入りますが、どなたか別の方に代わっていただくことは可能でしょうか。',
        schedule: '申し訳ございません。あいにくその時間は別のミーティングが入っており、同席が難しいです。\n16時以降であれば空いておりますので、変更可能でしたら幸いです。',
        doc: '申し訳ございません。共有いただいた資料ですが、一部数値が前月データと異なっているため、このまま承認することはいたしかねます。再確認をお願いいたします。'
      },
      pending: {
        normal: '承知いたしました。ただいま状況を確認しておりますので、分かり次第すぐに報告いたします。\n少々お待ちください。',
        schedule: 'ご連絡ありがとうございます。本日夕方に他社とのアポイントメントがあるため、スケジュールを確認し次第、改めてご連絡いたします。',
        doc: '資料ありがとうございます。内容を拝見し、修正点や質問をまとめて後ほどお送りいたします。\nよろしくお願いいたします。'
      },
      thanks: {
        normal: 'お忙しい中、ご指導・ご対応いただき誠にありがとうございました。\n引き続き、どうぞよろしくお願いいたします。',
        schedule: '打ち合わせのご調整をいただき、ありがとうございました。\nよろしくお願いいたします。',
        doc: '早急にご確認いただき、またアドバイスをいただきありがとうございました。\n早速修正して提出いたします。'
      }
    },
    peer: {
      agree: {
        normal: '了解しました！その方向で作業を進めておきますね。\n引き続きよろしく！',
        schedule: '変更了解です！15時からよろしくね！',
        doc: '資料のチェック完了したよ！これで問題ないと思う。\n共有ありがとう！'
      },
      decline: {
        normal: 'ごめん！今別のタスクで手がいっぱいで、ちょっと手伝えそうにないです…。\n他のタイミングなら大丈夫なんだけど、すまない！',
        schedule: 'ごめん！その時間、別の定例ミーティングと被ってたわ。\n16時以降か、明日ならいつでも大丈夫だけどどう？',
        doc: 'ごめん、このデータだけど、このまま使うのはちょっと難しいかも。\n〇〇の部分を直してからじゃないと通せないから、一旦ストップでお願い！'
      },
      pending: {
        normal: '了解！今コード（またはデータ）を確認中だから、わかり次第Slackで連絡するね！\nちょっと待ってて！',
        schedule: '了解！今日の午後にはスケジュール空くと思うから、確認してまた返信するね！',
        doc: '資料ありがとう！後で時間作って確認しておくね。\n確認できたら連絡する！'
      },
      thanks: {
        normal: 'いつもフォローしてくれてありがとう！助かりました！\nまた何かあればよろしく！',
        schedule: '時間調整してくれてありがとう！助かった！',
        doc: '資料を早く作って送ってくれてありがとう！めちゃくちゃ助かる！'
      }
    },
    junior: {
      agree: {
        normal: '了解！その進め方で問題ないよ。進捗があれば適宜教えてね。\nよろしく！',
        schedule: 'オッケー、15時からのミーティングで進めましょう。よろしく！',
        doc: '提出ありがとう。資料確認したよ。これでオッケーなので、本番環境に反映して進めてね。'
      },
      decline: {
        normal: '申し訳ないけれど、今回の提案はうちのチームのスコープ外だから見送ろう。\n次は別の切り口で考えてみてほしい。',
        schedule: 'ごめん、その時間は別の来客が入っているから変更は難しいな。\n午前中か、もしくは明日に調整してもらえるかな？',
        doc: '提出ありがとう。ただ、この資料だと詳細が少し足りないから、このまま提出はできないな。\n〇〇の項目を追加した上で再提出をお願いします。'
      },
      pending: {
        normal: '了解！今こちらで要件を確認しているところだから、追って指示するよ。\nそのまま待機しておいてね。',
        schedule: 'オッケー、自分の予定を確認するから、少し時間をちょうだい。',
        doc: '提出ありがとう。これから内容を確認するから、フィードバックがあるまで少し待っていてね。'
      },
      thanks: {
        normal: '迅速に対応してくれてありがとう！すごく助かったよ。\n引き続きよろしくね。お疲れ様！',
        schedule: 'スケジュールの調整ありがとう。助かりました。',
        doc: '資料をきれいにまとめてくれてありがとう！おかげでクライアントにすぐ送れそうだよ。'
      }
    }
  };

  const smartReplyGenerator = (intent) => {
    const text = inputMessage.value.trim().toLowerCase();
    const relation = selectRelation.value;
    
    // Determine context (schedule, document, or normal)
    let context = 'normal';
    if (text.includes('打ち合わせ') || text.includes('予定') || text.includes('ミーティング') || text.includes('日程') || text.includes('時間') || text.includes('カレンダー')) {
      context = 'schedule';
    } else if (text.includes('資料') || text.includes('ファイル') || text.includes('見積') || text.includes('提出') || text.includes('ドキュメント')) {
      context = 'doc';
    }

    const templateObj = replyTemplates[relation][intent];
    const replyText = templateObj[context] || templateObj['normal'];

    // Map intent to Badge Text
    const intentLabels = {
      agree: '承知・同意',
      decline: '辞退・お断り',
      pending: '確認・保留',
      thanks: 'お礼・感謝'
    };

    badgeIntent.textContent = intentLabels[intent] || '返信';
    outputReply.textContent = replyText;

    // Show output
    replyResultContainer.classList.remove('hidden');
  };

  intentBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const intent = btn.getAttribute('data-intent');
      smartReplyGenerator(intent);
    });
  });

  btnCopyReply.addEventListener('click', () => {
    const text = outputReply.innerText || outputReply.textContent;
    navigator.clipboard.writeText(text).then(triggerToast);
  });


  // --- Tab 2: Otsukaresama Maker Logic ---
  const selectTarget = document.getElementById('select-target');
  const selectSituation = document.getElementById('select-situation');
  const otsukaresamaList = document.getElementById('otsukaresama-list');

  const otsukaresamaData = {
    client: {
      normal: [
        'いつも大変お世話になっております。株式会社〇〇の〇〇です。\n先日の件について、取り急ぎご連絡差し上げました。',
        'いつもお世話になっております。〇〇です。\nお送りした件に関し、ご不明な点などはございませんでしょうか。',
        '平素より格別のご高配を賜り、心より御礼申し上げます。〇〇の〇〇でございます。'
      ],
      morning: [
        'おはようございます。いつも大変お世話になっております。\n株式会社〇〇の〇〇です。朝一番のご連絡にて失礼いたします。',
        'おはようございます。〇〇の〇〇でございます。\n本日もどうぞよろしくお願い申し上げます。',
        'いつもお世話になっております。〇〇の〇〇です。\n本日朝一にて資料を確認いたしましたのでご連絡いたします。'
      ],
      night: [
        '夜分遅くに大変失礼いたします。いつもお世話になっております。\n株式会社〇〇の〇〇でございます。',
        'いつもお世話になっております。〇〇です。遅い時間のご連絡となり誠に申し訳ございません。',
        'お仕事中、夜遅くにご連絡を差し上げる非礼をお詫び申し上げます。〇〇の〇〇です。'
      ],
      weekend: [
        'いつもお世話になっております。〇〇の〇〇です。\n今週も大変お世話になりました。来週も引き続き何卒よろしくお願い申し上げます。',
        'いつも大変お世話になっております。〇〇です。\n週末の折、急ぎの連絡にて失礼いたします。',
        'いつもお世話になっております。〇〇の〇〇です。\n今週最後の案件につきまして、ご報告させていただきます。'
      ],
      trouble: [
        'いつも大変お世話になっております。〇〇の〇〇でございます。\nこの度は、〇〇の件で多大なるご迷惑をおかけし、深くお詫び申し上げます。',
        'いつもお世話になっております。〇〇です。\n先ほど発生いたしました件につきまして、取り急ぎお詫びとご報告を申し上げます。',
        '度重なるご連絡となり大変申し訳ございません。〇〇の〇〇です。'
      ]
    },
    boss: {
      normal: [
        'お疲れ様です。〇〇です。先ほどの案件についてご報告いたします。',
        'お疲れ様です。〇〇です。お時間のある際にご確認をよろしくお願いいたします。',
        'お疲れ様です。〇〇です。〇〇の件で少しご相談させていただけますでしょうか。'
      ],
      morning: [
        'おはようございます。〇〇です。本日の予定をご報告いたします。',
        'おはようございます。〇〇です。本日もよろしくお願いいたします。',
        'おはようございます。〇〇です。昨日の件が完了いたしましたので報告いたします。'
      ],
      night: [
        '夜遅い時間にご連絡して申し訳ありません。お疲れ様です。〇〇です。',
        'お疲れ様です。〇〇です。本日の業務を終了し、退勤いたします。お先に失礼いたします。',
        'お疲れ様です。〇〇です。明日朝一でご確認いただきたい件があり、ご連絡いたしました。'
      ],
      weekend: [
        'お疲れ様です。〇〇です。今週もありがとうございました。来週もよろしくお願いいたします。',
        'お疲れ様です。〇〇です。今週の進捗が完了いたしましたので、ご報告いたします。',
        'お疲れ様です。〇〇です。金曜日のお忙しいところ恐れ入りますが、ご確認お願いいたします。'
      ],
      trouble: [
        'お疲れ様です。〇〇です。〇〇の件で予期せぬトラブルが発生したため、取り急ぎお詫びとご報告を申し上げます。',
        'お疲れ様です。〇〇です。私の確認不足によりご迷惑をおかけし、大変申し訳ございません。',
        'お疲れ様です。〇〇です。緊急でご相談したいトラブルが発生いたしました。'
      ]
    },
    peer: {
      normal: [
        'お疲れ様！〇〇です。ちょっと聞きたいことがあるんだけど、今いいかな？',
        'お疲れ様〜！〇〇です。先ほどのミーティングの資料、共有するね！',
        'お疲れ！〇〇です。例のプロジェクトの件で連絡しました！'
      ],
      morning: [
        'おはよう！〇〇です。今日の作業予定、ここに置いておくね。',
        'おはよう！〇〇です。今日も一日よろしく！',
        'おはよう！〇〇です。今日のミーティング、10時半からよろしくね！'
      ],
      night: [
        '夜遅くにごめん！〇〇です。ちょっと共有したいことがあって連絡した。',
        'お疲れ！〇〇です。今日の作業はここまでにするね。お先に失礼します！',
        'お疲れ様！遅い時間にごめん。急ぎじゃないので明日見てくれれば大丈夫です！'
      ],
      weekend: [
        '今週もお疲れ様でした！週末ゆっくり休んでね。',
        'お疲れ！今週も色々ありがとう。来週もよろしく！',
        'お疲れ様〜！金曜日の作業報告です。良い週末を！'
      ],
      trouble: [
        'ごめん！〇〇の件でミスっちゃって、ちょっとリカバリー手伝ってほしい！',
        'お疲れ様。例のバグの件でトラブルが起きてるから、一旦共有するね。',
        'ごめん！急ぎで確認してほしいトラブルが発生しちゃいました。'
      ]
    },
    junior: {
      normal: [
        'お疲れ様！〇〇です。この間のタスクの件、進捗はどんな感じかな？',
        'お疲れ様。時間があるときに、こちらの資料に目を通しておいてもらえる？',
        'お疲れ様！〇〇です。今日のミーティングについてフィードバックを共有します。'
      ],
      morning: [
        'おはよう！〇〇です。今日のタスクで何か不明な点があれば、いつでも聞いてね。',
        'おはよう。今日のデイリーミーティングもよろしく！',
        'おはよう！今朝の進捗について、時間あるときに教えてね。'
      ],
      night: [
        '遅い時間までお疲れ様。今日の作業は無理せず、適度なところで切り上げてね。',
        'お疲れ様。夜遅くまで対応してくれてありがとう！残りは明日で大丈夫だよ。',
        'お疲れ様。本日の報告確認したよ。遅くまでありがとう。'
      ],
      weekend: [
        '今週もお疲れ様！週末は仕事のことを忘れてゆっくり休んでね。また来週！',
        '今週も頑張ってくれてありがとう！来週もよろしく頼むね。',
        'お疲れ様！良い週末を過ごしてね。来週も頑張ろう。'
      ],
      trouble: [
        '連絡ありがとう。トラブルの件は気にしなくていいよ。一緒にリカバリー方法を考えよう。',
        'お疲れ様。発生した問題について、原因と今後の対策を一緒に整理しよう。',
        '報告ありがとう。まずは落ち着いて対応しよう。私もフォローに入るよ。'
      ]
    }
  };

  const populateOtsukaresama = () => {
    const target = selectTarget.value;
    const situation = selectSituation.value;
    const greetings = otsukaresamaData[target][situation] || [];

    otsukaresamaList.innerHTML = '';
    
    greetings.forEach(greet => {
      const div = document.createElement('div');
      div.className = 'greeting-item';
      div.textContent = greet;
      
      div.addEventListener('click', () => {
        navigator.clipboard.writeText(greet).then(triggerToast);
      });
      
      otsukaresamaList.appendChild(div);
    });
  };

  selectTarget.addEventListener('change', populateOtsukaresama);
  selectSituation.addEventListener('change', populateOtsukaresama);

  // Initial population
  populateOtsukaresama();
});
