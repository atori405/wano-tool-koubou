// ============================================
// 読書集中ルーラー — Background Service Worker
// ============================================

// Listen for keyboard shortcuts defined in manifest
chrome.commands.onCommand.addListener(async (command) => {
  if (command === "toggle-ruler") {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.url && (tab.url.startsWith("http://") || tab.url.startsWith("https://"))) {
        chrome.tabs.sendMessage(tab.id, { action: "toggleRuler" });
      }
    } catch (e) {
      console.error("Error toggling ruler via command:", e);
    }
  }
});
