// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// ============================================
// 読書集中ルーラー — Popup Script
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  // DOM Elements
  const masterToggle = document.getElementById('master-toggle');
  const rulerHeight = document.getElementById('ruler-height');
  const rulerHeightVal = document.getElementById('ruler-height-val');
  const maskOpacity = document.getElementById('mask-opacity');
  const maskOpacityVal = document.getElementById('mask-opacity-val');
  const borderEnabled = document.getElementById('border-enabled');
  const mouseFollow = document.getElementById('mouse-follow');
  const presetBtns = document.querySelectorAll('.preset-btn');

  // Default Settings
  const DEFAULT_SETTINGS = {
    enabled: true,
    height: 60,
    opacity: 50,
    preset: 'andon',
    borderEnabled: true,
    mouseFollow: true
  };

  let currentSettings = { ...DEFAULT_SETTINGS };

  // Load saved settings
  chrome.storage.local.get('readingRulerSettings', (data) => {
    if (data.readingRulerSettings) {
      currentSettings = { ...DEFAULT_SETTINGS, ...data.readingRulerSettings };
    }
    applySettingsToUI();
  });

  // Apply settings to UI controls
  function applySettingsToUI() {
    masterToggle.checked = currentSettings.enabled;
    rulerHeight.value = currentSettings.height;
    rulerHeightVal.textContent = `${currentSettings.height}px`;
    maskOpacity.value = currentSettings.opacity;
    maskOpacityVal.textContent = `${currentSettings.opacity}%`;
    borderEnabled.checked = currentSettings.borderEnabled;
    mouseFollow.checked = currentSettings.mouseFollow;

    // Set active preset button
    presetBtns.forEach(btn => {
      if (btn.dataset.preset === currentSettings.preset) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    notifyContentScript();
  }

  // Save settings and notify content script
  function saveSettings() {
    chrome.storage.local.set({ readingRulerSettings: currentSettings }, () => {
      notifyContentScript();
    });
  }

  // Send message to the active tab
  async function notifyContentScript() {
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs && tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, {
          action: 'updateRulerSettings',
          settings: currentSettings
        });
      }
    } catch (e) {
      // Ignore errors when active tab is not a web page
    }
  }

  // Event Listeners
  masterToggle.addEventListener('change', () => {
    currentSettings.enabled = masterToggle.checked;
    saveSettings();
  });

  rulerHeight.addEventListener('input', () => {
    currentSettings.height = parseInt(rulerHeight.value);
    rulerHeightVal.textContent = `${currentSettings.height}px`;
    saveSettings();
  });

  maskOpacity.addEventListener('input', () => {
    currentSettings.opacity = parseInt(maskOpacity.value);
    maskOpacityVal.textContent = `${currentSettings.opacity}%`;
    saveSettings();
  });

  borderEnabled.addEventListener('change', () => {
    currentSettings.borderEnabled = borderEnabled.checked;
    saveSettings();
  });

  mouseFollow.addEventListener('change', () => {
    currentSettings.mouseFollow = mouseFollow.checked;
    saveSettings();
  });

  presetBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      presetBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentSettings.preset = btn.dataset.preset;
      saveSettings();
    });
  });
});
