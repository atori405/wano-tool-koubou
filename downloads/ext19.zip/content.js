// ============================================
// 読書集中ルーラー — Content Script
// ============================================

(function () {
  // Avoid double injection
  if (document.getElementById('reading-ruler-container')) return;

  // Create DOM Elements
  const container = document.createElement('div');
  container.id = 'reading-ruler-container';

  const maskTop = document.createElement('div');
  maskTop.id = 'reading-ruler-mask-top';
  maskTop.className = 'reading-ruler-mask';

  const focusBar = document.createElement('div');
  focusBar.id = 'reading-ruler-focus-bar';

  const maskBottom = document.createElement('div');
  maskBottom.id = 'reading-ruler-mask-bottom';
  maskBottom.className = 'reading-ruler-mask';

  container.appendChild(maskTop);
  container.appendChild(focusBar);
  container.appendChild(maskBottom);
  document.documentElement.appendChild(container);

  // Default Settings
  let settings = {
    enabled: true,
    height: 60,
    opacity: 50,
    preset: 'andon',
    borderEnabled: true,
    mouseFollow: true
  };

  // State Variables for smooth animation
  let targetY = window.innerHeight / 2;
  let currentY = window.innerHeight / 2;
  let isRulerActive = false;
  let keyboardOffset = 0;

  // Initialize from storage
  chrome.storage.local.get('readingRulerSettings', (data) => {
    if (data.readingRulerSettings) {
      settings = { ...settings, ...data.readingRulerSettings };
    }
    updateRulerState();
  });

  // Listen for messages from popup or background
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'updateRulerSettings') {
      settings = message.settings;
      updateRulerState();
    } else if (message.action === 'toggleRuler') {
      settings.enabled = !settings.enabled;
      chrome.storage.local.set({ readingRulerSettings: settings }, () => {
        updateRulerState();
      });
    }
  });

  // Track mouse coordinates
  window.addEventListener('mousemove', (e) => {
    if (settings.enabled && settings.mouseFollow) {
      targetY = e.clientY;
      // Reset keyboard offset when mouse moves to avoid weird jumps
      keyboardOffset = 0;
    }
  });

  // Handle keyboard adjustments
  window.addEventListener('keydown', (e) => {
    if (!settings.enabled) return;

    // Shift + Up/Down key or Arrow keys when ruler is active
    if (e.key === 'ArrowUp' && e.altKey) {
      e.preventDefault();
      settings.height = Math.max(20, settings.height - 10);
      updateRulerState();
      chrome.storage.local.set({ readingRulerSettings: settings });
    } else if (e.key === 'ArrowDown' && e.altKey) {
      e.preventDefault();
      settings.height = Math.min(250, settings.height + 10);
      updateRulerState();
      chrome.storage.local.set({ readingRulerSettings: settings });
    } else if (e.key === 'ArrowUp') {
      // Move ruler up slightly
      keyboardOffset -= 15;
      e.preventDefault();
    } else if (e.key === 'ArrowDown') {
      // Move ruler down slightly
      keyboardOffset += 15;
      e.preventDefault();
    }
  });

  // Re-align on window resize
  window.addEventListener('resize', () => {
    if (targetY > window.innerHeight) {
      targetY = window.innerHeight / 2;
    }
  });

  // Update ruler styling and visibility
  function updateRulerState() {
    if (settings.enabled) {
      container.classList.add('active');
      isRulerActive = true;

      // Update preset classes on focus bar
      focusBar.className = '';
      focusBar.classList.add(`preset-${settings.preset}`);
      if (settings.borderEnabled) {
        focusBar.classList.add('with-border');
      }

      // Update mask opacity
      const opacityDecimal = settings.opacity / 100;
      maskTop.style.backgroundColor = `rgba(0, 0, 0, ${opacityDecimal})`;
      maskBottom.style.backgroundColor = `rgba(0, 0, 0, ${opacityDecimal})`;
    } else {
      container.classList.remove('active');
      isRulerActive = false;
    }
  }

  // Animation Loop for smooth follow effect
  function animLoop() {
    if (isRulerActive) {
      const finalTargetY = targetY + keyboardOffset;
      
      // Interpolate position (LERP) for smooth ease-out effect
      currentY = currentY + (finalTargetY - currentY) * 0.22;

      // Constrain Y position within viewport boundaries
      const halfHeight = settings.height / 2;
      const minY = halfHeight;
      const maxY = window.innerHeight - halfHeight;
      currentY = Math.max(minY, Math.min(maxY, currentY));

      const topY = currentY - halfHeight;

      // Update elements positions
      maskTop.style.height = `${topY}px`;
      
      focusBar.style.top = `${topY}px`;
      focusBar.style.height = `${settings.height}px`;
      
      maskBottom.style.top = `${topY + settings.height}px`;
      maskBottom.style.height = `${window.innerHeight - (topY + settings.height)}px`;
    }

    requestAnimationFrame(animLoop);
  }

  // Start animation loop
  requestAnimationFrame(animLoop);
})();


// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  const NS_ID = "wano-" + chrome.runtime.id;

  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // Add temporary shield to prevent iframe from stealing mouse events during dragging
      const existingShield = document.getElementById(NS_ID + "-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = NS_ID + "-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      // Use getBoundingClientRect() for correct viewport-relative position
      // (element.offsetTop is unreliable for position:fixed elements on scrolled pages)
      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      // Restrict within window boundaries to prevent going offscreen
      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById(NS_ID + "-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById(NS_ID + "-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "block" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = NS_ID + "-floating-container";
    
    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 440) + "px !important; z-index:2147483647 !important; width:430px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="${NS_ID}-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">Reading Ruler</span>
        </div>
        <button id="${NS_ID}-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#" + NS_ID + "-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#" + NS_ID + "-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
