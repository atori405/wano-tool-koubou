// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 460);
            var h = Math.min(screen.availHeight, 720);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 460,
          height: 720,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// popup.js - Japanese Regex Tester Core

document.addEventListener("DOMContentLoaded", () => {
  // --- 1. Element References ---
  const inputPattern = document.getElementById("input-pattern");
  const flagG = document.getElementById("flag-g");
  const flagI = document.getElementById("flag-i");
  const flagM = document.getElementById("flag-m");
  const flagS = document.getElementById("flag-s");
  const flagU = document.getElementById("flag-u");
  const activeFlagsIndicator = document.getElementById("active-flags-indicator");
  const regexErrorMsg = document.getElementById("regex-error-msg");
  const matchCounter = document.getElementById("match-counter");
  const textInput = document.getElementById("text-input");
  const highlightOverlay = document.getElementById("highlight-overlay");
  const explainSteps = document.getElementById("explain-steps");

  // --- 2. Preset Explanations (For inner accuracy) ---
  const PRESET_EXPLANATIONS = {
    "[ァ-ヶー]+": [
      { term: "[ァ-ヶー]+", desc: "<strong>[全角カタカナ]</strong> ァからヶまでのカタカナ、および長音符「ー」が<strong>1回以上連続</strong>する部分にマッチします。" }
    ],
    "[ｱ-ﾝﾟﾞ]+": [
      { term: "[ｱ-ﾝﾟﾞ]+", desc: "<strong>[半角カタカナ]</strong> ｱからﾝまでの半角カタカナ、および半角の濁点・半濁点が<strong>1回以上連続</strong>する部分にマッチします。" }
    ],
    "[ぁ-んー]+": [
      { term: "[ぁ-んー]+", desc: "<strong>[ひらがな]</strong> ぁからんまでの平仮名、および長音符「ー」が<strong>1回以上連続</strong>する部分にマッチします。" }
    ],
    "\\d{3}-\\d{4}": [
      { term: "\\d{3}", desc: "<strong>[3桁の数字]</strong> 半角数字（0〜9）が<strong>ちょうど3桁</strong>繰り返されます（郵便番号の前半部）。" },
      { term: "-", desc: "<strong>[ハイフン]</strong> 半角ハイフンが1回並びます。" },
      { term: "\\d{4}", desc: "<strong>[4桁の数字]</strong> 半角数字が<strong>ちょうど4桁</strong>繰り返されます（郵便番号の後半部）。" }
    ],
    "0[789]0-?\\d{4}-?\\d{4}": [
      { term: "0[789]0", desc: "<strong>[携帯プレフィックス]</strong> 先頭は『0』で始まり、2文字目は『7』『8』『9』のいずれか、3文字目は『0』であること（携帯・スマートフォンの識別子）。" },
      { term: "-?", desc: "<strong>[ハイフン（省略可）]</strong> ハイフン『-』が<strong>0回または1回</strong>出現します。あってもなくても構いません。" },
      { term: "\\d{4}", desc: "<strong>[4桁の数字]</strong> 4桁の半角数字が連続して存在します（中間の番号）。" },
      { term: "-?", desc: "<strong>[ハイフン（省略可）]</strong> 2つ目のハイフン『-』が<strong>0回または1回</strong>出現します（省略可能）。" },
      { term: "\\d{4}", desc: "<strong>[4桁の数字]</strong> 最後の4桁の半角数字が連続して存在します。" }
    ],
    "0(?!70|80|90)\\d{1,4}-\\d{1,4}-\\d{4}": [
      { term: "0(?!70|80|90)", desc: "<strong>[市外局番の先頭]</strong> 『0』で始まりますが、続く2文字が『70』『80』『90』（携帯電話プレフィックス）である場合は除外します（否定先読み）。" },
      { term: "\\d{1,4}", desc: "<strong>[市外局番の残り]</strong> <strong>1桁から最大4桁</strong>の半角数字が続きます（日本の市外局番フォーマット）。" },
      { term: "-", desc: "<strong>[ハイフン]</strong> 半角ハイフンが1回並びます。" },
      { term: "\\d{1,4}", desc: "<strong>[市内局番]</strong> <strong>1桁から最大4桁</strong>の半角数字が続きます（市外局番の長さに依存）。" },
      { term: "-", desc: "<strong>[ハイフン]</strong> 2つ目の半角ハイフンが1回並びます。" },
      { term: "\\d{4}", desc: "<strong>[加入者番号]</strong> 最後の4桁の半角数字が続きます。" }
    ]
  };

  // --- 3. Explanation Compiler for general regex patterns ---
  function compileGeneralExplanation(pattern) {
    const steps = [];
    let p = pattern;

    if (!p) {
      steps.push("正規表現パターンを入力してください。");
      return steps;
    }

    // Check if exact preset exists
    if (PRESET_EXPLANATIONS[p]) {
      return PRESET_EXPLANATIONS[p].map(item => `${item.term} ➔ ${item.desc}`);
    }

    // Basic Tokenizer
    let index = 1;
    if (p.startsWith("^")) {
      steps.push(`^ ➔ <strong>[先頭]</strong> 文字列の最初から判定を開始することを示します。`);
      p = p.slice(1);
    }

    // Simple parser loop for common elements
    while (p.length > 0) {
      if (p.startsWith("$")) {
        steps.push(`$ ➔ <strong>[末尾]</strong> 文字列の最後で終了することを示します。`);
        p = p.slice(1);
      } else if (p.startsWith("\\d")) {
        let text = `\\d ➔ <strong>[数字]</strong> 任意の半角数字（0〜9）にマッチします。`;
        p = p.slice(2);
        if (p.startsWith("{")) {
          const match = p.match(/^\{(\d+)(,?)(\d*)\}/);
          if (match) {
            const min = match[1];
            const hasComma = match[2];
            const max = match[3];
            if (!hasComma) {
              text = `\\d{${min}} ➔ <strong>[数字]</strong> 半角数字が <strong>ちょうど ${min} 桁</strong> 繰り返されます。`;
            } else if (!max) {
              text = `\\d{${min}, } ➔ <strong>[数字]</strong> 半角数字が <strong>${min} 桁以上</strong> 連続することを示します。`;
            } else {
              text = `\\d{${min},${max}} ➔ <strong>[数字]</strong> 半角数字が <strong>${min} 桁から最大 ${max} 桁</strong> の範囲で並びます。`;
            }
            p = p.slice(match[0].length);
          }
        }
        steps.push(text);
      } else if (p.startsWith("\\w")) {
        steps.push(`\\w ➔ <strong>[英数文字]</strong> 半角英数字およびアンダースコア（[A-Za-z0-9_]）のいずれか1文字にマッチします。`);
        p = p.slice(2);
      } else if (p.startsWith("\\s")) {
        steps.push(`\\s ➔ <strong>[空白文字]</strong> スペース、タブ、改行などの空白文字にマッチします。`);
        p = p.slice(2);
      } else if (p.startsWith("-?")) {
        steps.push(`-? ➔ <strong>[ハイフン（省略可）]</strong> ハイフン『-』が0回または1回出現します（省略可能を表します）。`);
        p = p.slice(2);
      } else if (p.startsWith("[ァ-ヶー]+")) {
        steps.push(`[ァ-ヶー]+ ➔ <strong>[全角カタカナ]</strong> 全角カタカナおよび長音符「ー」が <strong>1回以上連続</strong> していることを表します。`);
        p = p.slice(8);
      } else if (p.startsWith("[ｱ-ﾝﾟﾞ]+")) {
        steps.push(`[ｱ-ﾝﾟﾞ]+ ➔ <strong>[半角カタカナ]</strong> 半角カタカナ（濁点・半濁点含む）が <strong>1回以上連続</strong> していることを表します。`);
        p = p.slice(8);
      } else if (p.startsWith("[ぁ-んー]+")) {
        steps.push(`[ぁ-んー]+ ➔ <strong>[ひらがな]</strong> 平仮名および長音符が <strong>1回以上連続</strong> していることを表します。`);
        p = p.slice(8);
      } else {
        // Fallback for custom single characters
        const char = p.charAt(0);
        let detail = `『${char}』という特定の文字そのものにマッチします。`;
        if (char === "?") {
          detail = `直前の文字パターンが0回または1回出現する（省略可能）ことを示します。`;
        } else if (char === "+") {
          detail = `直前の文字パターンが1回以上繰り返されることを示します。`;
        } else if (char === "*") {
          detail = `直前の文字パターンが0回以上繰り返されることを示します。`;
        } else if (char === ".") {
          detail = `改行を除く任意の1文字を表します。`;
        }
        steps.push(`${char} ➔ <strong>[単一文字]</strong> ${detail}`);
        p = p.slice(1);
      }

      // Safeguard against infinite loop
      if (steps.length > 15) {
        steps.push("... (これ以降は省略されました)");
        break;
      }
    }

    return steps;
  }

  // --- 4. HTML Escaper Helper ---
  function escapeHTML(str) {
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  // --- 5. Realtime Regular Expression Engine ---

  // Collects {start, end, groupNum, matchIndex} ranges (absolute positions in the
  // full text) for the whole match (group 0) and every participating capture group,
  // using the regex "d" flag's match.indices (always added internally - see below).
  function collectRangesFromMatch(match, matchIndex, ranges) {
    const indices = match.indices;
    if (!indices) return;
    for (let g = 0; g < indices.length; g++) {
      const pair = indices[g];
      if (!pair) continue; // group did not participate in this match
      const [start, end] = pair;
      if (start === end) continue; // skip zero-length ranges
      ranges.push({ start, end, groupNum: g, matchIndex });
    }
  }

  // Partitions the text into escaped/plain runs and <mark class="grp-N"> runs.
  // Where ranges overlap (a capture group nested inside its own match), the
  // shortest (most specific) range wins, so groups are colored distinctly from
  // the rest of their enclosing match.
  function buildHighlightedHTML(text, ranges) {
    if (ranges.length === 0) return escapeHTML(text);

    const n = text.length;
    const winnerAt = new Array(n).fill(null);
    const sorted = ranges.slice().sort((a, b) => (b.end - b.start) - (a.end - a.start));
    sorted.forEach((r) => {
      for (let i = r.start; i < r.end; i++) {
        winnerAt[i] = r;
      }
    });

    let html = "";
    let i = 0;
    while (i < n) {
      const w = winnerAt[i];
      let j = i;
      if (!w) {
        while (j < n && !winnerAt[j]) j++;
        html += escapeHTML(text.slice(i, j));
      } else {
        while (j < n && winnerAt[j] === w) j++;
        const cls = "grp-" + (w.groupNum % 7);
        html += `<mark class="${cls}">${escapeHTML(text.slice(i, j))}</mark>`;
      }
      i = j;
    }
    return html;
  }

  function performMatch() {
    const pattern = inputPattern.value.trim();
    const isGlobal = flagG.checked;
    const isCaseInsensitive = flagI.checked;
    const isMultiline = flagM.checked;
    const isDotAll = flagS.checked;
    const isUnicode = flagU.checked;

    // Set active flags indicator (user-facing flags only; "d" is added internally
    // below to read match.indices for group-aware highlighting and never shown here)
    let flags = "";
    if (isGlobal) flags += "g";
    if (isCaseInsensitive) flags += "i";
    if (isMultiline) flags += "m";
    if (isDotAll) flags += "s";
    if (isUnicode) flags += "u";
    activeFlagsIndicator.textContent = flags || "(なし)";

    // Reset error box
    regexErrorMsg.style.display = "none";
    regexErrorMsg.textContent = "";

    // Load config auto-save
    saveConfig();

    const rawText = textInput.value;

    // Handle empty patterns
    if (!pattern) {
      highlightOverlay.textContent = rawText;
      matchCounter.textContent = "0件のマッチ";
      explainSteps.innerHTML = "<li>パターンが入力されていません。</li>";
      return;
    }

    // Try compilation ("d" is always added internally so match.indices is available
    // for group-aware highlighting; it doesn't change matching behavior)
    let regex;
    try {
      regex = new RegExp(pattern, flags + "d");
    } catch (e) {
      regexErrorMsg.style.display = "block";
      regexErrorMsg.textContent = `⚠️ 正規表現エラー: ${e.message}`;
      highlightOverlay.textContent = rawText;
      matchCounter.textContent = "構文エラー";
      explainSteps.innerHTML = "<li>有効な正規表現の構文を入力してください。</li>";
      return;
    }

    // Build Step by Step Explanation
    const explanationSteps = compileGeneralExplanation(pattern);
    explainSteps.innerHTML = explanationSteps
      .map(step => `<li>${step}</li>`)
      .join("");

    // Perform highlighting
    if (rawText === "") {
      highlightOverlay.innerHTML = "";
      matchCounter.textContent = "0件のマッチ";
      return;
    }

    let matchCount = 0;

    // Collect highlight ranges (whole match + each capture group) across all
    // matches, then render once via buildHighlightedHTML so nested/overlapping
    // group ranges are colored correctly (most specific range wins).
    const ranges = [];
    let outputHTML = "";

    if (isGlobal) {
      let match;

      // Prevent infinite loop with empty matches (e.g. ^ or $)
      while ((match = regex.exec(rawText)) !== null) {
        matchCount++;
        collectRangesFromMatch(match, match.index, ranges);

        if (match[0].length === 0) {
          // Force index progress if match is empty to prevent infinite loop
          regex.lastIndex++;
          if (regex.lastIndex > rawText.length) break;
        }
      }
      outputHTML = buildHighlightedHTML(rawText, ranges);
    } else {
      // Non-global mode (only highlights the first match)
      const match = regex.exec(rawText);
      if (match) {
        matchCount = 1;
        collectRangesFromMatch(match, match.index, ranges);
        outputHTML = buildHighlightedHTML(rawText, ranges);
      } else {
        outputHTML = escapeHTML(rawText);
      }
    }

    // Overlay content update
    // Add dummy newline to align textarea scroll layout wrapping logic
    highlightOverlay.innerHTML = outputHTML + (rawText.endsWith("\n") ? "\n" : "");
    matchCounter.textContent = `${matchCount}件のマッチ`;
  }

  // --- 6. Sync Scroll between Overlay and Textarea ---
  function syncScroll() {
    highlightOverlay.scrollTop = textInput.scrollTop;
    highlightOverlay.scrollLeft = textInput.scrollLeft;
  }

  // --- 7. Configuration Save/Load ---
  function loadConfig() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.get(["lastRegex", "lastText", "lastFlags"], (result) => {
        if (result.lastRegex !== undefined) {
          inputPattern.value = result.lastRegex;
        }
        if (result.lastText !== undefined) {
          textInput.value = result.lastText;
        }
        if (result.lastFlags !== undefined) {
          flagG.checked = result.lastFlags.includes("g");
          flagI.checked = result.lastFlags.includes("i");
          flagM.checked = result.lastFlags.includes("m");
          flagS.checked = result.lastFlags.includes("s");
          flagU.checked = result.lastFlags.includes("u");
        }
        performMatch();
        syncScroll();
      });
    } else {
      performMatch();
      syncScroll();
    }
  }

  function saveConfig() {
    if (window.chrome && chrome.storage) {
      let flags = "";
      if (flagG.checked) flags += "g";
      if (flagI.checked) flags += "i";
      if (flagM.checked) flags += "m";
      if (flagS.checked) flags += "s";
      if (flagU.checked) flags += "u";
      chrome.storage.local.set({
        lastRegex: inputPattern.value,
        lastText: textInput.value,
        lastFlags: flags
      });
    }
  }

  // --- 8. Event Listeners ---
  inputPattern.addEventListener("input", performMatch);
  flagG.addEventListener("change", performMatch);
  flagI.addEventListener("change", performMatch);
  flagM.addEventListener("change", performMatch);
  flagS.addEventListener("change", performMatch);
  flagU.addEventListener("change", performMatch);

  textInput.addEventListener("input", () => {
    performMatch();
    syncScroll();
  });
  textInput.addEventListener("scroll", syncScroll);

  // Snippets click triggers
  document.querySelectorAll(".wabi-snippet-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const pattern = btn.getAttribute("data-pattern");
      const flags = btn.getAttribute("data-flags");
      
      inputPattern.value = pattern;
      flagG.checked = flags.includes("g");
      flagI.checked = flags.includes("i");
      flagM.checked = flags.includes("m");
      flagS.checked = flags.includes("s");
      flagU.checked = flags.includes("u");

      // Auto-populate helper test texts to make it extremely premium
      const label = btn.getAttribute("data-label");
      if (label === "全角カタカナ") {
        textInput.value = "テストテキストです。サクラ、ミヤビ、モエギはマッチし、さとう、鈴木、123は除外されます。";
      } else if (label === "半角カタカナ") {
        textInput.value = "テストテキスト。ｱｲｳｴｵ、ｶｷｸｹｺはマッチし、アイウエオはマッチしません。";
      } else if (label === "ひらがな") {
        textInput.value = "あいうえお、さとうたろう、ひらがなはマッチし、漢字やカタカナ、123は除外されます。";
      } else if (label === "郵便番号") {
        textInput.value = "郵便番号は 100-0001 (マッチ) や 150-0002 (マッチ) です。1234567 や 12-345 はマッチしません。";
      } else if (label === "携帯電話番号") {
        textInput.value = "連絡先：090-1234-5678 (マッチ)、080-8765-4321 (マッチ)、または 07011112222 (マッチ)。03-1234-5678や0901234はダメです。";
      } else if (label === "固定電話番号") {
        textInput.value = "本社番号: 03-1234-5678 (マッチ), 大阪支社: 06-8765-4321 (マッチ)。090-1234-5678や、ハイフンなしの0312345678は除外されます。";
      }

      performMatch();
      syncScroll();
    });
  });

  // Init
  loadConfig();
});
