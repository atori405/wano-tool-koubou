// background.js - Service Worker for Japanese Regex Tester

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["lastRegex", "lastText", "lastFlags"], (result) => {
    const updates = {};
    if (result.lastRegex === undefined) {
      updates.lastRegex = "\\d{3}-\\d{4}"; // Default to Japanese Postal Code regex
    }
    if (result.lastText === undefined) {
      updates.lastText = "郵便番号は 100-0001 です。12-3456はマッチしません。";
    }
    if (result.lastFlags === undefined) {
      updates.lastFlags = "g"; // Global by default
    }
    if (Object.keys(updates).length > 0) {
      chrome.storage.local.set(updates);
    }
  });
  console.log("日本語正規表現テスター 拡張機能が正常にインストールされました。");
});
