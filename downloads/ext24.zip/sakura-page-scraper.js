// sakura-checker.jp の実ページ上でのみ動作するcontent script。
// バックグラウンドで開いたタブでこのページが実際にレンダリング・JS実行された後、
// 「実際に画面上に表示されている(サイズが0でない)要素」だけを読み取ることで、
// 同一ページ内に混在する無関係なダミー判定文・関連ランキング商品分の判定文を除外する。
(function () {
  const m = location.pathname.match(/\/search\/([A-Za-z0-9]{10})\/?/);
  if (!m) return;
  const asin = m[1];

  function isVisible(el) {
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  // 本家サイトの実際の判定メッセージ文言→社内ステータスの対応。
  // 現時点で実データで確認できているのは「安全な商品です！」(合格)と「分析不可」のみ。
  // 警告・危険帯の実際の文言は未確認のため、暫定的なマッピングとして残す。
  const MESSAGE_TO_STATUS = {
    "安全な商品です！": "合格",
    "まず安全な商品です！": "合格",
    "サクラに注意！": "警告",
    "サクラの疑いがあります。": "警告",
    "サクラレビューが多数検出されました！": "危険"
  };

  // 「Amazonより[かなり低い/低い/同等/高い]スコア」という、レビュー星評価がAmazon表示と
  // 比べて不自然かどうかの別指標。サクラ度(%)とは別の判定軸として本家サイトが表示している。
  function extractReviewScoreNote() {
    const el = Array.from(document.querySelectorAll(".item-rv-score")).find(isVisible);
    if (!el) return null;
    const text = el.textContent.replace(/\s+/g, "").trim();
    if (!text) return null;
    let severity = "不明";
    if (text.includes("かなり低い")) severity = "危険";
    else if (text.includes("低い")) severity = "警告";
    else if (text.includes("同等") || text.includes("高い")) severity = "合格";
    return { text: text, severity: severity };
  }

  function extractPercentage(nearAlert) {
    // 円グラフ(c100 pNN形式のクラス名)から実際のパーセンテージを取得する。
    // 数字自体は画像化されておりテキストとしては取れないため、この専用クラスに頼る。
    const circles = Array.from(document.querySelectorAll(".c100")).filter(isVisible);
    if (!circles.length) return null;
    const circle = circles[0];
    const clsMatch = circle.className.match(/\bp(\d+)\b/);
    if (clsMatch) return clsMatch[1] + "%";
    const textMatch = circle.textContent.match(/(\d+)%/);
    return textMatch ? textMatch[1] + "%" : null;
  }

  function extractAndSend() {
    try {
      const visibleAlert = Array.from(document.querySelectorAll(".sakura-alert")).find(isVisible);

      if (!visibleAlert) {
        chrome.runtime.sendMessage({
          action: "sakuraPageResult",
          asin: asin,
          error: true,
          message: "サクラチェッカーのページから判定結果を読み取れませんでした。"
        });
        return;
      }

      const alertText = visibleAlert.textContent.trim();
      if (alertText.includes("分析不可")) {
        chrome.runtime.sendMessage({
          action: "sakuraPageResult",
          asin: asin,
          error: true,
          message: "サクラチェッカー未登録、または新規解析中の商品です。詳細ボタンから公式サイトを開くと自動で解析が始まります。"
        });
        return;
      }

      const visibleMsg = Array.from(document.querySelectorAll(".sakura-msg")).find(isVisible);
      const message = visibleMsg ? visibleMsg.textContent.trim() : "";
      const status = MESSAGE_TO_STATUS[message] || "不明";
      const percentage = extractPercentage(visibleAlert) || "不明";
      const reviewScoreNote = extractReviewScoreNote();

      chrome.runtime.sendMessage({
        action: "sakuraPageResult",
        asin: asin,
        result: { percentage: percentage, message: message, status: status, reviewScoreNote: reviewScoreNote }
      });
    } catch (e) {
      chrome.runtime.sendMessage({
        action: "sakuraPageResult",
        asin: asin,
        error: true,
        message: "分析結果の読み取り中にエラーが発生しました。"
      });
    }
  }

  // ページ側のJS(難読化解除・DOM書き換え)が完了するのを少し待ってから読み取る
  function scheduleExtract() {
    setTimeout(extractAndSend, 900);
  }

  if (document.readyState === "complete") {
    scheduleExtract();
  } else {
    window.addEventListener("load", scheduleExtract);
  }
})();
