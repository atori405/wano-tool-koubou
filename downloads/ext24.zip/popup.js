// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (!(window.chrome && chrome.tabs)) return;

  function openFallbackWindow() {
    var w = Math.min(screen.availWidth, 380);
    var h = Math.min(screen.availHeight, 640);
    var left = Math.round((screen.availWidth - w) / 2);
    var top = Math.round((screen.availHeight - h) / 4);
    chrome.windows.create({
      url: chrome.runtime.getURL("popup.html?mode=window"),
      type: "popup",
      width: w,
      height: h,
      left: left,
      top: top,
      focused: true
    });
  }

  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    if (tabs && tabs[0] && tabs[0].id) {
      chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
        if (chrome.runtime.lastError || !response || response.status !== "toggled") {
          openFallbackWindow();
        }
        window.close();
      });
    } else {
      openFallbackWindow();
      window.close();
    }
  });
})();
// -----------------------------------------------------------------

document.addEventListener("DOMContentLoaded", () => {
  const statusText = document.getElementById("license-status-text");
  const openLicenseBtn = document.getElementById("open-license-btn");

  if (window.LicenseManager) {
    LicenseManager.checkStatus().then((status) => {
      if (status.status === "premium") {
        statusText.textContent = "ライセンス認証済み(プロ版)です。すべての機能を無制限にご利用いただけます。";
      } else if (status.status === "trial") {
        statusText.textContent = `無料お試し期間中です(残り${status.daysLeft}日)。`;
      } else {
        statusText.textContent = "無料お試し期間が終了しています。引き続きご利用いただくにはライセンスキーを設定してください。";
      }
    }).catch(() => {
      statusText.textContent = "ご利用状況を取得できませんでした。";
    });
  } else {
    statusText.textContent = "ご利用状況を取得できませんでした。";
  }

  openLicenseBtn.addEventListener("click", () => {
    if (chrome.runtime.openOptionsPage) {
      chrome.runtime.openOptionsPage();
    } else {
      window.open(chrome.runtime.getURL("license/license-options.html"));
    }
  });
});
