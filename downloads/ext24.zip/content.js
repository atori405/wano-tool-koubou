// ============================================
// サクラチェッカー連携ツール — Content Script
// ============================================

(async function () {
  // 1. Try to extract ASIN code from Amazon product page
  const asin = getAsinFromPage();
  if (!asin) {
    console.log("Sakura Checker Integration: No ASIN found on this page.");
    return;
  }

  // トライアル期限ゲート: 期限切れなら本体機能を起動せず、控えめな通知だけ出す
  // (<all_urls> で動く拡張機能のため、ASINが見つかった＝Amazon商品ページの場合のみ判定する)
  const trialActive = await window.WanoTrialGate.checkTrialActive();
  if (!trialActive) {
    window.WanoTrialGate.showTrialExpiredNotice("サクラチェッカー連携");
    return;
  }

  console.log(`Sakura Checker Integration: Found ASIN ${asin}. Checking details...`);

  // 2. Query the background worker for Sakura Checker details
  chrome.runtime.sendMessage({ action: "checkSakura", asin: asin }, (response) => {
    if (chrome.runtime.lastError || !response) {
      console.warn("Sakura Checker Integration: Failed to get response from background.");
      return;
    }

    // 3. Inject the badge into the Amazon rating area
    injectSakuraBadge(asin, response);
  });

  function getAsinFromPage() {
    // Attempt A: Input element (most reliable for detail pages)
    const asinInput = document.getElementById("ASIN");
    if (asinInput && asinInput.value) {
      return asinInput.value.trim();
    }

    // Attempt B: URL pattern matching
    const url = window.location.href;
    const match = url.match(/\/dp\/([A-Z0-9]{10})/i) || url.match(/\/gp\/product\/([A-Z0-9]{10})/i);
    if (match) {
      return match[1].trim();
    }

    return null;
  }

  function injectSakuraBadge(asin, data) {
    // Find the Amazon review section
    const target = document.getElementById("averageCustomerReviews_feature_div") || 
                   document.getElementById("averageCustomerReviews") ||
                   document.getElementById("titleSection");
                   
    if (!target) {
      console.warn("Sakura Checker Integration: Could not find target div to inject badge.");
      return;
    }

    // Check if we already injected a badge to prevent duplicates
    if (document.getElementById("sakura-badge-root")) return;

    // Create container wrapper
    const root = document.createElement("div");
    root.id = "sakura-badge-root";
    root.className = "sakura-badge-wrapper";

    let pctText = data.percentage || "分析不可";
    let statusClass = "sakura-status-unknown";
    let statusLabel = data.status || "判定不能";
    let message = data.message || "データがないか、レビュー件数が少ないため分析できません。";
    let pctInt = 0;

    if (data.error) {
      statusClass = "sakura-status-unknown";
      statusLabel = "分析不可";
      pctText = "分析不可";
    } else {
      pctInt = parseInt(data.percentage) || 0;
      if (pctInt >= 90) {
        statusClass = "sakura-status-danger";
      } else if (pctInt >= 50) {
        statusClass = "sakura-status-warn-high";
      } else if (pctInt >= 20) {
        statusClass = "sakura-status-warn-low";
      } else {
        statusClass = "sakura-status-safe";
      }
    }

    // Construct circular chart background gradient
    // 0% -> full grey circle, 100% -> full color circle
    const chartColor = pctInt >= 50 ? "#ff3b30" : (pctInt >= 20 ? "#ff9500" : "#34c759");
    const chartGradient = `conic-gradient(${chartColor} 0deg ${pctInt * 3.6}deg, rgba(255,255,255,0.1) ${pctInt * 3.6}deg 360deg)`;

    // Inject the structured HTML (combines badge + nested hover popup)
    const badgeHtml = data.error 
      ? `<span class="sakura-logo">🌸</span>
         <span class="sakura-label">サクラ度:</span>
         <span class="sakura-value">${pctText}</span>
         <span class="sakura-arrow">▾</span>`
      : `<span class="sakura-logo">🌸</span>
         <span class="sakura-label">サクラ度:</span>
         <span class="sakura-value">${pctText}</span>
         <span class="sakura-badge-tag">${statusLabel}</span>
         <span class="sakura-arrow">▾</span>`;

    root.innerHTML = `
      <div class="sakura-inline-badge ${statusClass}">
        ${badgeHtml}
      </div>

      <!-- Popover Detailed Card -->
      <div class="sakura-popover-card">
        <div class="sakura-card-header">
          <span class="sakura-card-logo">🌸 サクラチェッカー判定</span>
          <span class="sakura-card-status-label ${statusClass}-text">${statusLabel}</span>
        </div>
        <div class="sakura-card-body">
          <div class="sakura-chart-area">
            <div class="sakura-circle-chart" style="background: ${chartGradient}">
              <div class="sakura-circle-inner">${pctText}</div>
            </div>
          </div>
          <div class="sakura-message-area">
            <p class="sakura-msg-title">サクラ危険度評価</p>
            <p class="sakura-msg-content">${message}</p>
          </div>
        </div>
        <div class="sakura-card-footer">
          <a href="https://sakura-checker.jp/search/${asin}/" target="_blank" class="sakura-detail-link-btn">
            サクラチェッカーで詳細レポートを見る ➔
          </a>
        </div>
      </div>
    `;

    // Append root to Amazon page
    target.appendChild(root);
  }
})();


// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // Add temporary shield to prevent iframe from stealing mouse events during dragging
      const existingShield = document.getElementById("wano-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = "wano-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      // Use getBoundingClientRect() for correct viewport-relative position
      // (element.offsetTop is unreliable for position:fixed elements on scrolled pages)
      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      // Restrict within window boundaries to prevent going offscreen
      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById("wano-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById("wano-universal-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "block" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = "wano-universal-floating-container";
    
    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 440) + "px !important; z-index:2147483647 !important; width:430px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="wano-u-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">Sakura Checker</span>
        </div>
        <button id="wano-u-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#wano-u-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#wano-u-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
