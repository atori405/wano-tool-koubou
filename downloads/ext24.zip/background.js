// ============================================
// サクラチェッカー連携ツール — Background Script
// ============================================

const CACHE_TTL = 24 * 60 * 60 * 1000; // 24 hours in milliseconds

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "checkSakura") {
    const asin = request.asin;
    
    // 1. Check local storage cache first (using v2 key to clear old buggy caches)
    const cacheKey = `sakura_cache_v2_${asin}`;
    chrome.storage.local.get([cacheKey], (data) => {
      if (data && data[cacheKey]) {
        const cached = data[cacheKey];
        const age = Date.now() - cached.timestamp;
        if (age < CACHE_TTL) {
          console.log(`Cache hit for ASIN: ${asin}`);
          sendResponse(cached.result);
          return;
        }
      }
      
      // 2. Fetch fresh details from Sakura Checker if no valid cache
      fetchSakuraDetails(asin)
        .then((result) => {
          // CRITICAL: Only cache successful analysis results (do not cache errors!)
          if (result && !result.error) {
            const storeData = {};
            storeData[cacheKey] = {
              result: result,
              timestamp: Date.now()
            };
            chrome.storage.local.set(storeData);
          }
          sendResponse(result);
        })
        .catch((error) => {
          console.error("Error fetching Sakura Checker details:", error);
          sendResponse({ error: true, message: "分析結果の取得に失敗しました。" });
        });
    });
    
    return true; // Keep message channel open for asynchronous sendResponse
  }
});

async function fetchSakuraDetails(asin) {
  const url = `https://sakura-checker.jp/search/${asin}/`;
  
  const headers = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"
  };

  const response = await fetch(url, { headers });
  if (!response.ok) {
    if (response.status === 404) {
      return { error: true, message: "商品未登録（データなし）" };
    }
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  const html = await response.text();
  return parseSakuraHtml(html);
}

function parseSakuraHtml(html) {
  if (html.includes("該当する商品は見つかりませんでした") || html.includes("正しいURLを入力してください")) {
    return { error: true, message: "サクラチェッカー未登録、または新規解析中の商品です。詳細ボタンから公式サイトを開くと自動で解析が始まります。" };
  }

  // 1. Locate all base64-looking strings inside single quotes (length > 40)
  const candidates = html.match(/'([A-Za-z0-9+/=]{40,})'/g) || [];
  
  let percentage = null;
  let message = "";
  let level = "00";
  let status = "不明";

  // Recursive decoder helper for double/nested base64 obfuscation
  function recursiveDecode(payload) {
    try {
      const decoded = atob(payload);
      const unquoted = decodeURIComponent(decoded);
      
      // Find all nested single-quoted Base64-looking strings
      const nestedMatches = unquoted.match(/'([A-Za-z0-9+/=]{40,})'/g) || [];
      if (nestedMatches.length > 0) {
        let accumulated = unquoted;
        for (let nested of nestedMatches) {
          const nestedB64 = nested.replace(/'/g, "");
          const nestedDecoded = recursiveDecode(nestedB64);
          if (nestedDecoded) {
            accumulated += "\n" + nestedDecoded;
          }
        }
        return accumulated;
      }
      return unquoted;
    } catch (e) {
      return null;
    }
  }

  for (let cand of candidates) {
    const rawB64 = cand.replace(/'/g, "");
    const unquoted = recursiveDecode(rawB64);
    if (!unquoted) continue;

    // Parse metrics from the fully decoded HTML (first match only)
    const pctMatch = unquoted.match(/<span>(\d+%)<\/span>/);
    if (pctMatch && !percentage) {
      percentage = pctMatch[1];
    }

    const msgMatch = unquoted.match(/class="sakura-msg[^"]*">([^<]+)<\/span>/) || unquoted.match(/class="[^"]*sakura-msg[^"]*">([^<]+)/);
    if (msgMatch && !message) {
      message = msgMatch[1].trim();
    }

    const lvMatch = unquoted.match(/\/images\/sakura_lv(\d+)\.png/);
    if (lvMatch && level === "00") {
      level = lvMatch[1];
    }

    const labelMatch = unquoted.match(/sakura_label(\d+)\.png"\s+alt\s*=\s*"\s*([^"]+)"/);
    if (labelMatch && status === "不明") {
      status = labelMatch[2].trim();
    }
  }

  // 2. Apply robust fallbacks if some values are missing
  if (percentage) {
    const pctNum = parseInt(percentage);
    if (pctNum >= 90) {
      status = "超危険";
    } else if (pctNum >= 50) {
      status = "危険";
    } else if (pctNum >= 20) {
      status = "警告";
    } else {
      status = "合格";
    }
  } else {
    // If no percentage was found in text but level image was detected
    const lvlNum = parseInt(level);
    percentage = `${lvlNum}%`;
    if (lvlNum >= 90) status = "超危険";
    else if (lvlNum >= 50) status = "危険";
    else if (lvlNum >= 20) status = "警告";
    else status = "合格";
  }

  if (!message) {
    if (status === "合格") message = "安全な商品です！";
    else if (status === "警告") message = "サクラの疑いがあります。";
    else if (status === "危険" || status === "超危険") message = "サクラレビューが多数検出されました！";
  }

  // Handle completely unanalyzable pages (e.g. reviews disabled or no data)
  if (html.includes("分析不可") && percentage === "0%" && status === "合格") {
    // If it literally says "分析不可" on the page and it fallback-ed to 0%, it means we couldn't analyze
    return { error: true, message: "サクラチェッカー未登録、または新規解析中の商品です。詳細ボタンから公式サイトを開くと自動で解析が始まります。" };
  }

  return { percentage, message, level, status };
}
