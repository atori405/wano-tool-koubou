// ============================================
// サクラチェッカー連携ツール — Background Script
// ============================================
//
// 本家サイト(sakura-checker.jp)のHTMLは難読化されており、同一ページ内に
// 実際に表示している商品以外の判定文(先読み用ダミー・関連ランキング商品分)が
// 大量に混在している。単純な文字列デコードでは本物と偽物を区別できなかったため、
// 実際にそのページをバックグラウンドタブで開いて本物のブラウザにレンダリング・
// JS実行させ、「実際に画面上に表示されている(サイズが0でない)要素」だけを
// content script(sakura-page-scraper.js)で読み取る方式にしている。
// これにより本家サイトが実際に表示する判定ラベル・メッセージをそのまま使える。

const CACHE_TTL = 24 * 60 * 60 * 1000; // 24 hours in milliseconds
const FETCH_TIMEOUT = 15000;

const pendingSakuraRequests = {}; // asin -> { resolve, reject, tabId }

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "checkSakura") {
    const asin = request.asin;

    // v3: 旧方式(HTML文字列を独自解析)のキャッシュを無効化するためキー名を更新
    const cacheKey = `sakura_cache_v3_${asin}`;
    chrome.storage.local.get([cacheKey], (data) => {
      if (data && data[cacheKey]) {
        const cached = data[cacheKey];
        const age = Date.now() - cached.timestamp;
        if (age < CACHE_TTL) {
          sendResponse(cached.result);
          return;
        }
      }

      fetchSakuraDetailsViaTab(asin)
        .then((result) => {
          if (result && !result.error) {
            const storeData = {};
            storeData[cacheKey] = { result: result, timestamp: Date.now() };
            chrome.storage.local.set(storeData);
          }
          sendResponse(result);
        })
        .catch((error) => {
          console.error("Error fetching Sakura Checker details:", error);
          sendResponse({ error: true, message: "分析結果の取得に失敗しました。" });
        });
    });

    return true; // Keep message channel open for asynchronous sendResponse
  }

  if (request.action === "sakuraPageResult") {
    const pending = pendingSakuraRequests[request.asin];
    if (pending) {
      if (request.error) {
        pending.resolve({ error: true, message: request.message || "分析結果を取得できませんでした。" });
      } else {
        pending.resolve(request.result);
      }
    }
    return false;
  }
});

function fetchSakuraDetailsViaTab(asin) {
  return new Promise((resolve) => {
    const url = `https://sakura-checker.jp/search/${asin}/`;

    chrome.tabs.create({ url: url, active: false }, (tab) => {
      if (chrome.runtime.lastError || !tab) {
        resolve({ error: true, message: "解析用タブを開けませんでした。" });
        return;
      }

      let done = false;
      const timeoutId = setTimeout(() => {
        finish({ error: true, message: "分析がタイムアウトしました。時間をおいて再度お試しください。" });
      }, FETCH_TIMEOUT);

      function finish(result) {
        if (done) return;
        done = true;
        clearTimeout(timeoutId);
        delete pendingSakuraRequests[asin];
        chrome.tabs.remove(tab.id, () => {
          if (chrome.runtime.lastError) { /* タブは既に閉じられている等、無視してよい */ }
        });
        resolve(result);
      }

      pendingSakuraRequests[asin] = { resolve: finish };
    });
  });
}
