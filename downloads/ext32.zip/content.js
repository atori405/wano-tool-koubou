// content.js - Safe Reading & Writing Checker (NO DOM DELETION)
(function() {
  let lastActiveInputEl = null;

  // Track the last focused input field (textarea or contenteditable)
  // because clicking the extension popup will steal focus from the editor.
  document.addEventListener("focusin", (e) => {
    const el = e.target;
    if (el && (el.tagName === "TEXTAREA" || el.isContentEditable || (el.tagName === "INPUT" && el.type === "text"))) {
      lastActiveInputEl = el;
    }
  });

  // Extract page text based on selection, focus history, and rich editor detection
  function extractPageText() {
    // 1. Text Selection (User highlighted text)
    let selection = window.getSelection().toString();
    
    // Check iframes for selected text (same-origin only)
    if (!selection) {
      const iframes = document.querySelectorAll("iframe");
      for (const iframe of iframes) {
        try {
          const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
          const iframeSel = iframeDoc.getSelection().toString();
          if (iframeSel) {
            selection = iframeSel;
            break;
          }
        } catch (e) {}
      }
    }
    
    if (selection && selection.trim().length > 0) {
      return selection;
    }

    // 2. Active or Last Active Input Area
    let activeEl = document.activeElement;
    if (activeEl && activeEl.tagName === "IFRAME") {
      try {
        const iframeDoc = activeEl.contentDocument || activeEl.contentWindow.document;
        activeEl = iframeDoc.activeElement;
      } catch (e) {}
    }

    const targetEl = (activeEl && (activeEl.tagName === "TEXTAREA" || activeEl.isContentEditable)) ? activeEl : lastActiveInputEl;
    if (targetEl) {
      const text = targetEl.innerText || targetEl.value || "";
      if (text.trim().length > 0) {
        return text;
      }
    }

    // 3. WordPress (Gutenberg) and common rich editor detection
    const editorSelectors = [
      ".editor-styles-wrapper", // WordPress Gutenberg
      ".block-editor-writing-flow", // WordPress Block Editor
      ".wp-block-post-title", // WP Title Block
      ".note-editable", // Summernote
      ".cke_editable", // CKEditor
      ".mce-content-body", // TinyMCE (WordPress Classic)
      "[role='textbox']", // Generic editors
      "textarea" // Any raw textarea
    ];

    // Main window check
    for (const selector of editorSelectors) {
      const el = document.querySelector(selector);
      if (el) {
        const text = el.innerText || el.value || "";
        if (text.trim().length > 0) {
          return text;
        }
      }
    }

    // Same-origin iframe check (for nested Gutenberg canvas or classic TinyMCE iframe)
    const iframes = document.querySelectorAll("iframe");
    for (const iframe of iframes) {
      try {
        const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
        for (const selector of editorSelectors) {
          const el = iframeDoc.querySelector(selector);
          if (el) {
            const text = el.innerText || el.value || "";
            if (text.trim().length > 0) {
              return text;
            }
          }
        }
      } catch (e) {}
    }

    // 4. Default article or main body fallback
    const mainEl = document.querySelector("article, main, .entry-content, [role='main']") || document.body;
    return mainEl.innerText || "";
  }

  // Extract heading structure from the main document or within WordPress canvas iframe
  function extractHeadings() {
    const headingSelectors = "h1, h2, h3, h4";
    let headings = [];

    // Main window extraction
    const mainHeadings = Array.from(document.querySelectorAll(headingSelectors));
    const editorEl = document.querySelector(".editor-styles-wrapper");
    const targetHeadings = editorEl ? Array.from(editorEl.querySelectorAll(headingSelectors)) : mainHeadings;

    headings = targetHeadings.map(h => ({
      tag: h.tagName,
      text: (h.innerText || "").trim().slice(0, 50)
    }));

    // If no headings found, check inside same-origin iframe (WordPress editor canvas)
    if (headings.length === 0) {
      const iframes = document.querySelectorAll("iframe");
      for (const iframe of iframes) {
        try {
          const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
          const iframeEditor = iframeDoc.querySelector(".editor-styles-wrapper");
          const iframeHeadings = Array.from((iframeEditor || iframeDoc).querySelectorAll(headingSelectors));
          if (iframeHeadings.length > 0) {
            headings = iframeHeadings.map(h => ({
              tag: h.tagName,
              text: (h.innerText || "").trim().slice(0, 50)
            }));
            break;
          }
        } catch (e) {}
      }
    }

    return headings;
  }

  // Listener for analyzer trigger message
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "analyzePageText") {
      const text = extractPageText();
      const headings = extractHeadings();

      sendResponse({
        text: text,
        headings: headings,
        url: window.location.href,
        title: document.title
      });
    }
    return true;
  });
})();


// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  // 拡張機能ごとに一意なDOM ID接頭辞。この接頭辞を使わずリテラル文字列のIDのままだと、
  // 同じ仕組みを使う他の拡張機能(ext04/ext10等)と同じページ上でIDが衝突し、
  // document.getElementByIdが他拡張機能のコンテナを誤って見つけてしまう
  // (アイコンをクリックすると別の拡張機能のパネルが開くバグの原因だった)。
  const NS_ID = "wano-" + chrome.runtime.id;

  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // パネル自身が持つiframeは、ドラッグ中に一時的にpointer-eventsを無効化する。
      // 有効なままだと、ドラッグでマウスがiframe上を通った瞬間にmousemove/mouseup
      // がiframe側に奪われ、親ドキュメントがドラッグ終了を検知できなくなる
      // (シールドがiframeより低いz-indexのため覆いきれない)。その結果、
      // 全画面シールドとカーソルが「move」のまま貼りついたようになるバグがあった。
      const iframeEl = element.querySelector("iframe");
      if (iframeEl) iframeEl.style.setProperty("pointer-events", "none", "important");

      // Add temporary shield to prevent iframe from stealing mouse events during dragging
      const existingShield = document.getElementById(NS_ID + "-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = NS_ID + "-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      // Use getBoundingClientRect() for correct viewport-relative position
      // (element.offsetTop is unreliable for position:fixed elements on scrolled pages)
      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      // Restrict within window boundaries to prevent going offscreen
      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const iframeEl = element.querySelector("iframe");
      if (iframeEl) iframeEl.style.removeProperty("pointer-events");
      const shield = document.getElementById(NS_ID + "-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById(NS_ID + "-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "block" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = NS_ID + "-floating-container";

    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 440) + "px !important; z-index:2147483647 !important; width:430px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="${NS_ID}-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">Japanese Writing Checker</span>
        </div>
        <button id="${NS_ID}-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#" + NS_ID + "-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#" + NS_ID + "-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
