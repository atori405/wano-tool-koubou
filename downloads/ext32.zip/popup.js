// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  function openFallbackWindow() {
    // Fail-safe: Open popup.html as a draggable Chrome popup window
    var w = Math.min(screen.availWidth, 420);
    var h = Math.min(screen.availHeight, 620);
    var left = Math.round((screen.availWidth - w) / 2);
    var top = Math.round((screen.availHeight - h) / 4);
    chrome.windows.create({
      url: chrome.runtime.getURL("popup.html?mode=window"),
      type: "popup",
      width: w,
      height: h,
      left: left,
      top: top,
      focused: true
    });
  }

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        var tabId = tabs[0].id;
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabId, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Content script is likely stale/missing on this tab (e.g. the tab was
            // already open before the extension was installed/updated). Re-inject it
            // on demand and retry once before falling back to a separate OS window
            // (the separate-window fallback can vanish and never reappear).
            if (chrome.scripting) {
              chrome.scripting.executeScript({
                target: { tabId: tabId },
                files: ["draggable.js", "content.js"]
              }, function() {
                if (chrome.runtime.lastError) {
                  openFallbackWindow();
                  window.close();
                  return;
                }
                chrome.tabs.sendMessage(tabId, { action: "toggleFloatingPanel" }, function(response2) {
                  if (chrome.runtime.lastError || !response2 || response2.status !== "toggled") {
                    openFallbackWindow();
                  }
                  window.close();
                });
              });
              return;
            }
            openFallbackWindow();
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

document.addEventListener("DOMContentLoaded", () => {
  const btnAnalyze = document.getElementById("btn-analyze");
  const btnReset = document.getElementById("btn-reset");
  const valCharCount = document.getElementById("val-char-count");
  const valReadTime = document.getElementById("val-read-time");
  const valParagraphCount = document.getElementById("val-paragraph-count");
  const valHeadingCount = document.getElementById("val-heading-count");
  const headingTree = document.getElementById("heading-tree");
  const redundantList = document.getElementById("redundant-list");
  const headingAdvice = document.getElementById("heading-advice");
  
  // New Scan Range Elements
  const scanRangeBox = document.getElementById("scan-range-box");
  const scanRangeText = document.getElementById("scan-range-text");

  // --- Click: Analyze Button ---
  btnAnalyze.addEventListener("click", () => {
    let handled = false;

    // 1. Try Extension Message Passing
    if (window.chrome && chrome.tabs && chrome.runtime && chrome.runtime.id) {
      chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
        if (tabs && tabs[0] && tabs[0].id) {
          chrome.tabs.sendMessage(tabs[0].id, { action: "analyzePageText" }, (response) => {
            if (chrome.runtime.lastError || !response) {
              runStandaloneAnalysis();
            } else {
              processAnalysis(response.text, response.headings);
            }
          });
          handled = true;
        }
      });
    }

    // 2. Standalone fallback (for previews inside sandbox.html iframe or before install)
    if (!handled) {
      runStandaloneAnalysis();
    }
  });

  // --- Click: Reset Button ---
  btnReset.addEventListener("click", () => {
    valCharCount.textContent = "0";
    valReadTime.textContent = "0分";
    valParagraphCount.textContent = "0";
    valHeadingCount.textContent = "0";
    
    headingTree.innerHTML = '<p class="placeholder">「リアルタイム診断」を押すと、文章の見出し構造が表示されます。</p>';
    redundantList.innerHTML = '<p class="placeholder">「〜ということ」「〜を行う」などの冗長表現が検出されます。</p>';
    
    headingAdvice.style.display = "none";
    headingAdvice.textContent = "";
    headingAdvice.className = "tree-advice";

    scanRangeBox.style.display = "none";
    scanRangeText.textContent = "";
  });

  // Standalone Analysis fallback for previews
  function runStandaloneAnalysis() {
    let sampleText = "";
    let sampleHeadings = [];

    try {
      const parentDoc = window.parent.document;
      const sampleBox = parentDoc.querySelector(".sample-box");
      if (sampleBox) {
        sampleText = sampleBox.innerText || sampleBox.textContent || "";
        
        // Scraping headings from parent box
        const headingEls = sampleBox.querySelectorAll("h1, h2, h3, h4, h5, h6");
        headingEls.forEach(el => {
          sampleHeadings.push({
            tag: el.tagName,
            text: el.innerText || el.textContent || ""
          });
        });
      }
    } catch (e) {
      console.log("親ウィンドウへのアクセス制限のため、モックデータを使用します。", e);
    }

    // Standard fallback mock values if parent scraping failed or returned empty
    if (!sampleText || sampleText.trim() === "") {
      sampleText = "一、Web執筆における推敲と見出し構造の重要性\nWeb記事やメルマガの執筆において、読者に途中で離脱されずに最後まで読み切ってもらうためには、適切な見出し構造（H1〜H3）を設定し、冗長な日本語表現を排除することが極めて重要となります。\n\n二、冗長表現の自動検出と簡略化を行うこと\n「〜ということ」や「〜を行う」「〜することが可能」といったまわりくどい日本語表現は、文章のテンポを損ねる原因となります。本ツールを使用することにより、コンマ1秒で冗長表現を検出してスッキリとした美しい文章へ推敲することが可能となります。";
      sampleHeadings = [
        { tag: "H2", text: "一、Web執筆における推敲と見出し構造の重要性" },
        { tag: "H3", text: "二、冗長表現の自動検出と簡略化を行うこと" }
      ];
    }

    processAnalysis(sampleText, sampleHeadings);
  }

  // Helper to slice context text around the matched redundant phrases
  function getContextSnippets(text, patternRegex) {
    const snippets = [];
    let match;
    
    // Ensure regex has global flag to find all matches, but clone to prevent altering original
    const flags = patternRegex.flags.includes('g') ? patternRegex.flags : patternRegex.flags + 'g';
    const regex = new RegExp(patternRegex.source, flags);

    while ((match = regex.exec(text)) !== null) {
      const matchIndex = match.index;
      const matchText = match[0];
      
      const start = Math.max(0, matchIndex - 10);
      const end = Math.min(text.length, matchIndex + matchText.length + 10);
      
      let prefix = text.substring(start, matchIndex);
      let suffix = text.substring(matchIndex + matchText.length, end);
      
      // Clean up whitespace/newlines for single line display
      prefix = prefix.replace(/\n+/g, " ");
      suffix = suffix.replace(/\n+/g, " ");
      
      if (start > 0) prefix = "..." + prefix;
      if (end < text.length) suffix = suffix + "...";
      
      snippets.push({
        prefix: prefix,
        match: matchText,
        suffix: suffix
      });
    }
    return snippets;
  }

  // Core Text & Structure Analyzer
  function processAnalysis(text, headings) {
    const chars = text.length;
    valCharCount.textContent = chars.toLocaleString() + "文字";
    
    // Average Japanese reading speed: 500 chars/min
    const readMin = Math.max(1, Math.ceil(chars / 500));
    valReadTime.textContent = readMin + "分";

    const paragraphs = text.split(/\n+/).filter(p => p.trim().length > 0);
    valParagraphCount.textContent = paragraphs.length.toString();

    valHeadingCount.textContent = (headings || []).length.toString();

    // 0. Render Scan Range Preview
    if (chars > 0) {
      scanRangeBox.style.display = "block";
      let rangeText = "";
      if (chars <= 60) {
        rangeText = `「 ${text.trim()} 」`;
      } else {
        const cleanedText = text.replace(/\s+/g, " ").trim();
        rangeText = `「 ${cleanedText.substring(0, 30)} ... (中略) ... ${cleanedText.substring(cleanedText.length - 30)} 」`;
      }
      scanRangeText.textContent = rangeText;
    } else {
      scanRangeBox.style.display = "none";
    }

    // 1. Render Heading Tree with Indentation
    if (headings && headings.length > 0) {
      headingTree.innerHTML = "";
      headings.forEach(h => {
        const div = document.createElement("div");
        const level = h.tag.toLowerCase();
        
        // Logical Tree Indentation
        let prefix = "";
        if (level === "h2") {
          prefix = "  ";
        } else if (level === "h3") {
          prefix = "    └ ";
        } else if (level === "h4") {
          prefix = "      └ ";
        }
        
        div.className = `tree-item tree-${level}`;
        div.textContent = `${prefix}${h.tag}: ${h.text}`;
        headingTree.appendChild(div);
      });

      // Analyze structure health
      analyzeHeadingStructure(headings);
    } else {
      headingTree.innerHTML = '<p class="placeholder">見出しは見つかりませんでした。</p>';
      headingAdvice.style.display = "block";
      headingAdvice.className = "tree-advice info";
      headingAdvice.textContent = "💡 アドバイス: 記事に見出し（H2〜H3）を設定すると、読者が文章の要点を理解しやすくなり、SEO効果も向上します。";
    }

    // 2. Redundant phrase checks with context snippets
    // 注意: これは登録済みパターンとの照合のみを行う簡易チェックです。
    // 日本語の冗長表現は無数にあり、ここに無いパターンは検出されません。
    const redundantPatterns = [
      { pattern: /ということ/g, label: "「〜ということ」", advice: "言葉遣いの簡略化を検討" },
      { pattern: /を行う/g, label: "「〜を行う」", advice: "➔ 「〜する」へ単縮可能" },
      { pattern: /することが可能/g, label: "「〜することが可能」", advice: "➔ 「〜できる」へ単縮可能" },
      { pattern: /することができる/g, label: "「〜することができる」", advice: "➔ 「〜できる」へ単縮可能" },
      { pattern: /において/g, label: "「〜において」", advice: "➔ 「〜で」へ単縮可能" },
      { pattern: /ではないかと思われる/g, label: "「〜ではないかと思われる」", advice: "➔ 曖昧な表現を避けて断定化を検討" },
      { pattern: /という形で/g, label: "「〜という形で」", advice: "➔ 削除または簡略化を検討" },
      { pattern: /と言えるだろう/g, label: "「〜と言えるだろう」", advice: "➔ 断定表現「〜だ」への言い換えを検討" },
      { pattern: /のではないだろうか/g, label: "「〜のではないだろうか」", advice: "➔ 曖昧な表現を避けて断定化を検討" }
    ];

    let foundAlerts = [];
    redundantPatterns.forEach(item => {
      const snippets = getContextSnippets(text, item.pattern);
      if (snippets.length > 0) {
        foundAlerts.push({
          label: item.label,
          advice: item.advice,
          count: snippets.length,
          snippets: snippets
        });
      }
    });

    if (foundAlerts.length > 0) {
      redundantList.innerHTML = "";
      foundAlerts.forEach(alert => {
        const itemDiv = document.createElement("div");
        itemDiv.className = "alert-group";
        
        // Title banner
        const titleSpan = document.createElement("div");
        titleSpan.className = "alert-title";
        titleSpan.textContent = `• ${alert.label} ${alert.advice} (検出: ${alert.count}回)`;
        itemDiv.appendChild(titleSpan);
        
        // Snippets Container
        const snippetsContainer = document.createElement("div");
        snippetsContainer.className = "alert-snippets";
        
        alert.snippets.forEach(s => {
          const sDiv = document.createElement("div");
          sDiv.className = "snippet-item";
          
          // Escape HTML safely
          const escPrefix = document.createTextNode(s.prefix);
          const escSuffix = document.createTextNode(s.suffix);
          
          const highlightSpan = document.createElement("span");
          highlightSpan.className = "highlight";
          highlightSpan.textContent = s.match;
          
          sDiv.appendChild(escPrefix);
          sDiv.appendChild(highlightSpan);
          sDiv.appendChild(escSuffix);
          
          snippetsContainer.appendChild(sDiv);
        });
        
        itemDiv.appendChild(snippetsContainer);
        redundantList.appendChild(itemDiv);
      });
    } else {
      redundantList.innerHTML = '<p class="placeholder" style="color:#81c784;">登録済みの冗長表現パターン（9種類）には一致しませんでした。ただしこれは限定的なチェックのため、一致が無い＝完璧な文章とは限りません。</p>';
    }
  }

  // Heading hierarchy validator (Provides clear layout advices)
  function analyzeHeadingStructure(headings) {
    let hasH2 = false;
    let prevLevel = 1; // Base H1
    let warningMsg = "";

    for (let i = 0; i < headings.length; i++) {
      const tag = headings[i].tag.toUpperCase();
      const currentLevel = parseInt(tag.replace("H", ""), 10);
      
      if (currentLevel === 2) hasH2 = true;

      // Check hierarchy skip (e.g. H2 directly to H4, skipping H3)
      if (currentLevel > prevLevel + 1) {
        warningMsg = `⚠️ 見出し警告: ${headings[i].text} (${tag}) の前に、上位の見出し（H${currentLevel - 1}など）が抜けています。階層が急に飛んでいます。`;
        break;
      }
      
      // Check H3 before any H2
      if (currentLevel === 3 && !hasH2) {
        warningMsg = `⚠️ 見出し警告: H2 見出しが存在しない状態で、H3 見出しが配置されています。文章の親子構造が不自然です。`;
        break;
      }
      
      prevLevel = currentLevel;
    }

    headingAdvice.style.display = "block";
    if (warningMsg) {
      headingAdvice.className = "tree-advice warning";
      headingAdvice.textContent = warningMsg;
    } else {
      headingAdvice.className = "tree-advice success";
      headingAdvice.textContent = "✅ 見出し階層は完璧です！論理的で読みやすい親子構造になっています。";
    }
  }
});
