// background.js - Service Worker for Japanese Annotated JSON Viewer

chrome.runtime.onInstalled.addListener(() => {
  console.log("日本語注釈付きJSONビューア 拡張機能が正常にインストールされました。");
});
