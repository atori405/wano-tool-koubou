// background.js - Service Worker for Japanese Annotated JSON Viewer

chrome.runtime.onInstalled.addListener(() => {
  console.log("日本語注釈付きJSONビューア 拡張機能が正常にインストールされました。");
});

// この拡張機能はpopup/optionsページを持たず、JSONページを開くと自動的に
// 動作する設計(license/trial-gate.jsのコメント参照)。アイコンをクリックした
// ときに何も起きないと分かりにくいため、簡単な案内をページ上に表示する。
chrome.action.onClicked.addListener((tab) => {
  if (!tab || !tab.id) return;
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      if (document.getElementById('wano-json-viewer-hint')) return;
      var badge = document.createElement('div');
      badge.id = 'wano-json-viewer-hint';
      badge.style.cssText =
        'position:fixed !important; bottom:16px !important; right:16px !important; ' +
        'z-index:2147483647 !important; background:#1c1a17 !important; color:#fdfcfa !important; ' +
        'font-family:sans-serif !important; font-size:13px !important; line-height:1.6 !important; ' +
        'padding:12px 16px !important; border-radius:6px !important; ' +
        'box-shadow:0 8px 24px rgba(0,0,0,0.35) !important; max-width:260px !important;';
      badge.innerHTML =
        '<strong>日本語注釈付きJSONビューア</strong><br>このツールはボタン操作不要です。JSON形式のページ(APIレスポンスや.jsonファイルなど)を開くと自動的に日本語注釈が表示されます。';
      document.body.appendChild(badge);
      setTimeout(function () { badge.remove(); }, 6000);
    }
  }).catch((e) => {
    console.warn('[wano-json-viewer] could not show hint on this page:', e && e.message);
  });
});
