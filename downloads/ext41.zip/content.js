// content.js - Japanese Annotated JSON Viewer Core

// --- 1. IT English-to-Japanese Translation Dictionary (250+ terms) ---
const TRANSLATION_DICTIONARY = {
  // Common Entity & Fields
  user: "ユーザー",
  profile: "プロフィール",
  name: "名前",
  firstname: "名",
  lastname: "姓",
  myoji: "苗字",
  shimei: "氏名",
  namae: "名前",
  mail: "メール",
  email: "メールアドレス",
  phone: "電話番号",
  tel: "電話番号",
  denwa: "電話",
  mobile: "携帯番号",
  address: "住所",
  jusho: "住所",
  post: "郵便",
  zip: "郵便番号",
  yubin: "郵便番号",
  country: "国",
  nation: "国家",
  prefecture: "都道府県",
  city: "市区町村",
  town: "町名",
  street: "番地",
  building: "建物・ビル",
  room: "部屋番号",
  floor: "階数",
  location: "位置情報",
  geo: "地理位置",
  latitude: "緯度",
  longitude: "経度",
  lat: "緯度",
  lng: "経度",
  lon: "経度",
  age: "年齢",
  gender: "性別",
  sex: "性別",
  male: "男性",
  female: "女性",
  birthday: "誕生日",
  birth: "出生",

  // Account & Auth
  account: "アカウント",
  balance: "残高",
  point: "ポイント",
  score: "スコア",
  grade: "評価・学年",
  rank: "ランク",
  level: "レベル",
  role: "役割・権限",
  permission: "権限",
  token: "トークン",
  key: "キー",
  password: "パスワード",
  pwd: "パスワード",
  login: "ログイン",
  logout: "ログアウト",
  register: "登録",
  signup: "サインアップ",
  signin: "サインイン",
  auth: "認証",
  admin: "管理者",
  manager: "管理者",

  // Content & Meta
  title: "タイトル",
  subject: "件名・主題",
  desc: "説明",
  description: "説明文",
  content: "コンテンツ内容",
  body: "本文・ボディ",
  text: "テキストテキスト",
  url: "URL",
  uri: "URI",
  link: "リンク",
  href: "リンク先",
  src: "ソース元",
  source: "情報源",
  file: "ファイル",
  image: "画像",
  img: "画像",
  pic: "写真",
  photo: "写真",
  icon: "アイコン",
  avatar: "アバター",
  logo: "ロゴ",
  video: "動画",
  movie: "動画",
  audio: "音声",
  sound: "サウンド",
  music: "音楽",
  song: "楽曲",
  track: "トラック",
  artist: "アーティスト",
  album: "アルバム",
  genre: "ジャンル",
  tag: "タグ",
  label: "ラベル",
  flag: "フラグ",

  // Business & Shop
  price: "価格",
  cost: "コスト",
  fee: "手数料",
  tax: "税金",
  amount: "金額",
  total: "合計額",
  subtotal: "小計",
  quantity: "数量",
  qty: "数量",
  item: "アイテム",
  list: "リスト",
  product: "商品",
  goods: "グッズ",
  store: "店舗",
  shop: "ショップ",
  order: "注文",
  purchase: "購入",
  payment: "支払い",
  card: "カード",
  bank: "銀行",
  coupon: "クーポン",
  discount: "割引",
  shipping: "発送・送料",
  delivery: "配送",
  status: "ステータス",
  state: "状態",
  type: "種類",
  category: "カテゴリ",
  group: "グループ",
  class: "クラス",

  // Actions & States
  created: "作成",
  updated: "更新",
  deleted: "削除",
  modified: "変更",
  registered: "登録",
  joined: "参加",
  published: "公開",
  released: "リリース",
  started: "開始",
  ended: "終了",
  finished: "完了",
  completed: "完了",
  failed: "失敗",
  success: "成功",
  error: "エラー",
  message: "メッセージ",
  msg: "メッセージ",
  info: "情報",
  detail: "詳細",
  index: "インデックス",
  limit: "制限件数",
  offset: "開始位置",
  next: "次へ",
  prev: "前へ",
  first: "最初",
  last: "最後",
  start: "開始",
  end: "終了",
  time: "時間",
  date: "日付",
  datetime: "日時",
  year: "年",
  month: "月",
  day: "日",
  hour: "時間",
  minute: "分",
  second: "秒",

  // Systems & Tech
  setting: "設定",
  config: "設定",
  option: "オプション",
  preference: "環境設定",
  custom: "カスタム",
  theme: "テーマ",
  color: "カラー",
  style: "スタイル",
  layout: "レイアウト",
  view: "ビュー",
  mode: "モード",
  version: "バージョン",
  build: "ビルド",
  platform: "プラットフォーム",
  os: "OS",
  device: "デバイス",
  browser: "ブラウザ",
  agent: "エージェント",
  ip: "IPアドレス",
  host: "ホスト",
  port: "ポート",
  api: "API",
  method: "メソッド",
  path: "パス",
  header: "ヘッダー",
  request: "リクエスト",
  response: "レスポンス",
  param: "パラメータ",
  parameter: "パラメータ",
  json: "JSON",
  xml: "XML",
  data: "データ",
  object: "オブジェクト",
  array: "配列",
  value: "値",
  type: "型",
  id: "ID",
  code: "コード",
  number: "番号",
  no: "番号",
  num: "番号",
  count: "件数",
  size: "サイズ",
  length: "長さ",
  width: "幅",
  height: "高さ",
  depth: "深さ",
  weight: "重さ",

  // Common Romanized Japanese (for Japanese developer habit)
  kubun: "区分",
  bikou: "備考",
  biko: "備考",
  shosai: "詳細",
  henshu: "編集",
  sakujo: "削除",
  shinki: "新規作成",
  toroku: "登録",
  kojin: "個人",
  hojin: "法人",
  muryo: "無料",
  yuryo: "有料",
  kengen: "権限",
  flg: "フラグ"
};

// --- 2. Advanced Grammar Parser Engine ---
function translateKey(key) {
  if (!key || typeof key !== "string") return "";

  // Check direct exact match
  const lowerKey = key.toLowerCase();
  if (TRANSLATION_DICTIONARY[lowerKey]) {
    return TRANSLATION_DICTIONARY[lowerKey];
  }

  // Tokenize CamelCase or snake_case
  // Split by underscore or capital letters
  const tokens = key
    .replace(/([A-Z])/g, "_$1") // Camel to Snake spacer
    .split(/[^a-zA-Z0-9]+/)     // Split by non-alphabetic
    .filter(t => t.length > 0)
    .map(t => t.toLowerCase());

  if (tokens.length === 0) return "";

  // Check prefix rules (isDeleted, hasAccess)
  let prefixText = "";
  let suffixText = "";
  let baseTokens = [...tokens];

  if (tokens.length > 1) {
    const first = tokens[0];
    if (first === "is" || first === "has" || first === "can") {
      prefixText = first === "has" ? "があるか" : "か";
      baseTokens.shift(); // remove prefix
    }
  }

  // Check suffix rules (createdAt, userId, groupNo)
  if (baseTokens.length > 1) {
    const last = baseTokens[baseTokens.length - 1];
    if (last === "at" || last === "time" || last === "date" || last === "datetime") {
      suffixText = "日時";
      baseTokens.pop();
    } else if (last === "id") {
      suffixText = "ID";
      baseTokens.pop();
    } else if (last === "no" || last === "num" || last === "number" || last === "code") {
      suffixText = "番号";
      if (last === "code") suffixText = "コード";
      baseTokens.pop();
    } else if (last === "count" || last === "qty" || last === "quantity") {
      suffixText = "数";
      baseTokens.pop();
    } else if (last === "list" || last === "array") {
      suffixText = "一覧";
      baseTokens.pop();
    }
  }

  // Translate remaining core tokens
  const translatedParts = baseTokens.map(token => {
    return TRANSLATION_DICTIONARY[token] || token;
  });

  // Combine translations
  let result = translatedParts.join("");

  // Apply grammatical formatting
  if (prefixText) {
    result = `${result}${prefixText}`;
  }
  if (suffixText) {
    // Avoid double words like "日付日時"
    if (!result.endsWith(suffixText)) {
      result = `${result}${suffixText}`;
    }
  }

  // Clean up punctuation (e.g. if parts are untranslated English)
  return result;
}

// --- 3. HTML Tree Construction ---
function escapeHtml(str) {
  if (typeof str !== "string") return str;
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function renderValue(val) {
  if (val === null) {
    return `<span class="json-null">null</span>`;
  }
  if (typeof val === "boolean") {
    return `<span class="json-boolean">${val}</span>`;
  }
  if (typeof val === "number") {
    return `<span class="json-number">${val}</span>`;
  }
  if (typeof val === "string") {
    // Hyperlink auto-detector
    if (val.startsWith("http://") || val.startsWith("https://")) {
      return `<span class="json-string">"<a href="${escapeHtml(val)}" target="_blank" class="json-link">${escapeHtml(val)}</a>"</span>`;
    }
    return `<span class="json-string">"${escapeHtml(val)}"</span>`;
  }
  return escapeHtml(String(val));
}

function buildTreeHtml(obj) {
  if (obj === null || typeof obj !== "object") {
    return `<div class="json-line-primitive">${renderValue(obj)}</div>`;
  }

  const isArray = Array.isArray(obj);
  const keys = Object.keys(obj);

  if (keys.length === 0) {
    return isArray ? `<span class="bracket">[]</span>` : `<span class="bracket">{}</span>`;
  }

  let html = "";
  html += `<span class="toggle-btn collapsed-indicator">-</span>`;
  html += `<span class="bracket">${isArray ? "[" : "{"}</span>`;
  
  html += `<div class="children-container">`;
  
  keys.forEach((key, index) => {
    const val = obj[key];
    const isLast = index === keys.length - 1;
    const isValObject = val !== null && typeof val === "object";
    const valueKeys = isValObject ? Object.keys(val) : [];
    const isEmptyObject = isValObject && valueKeys.length === 0;

    html += `<div class="json-row ${isValObject && !isEmptyObject ? 'collapsible-node' : ''}">`;

    // Array keys are just numbers, no translation needed
    if (isArray) {
      // Just render item values in arrays
      if (isValObject && !isEmptyObject) {
        html += buildTreeHtml(val);
      } else {
        html += renderValue(val);
      }
    } else {
      // Object keys - translate key
      const translation = translateKey(key);
      const commentHtml = translation ? `<span class="json-comment">/* ${escapeHtml(translation)} */</span>` : "";

      html += `<span class="json-key">"${escapeHtml(key)}"</span><span class="colon">:</span> ${commentHtml} `;

      if (isValObject && !isEmptyObject) {
        html += buildTreeHtml(val);
      } else {
        html += renderValue(val);
      }
    }

    if (!isLast) {
      html += `<span class="comma">,</span>`;
    }

    html += `</div>`;
  });

  html += `</div>`;
  html += `<span class="bracket">${isArray ? "]" : "}"}</span>`;

  return html;
}

// --- 4. Main Controller Bootstrapper ---
function runViewerIfJson() {
  // Basic pre-checks for JSON documents
  const body = document.body;
  if (!body) return;

  // Typical Chrome raw-display structures:
  // <body><pre style="...">{"key": "value"}</pre></body>
  // OR raw text straight in body
  let rawText = "";
  let targetContainer = null;

  if (body.childNodes.length === 1 && body.childNodes[0].tagName === "PRE") {
    targetContainer = body.childNodes[0];
    rawText = targetContainer.innerText.trim();
  } else if (body.childNodes.length === 1 && body.childNodes[0].nodeType === Node.TEXT_NODE) {
    targetContainer = body;
    rawText = body.innerText.trim();
  } else {
    // Check if the overall text parsed parses as JSON
    const text = body.innerText.trim();
    if ((text.startsWith("{") && text.endsWith("}")) || (text.startsWith("[") && text.endsWith("]"))) {
      rawText = text;
      targetContainer = body;
    }
  }

  if (!rawText) return;

  // Verify it is actual JSON
  let jsonObject = null;
  try {
    jsonObject = JSON.parse(rawText);
  } catch (e) {
    // Not valid JSON, abort
    return;
  }

  // Backup original raw content
  const originalRaw = rawText;

  // Initialize Viewer DOM Structure
  const viewerDiv = document.createElement("div");
  viewerDiv.id = "jp-json-viewer-root";
  viewerDiv.className = "jp-json-theme-dark";

  // Build Toolbar
  const toolbar = document.createElement("header");
  toolbar.className = "viewer-toolbar";
  toolbar.innerHTML = `
    <div class="toolbar-brand">
      <span class="brand-emoji">💮</span>
      <span class="brand-title">日本語注釈付きJSONビューア</span>
    </div>
    <div class="toolbar-actions">
      <!-- Tree Actions -->
      <button class="tb-btn action-btn" id="btn-expand-all" title="すべての階層を一度に開く">すべて開く</button>
      <button class="tb-btn action-btn" id="btn-collapse-all" title="すべての階層を一度に閉じる">すべて閉じる</button>
      <span class="tb-divider">|</span>
      <!-- View Modes -->
      <button class="tb-btn active" id="btn-show-tree" title="ツリー表示モード">ツリー</button>
      <button class="tb-btn" id="btn-show-raw" title="生のテキスト表示モード">Rawテキスト</button>
      <span class="tb-divider">|</span>
      <button class="tb-btn" id="btn-copy-json" title="JSONデータをコピー">コピー</button>
    </div>
  `;

  // Render Tree and Raw Containers
  const treeContainer = document.createElement("div");
  treeContainer.className = "tree-viewport";
  treeContainer.innerHTML = buildTreeHtml(jsonObject);

  const rawContainer = document.createElement("div");
  rawContainer.className = "raw-viewport hidden";
  
  const rawPre = document.createElement("pre");
  rawPre.textContent = JSON.stringify(jsonObject, null, 2);
  rawContainer.appendChild(rawPre);

  // Toast notifier
  const toast = document.createElement("div");
  toast.className = "viewer-toast";
  toast.textContent = "コピーしました";

  // Assemble Viewer
  viewerDiv.appendChild(toolbar);
  viewerDiv.appendChild(treeContainer);
  viewerDiv.appendChild(rawContainer);
  viewerDiv.appendChild(toast);

  // Wipe body and inject viewer
  body.innerHTML = "";
  body.appendChild(viewerDiv);

  // Add styles hook to head if not injected (mostly for sandbox fallback)
  if (!document.getElementById("jp-json-viewer-styles") && !document.querySelector("link[href*='viewer.css']")) {
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = chrome.runtime.getURL ? chrome.runtime.getURL("viewer.css") : "viewer.css";
    document.head.appendChild(link);
  }

  // --- 5. Add Event Listeners ---

  // Collapse/Expand node toggler
  treeContainer.addEventListener("click", (e) => {
    const target = e.target;
    if (target.classList.contains("toggle-btn")) {
      const parent = target.parentElement;
      const children = parent.querySelector(".children-container");
      if (children) {
        const isCollapsed = children.classList.toggle("collapsed");
        target.textContent = isCollapsed ? "+" : "-";
        target.classList.toggle("is-collapsed", isCollapsed);
      }
    }
  });

  // Action: Expand All Nodes
  document.getElementById("btn-expand-all").addEventListener("click", () => {
    const containers = treeContainer.querySelectorAll(".children-container");
    containers.forEach(c => c.classList.remove("collapsed"));
    const toggles = treeContainer.querySelectorAll(".toggle-btn");
    toggles.forEach(t => {
      t.textContent = "-";
      t.classList.remove("is-collapsed");
    });
  });

  // Action: Collapse All Nodes
  document.getElementById("btn-collapse-all").addEventListener("click", () => {
    const containers = treeContainer.querySelectorAll(".children-container");
    containers.forEach(c => c.classList.add("collapsed"));
    const toggles = treeContainer.querySelectorAll(".toggle-btn");
    toggles.forEach(t => {
      t.textContent = "+";
      t.classList.add("is-collapsed");
    });
  });

  // Action: Show Tree View
  const btnShowTree = document.getElementById("btn-show-tree");
  const btnShowRaw = document.getElementById("btn-show-raw");
  const btnExpandAll = document.getElementById("btn-expand-all");
  const btnCollapseAll = document.getElementById("btn-collapse-all");

  btnShowTree.addEventListener("click", () => {
    btnShowTree.classList.add("active");
    btnShowRaw.classList.remove("active");
    treeContainer.classList.remove("hidden");
    rawContainer.classList.add("hidden");
    
    // Enable tree actions
    btnExpandAll.disabled = false;
    btnCollapseAll.disabled = false;
  });

  // Action: Show Raw Text
  btnShowRaw.addEventListener("click", () => {
    btnShowRaw.classList.add("active");
    btnShowTree.classList.remove("active");
    treeContainer.classList.add("hidden");
    rawContainer.classList.remove("hidden");
    
    // Disable tree actions
    btnExpandAll.disabled = true;
    btnCollapseAll.disabled = true;
  });

  // Action: Copy JSON
  document.getElementById("btn-copy-json").addEventListener("click", () => {
    navigator.clipboard.writeText(rawPre.textContent).then(() => {
      toast.classList.add("show");
      setTimeout(() => {
        toast.classList.remove("show");
      }, 1500);
    });
  });
}

// Run Detector
// JSONページかどうかの軽量判定（runViewerIfJson の描画を伴わない事前チェック）。
// <all_urls> で動く拡張機能のため、無関係な全サイトにトライアル終了通知を出さないよう、
// 本来この拡張機能が反応するページでのみゲート判定を行う。
function pageLooksLikeJson() {
  const body = document.body;
  if (!body) return false;
  let rawText = "";
  if (body.childNodes.length === 1 && body.childNodes[0].tagName === "PRE") {
    rawText = body.childNodes[0].innerText.trim();
  } else if (body.childNodes.length === 1 && body.childNodes[0].nodeType === Node.TEXT_NODE) {
    rawText = body.innerText.trim();
  } else {
    const text = body.innerText.trim();
    if ((text.startsWith("{") && text.endsWith("}")) || (text.startsWith("[") && text.endsWith("]"))) {
      rawText = text;
    }
  }
  if (!rawText) return false;
  try {
    JSON.parse(rawText);
    return true;
  } catch (e) {
    return false;
  }
}

// トライアル期限ゲート: 期限切れなら本体機能を起動せず、控えめな通知だけ出す
if (pageLooksLikeJson()) {
  window.WanoTrialGate.checkTrialActive().then((trialActive) => {
    if (trialActive) {
      runViewerIfJson();
    } else {
      window.WanoTrialGate.showTrialExpiredNotice("日本語注釈付きJSONビューア");
    }
  });
}

// Expose globals for sandbox simulation environments
window.__runViewerIfJson = runViewerIfJson;
window.__buildTreeHtml = buildTreeHtml;
window.__translateKey = translateKey;

