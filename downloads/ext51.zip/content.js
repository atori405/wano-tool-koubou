// content.js - Japanese Popup Blocker: detection & hiding
//
// Heuristic, best-effort detector for three common in-page annoyance types:
// cookie/GDPR consent banners, newsletter/notification-permission nag
// modals, and sticky/full-screen overlay ads. This deliberately does NOT try
// to catch "any big fixed element" — an earlier version of this file did
// something close to that and ended up hiding real product UI on sites like
// Substack and Google Docs, so it was shipped disabled instead of fixed.
// Every match here requires BOTH a fixed/sticky position AND a class/id (or,
// in strict mode, visible text) keyword tied to the specific category, which
// keeps ordinary site chrome (sticky headers, chat widgets, toolbars) out of
// scope since those don't carry cookie/newsletter/ad wording.
(function() {
  "use strict";

  const HIDDEN_CLASS = "jpop-blocked-hidden";
  const processed = new WeakSet();
  const currentHostname = window.location.hostname.toLowerCase();

  let currentSettings = null;
  let observer = null;

  const CATEGORY_ID_CLASS_KEYWORDS = {
    cookie: ["cookie", "consent", "gdpr", "cc-window", "cc-banner", "cookiebar", "cookie-notice", "cookie-consent", "onetrust", "cmp-container", "cmpbox", "privacy-banner", "truste"],
    newsletter: ["newsletter", "subscribe", "signup-modal", "email-capture", "exit-intent", "popup-subscribe", "modal-subscribe", "notification-permission", "push-opt-in", "allow-notification"],
    ad: ["sticky-ad", "ad-overlay", "interstitial-ad", "ad-modal", "sp-ad", "ad-banner-fixed", "adsbygoogle", "fixed-ad", "floating-ad", "fixed-bnr", "bnr-fixed", "ad-area", "ad_area", "adarea", "widget-ad"]
  };

  // Real ad units almost always come from one of a known set of ad-network
  // domains via an <iframe> (or a <script> that builds one). Site-specific
  // class/id names for these are too varied to guess reliably — a Japanese
  // news site's own wrapper div around a Google/Rakuten/MicroAd unit rarely
  // has an obviously "ad"-flavored class name at all — so this checks the
  // *loaded resource's origin* instead, which is a much more reliable signal
  // and won't accidentally match a site's own unrelated UI.
  const AD_NETWORK_DOMAIN_KEYWORDS = [
    "googlesyndication.com", "doubleclick.net", "googleadservices.com", "google.com/pagead", "adservice.google",
    "amazon-adsystem.com", "criteo.com", "criteo.net",
    "a8.net", "moshimo.com", "i2i.jp", "zucks.co.jp", "microad.jp", "fout.jp", "genieesspv.jp", "adingo.jp",
    "rakuten.co.jp/widget", "widget.rakuten", "af.moshimo.com"
  ];

  function containsAdNetworkFrame(el) {
    const frames = el.querySelectorAll ? el.querySelectorAll("iframe[src], script[src]") : [];
    for (const frame of frames) {
      const src = (frame.getAttribute("src") || "").toLowerCase();
      if (AD_NETWORK_DOMAIN_KEYWORDS.some((k) => src.includes(k))) return true;
    }
    return false;
  }

  // Only consulted in "strict" mode, as a second, weaker signal on top of the
  // id/class check above (never used on its own to avoid false positives on
  // ordinary article text that happens to mention these words once).
  const CATEGORY_TEXT_KEYWORDS = {
    cookie: ["cookieを使用", "クッキーを使用", "cookieの使用", "個人情報の取り扱いに同意", "プライバシーポリシーに同意", "cookie ポリシー", "cookie policy"],
    newsletter: ["メルマガ", "ニュースレター", "メール登録", "通知を受け取", "通知を許可", "購読する"],
    ad: ["今すぐ購入", "限定タイムセール", "キャンペーン終了まで", "% off", "残りわずか"]
  };

  function idAndClass(el) {
    const cls = typeof el.className === "string" ? el.className : (el.className && el.className.baseVal) || "";
    return ((el.id || "") + " " + cls).toLowerCase();
  }

  function matchesCategory(el, category, strict) {
    const haystack = idAndClass(el);
    if (CATEGORY_ID_CLASS_KEYWORDS[category].some((k) => haystack.includes(k))) return true;
    if (strict) {
      const text = (el.innerText || "").toLowerCase().slice(0, 500);
      return CATEGORY_TEXT_KEYWORDS[category].some((k) => text.includes(k));
    }
    return false;
  }

  function isOverlayShaped(el) {
    let style;
    try {
      style = getComputedStyle(el);
    } catch (e) {
      return false;
    }
    if (style.position !== "fixed" && style.position !== "sticky") return false;

    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return false;

    // Never touch a node that wraps the page's main content, and never touch
    // very text-heavy nodes (real banners/modals are short blurbs, not
    // full articles) — both guard against mis-hiding real page content.
    if (el.matches && (el.matches("main, article") || el.querySelector("main, article"))) return false;
    if ((el.innerText || "").length > 3000) return false;

    return true;
  }

  function classify(el) {
    if (!currentSettings) return null;
    const strict = currentSettings.blockMode === "strict";
    if (currentSettings.filterCookie && matchesCategory(el, "cookie", strict)) return "cookie";
    if (currentSettings.filterNewsletter && matchesCategory(el, "newsletter", strict)) return "newsletter";
    if (currentSettings.filterAd && (matchesCategory(el, "ad", strict) || containsAdNetworkFrame(el))) return "ad";
    return null;
  }

  function isWhitelisted() {
    if (!currentSettings || !currentSettings.whitelist) return false;
    return currentSettings.whitelist.some((domain) => {
      const cleaned = (domain || "").trim().toLowerCase();
      if (!cleaned) return false;
      return currentHostname === cleaned || currentHostname.endsWith("." + cleaned);
    });
  }

  function hideElement(el) {
    el.classList.add(HIDDEN_CLASS);

    // Full-screen overlay ads/cookie modals sometimes lock body scroll while
    // shown; restore it once we hide the thing that locked it.
    if (document.documentElement.style.overflow === "hidden") {
      document.documentElement.style.overflow = "";
    }
    if (document.body && document.body.style.overflow === "hidden") {
      document.body.style.overflow = "";
    }

    if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage({ action: "reportBlocked", count: 1 });
    }
  }

  function scanNode(node) {
    if (!currentSettings || !currentSettings.enabled) return;
    if (!(node instanceof Element)) return;
    if (processed.has(node)) return;
    if (isWhitelisted()) return;

    processed.add(node);

    if (isOverlayShaped(node)) {
      const category = classify(node);
      if (category) {
        hideElement(node);
        return; // no need to inspect descendants of a node we just hid
      }
    }

    if (node.children && node.children.length) {
      for (const child of node.children) {
        scanNode(child);
      }
    }
  }

  function scanExisting() {
    if (!document.body) return;
    // Overlays are almost always attached shallowly (direct children of
    // body, or one level deeper), so bound the initial scan instead of
    // walking the whole page tree.
    document.body.querySelectorAll(":scope > *, :scope > * > *").forEach(scanNode);
  }

  // Ad networks commonly create an empty, already-fixed-position placeholder
  // div first and fill in the actual <iframe> a moment later via async JS.
  // The placeholder itself gets scanned (and rejected) when it's still
  // empty, then never looked at again once the ad script fills it in — so
  // re-check the fixed/sticky ancestors of anything newly added, not just
  // the added node itself.
  function rescanAncestors(node) {
    let el = node.parentElement;
    let depth = 0;
    while (el && depth < 8 && el !== document.body) {
      processed.delete(el);
      scanNode(el);
      el = el.parentElement;
      depth++;
    }
  }

  function startObserving() {
    if (observer) return;
    observer = new MutationObserver((mutations) => {
      if (!currentSettings || !currentSettings.enabled) return;
      for (const mutation of mutations) {
        mutation.addedNodes.forEach((node) => {
          if (node instanceof Element) {
            scanNode(node);
            rescanAncestors(node);
          }
        });
      }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  function applySettings(settings) {
    currentSettings = settings;
    if (currentSettings && currentSettings.enabled) {
      scanExisting();
      startObserving();
    }
  }

  function init() {
    chrome.storage.local.get(["popupBlockerSettings"], (result) => {
      applySettings(
        result.popupBlockerSettings || {
          enabled: true,
          blockMode: "standard",
          filterNewsletter: true,
          filterCookie: true,
          filterAd: true,
          whitelist: []
        }
      );
    });
  }

  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === "local" && changes.popupBlockerSettings) {
      applySettings(changes.popupBlockerSettings.newValue);
    }
  });

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "updateBlockerSettings") {
      applySettings(message.settings);
      sendResponse({ status: "updated" });
      return true;
    }
    if (message.action === "toggleFloatingPanel") {
      toggleFloatingPanel();
      sendResponse({ status: "toggled" });
      return true;
    }
    return true;
  });

  if (document.body) {
    init();
  } else {
    document.addEventListener("DOMContentLoaded", init);
  }

  // --- Universal Floating Panel Loader ---
  // 拡張機能ごとに一意なDOM ID接頭辞。この接頭辞を使わずリテラル文字列のIDのままだと、
  // 同じ仕組みを使う他の拡張機能と同じページ上でIDが衝突し、
  // document.getElementByIdが他拡張機能のコンテナを誤って見つけてしまう
  // (アイコンをクリックすると別の拡張機能のパネルが開くバグの原因になる)。
  const NS_ID = "wano-" + chrome.runtime.id;

  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      const existingShield = document.getElementById(NS_ID + "-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = NS_ID + "-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById(NS_ID + "-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById(NS_ID + "-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "flex" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = NS_ID + "-floating-container";

    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 452) + "px !important; z-index:2147483647 !important; width:442px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="${NS_ID}-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">🛡️</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">遮断の結界</span>
        </div>
        <button id="${NS_ID}-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    const header = container.querySelector("#" + NS_ID + "-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#" + NS_ID + "-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }
})();
