// background.js - Japanese Popup Blocker Service Worker

const DEFAULT_SETTINGS = {
  enabled: true,
  blockMode: "standard",
  filterNewsletter: true,
  filterCookie: true,
  filterAd: true,
  whitelist: [],
  todayBlocked: 0,
  totalBlocked: 0
};

// Memory store for per-tab block counts
const tabBlockCounts = {};

// Initialize configuration
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["popupBlockerSettings"], (result) => {
    if (!result.popupBlockerSettings) {
      chrome.storage.local.set({ popupBlockerSettings: DEFAULT_SETTINGS }, () => {
        console.log("Japanese Popup Blocker: Default settings initialized.");
      });
    }
  });
});

// Clean memory on tab closed to prevent memory leaks
chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabBlockCounts[tabId] !== undefined) {
    delete tabBlockCounts[tabId];
  }
});

// Messages Listener
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "reportBlocked") {
    const tabId = sender.tab ? sender.tab.id : null;
    const count = parseInt(message.count || 1);
    
    if (tabId) {
      // 1. Update in-memory tab count
      tabBlockCounts[tabId] = (tabBlockCounts[tabId] || 0) + count;
      const currentTabCount = tabBlockCounts[tabId];
      
      // 2. Set Badge details
      chrome.action.setBadgeText({ tabId: tabId, text: currentTabCount.toString() });
      chrome.action.setBadgeBackgroundColor({ tabId: tabId, color: "#dfc299" }); // Accent Gold Badge
      
      // 3. Update Storage Cumulative Counts
      chrome.storage.local.get(["popupBlockerSettings"], (result) => {
        let settings = result.popupBlockerSettings || DEFAULT_SETTINGS;
        settings.todayBlocked = (settings.todayBlocked || 0) + count;
        settings.totalBlocked = (settings.totalBlocked || 0) + count;
        
        chrome.storage.local.set({ popupBlockerSettings: settings });
      });
    }
    sendResponse({ status: "success" });
  }
  
  else if (message.action === "getActiveTabCount") {
    const tabId = message.tabId;
    const count = tabBlockCounts[tabId] || 0;
    sendResponse({ count: count });
  }
  
  else if (message.action === "clearTabCount") {
    const tabId = message.tabId;
    if (tabId) {
      tabBlockCounts[tabId] = 0;
      chrome.action.setBadgeText({ tabId: tabId, text: "" });
    }
    sendResponse({ status: "cleared" });
  }
  
  return true;
});
