// background.js - Japanese Popup Blocker Service Worker

const DEFAULT_SETTINGS = {
  enabled: true,
  blockMode: "standard",
  filterNewsletter: true,
  filterCookie: true,
  filterAd: true,
  whitelist: [],
  todayBlocked: 0,
  totalBlocked: 0
};

// Memory store for per-tab block counts
const tabBlockCounts = {};

// Initialize configuration
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["popupBlockerSettings"], (result) => {
    if (!result.popupBlockerSettings) {
      chrome.storage.local.set({ popupBlockerSettings: DEFAULT_SETTINGS }, () => {
        console.log("Japanese Popup Blocker: Default settings initialized.");
      });
    }
    syncAdBlockRules(result.popupBlockerSettings || DEFAULT_SETTINGS);
  });
});

// --- Network-level ad blocking (declarativeNetRequest) ---
//
// content.js hides ad *elements* after they render, which works for most
// sites but cannot see inside a closed Shadow DOM — a technique some ad
// formats (e.g. Google's anchor/overlay ads) use specifically to resist
// DOM-based ad blockers. Blocking the ad network's own request before it
// ever loads sidesteps that entirely: nothing rendered means nothing to
// hide. Real ad blockers rely on exactly this for the same reason.
const AD_NETWORK_DOMAINS = [
  "googlesyndication.com", "doubleclick.net", "googleadservices.com", "adservice.google.com",
  "amazon-adsystem.com", "criteo.com", "criteo.net",
  "a8.net", "moshimo.com", "i2i.jp", "zucks.co.jp", "microad.jp", "fout.jp", "genieesspv.jp", "adingo.jp",
  "widget.rakuten.co.jp", "af.moshimo.com"
];

// Dynamic rule ids are scoped to this range so we can always find and
// replace exactly our own rules without touching any other extension's.
const DNR_RULE_ID_BASE = 10000;

function buildAdBlockRules(settings) {
  const enabled = !!(settings && settings.enabled && settings.filterAd);
  if (!enabled) return [];

  const whitelist = (settings.whitelist || []).map((d) => (d || "").trim().toLowerCase()).filter(Boolean);

  return AD_NETWORK_DOMAINS.map((domain, i) => {
    const rule = {
      id: DNR_RULE_ID_BASE + i,
      priority: 1,
      action: { type: "block" },
      condition: {
        urlFilter: "||" + domain,
        resourceTypes: ["sub_frame", "script", "xmlhttprequest", "image", "ping"]
      }
    };
    if (whitelist.length) {
      rule.condition.excludedInitiatorDomains = whitelist;
    }
    return rule;
  });
}

async function syncAdBlockRules(settings) {
  try {
    const newRules = buildAdBlockRules(settings);
    const existing = await chrome.declarativeNetRequest.getDynamicRules();
    const removeRuleIds = existing
      .filter((r) => r.id >= DNR_RULE_ID_BASE && r.id < DNR_RULE_ID_BASE + AD_NETWORK_DOMAINS.length + 100)
      .map((r) => r.id);
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules: newRules });
  } catch (e) {
    console.error("Japanese Popup Blocker: failed to sync network-level ad rules:", e);
  }
}

chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === "local" && changes.popupBlockerSettings) {
    syncAdBlockRules(changes.popupBlockerSettings.newValue);
  }
});

// onRuleMatchedDebug only fires for unpacked/dev-mode extensions — which is
// exactly how this product is distributed (load unpacked), so it's a
// reliable way to keep the existing badge/stats UI working for
// network-level blocks too, the same as DOM-level ones.
if (chrome.declarativeNetRequest.onRuleMatchedDebug) {
  chrome.declarativeNetRequest.onRuleMatchedDebug.addListener((info) => {
    const ruleId = info.rule && info.rule.ruleId;
    if (typeof ruleId !== "number" || ruleId < DNR_RULE_ID_BASE) return;
    const tabId = info.request && info.request.tabId;
    if (typeof tabId !== "number" || tabId < 0) return;
    recordBlockedForTab(tabId, 1);
  });
}

function recordBlockedForTab(tabId, count) {
  tabBlockCounts[tabId] = (tabBlockCounts[tabId] || 0) + count;
  const currentTabCount = tabBlockCounts[tabId];

  chrome.action.setBadgeText({ tabId: tabId, text: currentTabCount.toString() });
  chrome.action.setBadgeBackgroundColor({ tabId: tabId, color: "#dfc299" });

  chrome.storage.local.get(["popupBlockerSettings"], (result) => {
    let settings = result.popupBlockerSettings || DEFAULT_SETTINGS;
    settings.todayBlocked = (settings.todayBlocked || 0) + count;
    settings.totalBlocked = (settings.totalBlocked || 0) + count;
    chrome.storage.local.set({ popupBlockerSettings: settings });
  });
}

// Clean memory on tab closed to prevent memory leaks
chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabBlockCounts[tabId] !== undefined) {
    delete tabBlockCounts[tabId];
  }
});

// Messages Listener
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "reportBlocked") {
    const tabId = sender.tab ? sender.tab.id : null;
    const count = parseInt(message.count || 1);
    if (tabId) {
      recordBlockedForTab(tabId, count);
    }
    sendResponse({ status: "success" });
  }
  
  else if (message.action === "getActiveTabCount") {
    const tabId = message.tabId;
    const count = tabBlockCounts[tabId] || 0;
    sendResponse({ count: count });
  }
  
  else if (message.action === "clearTabCount") {
    const tabId = message.tabId;
    if (tabId) {
      tabBlockCounts[tabId] = 0;
      chrome.action.setBadgeText({ tabId: tabId, text: "" });
    }
    sendResponse({ status: "cleared" });
  }
  
  return true;
});
