// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window.
            // Pass the original tab's id through so the standalone window can
            // still target the right tab for "add to whitelist" (it becomes
            // its own focused window, so chrome.tabs.query({currentWindow:true})
            // would otherwise resolve to itself instead of the page the user
            // wants to unblock).
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window&tabId=" + tabs[0].id),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// popup.js - Japanese Popup Blocker Panel Logic

document.addEventListener("DOMContentLoaded", () => {
  // --- Elements ---
  const enableToggle = document.getElementById("main-enable-toggle");
  const toggleStatusLabel = document.getElementById("toggle-status-label");
  
  const statActiveTab = document.getElementById("stat-active-tab");
  const statToday = document.getElementById("stat-today");
  const statTotal = document.getElementById("stat-total");

  const filterNewsletter = document.getElementById("filter-newsletter");
  const filterCookie = document.getElementById("filter-cookie");
  const filterAd = document.getElementById("filter-ad");

  const domainInput = document.getElementById("whitelist-domain-input");
  const addWhitelistBtn = document.getElementById("add-whitelist-btn");
  const whitelistContainer = document.getElementById("whitelist-container");
  
  const statusDot = document.getElementById("footer-status-dot");
  const statusText = document.getElementById("footer-status-text");

  let currentDomain = "";
  let activeTabId = null;
  let settings = {
    enabled: true,
    blockMode: "standard", // "standard" or "strict"
    filterNewsletter: true,
    filterCookie: true,
    filterAd: true,
    whitelist: [],
    todayBlocked: 0,
    totalBlocked: 0
  };

  // In the "mode=window" fail-safe (this popup opened as its own standalone
  // OS window because the in-page floating panel could not be reached), this
  // window becomes the focused window, so chrome.tabs.query({currentWindow:true})
  // would resolve to itself rather than the page the user wants to unblock.
  // The originating tab's id is passed explicitly in that case.
  const popupUrlParams = new URLSearchParams(window.location.search);
  const explicitTabId = popupUrlParams.get("tabId");

  function applyTabInfo(tab) {
    if (tab) {
      activeTabId = tab.id;
      if (tab.url) {
        try {
          const parsedUrl = new URL(tab.url);
          if (parsedUrl.protocol.startsWith("http")) {
            currentDomain = parsedUrl.hostname;
            domainInput.value = currentDomain;
            checkWhitelistButtonState();
          } else {
            domainInput.value = "適用不可 (システム/ローカルページ)";
            addWhitelistBtn.disabled = true;
            addWhitelistBtn.style.opacity = "0.5";
          }
        } catch (e) {
          console.error(e);
        }
      }

      // Request active tab block count from background script
      chrome.runtime.sendMessage({ action: "getActiveTabCount", tabId: activeTabId }, (response) => {
        if (response && typeof response.count === "number") {
          animateNumber(statActiveTab, 0, response.count, 500);
        }
      });
    }
  }

  // --- 1. Get Current Tab Domain & Block Count ---
  if (window.chrome && chrome.tabs) {
    if (explicitTabId) {
      chrome.tabs.get(parseInt(explicitTabId, 10), (tab) => applyTabInfo(tab));
    } else {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => applyTabInfo(tabs && tabs[0]));
    }
  } else {
    // Sandbox default fallback and initial count request
    currentDomain = "sandbox.local";
    domainInput.value = currentDomain;
    if (window.parent && window.parent !== window) {
      window.parent.postMessage({ action: "getActiveTabCount" }, "*");
    }
  }

  // --- 2. Load Settings from Storage ---
  function loadSettings() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.get(["popupBlockerSettings"], (result) => {
        if (result.popupBlockerSettings) {
          settings = { ...settings, ...result.popupBlockerSettings };
        }
        applySettingsToUI();
      });
    } else {
      // Sandbox local fallback
      const saved = localStorage.getItem("popupBlockerSettings");
      if (saved) {
        settings = JSON.parse(saved);
      }
      applySettingsToUI();
    }
  }

  function saveSettings() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.set({ popupBlockerSettings: settings }, () => {
        notifyActiveTab();
      });
    } else {
      localStorage.setItem("popupBlockerSettings", JSON.stringify(settings));
      console.log("Sandbox Saved settings:", settings);
    }
    // Sandbox parent window relay
    if (window.parent && window.parent !== window) {
      window.parent.postMessage({
        action: "updateBlockerSettings",
        settings: settings
      }, "*");
    }
  }

  // --- 3. UI Application & Animation ---
  function applySettingsToUI() {
    enableToggle.checked = settings.enabled;
    updateStatusIndicator(settings.enabled);

    // Radios
    const radio = document.querySelector(`input[name="block-mode"][value="${settings.blockMode}"]`);
    if (radio) {
      radio.checked = true;
    }

    // Checkboxes
    filterNewsletter.checked = settings.filterNewsletter;
    filterCookie.checked = settings.filterCookie;
    filterAd.checked = settings.filterAd;

    // Numbers animation
    animateNumber(statToday, 0, settings.todayBlocked, 800);
    animateNumber(statTotal, 0, settings.totalBlocked, 1000);

    renderWhitelist();
    checkWhitelistButtonState();
  }

  function updateStatusIndicator(enabled) {
    if (enabled) {
      toggleStatusLabel.textContent = "有効";
      toggleStatusLabel.style.color = "var(--accent-gold)";
      statusDot.classList.add("active");
      statusText.textContent = "防護結界 稼働中";
    } else {
      toggleStatusLabel.textContent = "無効";
      toggleStatusLabel.style.color = "var(--text-muted)";
      statusDot.classList.remove("active");
      statusText.textContent = "防護結界 停止中";
    }
  }

  function animateNumber(element, start, end, duration) {
    if (start === end) {
      element.textContent = end;
      return;
    }
    let range = end - start;
    let current = start;
    let increment = end > start ? 1 : -1;
    let stepTime = Math.abs(Math.floor(duration / range));
    stepTime = Math.max(stepTime, 20); // Cap speed

    let timer = setInterval(() => {
      current += increment;
      element.textContent = current;
      if (current === end) {
        clearInterval(timer);
      }
    }, stepTime);
  }

  // --- 4. Event Listeners ---
  enableToggle.addEventListener("change", (e) => {
    settings.enabled = e.target.checked;
    updateStatusIndicator(settings.enabled);
    saveSettings();
  });

  // Block Mode Radios
  const radios = document.querySelectorAll('input[name="block-mode"]');
  radios.forEach(r => {
    r.addEventListener("change", (e) => {
      if (e.target.checked) {
        settings.blockMode = e.target.value;
        saveSettings();
      }
    });
  });

  // Checkboxes
  filterNewsletter.addEventListener("change", (e) => {
    settings.filterNewsletter = e.target.checked;
    saveSettings();
  });
  filterCookie.addEventListener("change", (e) => {
    settings.filterCookie = e.target.checked;
    saveSettings();
  });
  filterAd.addEventListener("change", (e) => {
    settings.filterAd = e.target.checked;
    saveSettings();
  });

  // Extract a bare hostname from whatever is in the field - it starts out
  // auto-filled with the current tab's domain, but the field is editable so
  // people can also paste a full URL or type a different domain by hand.
  function normalizeDomain(raw) {
    let str = (raw || "").trim();
    if (!str) return "";
    if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(str)) {
      str = "https://" + str;
    }
    try {
      return new URL(str).hostname.toLowerCase();
    } catch (e) {
      return str.toLowerCase();
    }
  }

  // Add the domain currently in the field (auto-filled or hand-edited) to the whitelist
  addWhitelistBtn.addEventListener("click", () => {
    const domain = normalizeDomain(domainInput.value);
    if (domain && !settings.whitelist.includes(domain)) {
      settings.whitelist.push(domain);
      saveSettings();
      renderWhitelist();
      checkWhitelistButtonState();

      // Request background script to clear badge and count for whitelist
      if (window.chrome && chrome.runtime && activeTabId) {
        chrome.runtime.sendMessage({ action: "clearTabCount", tabId: activeTabId }, () => {
          statActiveTab.textContent = "0";
        });
      } else {
        // Sandbox count reset
        if (window.parent && window.parent !== window) {
          window.parent.postMessage({ action: "clearTabCount" }, "*");
        }
      }
    }
  });

  // Re-check button state as the user edits the field by hand
  domainInput.addEventListener("input", checkWhitelistButtonState);

  // --- 5. Whitelist Render ---
  function renderWhitelist() {
    whitelistContainer.innerHTML = "";
    if (!settings.whitelist || settings.whitelist.length === 0) {
      whitelistContainer.innerHTML = `
        <div style="font-size: 11px; color: var(--text-muted); padding: 6px; text-align: center;">
          除外設定されたサイトはありません。
        </div>
      `;
      return;
    }

    settings.whitelist.forEach(domain => {
      const item = document.createElement("div");
      item.className = "blacklist-item";
      
      item.innerHTML = `
        <span class="blacklist-domain">${domain}</span>
        <button class="blacklist-remove-btn" title="除外解除">×</button>
      `;

      item.querySelector(".blacklist-remove-btn").addEventListener("click", () => {
        settings.whitelist = settings.whitelist.filter(d => d !== domain);
        saveSettings();
        renderWhitelist();
        checkWhitelistButtonState();
      });

      whitelistContainer.appendChild(item);
    });
  }

  function checkWhitelistButtonState() {
    const typedDomain = normalizeDomain(domainInput.value);
    if (!typedDomain) {
      addWhitelistBtn.textContent = "ブロックを解除";
      addWhitelistBtn.disabled = true;
      addWhitelistBtn.style.opacity = "0.5";
      return;
    }
    if (settings.whitelist && settings.whitelist.includes(typedDomain)) {
      addWhitelistBtn.textContent = "ブロック解除中";
      addWhitelistBtn.disabled = true;
      addWhitelistBtn.style.opacity = "0.6";
    } else {
      addWhitelistBtn.textContent = "ブロックを解除";
      addWhitelistBtn.disabled = false;
      addWhitelistBtn.style.opacity = "1";
    }
  }

  // --- 6. Notify active tab content script ---
  function notifyActiveTab() {
    if (window.chrome && chrome.tabs && activeTabId) {
      chrome.tabs.sendMessage(activeTabId, {
        action: "updateBlockerSettings",
        settings: settings
      }, () => {
        if (chrome.runtime.lastError) {
          // Silent
        }
      });
    }
  }

  // --- 7. Sandbox Simulator Message Receivers ---
  window.addEventListener("message", (event) => {
    if (event.data && event.data.action === "sandboxUpdateCounts") {
      // Direct mock update from test_sandbox.html
      animateNumber(statActiveTab, parseInt(statActiveTab.textContent || 0), event.data.activeCount, 300);
      animateNumber(statToday, parseInt(statToday.textContent || 0), event.data.todayBlocked, 300);
      animateNumber(statTotal, parseInt(statTotal.textContent || 0), event.data.totalBlocked, 300);
      
      // Update local settings representation
      settings.todayBlocked = event.data.todayBlocked;
      settings.totalBlocked = event.data.totalBlocked;
    }
    if (event.data && event.data.action === "activeTabCountResponse") {
      animateNumber(statActiveTab, 0, event.data.count, 300);
    }
    if (event.data && event.data.action === "clearTabCountResponse") {
      statActiveTab.textContent = "0";
    }
  });

  // Init panel
  loadSettings();
});
