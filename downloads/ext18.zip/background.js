// ============================================
// 定時退社リマインダー — Background Service Worker
// ============================================

const DEFAULT_SETTINGS = {
  leaveHour: 18,
  leaveMinute: 0,
  filterStrength: 'medium',
  notifyEnabled: true,
  soundEnabled: true,
  weekendOff: true
};

// Filter strength multipliers
const STRENGTH_MAP = {
  weak: 0.5,
  medium: 1.0,
  strong: 1.5
};

// ---- Alarm Setup ----
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get('teijiSettings', (data) => {
    if (!data.teijiSettings) {
      chrome.storage.local.set({ teijiSettings: DEFAULT_SETTINGS });
    }
  });
  setupAlarm();
});

chrome.runtime.onStartup.addListener(() => {
  setupAlarm();
});

function setupAlarm() {
  chrome.alarms.clearAll(() => {
    chrome.alarms.create('teijiCheck', { periodInMinutes: 1 });
  });
}

// ---- Alarm Handler ----
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'teijiCheck') {
    checkTime();
  }
});

async function checkTime() {
  const data = await chrome.storage.local.get(['teijiSettings', 'teijiNotifiedStages']);
  const settings = data.teijiSettings || DEFAULT_SETTINGS;
  const notifiedStages = data.teijiNotifiedStages || {};

  const now = new Date();
  const day = now.getDay();
  const todayStr = now.toISOString().slice(0, 10);

  // Skip weekends if enabled
  if (settings.weekendOff && (day === 0 || day === 6)) {
    updateBadge('休', '#555555');
    broadcastFilter(0, settings);
    return;
  }

  // Calculate minutes until leave time
  const target = new Date();
  target.setHours(settings.leaveHour, settings.leaveMinute, 0, 0);
  const diffMs = target - now;
  const diffMin = Math.floor(diffMs / 60000);

  // Determine stage and send notifications
  const todayNotified = notifiedStages[todayStr] || [];

  if (diffMin > 30) {
    // Normal working hours
    const hoursLeft = Math.floor(diffMin / 60);
    const minsLeft = diffMin % 60;
    if (hoursLeft > 0) {
      updateBadge(`${hoursLeft}h`, '#27AE60');
    } else {
      updateBadge(`${minsLeft}`, '#27AE60');
    }
    broadcastFilter(0, settings);

  } else if (diffMin > 15 && diffMin <= 30) {
    // 30 minutes warning
    updateBadge(`${diffMin}`, '#F39C12');
    broadcastFilter(0.02, settings);

    if (settings.notifyEnabled && !todayNotified.includes('30min')) {
      showNotification('⏰ あと30分で定時です', 'そろそろ今日の仕事を締めくくりましょう。');
      todayNotified.push('30min');
      notifiedStages[todayStr] = todayNotified;
      chrome.storage.local.set({ teijiNotifiedStages: notifiedStages });
    }

  } else if (diffMin > 0 && diffMin <= 15) {
    // 15 minutes warning
    updateBadge(`${diffMin}`, '#E67E22');
    broadcastFilter(0.04, settings);

    if (settings.notifyEnabled && !todayNotified.includes('15min')) {
      showNotification('🏮 あと15分で定時です', '帰り支度を始めましょう。明日に回せる仕事はありませんか？');
      todayNotified.push('15min');
      notifiedStages[todayStr] = todayNotified;
      chrome.storage.local.set({ teijiNotifiedStages: notifiedStages });
    }

  } else if (diffMin >= -1 && diffMin <= 0) {
    // Leave time!
    updateBadge('帰', '#E74C3C');
    broadcastFilter(0.06, settings);

    if (settings.notifyEnabled && !todayNotified.includes('time')) {
      showNotification('🎉 お疲れさまでした！', '定時です。今日も一日お疲れさまでした。ゆっくりお休みください。');
      todayNotified.push('time');
      notifiedStages[todayStr] = todayNotified;
      chrome.storage.local.set({ teijiNotifiedStages: notifiedStages });
    }

  } else if (diffMin < -1) {
    // Overtime
    const overtimeMin = Math.abs(diffMin);
    const overtimeHours = Math.floor(overtimeMin / 60);
    const overtimeMins = overtimeMin % 60;

    if (overtimeHours > 0) {
      updateBadge(`+${overtimeHours}h`, '#C0392B');
    } else {
      updateBadge(`+${overtimeMins}`, '#C0392B');
    }

    // Gradually increase filter (max opacity 0.15)
    const filterOpacity = Math.min(0.06 + (overtimeMin / 60) * 0.06, 0.15);
    broadcastFilter(filterOpacity, settings);

    // Notify every 15 minutes of overtime
    const overtimeStage = Math.floor(overtimeMin / 15);
    const stageKey = `ot_${overtimeStage}`;
    if (settings.notifyEnabled && overtimeStage > 0 && !todayNotified.includes(stageKey)) {
      const messages = [
        `残業${overtimeMin}分経過しました。明日に回せる仕事はありませんか？`,
        `残業${overtimeMin}分です。健康第一、そろそろ帰りましょう。`,
        `残業${overtimeMin}分…。今日はもう十分がんばりました。`,
        `残業${overtimeMin}分を超えました。身体を大切に。`
      ];
      const msg = messages[overtimeStage % messages.length];
      showNotification('⚠️ 残業中です', msg);
      todayNotified.push(stageKey);
      notifiedStages[todayStr] = todayNotified;
      chrome.storage.local.set({ teijiNotifiedStages: notifiedStages });
    }

    // Record overtime for today
    recordDay(todayStr, overtimeMin);
  }

  // Record on-time if we're past leave time and overtime is minimal
  if (diffMin <= 0 && diffMin > -15) {
    recordDay(todayStr, Math.abs(diffMin));
  }
}

// ---- Record daily result ----
async function recordDay(dateStr, overtimeMinutes) {
  const data = await chrome.storage.local.get('teijiWeeklyRecord');
  const record = data.teijiWeeklyRecord || {};

  if (overtimeMinutes <= 5) {
    record[dateStr] = 'on-time';
  } else if (overtimeMinutes <= 30) {
    record[dateStr] = 'overtime-short';
  } else {
    record[dateStr] = 'overtime-long';
  }

  // Clean old records (keep last 14 days)
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - 14);
  const cutoffStr = cutoff.toISOString().slice(0, 10);
  Object.keys(record).forEach(key => {
    if (key < cutoffStr) delete record[key];
  });

  chrome.storage.local.set({ teijiWeeklyRecord: record });
}

// ---- Badge ----
function updateBadge(text, color) {
  chrome.action.setBadgeText({ text });
  chrome.action.setBadgeBackgroundColor({ color });
}

// ---- Notifications ----
function showNotification(title, message) {
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title,
    message,
    priority: 2
  });
}

// ---- Broadcast filter to all tabs ----
async function broadcastFilter(opacity, settings) {
  const multiplier = STRENGTH_MAP[settings.filterStrength] || 1.0;
  const adjustedOpacity = opacity * multiplier;

  try {
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      if (tab.url && (tab.url.startsWith('http://') || tab.url.startsWith('https://'))) {
        try {
          chrome.tabs.sendMessage(tab.id, {
            type: 'updateFilter',
            opacity: adjustedOpacity,
            overtimeMinutes: adjustedOpacity > 0.04 ? Math.round((adjustedOpacity - 0.04) / 0.001) : 0
          });
        } catch (e) {
          // Tab might not have content script loaded
        }
      }
    }
  } catch (e) {
    // Ignore errors from querying tabs
  }
}

// ---- Message listener ----
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'settingsUpdated') {
    setupAlarm();
    checkTime();
  }
  if (msg.type === 'getState') {
    chrome.storage.local.get('teijiSettings', (data) => {
      const settings = data.teijiSettings || DEFAULT_SETTINGS;
      const now = new Date();
      const target = new Date();
      target.setHours(settings.leaveHour, settings.leaveMinute, 0, 0);
      const diffMin = Math.floor((target - now) / 60000);
      sendResponse({ diffMin, settings });
    });
    return true; // async response
  }
});
