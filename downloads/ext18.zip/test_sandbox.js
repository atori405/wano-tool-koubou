// test_sandbox.js
// chrome-extension://として開いた場合、MV3のCSPによりHTML内のインラインscriptは
// 実行できないため、外部ファイルに切り出している。
document.addEventListener("DOMContentLoaded", function () {
  const cards = document.querySelectorAll(".card, .panel, .iframe-wrapper");
  cards.forEach((card) => {
    const title = card.querySelector("h2, h1, .card-title, .panel-title");
    if (title && typeof makeDraggable === "function") {
      title.style.userSelect = "none";
      title.title = "✋ ここを掴んで自由な位置へドラッグ移動できます";
      makeDraggable(card, title);
    }
  });
});
