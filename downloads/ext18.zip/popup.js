// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// ============================================
// 定時退社リマインダー — Popup Script
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  // DOM Elements
  const statusCard = document.getElementById('status-card');
  const statusLabel = document.getElementById('status-label');
  const countdown = document.getElementById('countdown');
  const countdownDesc = document.getElementById('countdown-desc');
  const currentTimeEl = document.getElementById('current-time');
  const messageText = document.getElementById('message-text');
  const lantern = document.getElementById('lantern');

  // Weekly record elements
  const recMon = document.getElementById('rec-mon');
  const recTue = document.getElementById('rec-tue');
  const recWed = document.getElementById('rec-wed');
  const recThu = document.getElementById('rec-thu');
  const recFri = document.getElementById('rec-fri');
  const rateFill = document.getElementById('rate-fill');
  const rateValue = document.getElementById('rate-value');

  // Settings elements
  const settingsToggle = document.getElementById('settings-toggle');
  const settingsPanel = document.getElementById('settings-panel');
  const leaveHourSelect = document.getElementById('leave-hour');
  const leaveMinuteSelect = document.getElementById('leave-minute');
  const filterStrength = document.getElementById('filter-strength');
  const notifyEnabled = document.getElementById('notify-enabled');
  const soundEnabled = document.getElementById('sound-enabled');
  const weekendOff = document.getElementById('weekend-off');
  const saveBtn = document.getElementById('save-btn');

  // Default settings
  const DEFAULT_SETTINGS = {
    leaveHour: 18,
    leaveMinute: 0,
    filterStrength: 'medium',
    notifyEnabled: true,
    soundEnabled: true,
    weekendOff: true
  };

  let settings = { ...DEFAULT_SETTINGS };

  // Messages by state
  const MESSAGES = {
    working: [
      '今日も一日頑張りましょう。',
      '集中して、定時に帰りましょう！',
      'コツコツと、でも無理せずに。',
      '効率よく仕事を終わらせましょう。'
    ],
    soon: [
      'そろそろ締めくくりの時間です。',
      '残りの仕事を整理しましょう。',
      '明日に回せるものは、明日に。',
      'お帰り準備を始めてもよい頃です。'
    ],
    overtime: [
      '今日はもう十分がんばりました。',
      '明日の自分に任せる勇気も大切です。',
      '健康第一。早く帰って休みましょう。',
      '残業は身体と心に毒ですよ。'
    ],
    done: [
      '🎉 定時退社おめでとうございます！',
      '素晴らしい！今日も定時で帰れましたね。',
      '自分の時間を大切にできる人は偉い！'
    ],
    weekend: [
      '今日はお休みです。ゆっくり過ごしましょう。',
      '休日を満喫してくださいね。'
    ]
  };

  function randomMessage(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  // Populate time selects
  for (let h = 0; h < 24; h++) {
    const opt = document.createElement('option');
    opt.value = h;
    opt.textContent = String(h).padStart(2, '0');
    leaveHourSelect.appendChild(opt);
  }
  for (let m = 0; m < 60; m += 5) {
    const opt = document.createElement('option');
    opt.value = m;
    opt.textContent = String(m).padStart(2, '0');
    leaveMinuteSelect.appendChild(opt);
  }

  // Settings accordion toggle
  settingsToggle.addEventListener('click', () => {
    settingsPanel.classList.toggle('open');
  });

  // Save settings
  saveBtn.addEventListener('click', () => {
    settings.leaveHour = parseInt(leaveHourSelect.value);
    settings.leaveMinute = parseInt(leaveMinuteSelect.value);
    settings.filterStrength = filterStrength.value;
    settings.notifyEnabled = notifyEnabled.checked;
    settings.soundEnabled = soundEnabled.checked;
    settings.weekendOff = weekendOff.checked;

    chrome.storage.local.set({ teijiSettings: settings }, () => {
      // Notify background to recalculate alarms
      chrome.runtime.sendMessage({ type: 'settingsUpdated', settings });
      saveBtn.textContent = '✅ 保存しました！';
      setTimeout(() => { saveBtn.textContent = '💾 設定を保存'; }, 1500);
    });
  });

  // Load settings
  function loadSettings(callback) {
    chrome.storage.local.get('teijiSettings', (data) => {
      if (data.teijiSettings) {
        settings = { ...DEFAULT_SETTINGS, ...data.teijiSettings };
      }
      // Update UI
      leaveHourSelect.value = settings.leaveHour;
      leaveMinuteSelect.value = settings.leaveMinute;
      filterStrength.value = settings.filterStrength;
      notifyEnabled.checked = settings.notifyEnabled;
      soundEnabled.checked = settings.soundEnabled;
      weekendOff.checked = settings.weekendOff;
      if (callback) callback();
    });
  }

  // Calculate time difference in seconds
  function getSecondsDiff() {
    const now = new Date();
    const target = new Date();
    target.setHours(settings.leaveHour, settings.leaveMinute, 0, 0);
    return Math.floor((target - now) / 1000);
  }

  // Format seconds to HH:MM:SS
  function formatTime(totalSec) {
    const abs = Math.abs(totalSec);
    const h = Math.floor(abs / 3600);
    const m = Math.floor((abs % 3600) / 60);
    const s = abs % 60;
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }

  // Determine state
  function getState(secDiff) {
    const now = new Date();
    const day = now.getDay(); // 0=Sun, 6=Sat

    if (settings.weekendOff && (day === 0 || day === 6)) {
      return 'weekend';
    }

    if (secDiff > 30 * 60) return 'working';
    if (secDiff > 0) return 'soon';
    if (secDiff > -60) return 'done'; // within 1 minute of leave time
    return 'overtime';
  }

  // Update UI every second
  let lastMessageState = null;
  function updateUI() {
    const now = new Date();
    currentTimeEl.textContent = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    const secDiff = getSecondsDiff();
    const state = getState(secDiff);

    // メッセージは状態(勤務中/もうすぐ定時/残業中など)が切り替わったときだけ
    // 更新する。以前はポップアップを開いた瞬間の1回しか呼ばれておらず、
    // 設定画面で退社時刻を変えて保存しても、カウントダウンは動くのに
    // メッセージだけ古い状態のまま固定されてしまっていた。
    if (state !== lastMessageState) {
      lastMessageState = state;
      updateMessage();
    }

    // Remove all state classes
    statusCard.className = 'status-card';
    document.body.className = '';

    switch (state) {
      case 'working':
        statusLabel.textContent = '勤務中';
        countdown.textContent = formatTime(secDiff);
        countdownDesc.textContent = '退社まで';
        break;

      case 'soon':
        statusCard.classList.add('soon');
        document.body.classList.add('almost-time');
        statusLabel.textContent = 'もうすぐ定時';
        countdown.textContent = formatTime(secDiff);
        countdownDesc.textContent = '退社まで';
        break;

      case 'overtime':
        statusCard.classList.add('overtime');
        document.body.classList.add('overtime');
        statusLabel.textContent = '🔴 残業中';
        countdown.textContent = formatTime(secDiff);
        countdownDesc.textContent = '残業時間';
        break;

      case 'done':
        statusCard.classList.add('done');
        statusLabel.textContent = '🎉 定時退社！';
        countdown.textContent = '00:00:00';
        countdownDesc.textContent = 'お疲れさまでした';
        break;

      case 'weekend':
        statusLabel.textContent = '🌿 休日';
        countdown.textContent = '— — —';
        countdownDesc.textContent = 'お休みです';
        break;
    }
  }

  // Load and display weekly record
  function loadWeeklyRecord() {
    chrome.storage.local.get('teijiWeeklyRecord', (data) => {
      const record = data.teijiWeeklyRecord || {};
      const dayEls = { mon: recMon, tue: recTue, wed: recWed, thu: recThu, fri: recFri };
      const dayCells = document.querySelectorAll('.day-cell');

      // Get current week's Monday
      const now = new Date();
      const dayOfWeek = now.getDay();
      const monday = new Date(now);
      monday.setDate(now.getDate() - ((dayOfWeek + 6) % 7));
      monday.setHours(0, 0, 0, 0);

      const dayKeys = ['mon', 'tue', 'wed', 'thu', 'fri'];
      let onTimeCount = 0;
      let totalDays = 0;

      dayKeys.forEach((key, index) => {
        const date = new Date(monday);
        date.setDate(monday.getDate() + index);
        const dateStr = date.toISOString().slice(0, 10);
        const el = dayEls[key];
        const cell = el.closest('.day-cell');

        if (record[dateStr] !== undefined) {
          totalDays++;
          if (record[dateStr] === 'on-time') {
            el.textContent = '○';
            el.style.color = '#27AE60';
            cell.classList.add('on-time');
            onTimeCount++;
          } else if (record[dateStr] === 'overtime-short') {
            el.textContent = '△';
            el.style.color = '#F39C12';
            cell.classList.add('overtime-rec');
          } else {
            el.textContent = '×';
            el.style.color = '#E74C3C';
            cell.classList.add('late');
          }
        } else {
          el.textContent = '—';
          el.style.color = 'rgba(240,237,229,0.3)';
        }
      });

      // Update rate
      if (totalDays > 0) {
        const rate = Math.round((onTimeCount / totalDays) * 100);
        rateFill.style.width = rate + '%';
        rateValue.textContent = rate + '%';
      } else {
        rateFill.style.width = '0%';
        rateValue.textContent = '—%';
      }
    });
  }

  // Set message based on state
  function updateMessage() {
    const secDiff = getSecondsDiff();
    const state = getState(secDiff);
    const msgs = MESSAGES[state] || MESSAGES.working;
    messageText.textContent = randomMessage(msgs);
  }

  // Initialize
  loadSettings(() => {
    updateUI(); // 初回呼び出し時にupdateMessage()もあわせて実行される
    loadWeeklyRecord();

    // Update every second
    setInterval(updateUI, 1000);
  });
});
