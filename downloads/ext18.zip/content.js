// ============================================
// 定時退社リマインダー — Content Script
// Injects sunset filter overlay & reminder bar
// ============================================

(function () {
  // Avoid double injection
  if (document.getElementById('teiji-filter-overlay')) return;

  // Create filter overlay
  const overlay = document.createElement('div');
  overlay.id = 'teiji-filter-overlay';
  document.documentElement.appendChild(overlay);

  // Create reminder bar
  const bar = document.createElement('div');
  bar.id = 'teiji-reminder-bar';
  bar.innerHTML = `
    <span class="teiji-bar-text">
      <span>🏮</span>
      <span id="teiji-bar-message">定時退社リマインダー</span>
    </span>
    <span class="teiji-dismiss" title="5分間非表示">✕</span>
  `;
  document.documentElement.appendChild(bar);

  const barMessage = bar.querySelector('#teiji-bar-message');
  const dismissBtn = bar.querySelector('.teiji-dismiss');

  let dismissed = false;
  let dismissTimer = null;

  // Dismiss bar for 5 minutes
  dismissBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    dismissed = true;
    bar.classList.remove('visible');
    overlay.style.opacity = '0';

    if (dismissTimer) clearTimeout(dismissTimer);
    dismissTimer = setTimeout(() => {
      dismissed = false;
    }, 5 * 60 * 1000);
  });

  // Listen for messages from background
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'updateFilter') {
      if (dismissed) return;

      const opacity = msg.opacity || 0;

      if (opacity > 0) {
        overlay.style.opacity = String(Math.min(opacity, 0.25));

        // Show reminder bar when filter is active
        if (opacity > 0.04) {
          const overtimeMin = msg.overtimeMinutes || 0;
          if (overtimeMin > 0) {
            const hours = Math.floor(overtimeMin / 60);
            const mins = overtimeMin % 60;
            if (hours > 0) {
              barMessage.textContent = `残業 ${hours}時間${mins > 0 ? mins + '分' : ''} — そろそろ帰りましょう`;
            } else {
              barMessage.textContent = `残業 ${overtimeMin}分 — 今日もお疲れさまでした`;
            }
          } else {
            barMessage.textContent = 'もうすぐ定時です。帰り支度を始めましょう';
          }
          bar.classList.add('visible');
        } else {
          bar.classList.remove('visible');
        }
      } else {
        overlay.style.opacity = '0';
        bar.classList.remove('visible');
      }
    }
  });

  // Request initial state from background
  try {
    chrome.runtime.sendMessage({ type: 'getState' }, (response) => {
      if (chrome.runtime.lastError) return;
      if (response && response.diffMin !== undefined) {
        // Let background handle via the next alarm cycle
      }
    });
  } catch (e) {
    // Extension context may not be available
  }
})();


// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // Add temporary shield to prevent iframe from stealing mouse events during dragging
      const existingShield = document.getElementById("wano-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = "wano-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      // Use getBoundingClientRect() for correct viewport-relative position
      // (element.offsetTop is unreliable for position:fixed elements on scrolled pages)
      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      // Restrict within window boundaries to prevent going offscreen
      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById("wano-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById("wano-universal-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "block" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = "wano-universal-floating-container";
    
    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 440) + "px !important; z-index:2147483647 !important; width:430px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="wano-u-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">Teiji Reminder</span>
        </div>
        <button id="wano-u-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#wano-u-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#wano-u-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
