// Register periodic checks on startup/install
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("checkPointsAlarm", { periodInMinutes: 240 }); // Check every 4 hours
  checkExpiringPoints();
});

chrome.runtime.onStartup.addListener(() => {
  checkExpiringPoints();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "checkPointsAlarm") {
    checkExpiringPoints();
  }
});

// Update badge/notifications dynamically when storage changes
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local") {
    checkExpiringPoints();
  }
});

function checkExpiringPoints() {
  chrome.storage.local.get(null, (allData) => {
    let expiringTotal = 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const activeAlerts = [];

    // Filter local storage keys starting with "point_"
    const pointKeys = Object.keys(allData).filter(key => key.startsWith("point_"));

    pointKeys.forEach(key => {
      const data = allData[key];
      if (data && data.expiryDate && data.limitedPoints > 0) {
        const expiry = new Date(data.expiryDate);
        expiry.setHours(0, 0, 0, 0);
        
        // Calculate remaining days
        const diffTime = expiry.getTime() - today.getTime();
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        // Alert if points expire within 3 days (including today)
        if (diffDays >= 0 && diffDays <= 3) {
          expiringTotal += data.limitedPoints;
          activeAlerts.push({
            name: data.name,
            amount: data.limitedPoints,
            days: diffDays
          });
        }
      }
    });

    // 1. Update Badge text on extension icon
    if (expiringTotal > 0) {
      chrome.action.setBadgeText({ text: expiringTotal.toString() });
      chrome.action.setBadgeBackgroundColor({ color: "#E53E3E" }); // Warning Red
      
      // 2. Trigger Desktop Notification (Throttle to max once per day unless total increases)
      const todayStr = new Date().toDateString();
      chrome.storage.local.get(["lastNotifiedDate", "lastNotifiedTotal"], (notifData) => {
        const hasNotifiedToday = notifData.lastNotifiedDate === todayStr;
        const totalIncreased = expiringTotal > (notifData.lastNotifiedTotal || 0);

        if (!hasNotifiedToday || totalIncreased) {
          const detailMessage = activeAlerts
            .map(a => `${a.name}: ¥${a.amount.toLocaleString()} (あと${a.days}日)`)
            .join("\n");

          chrome.notifications.create("point_expiry_warning", {
            type: "basic",
            iconUrl: "icons/icon128.png",
            title: "⚠️ 期間限定ポイント失効警報",
            message: `失効間近の期間限定ポイントが合計 ¥${expiringTotal.toLocaleString()} 分あります！\n\n${detailMessage}`,
            priority: 2
          });

          // Save notification tracking state
          chrome.storage.local.set({
            lastNotifiedDate: todayStr,
            lastNotifiedTotal: expiringTotal
          });
        }
      });
    } else {
      chrome.action.setBadgeText({ text: "" });
      // Reset notification total when zero warnings remain
      chrome.storage.local.set({ lastNotifiedTotal: 0 });
    }
  });
}
