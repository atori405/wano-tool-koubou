/**
 * license-config.js
 * 
 * 拡張機能ごとの個別ライセンス商品ID設定。
 * 自動生成されたファイルです。手動で変更しないでください。
 */
window.LicenseConfig = {
  productId: "1318949",
  allToolsProductId: "1318293",
  singleCheckoutUrl: "https://wafuu-koubou.lemonsqueezy.com/checkout/buy/f3fa50f4-4b10-43cc-9cf5-986bbc2b38a1",
  bundleCheckoutUrl: "https://wafuu-koubou.lemonsqueezy.com/checkout/buy/d2530690-2049-4779-8a24-0a15c803bb24"
};
