// Scrape point data when pages load
window.addEventListener("load", () => {
  // Add a slight delay to allow client-side React/Vue elements to finish rendering
  setTimeout(scrapePoints, 3000);
});

function parseNumber(text) {
  if (!text) return 0;
  // Strip currency symbols, commas, spaces, and text like "P" or "ポイント"
  const cleaned = text.replace(/[¥￥,円ポイントP\s]/g, "");
  const num = parseInt(cleaned, 10);
  return isNaN(num) ? 0 : num;
}

function parseDate(text) {
  if (!text) return null;
  // Match patterns like YYYY/MM/DD, YYYY年MM月DD日
  const regex = /(\d{4})[/\-年](\d{1,2})[/\-月](\d{1,2})/;
  const match = text.match(regex);
  if (match) {
    return `${match[1]}-${match[2].padStart(2, '0')}-${match[3].padStart(2, '0')}`;
  }
  // If year is omitted (e.g. MM/DD or MM月DD日), assume current year
  const shortRegex = /(\d{1,2})[/\-月](\d{1,2})/;
  const shortMatch = text.match(shortRegex);
  if (shortMatch) {
    const curYear = new Date().getFullYear();
    return `${curYear}-${shortMatch[1].padStart(2, '0')}-${shortMatch[2].padStart(2, '0')}`;
  }
  return null;
}

function scrapePoints() {
  const hostname = window.location.hostname;
  
  if (hostname.includes("rakuten.co.jp")) {
    let totalPoints = 0;
    let limitedPoints = 0;
    let expiryDate = null;

    // Case A: Detailed Rakuten Point Club page (https://point.rakuten.co.jp/*)
    if (hostname.includes("point.rakuten.co.jp")) {
      const totalEl = document.querySelector(".point-box__total, #p_total");
      const limitEl = document.querySelector(".point-box__limit, #p_limit, .point-box__limit-value");
      const dateEl = document.querySelector(".point-box__limit-date, #p_limit_date, .point-box__limit-info");
      
      if (totalEl) totalPoints = parseNumber(totalEl.innerText);
      if (limitEl) limitedPoints = parseNumber(limitEl.innerText);
      if (dateEl) expiryDate = parseDate(dateEl.innerText);
      
      if (totalPoints > 0) {
        // 失効日が読み取れない場合は「今月末」等を勝手に仮定せず、不明のままにする。
        // 実際より近い/遠い日付を捏造すると、誤った警告(または油断)につながるため。
        savePointData("point_rakuten", {
          name: "楽天ポイント",
          total: totalPoints,
          limitedPoints: limitedPoints,
          expiryDate: expiryDate,
          lastUpdated: Date.now()
        });
      }
    } 
    // Case B: General Rakuten page headers
    else {
      const headerPointEl = document.querySelector("#common-header-point-balance, .common-header-point-balance, [data-testid='header-point-total']");
      if (headerPointEl) {
        totalPoints = parseNumber(headerPointEl.innerText);
        
        // Look for limited point elements in header
        const headerLimitEl = document.querySelector("#common-header-point-time-limit, .common-header-point-sub, .point-time-limit");
        if (headerLimitEl) {
          limitedPoints = parseNumber(headerLimitEl.innerText);
        }
        
        // Merge with existing detailed point data if available to avoid resetting expiry
        chrome.storage.local.get(["point_rakuten"], (data) => {
          const old = data.point_rakuten || {};
          // 失効日はこのページからは分からないので、以前に取得できていた値を
          // 引き継ぐだけにとどめる(無ければ不明=nullのまま。捏造しない)。
          savePointData("point_rakuten", {
            name: "楽天ポイント",
            total: totalPoints,
            limitedPoints: limitedPoints || old.limitedPoints || 0,
            expiryDate: old.expiryDate || null,
            lastUpdated: Date.now()
          });
        });
      }
    }
  } 
  
  else if (hostname.includes("yahoo.co.jp")) {
    let totalPoints = 0;
    
    // Selectors for PayPay balance on Yahoo Shopping / Portal
    const paypaySelectors = [
      ".elPaypayBalance",
      ".elPointValue",
      ".yidPointValue",
      "[data-testid='paypay-balance']",
      ".shopping-header-point",
      ".yjHdPoint"
    ];
    
    for (let sel of paypaySelectors) {
      const el = document.querySelector(sel);
      if (el && el.innerText) {
        totalPoints = parseNumber(el.innerText);
        if (totalPoints > 0) break;
      }
    }
    
    if (totalPoints > 0) {
      savePointData("point_paypay", {
        name: "PayPayポイント",
        total: totalPoints,
        limitedPoints: 0, // PayPay points rarely expire, treat as standard
        expiryDate: null,
        lastUpdated: Date.now()
      });
    }
  }
}

function savePointData(key, data) {
  const store = {};
  store[key] = data;
  chrome.storage.local.set(store);
}



// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // Add temporary shield to prevent iframe from stealing mouse events during dragging
      const existingShield = document.getElementById("wano-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = "wano-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      // Use getBoundingClientRect() for correct viewport-relative position
      // (element.offsetTop is unreliable for position:fixed elements on scrolled pages)
      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      // Restrict within window boundaries to prevent going offscreen
      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById("wano-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  // 拡張機能ごとに一意のIDでネームスペースを切る(他拡張機能とのDOM ID衝突防止。
  // persistent-panelスキルのGotcha4)
  const NS_ID = "wano-" + chrome.runtime.id;

  function toggleFloatingPanel() {
    let container = document.getElementById(NS_ID + "-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "flex" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = NS_ID + "-floating-container";

    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 440) + "px !important; z-index:2147483647 !important; width:430px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="${NS_ID}-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">Point Expiration Alert</span>
        </div>
        <button id="${NS_ID}-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#" + NS_ID + "-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#" + NS_ID + "-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
