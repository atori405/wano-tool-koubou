// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

document.addEventListener("DOMContentLoaded", () => {
  // UI Elements
  const warningBanner = document.getElementById("warning-banner");
  const expiringSum = document.getElementById("expiring-sum");
  const pointsList = document.getElementById("points-list");
  
  const pointForm = document.getElementById("point-form");
  const pointNameSelect = document.getElementById("point-name");
  const customNameGroup = document.getElementById("custom-name-group");
  const customNameInput = document.getElementById("custom-name-input");
  
  const totalPointsInput = document.getElementById("total-points");
  const limitedPointsInput = document.getElementById("limited-points");
  const expiryDateInput = document.getElementById("expiry-date");

  // Toggle custom name input group
  pointNameSelect.addEventListener("change", () => {
    if (pointNameSelect.value === "その他") {
      customNameGroup.classList.remove("hidden");
      customNameInput.required = true;
    } else {
      customNameGroup.classList.add("hidden");
      customNameInput.required = false;
    }
  });

  // Load and render points list from local storage
  function loadAndRenderPoints() {
    chrome.storage.local.get(null, (allData) => {
      const keys = Object.keys(allData).filter(k => k.startsWith("point_"));
      pointsList.innerHTML = "";

      if (keys.length === 0) {
        pointsList.innerHTML = '<div class="empty-list-message">登録されているポイントはありません。対象ECサイトにログインするか、下記フォームから手動で登録してください。</div>';
        warningBanner.classList.add("hidden");
        return;
      }

      let expiringTotal = 0;
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      // Sort keys to keep a clean rendering order (Rakuten, PayPay, then others)
      keys.sort((a, b) => {
        if (a.includes("rakuten")) return -1;
        if (b.includes("rakuten")) return 1;
        if (a.includes("paypay")) return -1;
        if (b.includes("paypay")) return 1;
        return a.localeCompare(b);
      });

      keys.forEach(key => {
        const data = allData[key];
        if (!data) return;

        let diffDays = null;
        let isExpiringSoon = false;
        let expiryText = "無期限";

        if (data.expiryDate && data.limitedPoints > 0) {
          const expiry = new Date(data.expiryDate);
          expiry.setHours(0, 0, 0, 0);
          const diffTime = expiry.getTime() - today.getTime();
          diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

          if (diffDays < 0) {
            expiryText = "期限切れ";
          } else if (diffDays === 0) {
            expiryText = "本日失効！";
            isExpiringSoon = true;
            expiringTotal += data.limitedPoints;
          } else if (diffDays <= 3) {
            expiryText = `あと${diffDays}日 (${formatMMDD(data.expiryDate)}失効)`;
            isExpiringSoon = true;
            expiringTotal += data.limitedPoints;
          } else {
            expiryText = `${formatMMDD(data.expiryDate)}失効 (あと${diffDays}日)`;
          }
        }

        const card = document.createElement("div");
        // Apply expiring visual style if within 3 days
        card.className = `point-card ${isExpiringSoon ? 'point-card-expiring' : ''}`;
        
        // Emblem character based on name
        const firstLetter = data.name ? data.name.charAt(0) : "P";

        card.innerHTML = `
          <div class="point-card-left">
            <div class="point-avatar">${firstLetter}</div>
            <div class="point-info">
              <div class="point-name-lbl">${data.name}</div>
              <div class="point-balance">${data.total.toLocaleString()}<span class="p-unit">P</span></div>
            </div>
          </div>
          <div class="point-card-right">
            <div class="point-limited">期間限定: <strong>${data.limitedPoints.toLocaleString()} P</strong></div>
            <div class="point-expiry">${expiryText}</div>
          </div>
          <button class="delete-btn" data-key="${key}" title="削除">🗑️</button>
        `;

        pointsList.appendChild(card);
      });

      // Show/Hide top emergency banner
      if (expiringTotal > 0) {
        expiringSum.innerText = expiringTotal.toLocaleString();
        warningBanner.classList.remove("hidden");
      } else {
        warningBanner.classList.add("hidden");
      }

      // Bind delete button events
      document.querySelectorAll(".delete-btn").forEach(btn => {
        btn.addEventListener("click", (e) => {
          const k = e.target.getAttribute("data-key");
          if (confirm("このポイント情報を削除しますか？")) {
            chrome.storage.local.remove(k, () => {
              loadAndRenderPoints();
            });
          }
        });
      });
    });
  }

  // Format YYYY-MM-DD to MM/DD
  function formatMMDD(dateStr) {
    if (!dateStr) return "";
    const parts = dateStr.split("-");
    if (parts.length >= 3) {
      return `${parseInt(parts[1], 10)}/${parseInt(parts[2], 10)}`;
    }
    return dateStr;
  }

  // Handle manual form submissions
  pointForm.addEventListener("submit", (e) => {
    e.preventDefault();

    let name = pointNameSelect.value;
    if (name === "その他") {
      name = customNameInput.value.trim() || "その他";
    }

    const total = parseInt(totalPointsInput.value, 10) || 0;
    const limited = parseInt(limitedPointsInput.value, 10) || 0;
    const expiry = expiryDateInput.value || null;

    if (limited > 0 && !expiry) {
      alert("期間限定ポイントがある場合は、失効日を入力してください。");
      return;
    }

    const sanitizedKey = `point_${name.replace(/[^a-zA-Z0-9亜-熙ぁ-んァ-ヶ]/g, "_")}`;

    const pointData = {
      name: name,
      total: total,
      limitedPoints: limited,
      expiryDate: limited > 0 ? expiry : null,
      lastUpdated: Date.now()
    };

    const store = {};
    store[sanitizedKey] = pointData;

    chrome.storage.local.set(store, () => {
      // Reset inputs
      totalPointsInput.value = "";
      limitedPointsInput.value = "";
      expiryDateInput.value = "";
      if (pointNameSelect.value === "その他") {
        customNameInput.value = "";
        customNameGroup.classList.add("hidden");
        pointNameSelect.value = "dポイント";
      }
      
      // Reload UI
      loadAndRenderPoints();
    });
  });

  // Run initial render
  loadAndRenderPoints();
});
