// background.js - Service Worker for Japanese Commit Message Generator

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["useEmoji", "msgFormat"], (result) => {
    const updates = {};
    if (result.useEmoji === undefined) {
      updates.useEmoji = "on"; // Default is emoji on
    }
    if (result.msgFormat === undefined) {
      updates.msgFormat = "emoji-type"; // Default: "✨ feat: [message]"
    }
    if (Object.keys(updates).length > 0) {
      chrome.storage.local.set(updates);
    }
  });
  console.log("日本語コミットメッセージ作成 拡張機能が正常にインストールされました。");
});
