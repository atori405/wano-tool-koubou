// diff-inference.js - shared rule-based commit message inference logic
// Used by both popup.js (manual git diff paste) and content.js (GitHub compare page scraping)
// so the two entry points always produce identical results from the same kind of summary data.
(function () {
  "use strict";

  const EMOJI_MAP = {
    feat: "✨",
    fix: "🐛",
    refactor: "♻️",
    docs: "📝",
    style: "💄",
    test: "🧪",
    chore: "🔧",
    perf: "⚡"
  };

  const JP_PREFIX_MAP = {
    feat: "【新機能】",
    fix: "【バグ修正】",
    refactor: "【改善】",
    docs: "【文書追加】",
    style: "【デザイン】",
    test: "【テスト】",
    chore: "【雑用】",
    perf: "【性能向上】"
  };

  // Rule-based inference from a pre-computed change summary
  // (shared by the raw-diff-text path and the GitHub-DOM-scraping path).
  function analyzeSummary({ changedFiles, additions, deletions, hasTests, hasStyles, hasDocs, hasFixKeywords, addedFunctions }) {
    let inferredType = "feat";
    let inferredSubject = "";
    let inferredScope = "";

    const mainFile = changedFiles[0];
    const fileBasename = mainFile.split("/").pop();
    const filenameNoExt = fileBasename.split(".").shift();

    if (changedFiles.length === 1) {
      inferredScope = filenameNoExt;
    }

    if (hasDocs && !hasStyles && additions < 10) {
      inferredType = "docs";
      inferredSubject = `${fileBasename}のドキュメントを更新`;
    } else if (hasTests) {
      inferredType = "test";
      inferredSubject = `${filenameNoExt}のテストケースを追加・修正`;
    } else if (hasStyles) {
      inferredType = "style";
      inferredSubject = `${fileBasename}のスタイル・デザイン調整`;
    } else if (hasFixKeywords) {
      inferredType = "fix";
      inferredSubject = addedFunctions.length > 0
        ? `${filenameNoExt}の${addedFunctions[0]}関数でのエラーバグを修正`
        : `${fileBasename}のエラーバグ不具合を修正`;
    } else if (additions > 15 && addedFunctions.length > 0) {
      inferredType = "feat";
      inferredSubject = `${filenameNoExt}に新規機能 (${addedFunctions.join(", ")}) を追加`;
    } else if (deletions > additions && deletions > 5) {
      inferredType = "refactor";
      inferredSubject = `${fileBasename}のコード整理・不要コード削除`;
    } else {
      inferredType = "feat";
      inferredSubject = `${fileBasename}に機能実装・ロジック追加`;
    }

    const fileSummary = changedFiles.length > 1 ? `${changedFiles.length}個のファイルを変更` : `${fileBasename}を変更`;
    const inferredBody = `■ 変更概要:\n- ${fileSummary} (追加: +${additions}行, 削除: -${deletions}行)\n` +
      (addedFunctions.length > 0 ? `- 追加された関数: ${addedFunctions.join(", ")}\n` : "") +
      `- 差分解析結果に基づく自動生成メッセージです。`;

    return { type: inferredType, scope: inferredScope, subject: inferredSubject, body: inferredBody };
  }

  // Parse a raw `git diff` text blob into a change summary, then run analyzeSummary().
  function analyzeDiffText(diff) {
    const fileRegex = /diff --git a\/(.+?) b\//g;
    let match;
    const changedFiles = [];
    while ((match = fileRegex.exec(diff)) !== null) {
      changedFiles.push(match[1]);
    }
    if (changedFiles.length === 0) return null;

    let additions = 0;
    let deletions = 0;
    let hasTests = false;
    let hasStyles = false;
    let hasDocs = false;
    let hasFixKeywords = false;
    const addedFunctions = [];

    diff.split("\n").forEach((line) => {
      if (line.startsWith("+") && !line.startsWith("+++")) {
        additions++;
        const funcMatch = line.match(/(?:function|const|let|class)\s+([a-zA-Z0-9_]+)\s*[\(=]/);
        if (funcMatch && funcMatch[1]) addedFunctions.push(funcMatch[1]);
        const lowerLine = line.toLowerCase();
        if (lowerLine.includes("error") || lowerLine.includes("fix") || lowerLine.includes("bug") || lowerLine.includes("resolve")) {
          hasFixKeywords = true;
        }
      } else if (line.startsWith("-") && !line.startsWith("---")) {
        deletions++;
      }
    });

    changedFiles.forEach((file) => {
      const lowerFile = file.toLowerCase();
      if (lowerFile.endsWith(".md") || lowerFile.includes("docs/") || lowerFile.includes("license")) hasDocs = true;
      if (lowerFile.endsWith(".css") || lowerFile.endsWith(".scss") || lowerFile.endsWith(".html") || lowerFile.includes("styles/")) hasStyles = true;
      if (lowerFile.includes("test") || lowerFile.includes("spec") || lowerFile.endsWith(".test.js")) hasTests = true;
    });

    return analyzeSummary({ changedFiles, additions, deletions, hasTests, hasStyles, hasDocs, hasFixKeywords, addedFunctions });
  }

  function buildHeader(type, scope, subject, format) {
    const emoji = EMOJI_MAP[type] || "";
    const jpPrefix = JP_PREFIX_MAP[type] || "";
    const scopePartParen = scope ? `(${scope})` : "";

    if (format === "jp-prefix") {
      const scopePartSpace = scope ? `(${scope}) ` : "";
      return `${jpPrefix} ${scopePartSpace}${subject}`;
    }
    if (format === "clean") {
      return subject;
    }
    if (format === "english") {
      return `${type}${scopePartParen}: ${subject}`;
    }
    // Default: "emoji-type"
    return `${emoji} ${type}${scopePartParen}: ${subject}`;
  }

  window.WabiDiffInference = { EMOJI_MAP, JP_PREFIX_MAP, analyzeDiffText, analyzeSummary, buildHeader };
})();
