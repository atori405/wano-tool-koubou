// content.js - GitHub compare/PR-creation page assistant
// Scrapes the diff GitHub already renders on a compare page, runs it through the same
// rule-based inference used in the popup (diff-inference.js), and fills the PR title/body
// fields if found. Always also copies the result to the clipboard as a fallback, since
// GitHub's exact form markup is not guaranteed to stay stable.

(function () {
  "use strict";

  const NS_ID = "wano-" + chrome.runtime.id;

  // This content script runs on <all_urls> (needed so the floating panel loader below
  // works on any site), so the GitHub-specific diff assistant must gate itself to
  // actual PR-creation (compare) pages only.
  function isGithubComparePage() {
    return /^https:\/\/github\.com\/[^/]+\/[^/]+\/compare(\/|$|\?)/.test(location.href);
  }

  // GitHub renders each changed file as .file[data-tagsearch-path], with per-line
  // <td class="blob-code blob-code-addition|blob-code-deletion|blob-code-context">.
  function scrapeGithubDiff() {
    const fileEls = document.querySelectorAll(".file[data-tagsearch-path]");
    if (fileEls.length === 0) return null;

    const changedFiles = [];
    let additions = 0;
    let deletions = 0;
    let hasTests = false;
    let hasStyles = false;
    let hasDocs = false;
    let hasFixKeywords = false;
    const addedFunctions = [];

    fileEls.forEach((file) => {
      const filePath = file.getAttribute("data-tagsearch-path");
      if (!filePath) return;
      changedFiles.push(filePath);

      const lowerFile = filePath.toLowerCase();
      if (lowerFile.endsWith(".md") || lowerFile.includes("docs/") || lowerFile.includes("license")) hasDocs = true;
      if (lowerFile.endsWith(".css") || lowerFile.endsWith(".scss") || lowerFile.endsWith(".html") || lowerFile.includes("styles/")) hasStyles = true;
      if (lowerFile.includes("test") || lowerFile.includes("spec") || lowerFile.endsWith(".test.js")) hasTests = true;

      const addTds = file.querySelectorAll("td.blob-code-addition");
      const delTds = file.querySelectorAll("td.blob-code-deletion");
      additions += addTds.length;
      deletions += delTds.length;

      addTds.forEach((td) => {
        const line = td.textContent || "";
        const funcMatch = line.match(/(?:function|const|let|class)\s+([a-zA-Z0-9_]+)\s*[\(=]/);
        if (funcMatch && funcMatch[1]) addedFunctions.push(funcMatch[1]);
        const lowerLine = line.toLowerCase();
        if (lowerLine.includes("error") || lowerLine.includes("fix") || lowerLine.includes("bug") || lowerLine.includes("resolve")) {
          hasFixKeywords = true;
        }
      });
    });

    if (changedFiles.length === 0) return null;
    return { changedFiles, additions, deletions, hasTests, hasStyles, hasDocs, hasFixKeywords, addedFunctions };
  }

  // React-controlled inputs ignore a plain `el.value = x` assignment (React's own value
  // tracker doesn't see it), so the native property setter + a real input event are needed.
  function setNativeValue(el, value) {
    const proto = el.tagName === "TEXTAREA" ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(proto, "value");
    if (descriptor && descriptor.set) {
      descriptor.set.call(el, value);
    } else {
      el.value = value;
    }
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function findTitleField() {
    return document.getElementById("pull_request_title")
      || document.querySelector('input[name="pull_request[title]"]')
      || document.querySelector('input[aria-label="Title"]');
  }

  function findBodyField() {
    return document.getElementById("pull_request_body")
      || document.querySelector('textarea[name="pull_request[body]"]')
      || document.querySelector('textarea[aria-label="Comment body"]');
  }

  // NS_ID is derived at runtime from chrome.runtime.id, so styling can't live in a static
  // CSS file with class selectors — everything is applied as inline styles instead.
  let toastEl = null;
  let toastTimer = null;
  function showToast(message) {
    if (!toastEl) {
      toastEl = document.createElement("div");
      toastEl.id = NS_ID + "-gh-toast";
      toastEl.style.cssText =
        "position:fixed !important; bottom:74px !important; right:16px !important; " +
        "z-index:2147483647 !important; max-width:320px !important; " +
        "background:#1c1a17 !important; color:#fdfcfa !important; " +
        "font-family:sans-serif !important; font-size:12.5px !important; line-height:1.6 !important; " +
        "padding:10px 14px !important; border-radius:8px !important; " +
        "box-shadow:0 8px 24px rgba(0,0,0,0.35) !important; " +
        "opacity:0 !important; transform:translateY(8px) !important; " +
        "transition:opacity 0.25s, transform 0.25s !important; pointer-events:none !important;";
      document.body.appendChild(toastEl);
    }
    toastEl.textContent = message;
    toastEl.style.setProperty("opacity", "1", "important");
    toastEl.style.setProperty("transform", "translateY(0)", "important");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toastEl.style.setProperty("opacity", "0", "important");
      toastEl.style.setProperty("transform", "translateY(8px)", "important");
    }, 3200);
  }

  function generateAndFill() {
    const summary = scrapeGithubDiff();
    if (!summary) {
      showToast("差分が見つかりませんでした。差分の表示が完了してから再度お試しください。");
      return;
    }

    const inferred = window.WabiDiffInference.analyzeSummary(summary);
    const header = window.WabiDiffInference.buildHeader(inferred.type, inferred.scope, inferred.subject, "emoji-type");

    const titleField = findTitleField();
    const bodyField = findBodyField();
    let filled = false;
    if (titleField) { setNativeValue(titleField, header); filled = true; }
    if (bodyField) { setNativeValue(bodyField, inferred.body); filled = true; }

    const clipboardText = header + (inferred.body ? "\n\n" + inferred.body : "");
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(clipboardText).catch(() => {});
    }

    showToast(filled
      ? "PRのタイトル・説明欄に反映しました（念のためクリップボードにもコピー済み）"
      : "PRの入力欄が見つからなかったため、クリップボードにコピーしました。手動で貼り付けてください。");
  }

  function injectButton() {
    if (document.getElementById(NS_ID + "-gh-generate-btn")) return;
    const btn = document.createElement("button");
    btn.id = NS_ID + "-gh-generate-btn";
    btn.type = "button";
    btn.innerHTML = "💮 コミットメッセージを生成";
    btn.title = "表示されている差分からタイトル・説明を自動生成します（ルールベース解析。AIによる文章生成ではありません）";
    btn.style.cssText =
      "position:fixed !important; bottom:16px !important; right:16px !important; " +
      "z-index:2147483647 !important; background:#eb6100 !important; color:#ffffff !important; " +
      "font-family:sans-serif !important; font-size:13px !important; font-weight:700 !important; " +
      "border:none !important; border-radius:24px !important; padding:10px 18px !important; " +
      "box-shadow:0 6px 20px rgba(0,0,0,0.3) !important; cursor:pointer !important; " +
      "line-height:1.4 !important;";
    btn.addEventListener("mouseenter", () => btn.style.setProperty("filter", "brightness(1.08)", "important"));
    btn.addEventListener("mouseleave", () => btn.style.removeProperty("filter"));
    btn.addEventListener("click", generateAndFill);
    document.body.appendChild(btn);
  }

  function bootGithubAssistantWithTrialGate() {
    if (!isGithubComparePage()) return;
    window.WanoTrialGate.checkTrialActive().then((trialActive) => {
      if (trialActive) {
        injectButton();
      } else {
        window.WanoTrialGate.showTrialExpiredNotice("日本語コミットメッセージ作成");
      }
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bootGithubAssistantWithTrialGate);
  } else {
    bootGithubAssistantWithTrialGate();
  }

  // --- Universal Floating Panel Loader ---
  // Lets the toolbar icon open the popup UI as an in-page draggable panel instead of the
  // tiny native browser popup, matching the rest of this product line. Unlike the GitHub
  // assistant above, this isn't trial-gated here — the popup itself (license-checker.js)
  // already enforces the trial/license check once it loads, whether floating or native.
  (function () {
    "use strict";

    function makeElementDraggable(element, handle) {
      if (!element || !handle) return;
      let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
      handle.style.cursor = "move";

      handle.addEventListener("mousedown", dragStart);

      function dragStart(e) {
        if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
        e.preventDefault();
        pos3 = e.clientX;
        pos4 = e.clientY;

        element.style.setProperty("outline", "2px dashed #dfc299", "important");
        element.style.setProperty("outline-offset", "-2px", "important");
        element.style.setProperty("z-index", "2147483647", "important");

        const existingShield = document.getElementById(NS_ID + "-drag-shield");
        if (existingShield) existingShield.remove();
        const shield = document.createElement("div");
        shield.id = NS_ID + "-drag-shield";
        shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
        document.body.appendChild(shield);

        document.addEventListener("mouseup", dragEnd);
        document.addEventListener("mousemove", dragMove);
      }

      function dragMove(e) {
        e.preventDefault();
        pos1 = pos3 - e.clientX;
        pos2 = pos4 - e.clientY;
        pos3 = e.clientX;
        pos4 = e.clientY;

        const rect = element.getBoundingClientRect();
        let newTop = rect.top - pos2;
        let newLeft = rect.left - pos1;

        const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
        const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

        newTop = Math.max(10, Math.min(newTop, maxTop));
        newLeft = Math.max(10, Math.min(newLeft, maxLeft));

        element.style.setProperty("position", "fixed", "important");
        element.style.setProperty("top", newTop + "px", "important");
        element.style.setProperty("left", newLeft + "px", "important");
        element.style.setProperty("right", "auto", "important");
        element.style.setProperty("bottom", "auto", "important");
        element.style.setProperty("margin", "0", "important");
      }

      function dragEnd() {
        element.style.removeProperty("outline");
        element.style.removeProperty("outline-offset");
        const shield = document.getElementById(NS_ID + "-drag-shield");
        if (shield) shield.remove();
        document.removeEventListener("mouseup", dragEnd);
        document.removeEventListener("mousemove", dragMove);
      }
    }

    function toggleFloatingPanel() {
      let container = document.getElementById(NS_ID + "-floating-container");
      if (container) {
        container.style.display = (container.style.display === "none") ? "flex" : "none";
        return;
      }

      container = document.createElement("div");
      container.id = NS_ID + "-floating-container";

      container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 440) + "px !important; z-index:2147483647 !important; width:430px !important; height:680px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

      const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
      container.innerHTML = `
        <div id="${NS_ID}-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
          <div style="display:flex; align-items:center; gap:8px;">
            <span style="font-size:16px;">💮</span>
            <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">日本語コミットメッセージ作成</span>
          </div>
          <button id="${NS_ID}-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
        </div>
        <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
      `;

      (document.body || document.documentElement).appendChild(container);

      const header = container.querySelector("#" + NS_ID + "-drag-header");
      makeElementDraggable(container, header);

      container.querySelector("#" + NS_ID + "-close").addEventListener("click", () => {
        container.style.display = "none";
      });
    }

    if (typeof chrome !== "undefined" && chrome.runtime) {
      chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.action === "toggleFloatingPanel") {
          toggleFloatingPanel();
          sendResponse({ status: "toggled" });
        }
        return true;
      });
    }
  })();
})();
