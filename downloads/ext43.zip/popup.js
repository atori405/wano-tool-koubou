// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 680);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 680,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// popup.js - Japanese Commit Message Generator Core

document.addEventListener("DOMContentLoaded", () => {
  // --- 1. Mappings & Constants (shared with content.js via diff-inference.js) ---
  const EMOJI_MAP = window.WabiDiffInference.EMOJI_MAP;
  const JP_PREFIX_MAP = window.WabiDiffInference.JP_PREFIX_MAP;

  // --- 2. Elements Query ---
  const typesGrid = document.getElementById("types-grid");
  const inputScope = document.getElementById("input-scope");
  const selectFormat = document.getElementById("select-format");
  const inputSubject = document.getElementById("input-subject");
  const inputBody = document.getElementById("input-body");
  const diffTextarea = document.getElementById("diff-textarea");
  const btnAnalyzeDiff = document.getElementById("btn-analyze-diff");
  const messagePreview = document.getElementById("message-preview");
  const btnCopy = document.getElementById("btn-copy");
  const toast = document.getElementById("wabi-toast");

  let activeType = "feat"; // Default active type

  // --- 3. Save / Load Settings ---
  function loadSettings() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.get(["msgFormat", "lastScope"], (result) => {
        if (result.msgFormat) {
          selectFormat.value = result.msgFormat;
        }
        if (result.lastScope) {
          inputScope.value = result.lastScope;
        }
        updatePreview();
      });
    } else {
      updatePreview();
    }
  }

  function saveSettings() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.set({
        msgFormat: selectFormat.value,
        lastScope: inputScope.value
      });
    }
  }

  // --- 4. Message Construction ---
  function updatePreview() {
    const scopeVal = inputScope.value.trim();
    const formatVal = selectFormat.value;
    const subjectVal = inputSubject.value.trim() || "(変更内容を入力してください)";
    const bodyVal = inputBody.value.trim();

    const header = window.WabiDiffInference.buildHeader(activeType, scopeVal, subjectVal, formatVal);

    let finalMessage = header;
    if (bodyVal) {
      finalMessage = `${header}\n\n${bodyVal}`;
    }

    messagePreview.textContent = finalMessage;
  }

  // --- 5. Type Cards Interaction ---
  typesGrid.addEventListener("click", (e) => {
    const card = e.target.closest(".wabi-type-card");
    if (!card) return;

    // Deactivate previous
    document.querySelectorAll(".wabi-type-card").forEach(c => c.classList.remove("active"));
    // Activate clicked
    card.classList.add("active");
    activeType = card.getAttribute("data-type");

    updatePreview();
  });

  // --- 6. Form Listeners ---
  [inputScope, inputSubject, inputBody].forEach(input => {
    input.addEventListener("input", () => {
      updatePreview();
      saveSettings();
    });
  });

  selectFormat.addEventListener("change", () => {
    updatePreview();
    saveSettings();
  });

  // --- 7. Offline Diff Analyzer Engine (rule-based, delegates to diff-inference.js) ---
  btnAnalyzeDiff.addEventListener("click", () => {
    const diff = diffTextarea.value.trim();
    if (!diff) {
      alert("git diff のテキストを貼り付けてください。");
      return;
    }

    const inferred = window.WabiDiffInference.analyzeDiffText(diff);
    if (!inferred) {
      alert("有効な git diff の差分データが見つかりませんでした。");
      return;
    }

    // Set UI values
    activeType = inferred.type;
    inputSubject.value = inferred.subject;
    inputScope.value = inferred.scope;

    // Apply Active Card styling
    document.querySelectorAll(".wabi-type-card").forEach(c => {
      c.classList.toggle("active", c.getAttribute("data-type") === inferred.type);
    });

    inputBody.value = inferred.body;

    updatePreview();
    saveSettings();
  });

  // --- 8. Copy to Clipboard Action ---
  btnCopy.addEventListener("click", () => {
    const text = messagePreview.textContent;
    navigator.clipboard.writeText(text).then(() => {
      // Trigger toast
      toast.classList.add("show");
      setTimeout(() => {
        toast.classList.remove("show");
      }, 1500);

      // Button feedback
      const originalText = btnCopy.innerHTML;
      btnCopy.innerHTML = `<span>✅</span> コピー完了`;
      btnCopy.classList.add("success");
      setTimeout(() => {
        btnCopy.innerHTML = originalText;
        btnCopy.classList.remove("success");
      }, 1500);
    });
  });

  // Init
  loadSettings();
});
