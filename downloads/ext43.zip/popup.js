



// popup.js - Japanese Commit Message Generator Core

document.addEventListener("DOMContentLoaded", () => {
  // --- 1. Mappings & Constants ---
  const EMOJI_MAP = {
    feat: "✨",
    fix: "🐛",
    refactor: "♻️",
    docs: "📝",
    style: "💄",
    test: "🧪",
    chore: "🔧",
    perf: "⚡"
  };

  const JP_PREFIX_MAP = {
    feat: "【新機能】",
    fix: "【バグ修正】",
    refactor: "【改善】",
    docs: "【文書追加】",
    style: "【デザイン】",
    test: "【テスト】",
    chore: "【雑用】",
    perf: "【性能向上】"
  };

  // --- 2. Elements Query ---
  const typesGrid = document.getElementById("types-grid");
  const inputScope = document.getElementById("input-scope");
  const selectFormat = document.getElementById("select-format");
  const inputSubject = document.getElementById("input-subject");
  const inputBody = document.getElementById("input-body");
  const diffTextarea = document.getElementById("diff-textarea");
  const btnAnalyzeDiff = document.getElementById("btn-analyze-diff");
  const messagePreview = document.getElementById("message-preview");
  const btnCopy = document.getElementById("btn-copy");
  const toast = document.getElementById("wabi-toast");

  let activeType = "feat"; // Default active type

  // --- 3. Save / Load Settings ---
  function loadSettings() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.get(["msgFormat", "lastScope"], (result) => {
        if (result.msgFormat) {
          selectFormat.value = result.msgFormat;
        }
        if (result.lastScope) {
          inputScope.value = result.lastScope;
        }
        updatePreview();
      });
    } else {
      updatePreview();
    }
  }

  function saveSettings() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.set({
        msgFormat: selectFormat.value,
        lastScope: inputScope.value
      });
    }
  }

  // --- 4. Message Construction ---
  function updatePreview() {
    const scopeVal = inputScope.value.trim();
    const formatVal = selectFormat.value;
    const subjectVal = inputSubject.value.trim() || "(変更内容を入力してください)";
    const bodyVal = inputBody.value.trim();

    const emoji = EMOJI_MAP[activeType] || "";
    const jpPrefix = JP_PREFIX_MAP[activeType] || "";
    
    let header = "";
    
    // Construct message header based on selected format
    if (formatVal === "emoji-type") {
      const scopePart = scopeVal ? `(${scopeVal})` : "";
      header = `${emoji} ${activeType}${scopePart}: ${subjectVal}`;
    } else if (formatVal === "jp-prefix") {
      const scopePart = scopeVal ? `(${scopeVal}) ` : "";
      header = `${jpPrefix} ${scopePart}${subjectVal}`;
    } else if (formatVal === "clean") {
      header = subjectVal;
    } else if (formatVal === "english") {
      const scopePart = scopeVal ? `(${scopeVal})` : "";
      header = `${activeType}${scopePart}: ${subjectVal}`;
    }

    let finalMessage = header;
    if (bodyVal) {
      finalMessage = `${header}\n\n${bodyVal}`;
    }

    messagePreview.textContent = finalMessage;
  }

  // --- 5. Type Cards Interaction ---
  typesGrid.addEventListener("click", (e) => {
    const card = e.target.closest(".wabi-type-card");
    if (!card) return;

    // Deactivate previous
    document.querySelectorAll(".wabi-type-card").forEach(c => c.classList.remove("active"));
    // Activate clicked
    card.classList.add("active");
    activeType = card.getAttribute("data-type");

    updatePreview();
  });

  // --- 6. Form Listeners ---
  [inputScope, inputSubject, inputBody].forEach(input => {
    input.addEventListener("input", () => {
      updatePreview();
      saveSettings();
    });
  });

  selectFormat.addEventListener("change", () => {
    updatePreview();
    saveSettings();
  });

  // --- 7. Offline Diff Analyzer Engine ---
  btnAnalyzeDiff.addEventListener("click", () => {
    const diff = diffTextarea.value.trim();
    if (!diff) {
      alert("git diff のテキストを貼り付けてください。");
      return;
    }

    // Step 1: Parse changed files
    const fileRegex = /diff --git a\/(.+?) b\//g;
    let match;
    const changedFiles = [];
    while ((match = fileRegex.exec(diff)) !== null) {
      changedFiles.push(match[1]);
    }

    if (changedFiles.length === 0) {
      alert("有効な git diff の差分データが見つかりませんでした。");
      return;
    }

    // Step 2: Analyze contents
    let additions = 0;
    let deletions = 0;
    let hasTests = false;
    let hasStyles = false;
    let hasDocs = false;
    let hasFixKeywords = false;
    let addedFunctions = [];

    const lines = diff.split("\n");
    lines.forEach(line => {
      if (line.startsWith("+") && !line.startsWith("+++")) {
        additions++;
        // Look for function additions
        const funcMatch = line.match(/(?:function|const|let|class)\s+([a-zA-Z0-9_]+)\s*[\(=]/);
        if (funcMatch && funcMatch[1]) {
          addedFunctions.push(funcMatch[1]);
        }
        // Look for keywords
        const lowerLine = line.toLowerCase();
        if (lowerLine.includes("error") || lowerLine.includes("fix") || lowerLine.includes("bug") || lowerLine.includes("resolve")) {
          hasFixKeywords = true;
        }
      } else if (line.startsWith("-") && !line.startsWith("---")) {
        deletions++;
      }
    });

    // Step 3: Analyze file extensions
    changedFiles.forEach(file => {
      const lowerFile = file.toLowerCase();
      if (lowerFile.endsWith(".md") || lowerFile.includes("docs/") || lowerFile.includes("license")) {
        hasDocs = true;
      }
      if (lowerFile.endsWith(".css") || lowerFile.endsWith(".scss") || lowerFile.endsWith(".html") || lowerFile.includes("styles/")) {
        hasStyles = true;
      }
      if (lowerFile.includes("test") || lowerFile.includes("spec") || lowerFile.endsWith(".test.js")) {
        hasTests = true;
      }
    });

    // Step 4: Rule-based Commit Type & Title Inference
    let inferredType = "feat";
    let inferredSubject = "";
    let inferredScope = "";

    // Determine target main file for Scope
    const mainFile = changedFiles[0];
    const fileBasename = mainFile.split("/").pop();
    const filenameNoExt = fileBasename.split(".").shift();
    
    if (changedFiles.length === 1) {
      inferredScope = filenameNoExt;
    }

    // Inference Rules
    if (hasDocs && !hasStyles && additions < 10) {
      inferredType = "docs";
      inferredSubject = `${fileBasename}のドキュメントを更新`;
    } else if (hasTests) {
      inferredType = "test";
      inferredSubject = `${filenameNoExt}のテストケースを追加・修正`;
    } else if (hasStyles) {
      inferredType = "style";
      inferredSubject = `${fileBasename}のスタイル・デザイン調整`;
    } else if (hasFixKeywords) {
      inferredType = "fix";
      if (addedFunctions.length > 0) {
        inferredSubject = `${filenameNoExt}の${addedFunctions[0]}関数でのエラーバグを修正`;
      } else {
        inferredSubject = `${fileBasename}のエラーバグ不具合を修正`;
      }
    } else {
      // Feature or Refactor
      if (additions > 15 && addedFunctions.length > 0) {
        inferredType = "feat";
        inferredSubject = `${filenameNoExt}に新規機能 (${addedFunctions.join(", ")}) を追加`;
      } else if (deletions > additions && deletions > 5) {
        inferredType = "refactor";
        inferredSubject = `${fileBasename}のコード整理・不要コード削除`;
      } else {
        inferredType = "feat";
        inferredSubject = `${fileBasename}に機能実装・ロジック追加`;
      }
    }

    // Set UI values
    activeType = inferredType;
    inputSubject.value = inferredSubject;
    inputScope.value = inferredScope;

    // Apply Active Card styling
    document.querySelectorAll(".wabi-type-card").forEach(c => {
      c.classList.toggle("active", c.getAttribute("data-type") === inferredType);
    });

    // Add analytical details in Body
    const fileSummary = changedFiles.length > 1 ? `${changedFiles.length}個のファイルを変更` : `${fileBasename}を変更`;
    inputBody.value = `■ 変更概要:\n- ${fileSummary} (追加: +${additions}行, 削除: -${deletions}行)\n` + 
      (addedFunctions.length > 0 ? `- 追加された関数: ${addedFunctions.join(", ")}\n` : "") +
      `- 差分解析結果に基づく自動生成メッセージです。`;

    updatePreview();
    saveSettings();
  });

  // --- 8. Copy to Clipboard Action ---
  btnCopy.addEventListener("click", () => {
    const text = messagePreview.textContent;
    navigator.clipboard.writeText(text).then(() => {
      // Trigger toast
      toast.classList.add("show");
      setTimeout(() => {
        toast.classList.remove("show");
      }, 1500);

      // Button feedback
      const originalText = btnCopy.innerHTML;
      btnCopy.innerHTML = `<span>✅</span> コピー完了`;
      btnCopy.classList.add("success");
      setTimeout(() => {
        btnCopy.innerHTML = originalText;
        btnCopy.classList.remove("success");
      }, 1500);
    });
  });

  // Init
  loadSettings();
});
