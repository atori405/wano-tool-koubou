// ============================================
// 最安値ハンター — Background Service Worker
// ============================================

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "searchBargainHunter",
    title: "「%s」の最安値を検索 💰",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "searchBargainHunter" && info.selectionText) {
    const query = info.selectionText.trim();
    if (query && tab.id !== chrome.tabs.TAB_ID_NONE) {
      chrome.tabs.sendMessage(tab.id, {
        action: "showBargainFloatingCard",
        query: query
      });
    }
  }
});
