// ============================================
// 最安値ハンター — Content Script
// ============================================

(function() {
  const selectRules = [
    { url: "amazon.co.jp", selector: "#productTitle" },
    { url: "rakuten.co.jp", selector: ".item_name" },
    { url: "rakuten.co.jp", selector: "h1.normal_reserve_item_name" },
    { url: "shopping.yahoo.co.jp", selector: "h1.mdItemName" },
    { url: "shopping.yahoo.co.jp", selector: ".elTitle" },
    { url: "yodobashi.com", selector: "#productsTitle" },
    { url: "kakaku.com", selector: ".productName h2" },
    { url: "kakaku.com", selector: "h2" }
  ];

  function isProductDetailPage() {
    const loc = window.location.href;
    if (loc.includes("mock=amazon") || loc.includes("mock=rakuten")) {
      return true;
    }
    if (loc.includes("amazon.co.jp") && (loc.includes("/dp/") || loc.includes("/gp/product/"))) {
      return true;
    }
    if (loc.includes("rakuten.co.jp") && loc.includes("/item/")) {
      return true;
    }
    if (loc.includes("shopping.yahoo.co.jp") && (loc.includes("/item/") || loc.includes("/products/"))) {
      return true;
    }
    if (loc.includes("yodobashi.com") && loc.includes("/product/")) {
      return true;
    }
    if (loc.includes("kakaku.com") && loc.includes("/item/")) {
      return true;
    }
    return false;
  }

  function getProductTitle() {
    if (!isProductDetailPage()) {
      return null;
    }
    const loc = window.location.href;
    
    // サンドボックス用のフォールバック
    if (loc.includes("mock=amazon")) {
      return document.getElementById("productTitle")?.textContent?.trim() || "ソニー ワイヤレスノイズキャンセリングヘッドホン WH-1000XM5";
    }
    if (loc.includes("mock=rakuten")) {
      const el = document.querySelector(".item_name") || document.querySelector("[class*='item_name']");
      return el?.textContent?.trim() || "Dyson V12 コードレス掃除機";
    }

    for (const rule of selectRules) {
      if (loc.includes(rule.url)) {
        const el = document.querySelector(rule.selector);
        if (el && el.textContent.trim()) {
          return el.textContent.trim();
        }
      }
    }
    // Metadata fallback
    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle && ogTitle.content) {
      return ogTitle.content.split("|")[0].split("-")[0].trim();
    }
    return document.title.split("|")[0].split("-")[0].trim();
  }

  function getProductPriceOnPage() {
    if (!isProductDetailPage()) {
      return null;
    }
    const loc = window.location.href;

    // サンドボックス用のフォールバック
    if (loc.includes("mock=amazon")) {
      const el = document.querySelector(".a-price-whole");
      return el ? "¥" + el.textContent.trim().replace(/[^\d,]/g, "") : "¥48,500";
    }
    if (loc.includes("mock=rakuten")) {
      const el = document.querySelector(".price");
      return el ? "¥" + el.textContent.trim().replace(/[^\d,]/g, "") : "¥78,800";
    }

    let selectors = [];
    if (loc.includes("amazon.co.jp")) {
      selectors = [".a-price-whole", "#priceBlock_ourPrice", "#priceblock_dealprice", "#corePrice_feature_div .a-price-whole"];
    } else if (loc.includes("rakuten.co.jp")) {
      selectors = ["[class*='price--']", ".price", ".important", "#price-box"];
    } else if (loc.includes("shopping.yahoo.co.jp")) {
      selectors = ["[class*='PriceValue']", "span.elPriceValue", ".c-price"];
    } else if (loc.includes("yodobashi.com")) {
      selectors = [".productPrice", "#unitPrice"];
    } else if (loc.includes("kakaku.com")) {
      selectors = [".priceVal span", ".prc span", ".priceNum"];
    }
    
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) {
        let cleaned = el.textContent.trim().replace(/[^\d,]/g, "");
        if (cleaned) {
          return "¥" + cleaned;
        }
      }
    }
    return null;
  }

  // Listen for messages
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "getProductTitle") {
      sendResponse({
        title: getProductTitle(),
        price: getProductPriceOnPage()
      });
    } else if (message.action === "showBargainFloatingCard") {
      // コンテキストメニューからの呼び出し時は、lastQueryを保存してフローティングパネルを起動
      if (message.query) {
        chrome.storage.local.set({ lastQuery: message.query }, () => {
          toggleFloatingPanel();
        });
      }
    }
  });

  // 自動スライドイン通知の初期化
  function initAutoNotification() {
    if (!isProductDetailPage()) return;
    
    // 既に通知かコンテナが存在する場合はスキップ
    if (document.getElementById("bh-slide-notification") || document.getElementById("wano-universal-floating-container")) {
      return;
    }

    const title = getProductTitle();
    const price = getProductPriceOnPage() || "";
    if (!title) return;

    // スライドイン通知のCSSをインジェクト
    const style = document.createElement("style");
    style.id = "bh-notification-style";
    style.innerHTML = `
      #bh-slide-notification {
        position: fixed !important;
        bottom: 25px !important;
        right: -340px !important;
        width: 300px !important;
        background: linear-gradient(135deg, #1C232B, #12161A) !important;
        border: 1.5px solid #D4A017 !important;
        border-radius: 10px !important;
        box-shadow: 0 10px 40px rgba(0,0,0,0.85) !important;
        padding: 14px 18px !important;
        z-index: 2147483647 !important;
        transition: right 0.6s cubic-bezier(0.16, 1, 0.3, 1) !important;
        cursor: pointer !important;
        font-family: 'Hiragino Kaku Gothic ProN', 'Segoe UI', Meiryo, sans-serif !important;
        color: #ECE9E2 !important;
        display: flex !important;
        flex-direction: column !important;
        gap: 6px !important;
        box-sizing: border-box !important;
      }
      #bh-slide-notification:hover {
        transform: translateY(-2px) !important;
        box-shadow: 0 15px 45px rgba(0,0,0,0.95) !important;
        border-color: #F1C40F !important;
      }
      #bh-slide-notification .title-row {
        display: flex !important;
        justify-content: space-between !important;
        align-items: center !important;
        font-size: 13px !important;
        font-weight: bold !important;
        color: #D4A017 !important;
      }
      #bh-slide-notification .prod-name {
        font-size: 12px !important;
        color: rgba(236, 233, 226, 0.85) !important;
        white-space: nowrap !important;
        overflow: hidden !important;
        text-overflow: ellipsis !important;
        font-weight: 500 !important;
      }
      #bh-slide-notification .action-text {
        font-size: 11px !important;
        color: #ffb74d !important;
        text-align: right !important;
        font-weight: bold !important;
        margin-top: 4px !important;
      }
      #bh-notification-close {
        background: none !important;
        border: none !important;
        color: rgba(236, 233, 226, 0.5) !important;
        font-size: 14px !important;
        cursor: pointer !important;
        padding: 2px 6px !important;
      }
      #bh-notification-close:hover {
        color: #fff !important;
      }
    `;
    document.head.appendChild(style);

    const notification = document.createElement("div");
    notification.id = "bh-slide-notification";
    notification.innerHTML = `
      <div class="title-row">
        <span>💰 最安値比較のチャンス！</span>
        <button id="bh-notification-close">✕</button>
      </div>
      <div class="prod-name">${escapeHTML(cleanProductTitle(title))} ${price ? `(${price})` : ''}</div>
      <div class="action-text">他社の最安値を調べる ➔</div>
    `;

    document.body.appendChild(notification);

    // スライドインアニメーション
    setTimeout(() => {
      notification.style.right = "25px";
    }, 800);

    // クリックイベント
    notification.addEventListener("click", (e) => {
      // ✕ボタンがクリックされたか
      if (e.target.id === "bh-notification-close") {
        e.stopPropagation();
        notification.style.right = "-340px";
        setTimeout(() => notification.remove(), 600);
      } else {
        notification.style.right = "-340px";
        setTimeout(() => {
          notification.remove();
          // ストレージに商品名をキャッシュしてから起動
          chrome.storage.local.set({ lastQuery: title }, () => {
            toggleFloatingPanel();
          });
        }, 400);
      }
    });
  }

  function cleanProductTitle(title) {
    return title
      .trim()
      .replace(/^\[.*?\]\s*/g, "")
      .replace(/\s*【.*?】/g, "")
      .replace(/\s*［.*?］/g, "")
      .substring(0, 30)
      .trim();
  }

  function escapeHTML(str) {
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  // ページ読み込み完了後に通知初期化を実行
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initAutoNotification);
  } else {
    initAutoNotification();
  }

})();


// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      const existingShield = document.getElementById("wano-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = "wano-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById("wano-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById("wano-universal-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "block" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = "wano-universal-floating-container";
    
    // Set initial position top right
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 450) + "px !important; z-index:2147483647 !important; width:430px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="wano-u-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">💰</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">最安値ハンター</span>
        </div>
        <button id="wano-u-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#wano-u-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#wano-u-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
