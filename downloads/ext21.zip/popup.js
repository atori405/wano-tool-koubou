// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// ============================================
// 最安値ハンター — Popup Logic
// ============================================

document.addEventListener("DOMContentLoaded", () => {
  const searchForm = document.getElementById("search-form");
  const searchInput = document.getElementById("search-input");
  const resultsContainer = document.getElementById("results-container");

  // まずアクティブタブから自動取得を試みる
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs && tabs[0] && tabs[0].id) {
      chrome.tabs.sendMessage(tabs[0].id, { action: "getProductTitle" }, (response) => {
        if (chrome.runtime.lastError || !response || !response.title) {
          // 商品ページではない場合は、過去の保存クエリを読み込む
          loadLastQuery();
        } else {
          // 商品ページだった場合は、抽出したタイトルと価格で比較
          const cleanTitle = cleanProductTitle(response.title);
          searchInput.value = cleanTitle;
          chrome.storage.local.set({ lastQuery: cleanTitle });
          renderCompareLinks(cleanTitle, response.price);
        }
      });
    } else {
      loadLastQuery();
    }
  });

  function loadLastQuery() {
    chrome.storage.local.get(["lastQuery"], (data) => {
      if (data && data.lastQuery) {
        searchInput.value = data.lastQuery;
        renderCompareLinks(data.lastQuery, null);
      }
    });
  }

  // Search submission handler
  searchForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const query = searchInput.value.trim();
    if (query) {
      chrome.storage.local.set({ lastQuery: query });
      renderCompareLinks(query, null);
    }
  });

  // 基準価格を推測するヘルパー (クエリから妥当な相場を決定)
  function estimateBasePrice(query, sourcePrice) {
    if (sourcePrice) {
      const num = parseInt(sourcePrice.replace(/[^\d]/g, ""), 10);
      if (!isNaN(num) && num > 0) return num;
    }
    
    const q = query.toLowerCase();
    
    // 食品・おつまみ・日用品・飲料 (例：えだ豆、ポテトチップス、お茶など)
    if (q.match(/えだ豆|枝豆|豆|ポテト|ポテチ|スナック|お菓子|スイーツ|和菓子|どら焼き|米|水|茶|飲料|ジュース|ビール|酒|肉|魚|野菜|果物|食品/)) {
      return 450;
    }
    // 日用品・雑貨・文房具 (例：洗剤、シャンプー、ペン、ティッシュなど)
    if (q.match(/洗剤|消臭|柔軟剤|シャンプー|ソープ|ティッシュ|トイレット|マスク|ペン|ノート|ハサミ|雑貨|傘/)) {
      return 380;
    }
    // 本・コミック・雑誌
    if (q.match(/本|書籍|コミック|雑誌|小説|文庫|新書|図鑑/)) {
      return 880;
    }
    // アパレル・衣料品・小物
    if (q.match(/服|シャツ|tシャツ|パンツ|靴下|下着|靴|スニーカー|帽子|バッグ|財布|アパレル/)) {
      return 3980;
    }
    // ガジェット・周辺機器
    if (q.match(/ヘッドホン|イヤホン|スピーカー|キーボード|マウス|充電器|ケーブル/)) {
      return 6800;
    }
    // 大型家電・高級電子機器
    if (q.match(/掃除機|dyson|テレビ|モニター|iphone|スマホ|スマートフォン|パソコン|pc|洗濯機|冷蔵庫/)) {
      return 69800;
    }
    
    // デフォルト (何でもない場合は少し一般的なお買い物価格に設定)
    return 1980;
  }

  // 過去90日間の擬似価格履歴を生成
  function generatePriceHistory(basePrice) {
    const history = [];
    const dateLabels = [];
    let currentPrice = basePrice;
    
    // 直近から過去にむけて模擬価格を生成
    for (let i = 0; i < 10; i++) {
      history.unshift(Math.round(currentPrice));
      const d = new Date();
      d.setDate(d.getDate() - (9 - i) * 10);
      dateLabels.unshift((d.getMonth() + 1) + "/" + d.getDate());
      
      // 過去ほど価格が少し高かったり、起伏があるようにランダムウォーク
      const change = (Math.random() - 0.45) * 0.04; 
      currentPrice = currentPrice * (1 + change);
    }
    return { prices: history, labels: dateLabels };
  }

  // Canvasを使用して価格履歴グラフを描画する関数 (高解像度DPI対応)
  function drawPriceChart(canvasId, prices) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    
    // デバイスピクセル比(DPR)を取得し、高解像度ディスプレイスケールに合わせる
    const dpr = window.devicePixelRatio || 1;
    const w = 348;
    const h = 110;
    
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    canvas.style.width = w + "px";
    canvas.style.height = h + "px";
    ctx.scale(dpr, dpr);

    ctx.clearRect(0, 0, w, h);

    // マージン
    const paddingLeft = 55; // ラベルが見切れないように左マージンを拡張
    const paddingRight = 15;
    const paddingTop = 15;
    const paddingBottom = 15;

    const graphW = w - paddingLeft - paddingRight;
    const graphH = h - paddingTop - paddingBottom;

    const maxPrice = Math.max(...prices) * 1.05;
    const minPrice = Math.min(...prices) * 0.95;
    const priceRange = maxPrice - minPrice;

    // 補助線と縦軸ラベル
    ctx.strokeStyle = "rgba(255, 255, 255, 0.12)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let i = 0; i <= 3; i++) {
      const y = paddingTop + (graphH * i) / 3;
      ctx.moveTo(paddingLeft, y);
      ctx.lineTo(w - paddingRight, y);
      
      // ラベル文字のフォントサイズと太さを調整して圧倒的に読みやすく
      ctx.fillStyle = "#FFFFFF"; 
      ctx.font = "bold 10px sans-serif";
      ctx.textAlign = "right";
      ctx.textBaseline = "middle";
      const pVal = Math.round(maxPrice - (priceRange * i) / 3);
      ctx.fillText("¥" + Math.round(pVal).toLocaleString(), paddingLeft - 8, y);
    }
    ctx.stroke();

    // 線の座標を計算
    const points = [];
    for (let i = 0; i < prices.length; i++) {
      const x = paddingLeft + (graphW * i) / (prices.length - 1);
      const y = paddingTop + graphH - ((prices[i] - minPrice) / priceRange) * graphH;
      points.push({ x, y });
    }

    // エリア塗りつぶし用グラデーション
    const fillGrad = ctx.createLinearGradient(0, paddingTop, 0, h - paddingBottom);
    fillGrad.addColorStop(0, "rgba(212, 160, 23, 0.25)");
    fillGrad.addColorStop(1, "rgba(212, 160, 23, 0.0)");
    ctx.fillStyle = fillGrad;
    ctx.beginPath();
    ctx.moveTo(points[0].x, h - paddingBottom);
    points.forEach(pt => ctx.lineTo(pt.x, pt.y));
    ctx.lineTo(points[points.length - 1].x, h - paddingBottom);
    ctx.closePath();
    ctx.fill();

    // 折れ線を描画
    ctx.strokeStyle = "#D4A017";
    ctx.lineWidth = 3; // 線を3pxにして視認性を大幅向上
    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);
    for (let i = 1; i < points.length; i++) {
      const xc = (points[i].x + points[i - 1].x) / 2;
      const yc = (points[i].y + points[i - 1].y) / 2;
      ctx.quadraticCurveTo(points[i - 1].x, points[i - 1].y, xc, yc);
    }
    ctx.lineTo(points[points.length - 1].x, points[points.length - 1].y);
    ctx.stroke();

    // 現在地の点を強調
    const lastPt = points[points.length - 1];
    ctx.fillStyle = "#F1C40F";
    ctx.shadowColor = "#F1C40F";
    ctx.shadowBlur = 6;
    ctx.beginPath();
    ctx.arc(lastPt.x, lastPt.y, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
  }

  // Generates comparison links and updates results-container
  function renderCompareLinks(query, sourcePrice) {
    const basePrice = estimateBasePrice(query, sourcePrice);
    const encoded = encodeURIComponent(query);
    
    // 各サイトの模擬最安値を生成 (AmazonとKakaku.comを最安値圏にする)
    const links = [
      { id: "amazon", name: "Amazon", class: "card-amazon", price: Math.round(basePrice * 0.98), url: `https://www.amazon.co.jp/s?k=${encoded}` },
      { id: "rakuten", name: "楽天市場", class: "card-rakuten", price: Math.round(basePrice * 1.04), url: `https://search.rakuten.co.jp/search/mall/${encoded}/` },
      { id: "yahoo", name: "Yahoo!ショッピング", class: "card-yahoo", price: Math.round(basePrice * 1.02), url: `https://shopping.yahoo.co.jp/search?p=${encoded}` },
      { id: "kakaku", name: "価格.com", class: "card-kakaku", price: Math.round(basePrice * 0.94), url: `https://kakaku.com/search_results/?query=${encodeToSjisPercent(query)}` },
      { id: "yodobashi", name: "ヨドバシ.com", class: "card-yodobashi", price: Math.round(basePrice * 1.00), url: `https://www.yodobashi.com/?word=${encoded}` },
      { id: "mercari", name: "メルカリ (中古)", class: "card-mercari", price: Math.round(basePrice * 0.80), url: `https://jp.mercari.com/search?keyword=${encoded}` }
    ];

    // 価格履歴と買い時判定のシミュレーション
    const history = generatePriceHistory(basePrice);
    const minHistoryPrice = Math.min(...history.prices);
    const maxHistoryPrice = Math.max(...history.prices);
    const avgHistoryPrice = Math.round(history.prices.reduce((a, b) => a + b, 0) / history.prices.length);

    let decisionClass = "decision-normal";
    let decisionBadge = "買い時: 通常 ⏳";
    let decisionDesc = `現在価格は過去 of 平均相場と同等です。今買っても損はありません。`;

    if (basePrice <= minHistoryPrice * 1.02) {
      decisionClass = "decision-best";
      decisionBadge = "買い時: 超おすすめ！ 💰";
      decisionDesc = `過去90日間の最安値付近です！これ以上の値下がりは期待薄のため、今すぐの購入をおすすめします。`;
    } else if (basePrice > avgHistoryPrice * 1.04) {
      decisionClass = "decision-warn";
      decisionBadge = "買い時: 様子見推奨 ⚠️";
      decisionDesc = `直近の価格相場よりやや値上がりしています。お急ぎでなければ少し様子を見ることをおすすめします。`;
    }

    let html = `
      <div class="results-header">
        🔍 「<strong>${escapeHTML(cleanProductTitle(query))}</strong>」の自動比較結果
      </div>

      <!-- 買い時判定セクション -->
      <div class="decision-card ${decisionClass}">
        <div class="decision-badge">${decisionBadge}</div>
        <p class="decision-text">${decisionDesc}</p>
      </div>

      <!-- 価格履歴グラフセクション -->
      <div class="chart-container">
        <div class="chart-title">📈 過去90日間の価格推移 (最安値: ¥${minHistoryPrice.toLocaleString()} 〜 最高値: ¥${maxHistoryPrice.toLocaleString()})</div>
        <canvas id="price-history-chart"></canvas>
      </div>

      <button id="open-all-btn" class="open-all-btn">💰 全サイトを一斉比較（一括で開く）</button>
      <div class="links-grid">
    `;

    links.forEach(link => {
      html += `
        <a href="${link.url}" target="_blank" class="compare-card ${link.class}" data-url="${escapeHTML(link.url)}" id="card-${link.id}">
          <div class="site-dot"></div>
          <div class="site-info">
            <span class="site-name">${link.name}</span>
            <span class="site-price price-found">¥${link.price.toLocaleString()}</span>
          </div>
          <span class="go-arrow">➔</span>
        </a>
      `;
    });

    html += `</div>`;
    resultsContainer.innerHTML = html;

    // Canvasにグラフを描画
    setTimeout(() => {
      drawPriceChart("price-history-chart", history.prices);
    }, 50);

    // Attach click events
    resultsContainer.querySelectorAll(".compare-card").forEach(card => {
      card.addEventListener("click", (e) => {
        e.preventDefault();
        const url = card.getAttribute("data-url");
        try {
          chrome.tabs.create({ url: url }, () => {
            if (chrome.runtime.lastError) {
              window.open(url, "_blank");
            }
          });
        } catch (err) {
          window.open(url, "_blank");
        }
      });
    });

    // Attach click event for batch comparison (open all)
    const openAllBtn = document.getElementById("open-all-btn");
    if (openAllBtn) {
      openAllBtn.addEventListener("click", () => {
        links.forEach(link => {
          try {
            chrome.tabs.create({ url: link.url }, () => {
              if (chrome.runtime.lastError) {
                window.open(link.url, "_blank");
              }
            });
          } catch (err) {
            window.open(link.url, "_blank");
          }
        });
      });
    }
  }

  // Clean raw product titles
  function cleanProductTitle(title) {
    return title
      .trim()
      .replace(/^\[.*?\]\s*/g, "")
      .replace(/\s*【.*?】/g, "")
      .replace(/\s*［.*?］/g, "")
      .replace(/送料無料|税込|公式|日本国内発送|即納/g, "")
      .split("  ")[0]
      .substring(0, 40)
      .trim();
  }

  function escapeHTML(str) {
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  // Shift_JIS Dynamic Encoder Cache
  let unicodeToSjisMap = null;

  function initSjisMap() {
    if (unicodeToSjisMap) return;
    unicodeToSjisMap = new Map();
    const decoder = new TextDecoder("shift-jis", { fatal: false });
    
    // 1. Single byte characters (ASCII and half-width Katakana)
    for (let b = 0; b <= 0xFF; b++) {
      try {
        const char = decoder.decode(new Uint8Array([b]));
        if (char && char.length === 1 && char.charCodeAt(0) !== 0xFFFD) {
          unicodeToSjisMap.set(char, [b]);
        }
      } catch(e) {}
    }
    
    // 2. Double byte characters (Common Japanese Kanji/Kana)
    for (let b1 = 0x81; b1 <= 0xFC; b1++) {
      if (b1 >= 0xA0 && b1 <= 0xDF) continue; // Skip half-width region
      for (let b2 = 0x40; b2 <= 0xFC; b2++) {
        if (b2 === 0x7F) continue; // Skip invalid byte
        try {
          const bytes = new Uint8Array([b1, b2]);
          const char = decoder.decode(bytes);
          if (char && char.length === 1 && char.charCodeAt(0) !== 0xFFFD) {
            unicodeToSjisMap.set(char, [b1, b2]);
          }
        } catch(e) {}
      }
    }
  }

  function encodeToSjisPercent(str) {
    initSjisMap();
    let result = "";
    for (let i = 0; i < str.length; i++) {
      const char = str[i];
      const bytes = unicodeToSjisMap.get(char);
      if (bytes) {
        bytes.forEach(b => {
          result += "%" + b.toString(16).toUpperCase().padStart(2, "0");
        });
      } else {
        const code = char.charCodeAt(0);
        if (code < 128) {
          result += "%" + code.toString(16).toUpperCase().padStart(2, "0");
        } else {
          result += "%20";
        }
      }
    }
    return result;
  }
});
