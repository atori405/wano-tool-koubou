// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// ============================================
// 最安値ハンター — Popup Logic
// ============================================

document.addEventListener("DOMContentLoaded", () => {
  const searchForm = document.getElementById("search-form");
  const searchInput = document.getElementById("search-input");
  const resultsContainer = document.getElementById("results-container");

  // まずアクティブタブから自動取得を試みる
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs && tabs[0] && tabs[0].id) {
      chrome.tabs.sendMessage(tabs[0].id, { action: "getProductTitle" }, (response) => {
        if (chrome.runtime.lastError || !response || !response.title) {
          // 商品ページではない場合は、過去の保存クエリを読み込む
          loadLastQuery();
        } else {
          // 商品ページだった場合は、抽出したタイトルと価格で比較
          const cleanTitle = cleanProductTitle(response.title);
          searchInput.value = cleanTitle;
          chrome.storage.local.set({ lastQuery: cleanTitle });
          renderCompareLinks(cleanTitle, response.price);
        }
      });
    } else {
      loadLastQuery();
    }
  });

  function loadLastQuery() {
    chrome.storage.local.get(["lastQuery"], (data) => {
      if (data && data.lastQuery) {
        searchInput.value = data.lastQuery;
        renderCompareLinks(data.lastQuery, null);
      }
    });
  }

  // Search submission handler
  searchForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const query = searchInput.value.trim();
    if (query) {
      chrome.storage.local.set({ lastQuery: query });
      renderCompareLinks(query, null);
    }
  });

  // 楽天市場・Yahoo!ショッピング: 実際の価格取得は、ライセンス認証と同じ中継サーバー
  // (PROXY_SERVER_URL、license-manager.jsで定義済み)を経由して行う。
  // 楽天/Yahooの本物のAPIキーは中継サーバー側だけが持ち、拡張機能のコードには
  // 一切埋め込まない(誰でも中身を見られる拡張機能にキーを直接置くのは危険なため)。
  async function fetchPriceViaProxy(endpoint, query) {
    try {
      const res = await fetch(`${PROXY_SERVER_URL}${endpoint}?keyword=${encodeURIComponent(query)}`);
      if (!res.ok) return null;
      const data = await res.json();
      if (!data.found) return null;
      return { price: data.price, url: data.url };
    } catch (e) {
      console.error("[最安値ハンター] 価格取得失敗:", endpoint, e);
      return null;
    }
  }

  function fetchRakutenPrice(query) {
    return fetchPriceViaProxy("/api/rakuten-search", query);
  }

  function fetchYahooPrice(query) {
    return fetchPriceViaProxy("/api/yahoo-search", query);
  }

  // 該当カードの価格表示を更新する。取得できた場合は本物の価格とリンク先を反映し、
  // できなかった場合は正直に「検索結果を見る」のままにする(捏造は絶対にしない)。
  function applyApiResult(link, result) {
    const card = document.getElementById(`card-${link.id}`);
    if (!card) return;
    const priceEl = card.querySelector(".site-price");
    if (result) {
      if (priceEl) {
        priceEl.textContent = `¥${result.price.toLocaleString()}(最安)`;
        priceEl.classList.add("price-found");
      }
      if (result.url) {
        card.setAttribute("href", result.url);
        card.setAttribute("data-url", result.url);
      }
    } else if (priceEl) {
      priceEl.textContent = "検索結果を見る";
    }
  }

  // Generates search links and updates results-container
  // 注意: Amazon・価格.com・ヨドバシ.com・メルカリは公開APIが無いため検索リンクのみ。
  // 楽天市場・Yahoo!ショッピングは公式APIキーが設定されていれば実際の最安値を非同期で反映する。
  // 「今見ているページ」の価格はcontent.jsが実際のDOMから取得した本物の値。
  function renderCompareLinks(query, sourcePrice) {
    const encoded = encodeURIComponent(query);

    const links = [
      { id: "amazon", name: "Amazon", class: "card-amazon", url: `https://www.amazon.co.jp/s?k=${encoded}` },
      { id: "rakuten", name: "楽天市場", class: "card-rakuten", url: `https://search.rakuten.co.jp/search/mall/${encoded}/`, api: fetchRakutenPrice },
      { id: "yahoo", name: "Yahoo!ショッピング", class: "card-yahoo", url: `https://shopping.yahoo.co.jp/search?p=${encoded}`, api: fetchYahooPrice },
      { id: "kakaku", name: "価格.com", class: "card-kakaku", url: `https://kakaku.com/search_results/?query=${encodeToSjisPercent(query)}` },
      { id: "yodobashi", name: "ヨドバシ.com", class: "card-yodobashi", url: `https://www.yodobashi.com/?word=${encoded}` },
      { id: "mercari", name: "メルカリ (中古)", class: "card-mercari", url: `https://jp.mercari.com/search?keyword=${encoded}` }
    ];

    const sourcePriceHtml = sourcePrice
      ? `<div class="source-price-note">このページでの価格: <strong>${escapeHTML(sourcePrice)}</strong></div>`
      : "";

    let html = `
      <div class="results-header">
        🔍 「<strong>${escapeHTML(cleanProductTitle(query))}</strong>」を各サイトで検索
      </div>
      ${sourcePriceHtml}

      <button id="open-all-btn" class="open-all-btn">🔍 全サイトの検索結果を一括で開く</button>
      <div class="links-grid">
    `;

    links.forEach(link => {
      const placeholder = link.api ? "取得中..." : "検索結果を見る";
      html += `
        <a href="${link.url}" target="_blank" class="compare-card ${link.class}" data-url="${escapeHTML(link.url)}" id="card-${link.id}">
          <div class="site-dot"></div>
          <div class="site-info">
            <span class="site-name">${link.name}</span>
            <span class="site-price">${placeholder}</span>
          </div>
          <span class="go-arrow">➔</span>
        </a>
      `;
    });

    html += `</div>`;
    resultsContainer.innerHTML = html;

    // 楽天市場・Yahoo!ショッピングはAPIキーが設定されていれば非同期で実際の最安値を取得する
    links.forEach(link => {
      if (link.api) {
        link.api(query).then(result => applyApiResult(link, result));
      }
    });

    // Attach click events
    resultsContainer.querySelectorAll(".compare-card").forEach(card => {
      card.addEventListener("click", (e) => {
        e.preventDefault();
        const url = card.getAttribute("data-url");
        try {
          chrome.tabs.create({ url: url }, () => {
            if (chrome.runtime.lastError) {
              window.open(url, "_blank");
            }
          });
        } catch (err) {
          window.open(url, "_blank");
        }
      });
    });

    // Attach click event for batch comparison (open all)
    // 各カードのdata-urlを見に行く(API取得後は実商品ページのURLに更新されているため)
    const openAllBtn = document.getElementById("open-all-btn");
    if (openAllBtn) {
      openAllBtn.addEventListener("click", () => {
        resultsContainer.querySelectorAll(".compare-card").forEach(card => {
          const url = card.getAttribute("data-url");
          try {
            chrome.tabs.create({ url: url }, () => {
              if (chrome.runtime.lastError) {
                window.open(url, "_blank");
              }
            });
          } catch (err) {
            window.open(url, "_blank");
          }
        });
      });
    }
  }

  // Clean raw product titles
  function cleanProductTitle(title) {
    return title
      .trim()
      .replace(/^\[.*?\]\s*/g, "")
      .replace(/\s*【.*?】/g, "")
      .replace(/\s*［.*?］/g, "")
      .replace(/送料無料|税込|公式|日本国内発送|即納/g, "")
      .split("  ")[0]
      .substring(0, 40)
      .trim();
  }

  function escapeHTML(str) {
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  // Shift_JIS Dynamic Encoder Cache
  let unicodeToSjisMap = null;

  function initSjisMap() {
    if (unicodeToSjisMap) return;
    unicodeToSjisMap = new Map();
    const decoder = new TextDecoder("shift-jis", { fatal: false });
    
    // 1. Single byte characters (ASCII and half-width Katakana)
    for (let b = 0; b <= 0xFF; b++) {
      try {
        const char = decoder.decode(new Uint8Array([b]));
        if (char && char.length === 1 && char.charCodeAt(0) !== 0xFFFD) {
          unicodeToSjisMap.set(char, [b]);
        }
      } catch(e) {}
    }
    
    // 2. Double byte characters (Common Japanese Kanji/Kana)
    for (let b1 = 0x81; b1 <= 0xFC; b1++) {
      if (b1 >= 0xA0 && b1 <= 0xDF) continue; // Skip half-width region
      for (let b2 = 0x40; b2 <= 0xFC; b2++) {
        if (b2 === 0x7F) continue; // Skip invalid byte
        try {
          const bytes = new Uint8Array([b1, b2]);
          const char = decoder.decode(bytes);
          if (char && char.length === 1 && char.charCodeAt(0) !== 0xFFFD) {
            unicodeToSjisMap.set(char, [b1, b2]);
          }
        } catch(e) {}
      }
    }
  }

  function encodeToSjisPercent(str) {
    initSjisMap();
    let result = "";
    for (let i = 0; i < str.length; i++) {
      const char = str[i];
      const bytes = unicodeToSjisMap.get(char);
      if (bytes) {
        bytes.forEach(b => {
          result += "%" + b.toString(16).toUpperCase().padStart(2, "0");
        });
      } else {
        const code = char.charCodeAt(0);
        if (code < 128) {
          result += "%" + code.toString(16).toUpperCase().padStart(2, "0");
        } else {
          result += "%20";
        }
      }
    }
    return result;
  }
});
