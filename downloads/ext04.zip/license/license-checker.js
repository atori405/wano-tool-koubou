/**
 * license-checker.js
 * 
 * 各拡張機能の popup.html やメイン画面の先頭で読み込まれ、
 * 無料体験の期限切れ時に画面をロックしてライセンス設定画面へ誘導します。
 */

document.addEventListener('DOMContentLoaded', async () => {
  // すでにライセンスオプション画面自体を開いている場合はチェックをスキップ（無限ループ防止）
  if (window.location.pathname.includes('license-options.html')) {
    return;
  }

  // ステータスをチェック
  const status = await LicenseManager.checkStatus();

  if (status.status === 'expired') {
    // 期限切れの場合、元の body の中身を非表示にしてロック画面を表示
    lockUI();
  } else if (status.status === 'trial') {
    // トライアル中の場合、画面上部に残り日数の小さなインジケータ（バナー）を控えめに表示
    showTrialBanner(status.daysLeft);
  }
});

/**
 * 画面をロックし、ライセンス有効化への誘導画面に書き換える
 */
function lockUI() {
  // 元のコンテンツをすべて非表示にするためのスタイルを適用
  const style = document.createElement('style');
  style.innerHTML = `
    body > * { display: none !important; }
    #license-lock-screen { 
      display: flex !important; 
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      padding: 30px !important;
      text-align: center !important;
      background: linear-gradient(135deg, #0f172a, #1e1b4b) !important;
      color: #f8fafc !important;
      font-family: sans-serif !important;
      position: fixed !important;
      top: 0 !important; left: 0 !important; right: 0 !important; bottom: 0 !important;
      z-index: 999999 !important;
    }
    #license-lock-screen h2 { font-size: 1.3rem !important; color: #f59e0b !important; margin-bottom: 12px !important; font-weight: bold !important; }
    #license-lock-screen p { font-size: 0.9rem !important; color: #94a3b8 !important; margin-bottom: 20px !important; line-height: 1.5 !important; }
    #license-lock-screen button {
      background: #d97706 !important;
      color: white !important;
      border: none !important;
      border-radius: 6px !important;
      padding: 10px 20px !important;
      font-size: 0.9rem !important;
      cursor: pointer !important;
      font-weight: 500 !important;
      transition: background 0.2s !important;
    }
    #license-lock-screen button:hover { background: #b45309 !important; }
  `;
  document.head.appendChild(style);

  // ロック画面要素を作成
  const lockScreen = document.createElement('div');
  lockScreen.id = 'license-lock-screen';
  lockScreen.innerHTML = `
    <h2>🔒 無料体験期間が終了しました</h2>
    <p>この機能を引き続きご利用いただくには、ライセンスキーの入力、またはメールアドレスの登録（無料期間の延長）が必要です。</p>
    <button id="open-license-btn">ライセンスを設定する</button>
  `;
  document.body.appendChild(lockScreen);

  // ボタンクリックで拡張機能のオプション（設定）画面を開く
  document.getElementById('open-license-btn').addEventListener('click', () => {
    if (chrome.runtime.openOptionsPage) {
      chrome.runtime.openOptionsPage();
    } else {
      window.open(chrome.runtime.getURL('license/license-options.html'));
    }
  });
}

/**
 * 試用期間中のバナーを画面上部に表示
 */
function showTrialBanner(daysLeft) {
  // ポップアップなどの上部に小さく表示するためのスタイル
  const style = document.createElement('style');
  style.innerHTML = `
    #trial-banner {
      background: #1e293b;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      color: #94a3b8;
      padding: 6px 12px;
      font-size: 0.75rem;
      text-align: center;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-family: sans-serif;
      z-index: 99999;
    }
    #trial-banner a {
      color: #f59e0b;
      text-decoration: none;
      font-weight: bold;
    }
    #trial-banner a:hover {
      text-decoration: underline;
    }
  `;
  document.head.appendChild(style);

  const banner = document.createElement('div');
  banner.id = 'trial-banner';
  banner.innerHTML = `
    <span>無料体験中 (残り ${daysLeft} 日)</span>
    <a href="#" id="upgrade-link">プロ版へ有効化 ➔</a>
  `;
  
  // bodyの先頭に挿入
  document.body.insertBefore(banner, document.body.firstChild);

  document.getElementById('upgrade-link').addEventListener('click', (e) => {
    e.preventDefault();
    if (chrome.runtime.openOptionsPage) {
      chrome.runtime.openOptionsPage();
    } else {
      window.open(chrome.runtime.getURL('license/license-options.html'));
    }
  });
}
