/**
 * license-options.js
 * 
 * 共通ライセンス設定画面のUI制御スクリプト。
 */

document.addEventListener('DOMContentLoaded', async () => {
  const statusCard = document.getElementById('statusCard');
  const statusIcon = document.getElementById('statusIcon');
  const statusTitle = document.getElementById('statusTitle');
  const statusDesc = document.getElementById('statusDesc');
  const deactivateBtn = document.getElementById('deactivateBtn');

  const alertBox = document.getElementById('alertBox');

  const emailSection = document.getElementById('emailSection');
  const emailInput = document.getElementById('emailInput');
  const emailSubmitBtn = document.getElementById('emailSubmitBtn');

  const licenseSection = document.getElementById('licenseSection');
  const licenseInput = document.getElementById('licenseInput');
  const licenseSubmitBtn = document.getElementById('licenseSubmitBtn');

  const footer = document.querySelector('.license-footer');

  // 購入URLの動的適用
  const bundlePurchaseBtn = document.getElementById('bundlePurchaseBtn');
  const singlePurchaseBtn = document.getElementById('singlePurchaseBtn');
  const config = window.LicenseConfig || {};

  if (bundlePurchaseBtn && config.bundleCheckoutUrl) {
    bundlePurchaseBtn.href = config.bundleCheckoutUrl;
  }
  if (singlePurchaseBtn && config.singleCheckoutUrl) {
    singlePurchaseBtn.href = config.singleCheckoutUrl;
  }

  // UI表示の更新処理
  async function updateUI() {
    const status = await LicenseManager.checkStatus();
    
    // 全ての動的クラスを一旦削除
    statusCard.className = 'status-card';
    
    chrome.storage.local.get(['emailRegistered'], (result) => {
      if (status.status === 'premium') {
        // プロ版（プレミアム）
        statusCard.classList.add('premium');
        statusIcon.textContent = '👑';
        statusTitle.textContent = 'プロ版 ライセンス有効';
        statusDesc.textContent = 'すべての機能制限が解除され、無制限にご利用いただけます。';

        // 解除ボタンを表示
        deactivateBtn.classList.remove('hidden');

        // プレミアム時はアクションフォームと購入案内を非表示に
        emailSection.classList.add('hidden');
        licenseSection.classList.add('hidden');
        footer.classList.add('hidden');
      } else if (status.status === 'trial') {
        // トライアル中
        statusCard.classList.add('trial');
        statusIcon.textContent = '⏳';
        statusTitle.textContent = `無料体験中`;
        statusDesc.textContent = `残り ${status.daysLeft} 日間、すべての機能をお試しいただけます。`;

        // 解除ボタンを非表示
        deactivateBtn.classList.add('hidden');

        // すでにメール登録で延長済みの場合はメールフォームを隠す
        if (result.emailRegistered) {
          emailSection.classList.add('hidden');
        } else {
          emailSection.classList.remove('hidden');
        }
        licenseSection.classList.remove('hidden');
        footer.classList.remove('hidden');
      } else {
        // 期限切れ
        statusCard.classList.add('expired');
        statusIcon.textContent = '🔒';
        statusTitle.textContent = '無料体験の期間が終了しました';
        statusDesc.textContent = '引き続きご利用いただくには、ライセンスを登録するか、メール登録で体験期間を延長してください。';

        // 解除ボタンを非表示
        deactivateBtn.classList.add('hidden');

        // メール登録がまだならメールフォームを表示、登録済みなら非表示に
        if (result.emailRegistered) {
          emailSection.classList.add('hidden');
          statusDesc.textContent = '体験期間が終了しました。引き続きご利用いただくにはライセンスの有効化が必要です。';
        } else {
          emailSection.classList.remove('hidden');
        }
        licenseSection.classList.remove('hidden');
        footer.classList.remove('hidden');
      }
    });
  }

  // アラートボックスの表示
  function showAlert(message, type = 'success') {
    alertBox.textContent = message;
    alertBox.className = `alert-box ${type}`;
    
    // スクロールして表示
    alertBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function hideAlert() {
    alertBox.className = 'alert-box hidden';
  }

  // メールアドレス登録処理
  emailSubmitBtn.addEventListener('click', async () => {
    const email = emailInput.value.trim();
    if (!email) {
      showAlert('メールアドレスを入力してください。', 'error');
      return;
    }

    emailSubmitBtn.disabled = true;
    emailSubmitBtn.textContent = '登録中...';
    hideAlert();

    const result = await LicenseManager.registerEmail(email);
    
    emailSubmitBtn.disabled = false;
    emailSubmitBtn.textContent = '無料体験を延長する';

    if (result.success) {
      showAlert(result.message, 'success');
      emailInput.value = '';
      await updateUI();
    } else {
      showAlert(result.message, 'error');
    }
  });

  // ライセンスキーの認証処理
  licenseSubmitBtn.addEventListener('click', async () => {
    const key = licenseInput.value.trim();
    if (!key) {
      showAlert('ライセンスキーを入力してください。', 'error');
      return;
    }

    licenseSubmitBtn.disabled = true;
    licenseSubmitBtn.textContent = '認証中...';
    hideAlert();

    const result = await LicenseManager.verifyLicense(key);

    licenseSubmitBtn.disabled = false;
    licenseSubmitBtn.textContent = 'プロ版を有効化する';

    if (result.success) {
      showAlert(result.message, 'success');
      licenseInput.value = '';
      await updateUI();
      
      // 親ウィンドウ（ポップアップやタブ）に通知（必要に応じて）
      chrome.runtime.sendMessage({ action: 'license_activated' });
    } else {
      showAlert(result.message, 'error');
    }
  });

  // ライセンス解除処理
  deactivateBtn.addEventListener('click', async () => {
    if (!confirm('ライセンス認証を解除しますか？\n解除するとプロ版機能が使えなくなりますが、新しいPCで再度キーが使用可能になります。')) {
      return;
    }

    deactivateBtn.disabled = true;
    deactivateBtn.textContent = '解除中...';
    hideAlert();

    const result = await LicenseManager.deactivateLicense();

    deactivateBtn.disabled = false;
    deactivateBtn.textContent = 'ライセンス解除';

    if (result.success) {
      showAlert(result.message, 'success');
      await updateUI();
      // 親ウィンドウ（ポップアップやタブ）に通知
      chrome.runtime.sendMessage({ action: 'license_deactivated' });
    } else {
      showAlert(result.message, 'error');
    }
  });

  // 初期ロード実行
  await updateUI();
});
