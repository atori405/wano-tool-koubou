// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  function openFallbackWindow() {
    // Fail-safe: Open popup.html as a draggable Chrome popup window
    var w = Math.min(screen.availWidth, 420);
    var h = Math.min(screen.availHeight, 620);
    var left = Math.round((screen.availWidth - w) / 2);
    var top = Math.round((screen.availHeight - h) / 4);
    chrome.windows.create({
      url: chrome.runtime.getURL("popup.html?mode=window"),
      type: "popup",
      width: w,
      height: h,
      left: left,
      top: top,
      focused: true
    });
  }

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        var tabId = tabs[0].id;
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabId, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Content script is likely stale/missing on this tab (e.g. the tab was
            // already open before the extension was installed/updated). Re-inject it
            // on demand and retry once before falling back to a separate OS window
            // (the separate-window fallback can vanish and never reappear).
            if (chrome.scripting) {
              chrome.scripting.executeScript({
                target: { tabId: tabId },
                files: ["draggable.js", "content.js"]
              }, function() {
                if (chrome.runtime.lastError) {
                  openFallbackWindow();
                  window.close();
                  return;
                }
                chrome.tabs.sendMessage(tabId, { action: "toggleFloatingPanel" }, function(response2) {
                  if (chrome.runtime.lastError || !response2 || response2.status !== "toggled") {
                    openFallbackWindow();
                  }
                  window.close();
                });
              });
              return;
            }
            openFallbackWindow();
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

document.addEventListener('DOMContentLoaded', () => {
  // --- State ---
  let currentTheme = 'light';

  // --- Theme Toggle ---
  const themeToggle = document.getElementById('theme-toggle');
  const sunIcon = themeToggle.querySelector('.sun-icon');
  const moonIcon = themeToggle.querySelector('.moon-icon');

  const applyTheme = (theme) => {
    if (theme === 'dark') {
      document.body.classList.remove('light-theme');
      document.body.classList.add('dark-theme');
      sunIcon.style.display = 'none';
      moonIcon.style.display = 'block';
    } else {
      document.body.classList.remove('dark-theme');
      document.body.classList.add('light-theme');
      sunIcon.style.display = 'block';
      moonIcon.style.display = 'none';
    }
    currentTheme = theme;
    localStorage.setItem('summary-theme', theme);
  };

  const savedTheme = localStorage.getItem('summary-theme') || 'light';
  applyTheme(savedTheme);

  themeToggle.addEventListener('click', () => {
    applyTheme(currentTheme === 'light' ? 'dark' : 'light');
  });

  // --- Tab Navigation ---
  const navTabs = document.querySelectorAll('.nav-tab');
  const tabContents = document.querySelectorAll('.tab-content');

  navTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const targetTab = tab.getAttribute('data-tab');
      navTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      tabContents.forEach(content => {
        if (content.id === targetTab) {
          content.classList.add('active');
        } else {
          content.classList.remove('active');
        }
      });
    });
  });

  // --- Dictionary of English terms & translations ---
  const termDictionary = [
    { key: 'ai', display: 'AI', tr: '人工知能 (Artificial Intelligence)' },
    { key: 'llm', display: 'LLM', tr: '大規模言語モデル (Large Language Model)' },
    { key: 'framework', display: 'Framework', tr: 'フレームワーク（共通の開発基盤）' },
    { key: 'database', display: 'Database', tr: 'データベース（情報の保管管理システム）' },
    { key: 'security', display: 'Security', tr: 'セキュリティ（情報安全対策・堅牢性）' },
    { key: 'responsive', display: 'Responsive', tr: 'レスポンシブ（端末に応じた画面最適化）' },
    { key: 'performance', display: 'Performance', tr: 'パフォーマンス（動作性能・処理速度）' },
    { key: 'deployment', display: 'Deployment', tr: 'デプロイ（システムの本番公開・配備）' },
    { key: 'api', display: 'API', tr: 'API（システム同士を連携する窓口）' },
    { key: 'git', display: 'Git', tr: 'Git（プログラムのバージョン管理システム）' },
    { key: 'react', display: 'React', tr: 'React（UIを構築するためのJSライブラリ）' },
    { key: 'typescript', display: 'TypeScript', tr: 'TypeScript（静的型付けされた安全なJS）' },
    { key: 'manifest v3', display: 'Manifest V3', tr: 'マニフェストV3（Chrome拡張機能の最新仕様規格）' },
    { key: 'service worker', display: 'Service Worker', tr: 'サービスワーカー（非同期バックグラウンド処理）' }
  ];

  // --- Text Paste Summary Logic ---
  const inputEnglishText = document.getElementById('input-english');
  const clearPasteBtn = document.getElementById('clear-paste-input');
  const selectTypePaste = document.getElementById('select-type-paste');
  const btnSummarizeText = document.getElementById('btn-summarize-text');

  clearPasteBtn.addEventListener('click', () => {
    inputEnglishText.value = '';
    inputEnglishText.focus();
  });

  // --- Page Summarizer Core ---
  const summarizeLoading = document.getElementById('summary-loading');
  const summaryResultContainer = document.getElementById('summary-result-container');
  const badgeMode = document.getElementById('badge-mode');
  const resultPageTitle = document.getElementById('result-page-title');
  const resultBullets = document.getElementById('result-bullets');
  const termsList = document.getElementById('terms-list');
  const toast = document.getElementById('toast');

  // --- 日本語訳(Chrome内蔵の端末内翻訳API) 用の要素参照 ---
  const btnTranslateJa = document.getElementById('btn-translate-ja');
  const translateStatus = document.getElementById('translate-status');
  const translateNotice = document.getElementById('translate-unavailable-notice');

  const triggerToast = () => {
    toast.classList.remove('hidden');
    setTimeout(() => {
      toast.classList.add('hidden');
    }, 2000);
  };

  // 実際のページの見出し・本文から、本当に関連度の高い部分だけを抜き出す
  // (抽出型サマリー)。文章を書き換える「翻訳・要約AI」ではないため、
  // 見出しと注目文は原文（英語）のまま表示する。
  const splitIntoSentences = (paragraph) => {
    return paragraph
      // 元は(?<=[.!?])\s+のみだったため、"just sports." のように終端記号の直後に
      // 閉じ引用符が来る文(英語では非常によくあるパターン)で分割点を認識できず、
      // 本来3〜4文に分かれるはずの箇所が1つの巨大な文として結合されてしまい、
      // 結果的に文字数フィルターで丸ごと弾かれる原因になっていた。
      .split(/(?<=[.!?]["'”’)])\s+|(?<=[.!?])\s+/)
      .map(s => s.trim())
      // 220字までだと、ニュース記事等でよくある一文が長めの文章が軒並み
      // 弾かれ、候補が1〜2文しか残らず結果が痩せてしまっていた
      // (実例: Sydney Sweeney関連記事で本来拾うべき文が2文とも220字超え)。
      // 320字まで許容範囲を広げ、実質的な内容を含む文を取りこぼさないようにする。
      .filter(s => s.length >= 30 && s.length <= 320);
  };

  // スコアリングは元々「専門用語辞書に一致するか」と「先頭の段落か」の2点だけで、
  // どちらも技術記事向けの signal だった。技術用語が一切登場しない一般記事
  // (スポーツ・エンタメ系など)では全文が同点になり、事実上「たまたま先に
  // 見つかった文」が採用されるだけの状態になっていた。技術記事以外でも
  // 意味のある優先順位が付くよう、一般的な「要点らしさ」のsignal
  // (段落の位置・段落内での位置・数字を含むか・引用符を含むか)を追加する。
  // あくまでページの実データに対する加点方式であり、文章の書き換えや
  // 捏造は行わない。
  const scoreSentence = (sentence, paragraphIndex, sentenceIndex) => {
    let score = Math.max(0, 4 - paragraphIndex); // 記事冒頭に近い段落ほど要点を含みやすい
    if (sentenceIndex === 0) score += 1; // 段落の先頭文はトピックセンテンスであることが多い
    if (/\d/.test(sentence)) score += 1; // 数字・統計を含む文は要旨として重要度が高いことが多い
    if (/["“][^"”]{4,}["”]/.test(sentence)) score += 1; // 引用を含む文も同様
    const lower = sentence.toLowerCase();
    termDictionary.forEach(term => { if (lower.includes(term.key)) score += 2; }); // 技術記事向けの精度は維持
    return score;
  };

  const processSummary = (pageData, mode) => {
    summarizeLoading.classList.remove('hidden');
    summaryResultContainer.classList.add('hidden');

    setTimeout(() => {
      const title = pageData.title || 'Untitled Page';
      const allHeadings = pageData.headings || [];
      const allParagraphs = pageData.paragraphs || [];
      const textToScan = ((pageData.description || '') + ' ' + allHeadings.join(' ') + ' ' + allParagraphs.join(' ')).toLowerCase();

      // 実際にページ内に出現する専門用語だけを検出する
      const matchedTerms = termDictionary.filter(term => textToScan.includes(term.key));

      // 段落を文単位に分割し、専門用語を含む文・冒頭の文を優先してスコアリング
      const scoredSentences = [];
      allParagraphs.forEach((p, pIdx) => {
        splitIntoSentences(p).forEach((s, sIdx) => {
          scoredSentences.push({ text: s, score: scoreSentence(s, pIdx, sIdx) });
        });
      });
      scoredSentences.sort((a, b) => b.score - a.score);

      // モードによって「見出し中心」か「抜粋文中心」かの配分を変える
      // (内容を捏造せず、実データの見せ方だけを変える)
      let headingCount = 3, excerptCount = 3;
      if (mode === 'business') { headingCount = 1; excerptCount = 2; }
      else if (mode === 'tech') { headingCount = 2; excerptCount = 5; }

      const badgeLabels = { bullet: '見出し中心', business: '要点のみ', tech: '専門用語重視' };
      badgeMode.textContent = badgeLabels[mode] || '見出し中心';

      // タイトルは翻訳せず、取得できた原文タイトルをそのまま表示する
      resultPageTitle.textContent = title;

      resultBullets.innerHTML = '';
      const shownHeadings = allHeadings.slice(0, headingCount);
      const shownExcerpts = scoredSentences.slice(0, excerptCount).map(s => s.text);

      const addSubhead = (label) => {
        const li = document.createElement('li');
        li.style.cssText = 'list-style:none; margin-left:-16px; font-weight:700; font-size:12px; color:var(--primary);';
        li.textContent = label;
        resultBullets.appendChild(li);
      };

      if (shownHeadings.length > 0) {
        addSubhead('見出し構成（原文）');
        shownHeadings.forEach(h => {
          const li = document.createElement('li');
          li.textContent = h;
          li.dataset.translatable = 'true';
          resultBullets.appendChild(li);
        });
      }
      if (shownExcerpts.length > 0) {
        addSubhead('注目文の抜粋（原文英語）');
        shownExcerpts.forEach(s => {
          const li = document.createElement('li');
          li.textContent = s;
          li.dataset.translatable = 'true';
          resultBullets.appendChild(li);
        });
      }
      if (shownHeadings.length === 0 && shownExcerpts.length === 0) {
        const li = document.createElement('li');
        li.textContent = 'このページからは見出し・本文を十分に抽出できませんでした。';
        resultBullets.appendChild(li);
      }

      // Populate Terms & Search Links UI(実際に検出できた用語だけを表示する)
      termsList.innerHTML = '';
      if (matchedTerms.length === 0) {
        const empty = document.createElement('p');
        empty.style.cssText = 'font-size:12px; color:var(--text-muted);';
        empty.textContent = 'このページからは辞書登録済みの専門用語は検出されませんでした。';
        termsList.appendChild(empty);
      }

      matchedTerms.forEach(term => {
        const row = document.createElement('div');
        row.className = 'term-row';

        row.innerHTML = `
          <div class="term-meta">
            <span class="term-badge">${term.display}</span>
            <span class="term-translation">${term.tr}</span>
          </div>
          <div class="term-search-grid">
            <button class="search-btn qiita" data-url="https://qiita.com/search?q=${encodeURIComponent(term.display)}">Qiita で検索</button>
            <button class="search-btn zenn" data-url="https://zenn.dev/search?q=${encodeURIComponent(term.display)}">Zenn で検索</button>
            <button class="search-btn wiki" data-url="https://ja.wikipedia.org/wiki/${encodeURIComponent(term.display)}">Wikipedia で検索</button>
          </div>
        `;
        termsList.appendChild(row);
      });

      // Hook up search buttons
      termsList.querySelectorAll('.search-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const url = btn.getAttribute('data-url');
          if (chrome.tabs && chrome.tabs.create) {
            chrome.tabs.create({ url: url });
          } else {
            window.open(url, '_blank');
          }
          triggerToast();
        });
      });

      // 新しい要約が生成されるたびに、日本語訳ボタンの状態を初期化する
      resetTranslateUI();

      // Toggle panels
      summarizeLoading.classList.add('hidden');
      summaryResultContainer.classList.remove('hidden');
    }, 800); // 800ms loading effect
  };

  // --- 日本語訳(Chrome内蔵の端末内翻訳API) ---
  // Translator APIはChrome 138以降で安定版として提供されている端末内AIで、
  // 外部サーバーへの送信なしに英->日翻訳ができる。ただし(1)対応していない
  // 古いChromeやChrome以外のブラウザ、(2)PCのスペック不足、(3)初回利用時に
  // 翻訳モデルの準備が完了していない、(4)組織のポリシーで無効化、等の理由で
  // 利用できない環境が普通にあり得るため、使えない場合は「なぜ使えないか」を
  // 案内した上で、これまで通り原文(英語)表示にフォールバックする。
  let isTranslatedToJa = false;
  let translatorInstance = null;

  function resetTranslateUI() {
    isTranslatedToJa = false;
    translatorInstance = null;
    if (!btnTranslateJa) return;
    btnTranslateJa.textContent = '🇯🇵 日本語に翻訳';
    btnTranslateJa.disabled = false;
    translateStatus.classList.add('hidden');
    translateStatus.textContent = '';
    translateNotice.classList.add('hidden');
    translateNotice.innerHTML = '';
  }

  function showTranslateUnavailableNotice() {
    translateNotice.innerHTML =
      '<strong>この端末では日本語訳を利用できません。</strong><br>' +
      '要約は原文(英語)のまま表示しています。Chromeに内蔵された翻訳機能は、' +
      '古いバージョンのChrome／Chrome以外のブラウザ、PCのスペック不足、' +
      '初回利用時のモデル準備中、組織の管理ポリシーによる無効化、' +
      'のいずれかに該当すると利用できないことがあります。';
    translateNotice.classList.remove('hidden');
  }

  function getTranslatableBullets() {
    return Array.from(resultBullets.querySelectorAll('li[data-translatable="true"]'));
  }

  function restoreOriginalText() {
    if (resultPageTitle.dataset.original) resultPageTitle.textContent = resultPageTitle.dataset.original;
    getTranslatableBullets().forEach(li => {
      if (li.dataset.original) li.textContent = li.dataset.original;
    });
  }

  async function translateAllToJapanese() {
    if (typeof Translator === 'undefined') {
      showTranslateUnavailableNotice();
      return false;
    }
    try {
      const availability = await Translator.availability({ sourceLanguage: 'en', targetLanguage: 'ja' });
      if (availability === 'unavailable') {
        showTranslateUnavailableNotice();
        return false;
      }

      if (!translatorInstance) {
        translateStatus.classList.remove('hidden');
        translateStatus.textContent = (availability === 'available')
          ? '翻訳中…'
          : '翻訳モデルを準備中です(初回のみ、数十秒〜数分かかることがあります)…';

        translatorInstance = await Translator.create({
          sourceLanguage: 'en',
          targetLanguage: 'ja',
          monitor(m) {
            m.addEventListener('downloadprogress', (e) => {
              const pct = Math.round((e.loaded || 0) * 100);
              translateStatus.textContent = '翻訳モデルをダウンロード中… ' + pct + '%';
            });
          }
        });
      }

      translateStatus.classList.remove('hidden');
      translateStatus.textContent = '翻訳中…';

      resultPageTitle.dataset.original = resultPageTitle.dataset.original || resultPageTitle.textContent;
      resultPageTitle.textContent = await translatorInstance.translate(resultPageTitle.dataset.original);

      const bullets = getTranslatableBullets();
      for (const li of bullets) {
        li.dataset.original = li.dataset.original || li.textContent;
        li.textContent = await translatorInstance.translate(li.dataset.original);
      }

      translateStatus.classList.add('hidden');
      return true;
    } catch (e) {
      console.warn('[wano-ext04] translation failed:', e);
      showTranslateUnavailableNotice();
      translateStatus.classList.add('hidden');
      return false;
    }
  }

  if (btnTranslateJa) {
    btnTranslateJa.addEventListener('click', async () => {
      if (isTranslatedToJa) {
        restoreOriginalText();
        isTranslatedToJa = false;
        btnTranslateJa.textContent = '🇯🇵 日本語に翻訳';
        return;
      }

      translateNotice.classList.add('hidden');
      btnTranslateJa.disabled = true;
      const ok = await translateAllToJapanese();
      btnTranslateJa.disabled = false;
      if (ok) {
        isTranslatedToJa = true;
        btnTranslateJa.textContent = '🔤 原文(英語)に戻す';
      }
    });
  }

  // Live Page Summarizer trigger
  const btnSummarizePage = document.getElementById('btn-summarize-page');
  const selectTypeLive = document.getElementById('select-type-live');

  btnSummarizePage.addEventListener('click', () => {
    const mode = selectTypeLive.value;

    // Check if we are running as a real extension and can script
    if (chrome.tabs) {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const activeTab = tabs[0];
        if (!activeTab || !activeTab.id || activeTab.url.startsWith('chrome://')) {
          // Fallback demo for internal chrome pages
          const mockData = {
            title: 'Deep Dive into Manifest V3: Performance and Security Enhancements in Chrome Extensions',
            description: 'Learn about service worker, declarativeNetRequest and secure coding guidelines in MV3.',
            headings: ['Introduction to Manifest V3', 'Performance benchmarks', 'Security enhancements', 'API updates'],
            paragraphs: ['Manifest V3 is the latest specification.', 'Service worker replaces background page.', 'declarativeNetRequest provides faster ad blocking.']
          };
          processSummary(mockData, mode);
          return;
        }

        // content.jsは常駐content_scriptとして既に注入済みのため、
        // chrome.scripting.executeScriptで再注入するのではなく常駐リスナーへ
        // メッセージを送って抽出結果を受け取る(再注入すると、フローティング
        // パネル管理コードの完了値で上書きされ結果を受け取れなくなるため)。
        chrome.tabs.sendMessage(activeTab.id, { action: 'extractPageData' }, (response) => {
          if (!chrome.runtime.lastError && response) {
            processSummary(response, mode);
            return;
          }
          // 拡張機能のインストール/更新前から開いていたタブ等、content script
          // が未挿入の場合は注入してから一度だけ再試行する。
          if (chrome.scripting) {
            chrome.scripting.executeScript({
              target: { tabId: activeTab.id },
              files: ['draggable.js', 'content.js']
            }, () => {
              if (chrome.runtime.lastError) {
                alert('ページの読み込みに失敗しました。');
                return;
              }
              chrome.tabs.sendMessage(activeTab.id, { action: 'extractPageData' }, (response2) => {
                if (chrome.runtime.lastError || !response2) {
                  alert('ページの読み込みに失敗しました。');
                  return;
                }
                processSummary(response2, mode);
              });
            });
            return;
          }
          alert('ページの読み込みに失敗しました。');
        });
      });
    } else {
      // Offline fallback for development mockup
      const mockData = {
        title: 'Introducing Next-Gen AI Framework for Responsive Databases',
        description: 'Review performance, security, and deployment pipelines.',
        headings: ['Modern database architecture', 'AI indexing', 'Performance and TypeScript integration'],
        paragraphs: ['Our framework supports typescript and React.', 'Database deployment is easy.', 'Excellent performance.']
      };
      processSummary(mockData, mode);
    }
  });

  // Text Input Summarizer trigger
  btnSummarizeText.addEventListener('click', () => {
    const text = inputEnglishText.value.trim();
    if (!text) return;

    const mode = selectTypePaste.value;
    
    // Construct pageData from input
    const pageData = {
      title: 'Pasted Text Summary',
      description: '',
      headings: [],
      paragraphs: [text]
    };

    // Swap to tab-live visual results
    document.querySelectorAll('.nav-tab').forEach(t => {
      if (t.getAttribute('data-tab') === 'tab-live') t.classList.add('active');
      else t.classList.remove('active');
    });
    document.querySelectorAll('.tab-content').forEach(c => {
      if (c.id === 'tab-live') c.classList.add('active');
      else c.classList.remove('active');
    });

    processSummary(pageData, mode);
  });
});
