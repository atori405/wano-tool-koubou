// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  function openFallbackWindow() {
    // Fail-safe: Open popup.html as a draggable Chrome popup window
    var w = Math.min(screen.availWidth, 420);
    var h = Math.min(screen.availHeight, 620);
    var left = Math.round((screen.availWidth - w) / 2);
    var top = Math.round((screen.availHeight - h) / 4);
    chrome.windows.create({
      url: chrome.runtime.getURL("popup.html?mode=window"),
      type: "popup",
      width: w,
      height: h,
      left: left,
      top: top,
      focused: true
    });
  }

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        var tabId = tabs[0].id;
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabId, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Content script is likely stale/missing on this tab (e.g. the tab was
            // already open before the extension was installed/updated). Re-inject it
            // on demand and retry once before falling back to a separate OS window
            // (the separate-window fallback can vanish and never reappear).
            if (chrome.scripting) {
              chrome.scripting.executeScript({
                target: { tabId: tabId },
                files: ["draggable.js", "content.js"]
              }, function() {
                if (chrome.runtime.lastError) {
                  openFallbackWindow();
                  window.close();
                  return;
                }
                chrome.tabs.sendMessage(tabId, { action: "toggleFloatingPanel" }, function(response2) {
                  if (chrome.runtime.lastError || !response2 || response2.status !== "toggled") {
                    openFallbackWindow();
                  }
                  window.close();
                });
              });
              return;
            }
            openFallbackWindow();
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

document.addEventListener('DOMContentLoaded', () => {
  // --- State ---
  let currentTheme = 'light';

  // --- Theme Toggle ---
  const themeToggle = document.getElementById('theme-toggle');
  const sunIcon = themeToggle.querySelector('.sun-icon');
  const moonIcon = themeToggle.querySelector('.moon-icon');

  const applyTheme = (theme) => {
    if (theme === 'dark') {
      document.body.classList.remove('light-theme');
      document.body.classList.add('dark-theme');
      sunIcon.style.display = 'none';
      moonIcon.style.display = 'block';
    } else {
      document.body.classList.remove('dark-theme');
      document.body.classList.add('light-theme');
      sunIcon.style.display = 'block';
      moonIcon.style.display = 'none';
    }
    currentTheme = theme;
    localStorage.setItem('summary-theme', theme);
  };

  const savedTheme = localStorage.getItem('summary-theme') || 'light';
  applyTheme(savedTheme);

  themeToggle.addEventListener('click', () => {
    applyTheme(currentTheme === 'light' ? 'dark' : 'light');
  });

  // --- Tab Navigation ---
  const navTabs = document.querySelectorAll('.nav-tab');
  const tabContents = document.querySelectorAll('.tab-content');

  navTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const targetTab = tab.getAttribute('data-tab');
      navTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      tabContents.forEach(content => {
        if (content.id === targetTab) {
          content.classList.add('active');
        } else {
          content.classList.remove('active');
        }
      });
    });
  });

  // --- Dictionary of English terms & translations ---
  const termDictionary = [
    { key: 'ai', display: 'AI', tr: '人工知能 (Artificial Intelligence)' },
    { key: 'llm', display: 'LLM', tr: '大規模言語モデル (Large Language Model)' },
    { key: 'framework', display: 'Framework', tr: 'フレームワーク（共通の開発基盤）' },
    { key: 'database', display: 'Database', tr: 'データベース（情報の保管管理システム）' },
    { key: 'security', display: 'Security', tr: 'セキュリティ（情報安全対策・堅牢性）' },
    { key: 'responsive', display: 'Responsive', tr: 'レスポンシブ（端末に応じた画面最適化）' },
    { key: 'performance', display: 'Performance', tr: 'パフォーマンス（動作性能・処理速度）' },
    { key: 'deployment', display: 'Deployment', tr: 'デプロイ（システムの本番公開・配備）' },
    { key: 'api', display: 'API', tr: 'API（システム同士を連携する窓口）' },
    { key: 'git', display: 'Git', tr: 'Git（プログラムのバージョン管理システム）' },
    { key: 'react', display: 'React', tr: 'React（UIを構築するためのJSライブラリ）' },
    { key: 'typescript', display: 'TypeScript', tr: 'TypeScript（静的型付けされた安全なJS）' },
    { key: 'manifest v3', display: 'Manifest V3', tr: 'マニフェストV3（Chrome拡張機能の最新仕様規格）' },
    { key: 'service worker', display: 'Service Worker', tr: 'サービスワーカー（非同期バックグラウンド処理）' }
  ];

  // --- Text Paste Summary Logic ---
  const inputEnglishText = document.getElementById('input-english');
  const clearPasteBtn = document.getElementById('clear-paste-input');
  const selectTypePaste = document.getElementById('select-type-paste');
  const btnSummarizeText = document.getElementById('btn-summarize-text');

  clearPasteBtn.addEventListener('click', () => {
    inputEnglishText.value = '';
    inputEnglishText.focus();
  });

  // --- Page Summarizer Core ---
  const summarizeLoading = document.getElementById('summary-loading');
  const summaryResultContainer = document.getElementById('summary-result-container');
  const badgeMode = document.getElementById('badge-mode');
  const resultPageTitle = document.getElementById('result-page-title');
  const resultBullets = document.getElementById('result-bullets');
  const termsList = document.getElementById('terms-list');
  const toast = document.getElementById('toast');

  const triggerToast = () => {
    toast.classList.remove('hidden');
    setTimeout(() => {
      toast.classList.add('hidden');
    }, 2000);
  };

  // 実際のページの見出し・本文から、本当に関連度の高い部分だけを抜き出す
  // (抽出型サマリー)。文章を書き換える「翻訳・要約AI」ではないため、
  // 見出しと注目文は原文（英語）のまま表示する。
  const splitIntoSentences = (paragraph) => {
    return paragraph
      .split(/(?<=[.!?])\s+/)
      .map(s => s.trim())
      .filter(s => s.length >= 30 && s.length <= 220);
  };

  const scoreSentence = (sentence, paragraphIndex) => {
    let score = paragraphIndex === 0 ? 2 : 0; // 冒頭の段落を少し優先
    const lower = sentence.toLowerCase();
    termDictionary.forEach(term => { if (lower.includes(term.key)) score += 2; });
    return score;
  };

  const processSummary = (pageData, mode) => {
    summarizeLoading.classList.remove('hidden');
    summaryResultContainer.classList.add('hidden');

    setTimeout(() => {
      const title = pageData.title || 'Untitled Page';
      const allHeadings = pageData.headings || [];
      const allParagraphs = pageData.paragraphs || [];
      const textToScan = ((pageData.description || '') + ' ' + allHeadings.join(' ') + ' ' + allParagraphs.join(' ')).toLowerCase();

      // 実際にページ内に出現する専門用語だけを検出する
      const matchedTerms = termDictionary.filter(term => textToScan.includes(term.key));

      // 段落を文単位に分割し、専門用語を含む文・冒頭の文を優先してスコアリング
      const scoredSentences = [];
      allParagraphs.forEach((p, pIdx) => {
        splitIntoSentences(p).forEach(s => {
          scoredSentences.push({ text: s, score: scoreSentence(s, pIdx) });
        });
      });
      scoredSentences.sort((a, b) => b.score - a.score);

      // モードによって「見出し中心」か「抜粋文中心」かの配分を変える
      // (内容を捏造せず、実データの見せ方だけを変える)
      let headingCount = 3, excerptCount = 3;
      if (mode === 'business') { headingCount = 1; excerptCount = 2; }
      else if (mode === 'tech') { headingCount = 2; excerptCount = 5; }

      const badgeLabels = { bullet: '見出し中心', business: '要点のみ', tech: '専門用語重視' };
      badgeMode.textContent = badgeLabels[mode] || '見出し中心';

      // タイトルは翻訳せず、取得できた原文タイトルをそのまま表示する
      resultPageTitle.textContent = title;

      resultBullets.innerHTML = '';
      const shownHeadings = allHeadings.slice(0, headingCount);
      const shownExcerpts = scoredSentences.slice(0, excerptCount).map(s => s.text);

      const addSubhead = (label) => {
        const li = document.createElement('li');
        li.style.cssText = 'list-style:none; margin-left:-16px; font-weight:700; font-size:12px; color:var(--primary);';
        li.textContent = label;
        resultBullets.appendChild(li);
      };

      if (shownHeadings.length > 0) {
        addSubhead('見出し構成（原文）');
        shownHeadings.forEach(h => {
          const li = document.createElement('li');
          li.textContent = h;
          resultBullets.appendChild(li);
        });
      }
      if (shownExcerpts.length > 0) {
        addSubhead('注目文の抜粋（原文英語）');
        shownExcerpts.forEach(s => {
          const li = document.createElement('li');
          li.textContent = s;
          resultBullets.appendChild(li);
        });
      }
      if (shownHeadings.length === 0 && shownExcerpts.length === 0) {
        const li = document.createElement('li');
        li.textContent = 'このページからは見出し・本文を十分に抽出できませんでした。';
        resultBullets.appendChild(li);
      }

      // Populate Terms & Search Links UI(実際に検出できた用語だけを表示する)
      termsList.innerHTML = '';
      if (matchedTerms.length === 0) {
        const empty = document.createElement('p');
        empty.style.cssText = 'font-size:12px; color:var(--text-muted);';
        empty.textContent = 'このページからは辞書登録済みの専門用語は検出されませんでした。';
        termsList.appendChild(empty);
      }

      matchedTerms.forEach(term => {
        const row = document.createElement('div');
        row.className = 'term-row';

        row.innerHTML = `
          <div class="term-meta">
            <span class="term-badge">${term.display}</span>
            <span class="term-translation">${term.tr}</span>
          </div>
          <div class="term-search-grid">
            <button class="search-btn qiita" data-url="https://qiita.com/search?q=${encodeURIComponent(term.display)}">Qiita で検索</button>
            <button class="search-btn zenn" data-url="https://zenn.dev/search?q=${encodeURIComponent(term.display)}">Zenn で検索</button>
            <button class="search-btn wiki" data-url="https://ja.wikipedia.org/wiki/${encodeURIComponent(term.display)}">Wikipedia で検索</button>
          </div>
        `;
        termsList.appendChild(row);
      });

      // Hook up search buttons
      termsList.querySelectorAll('.search-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const url = btn.getAttribute('data-url');
          if (chrome.tabs && chrome.tabs.create) {
            chrome.tabs.create({ url: url });
          } else {
            window.open(url, '_blank');
          }
          triggerToast();
        });
      });

      // Toggle panels
      summarizeLoading.classList.add('hidden');
      summaryResultContainer.classList.remove('hidden');
    }, 800); // 800ms loading effect
  };

  // Live Page Summarizer trigger
  const btnSummarizePage = document.getElementById('btn-summarize-page');
  const selectTypeLive = document.getElementById('select-type-live');

  btnSummarizePage.addEventListener('click', () => {
    const mode = selectTypeLive.value;

    // Check if we are running as a real extension and can script
    if (chrome.tabs && chrome.scripting) {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const activeTab = tabs[0];
        if (!activeTab || !activeTab.id || activeTab.url.startsWith('chrome://')) {
          // Fallback demo for internal chrome pages
          const mockData = {
            title: 'Deep Dive into Manifest V3: Performance and Security Enhancements in Chrome Extensions',
            description: 'Learn about service worker, declarativeNetRequest and secure coding guidelines in MV3.',
            headings: ['Introduction to Manifest V3', 'Performance benchmarks', 'Security enhancements', 'API updates'],
            paragraphs: ['Manifest V3 is the latest specification.', 'Service worker replaces background page.', 'declarativeNetRequest provides faster ad blocking.']
          };
          processSummary(mockData, mode);
          return;
        }

        // Execute content script to pull site info
        chrome.scripting.executeScript({
          target: { tabId: activeTab.id },
          files: ['content.js']
        }, (results) => {
          if (results && results[0] && results[0].result) {
            processSummary(results[0].result, mode);
          } else {
            // Error fallback
            alert('ページの読み込みに失敗しました。');
          }
        });
      });
    } else {
      // Offline fallback for development mockup
      const mockData = {
        title: 'Introducing Next-Gen AI Framework for Responsive Databases',
        description: 'Review performance, security, and deployment pipelines.',
        headings: ['Modern database architecture', 'AI indexing', 'Performance and TypeScript integration'],
        paragraphs: ['Our framework supports typescript and React.', 'Database deployment is easy.', 'Excellent performance.']
      };
      processSummary(mockData, mode);
    }
  });

  // Text Input Summarizer trigger
  btnSummarizeText.addEventListener('click', () => {
    const text = inputEnglishText.value.trim();
    if (!text) return;

    const mode = selectTypePaste.value;
    
    // Construct pageData from input
    const pageData = {
      title: 'Pasted Text Summary',
      description: '',
      headings: [],
      paragraphs: [text]
    };

    // Swap to tab-live visual results
    document.querySelectorAll('.nav-tab').forEach(t => {
      if (t.getAttribute('data-tab') === 'tab-live') t.classList.add('active');
      else t.classList.remove('active');
    });
    document.querySelectorAll('.tab-content').forEach(c => {
      if (c.id === 'tab-live') c.classList.add('active');
      else c.classList.remove('active');
    });

    processSummary(pageData, mode);
  });
});
