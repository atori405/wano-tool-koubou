// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

document.addEventListener('DOMContentLoaded', () => {
  // --- State ---
  let currentTheme = 'light';

  // --- Theme Toggle ---
  const themeToggle = document.getElementById('theme-toggle');
  const sunIcon = themeToggle.querySelector('.sun-icon');
  const moonIcon = themeToggle.querySelector('.moon-icon');

  const applyTheme = (theme) => {
    if (theme === 'dark') {
      document.body.classList.remove('light-theme');
      document.body.classList.add('dark-theme');
      sunIcon.style.display = 'none';
      moonIcon.style.display = 'block';
    } else {
      document.body.classList.remove('dark-theme');
      document.body.classList.add('light-theme');
      sunIcon.style.display = 'block';
      moonIcon.style.display = 'none';
    }
    currentTheme = theme;
    localStorage.setItem('summary-theme', theme);
  };

  const savedTheme = localStorage.getItem('summary-theme') || 'light';
  applyTheme(savedTheme);

  themeToggle.addEventListener('click', () => {
    applyTheme(currentTheme === 'light' ? 'dark' : 'light');
  });

  // --- Tab Navigation ---
  const navTabs = document.querySelectorAll('.nav-tab');
  const tabContents = document.querySelectorAll('.tab-content');

  navTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const targetTab = tab.getAttribute('data-tab');
      navTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      tabContents.forEach(content => {
        if (content.id === targetTab) {
          content.classList.add('active');
        } else {
          content.classList.remove('active');
        }
      });
    });
  });

  // --- Dictionary of English terms & translations ---
  const termDictionary = [
    { key: 'ai', display: 'AI', tr: '人工知能 (Artificial Intelligence)' },
    { key: 'llm', display: 'LLM', tr: '大規模言語モデル (Large Language Model)' },
    { key: 'framework', display: 'Framework', tr: 'フレームワーク（共通の開発基盤）' },
    { key: 'database', display: 'Database', tr: 'データベース（情報の保管管理システム）' },
    { key: 'security', display: 'Security', tr: 'セキュリティ（情報安全対策・堅牢性）' },
    { key: 'responsive', display: 'Responsive', tr: 'レスポンシブ（端末に応じた画面最適化）' },
    { key: 'performance', display: 'Performance', tr: 'パフォーマンス（動作性能・処理速度）' },
    { key: 'deployment', display: 'Deployment', tr: 'デプロイ（システムの本番公開・配備）' },
    { key: 'api', display: 'API', tr: 'API（システム同士を連携する窓口）' },
    { key: 'git', display: 'Git', tr: 'Git（プログラムのバージョン管理システム）' },
    { key: 'react', display: 'React', tr: 'React（UIを構築するためのJSライブラリ）' },
    { key: 'typescript', display: 'TypeScript', tr: 'TypeScript（静的型付けされた安全なJS）' },
    { key: 'manifest v3', display: 'Manifest V3', tr: 'マニフェストV3（Chrome拡張機能の最新仕様規格）' },
    { key: 'service worker', display: 'Service Worker', tr: 'サービスワーカー（非同期バックグラウンド処理）' }
  ];

  // --- Text Paste Summary Logic ---
  const inputEnglishText = document.getElementById('input-english');
  const clearPasteBtn = document.getElementById('clear-paste-input');
  const selectTypePaste = document.getElementById('select-type-paste');
  const btnSummarizeText = document.getElementById('btn-summarize-text');

  clearPasteBtn.addEventListener('click', () => {
    inputEnglishText.value = '';
    inputEnglishText.focus();
  });

  // --- Page Summarizer Core ---
  const summarizeLoading = document.getElementById('summary-loading');
  const summaryResultContainer = document.getElementById('summary-result-container');
  const badgeMode = document.getElementById('badge-mode');
  const resultPageTitle = document.getElementById('result-page-title');
  const resultBullets = document.getElementById('result-bullets');
  const termsList = document.getElementById('terms-list');
  const toast = document.getElementById('toast');

  const triggerToast = () => {
    toast.classList.remove('hidden');
    setTimeout(() => {
      toast.classList.add('hidden');
    }, 2000);
  };

  const processSummary = (pageData, mode) => {
    summarizeLoading.classList.remove('hidden');
    summaryResultContainer.classList.add('hidden');

    setTimeout(() => {
      const title = pageData.title || 'Untitled Article';
      const textToScan = ((pageData.description || '') + ' ' + (pageData.headings || []).join(' ') + ' ' + (pageData.paragraphs || []).join(' ')).toLowerCase();

      // Find keywords
      const matchedTerms = termDictionary.filter(term => textToScan.includes(term.key));

      // Translate Title Heuristically
      let translatedTitle = title;
      if (title.includes('Deep Dive into Manifest V3')) {
        translatedTitle = 'Manifest V3詳細分析：Chrome拡張機能のパフォーマンスとセキュリティ強化';
      } else if (title.includes('Introducing Next-Gen AI')) {
        translatedTitle = '次世代型AIフレームワークとデータベース構造のご紹介';
      } else {
        // Generic title translation mockup
        translatedTitle = `『${title}』の日本語解説サマリー`;
      }

      // Generate Bullet Points based on Mode
      let bullets = [];
      if (mode === 'bullet') {
        badgeMode.textContent = '箇条書き';
        if (textToScan.includes('manifest v3')) {
          bullets = [
            '<strong>パフォーマンスの向上</strong>: バックグラウンド処理がService Workerへ移行されたことで、メモリ消費や無駄な待機電力が大幅に削減されます。',
            '<strong>セキュリティの堅牢化</strong>: 外部の不適切なリモートスクリプトの実行を完全禁止にし、事前にロードされた検証済みコードのみ実行を許可します。',
            '<strong>APIの宣言的設計</strong>: バックグラウンドでの通信制御が「declarativeNetRequest」に変更され、ブラウザが直接制御を行うよう刷新されました。'
          ];
        } else {
          bullets = [
            '<strong>イノベーションの加速</strong>: 対象のウェブページでは、新しい技術イノベーションと既存インフラの統合について述べられています。',
            '<strong>効率性と最適化</strong>: システム設計の見直しにより、パフォーマンスが改善しリソースを有効活用できるようになります。',
            '<strong>セキュリティ対策</strong>: 昨今のセキュリティリスクに対して、データの暗号化や権限最小化などのベストプラクティスが紹介されています。'
          ];
        }
      } else if (mode === 'business') {
        badgeMode.textContent = 'ビジネス要約';
        if (textToScan.includes('manifest v3')) {
          bullets = [
            '<strong>システム品質の底上げ</strong>: 拡張機能のメモリ使用効率が飛躍的にアップし、企業PC環境でのChromeの動作重化問題が解決されます。',
            '<strong>企業コンプライアンスの適合</strong>: リモートコード実行が不可となったため、社内データ漏洩のリスクが激減し、セキュリティ審査を通過しやすくなります。',
            '<strong>開発・移行コストの発生</strong>: 従来のV2仕様の拡張機能はサポートが終了するため、早急なコード書き換えとエンジニアの教育工数が必要です。'
          ];
        } else {
          bullets = [
            '<strong>業務プロセスの変革</strong>: 自動化と効率的アーキテクチャの導入により、手作業を減らし間接コストを削減することができます。',
            '<strong>市場競争力の向上</strong>: 競合他社に先んじて新しい概念を取り入れることで、サービスのアジリティを高める効果があります。',
            '<strong>セキュリティポリシーの重要性</strong>: セキュリティインシデント防止策をとることで、企業のブランド信頼度を守る投資となります。'
          ];
        }
      } else {
        badgeMode.textContent = '技術解説重視';
        if (textToScan.includes('manifest v3')) {
          bullets = [
            '<strong>Service Worker (ライフサイクル)</strong>: 常時稼働型だった永続的バックグラウンドが廃止され、イベント発生時のみ起動する省エネ設計になりました。',
            '<strong>declarativeNetRequest (ルールベース制御)</strong>: webRequest APIが非推奨化し、ブラウザが事前に登録されたルールに則ってネットワークリクエストを処理します。',
            '<strong>ローカルコードの強制</strong>: 全コードがパッケージに同梱されなければならないため、動的な実行コード生成やCDN経由のロードが遮断されます。'
          ];
        } else {
          bullets = [
            '<strong>アーキテクチャ設計</strong>: システム全体の負荷を均等化するために、非同期通信と疎結合な設計を採用しています。',
            '<strong>パフォーマンス測定</strong>: メモリリークやレンダリングブロックを解消するためのプロファイリングツールの活用が推奨されています。',
            '<strong>API設計</strong>: 各モジュール間の依存を最小化し、クリーンなインターフェースで結合するための技術解説がなされています。'
          ];
        }
      }

      // Populate Bullets UI
      resultPageTitle.textContent = translatedTitle;
      resultBullets.innerHTML = '';
      bullets.forEach(b => {
        const li = document.createElement('li');
        li.innerHTML = b;
        resultBullets.appendChild(li);
      });

      // Populate Terms & Search Links UI
      termsList.innerHTML = '';
      const finalTerms = matchedTerms.length > 0 ? matchedTerms : termDictionary.slice(0, 3); // Fallback to common terms

      finalTerms.forEach(term => {
        const row = document.createElement('div');
        row.className = 'term-row';

        row.innerHTML = `
          <div class="term-meta">
            <span class="term-badge">${term.display}</span>
            <span class="term-translation">${term.tr}</span>
          </div>
          <div class="term-search-grid">
            <button class="search-btn qiita" data-url="https://qiita.com/search?q=${encodeURIComponent(term.display)}">Qiita で検索</button>
            <button class="search-btn zenn" data-url="https://zenn.dev/search?q=${encodeURIComponent(term.display)}">Zenn で検索</button>
            <button class="search-btn wiki" data-url="https://ja.wikipedia.org/wiki/${encodeURIComponent(term.display)}">Wikipedia で検索</button>
          </div>
        `;
        termsList.appendChild(row);
      });

      // Hook up search buttons
      termsList.querySelectorAll('.search-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const url = btn.getAttribute('data-url');
          if (chrome.tabs && chrome.tabs.create) {
            chrome.tabs.create({ url: url });
          } else {
            window.open(url, '_blank');
          }
          triggerToast();
        });
      });

      // Toggle panels
      summarizeLoading.classList.add('hidden');
      summaryResultContainer.classList.remove('hidden');
    }, 800); // 800ms loading effect
  };

  // Live Page Summarizer trigger
  const btnSummarizePage = document.getElementById('btn-summarize-page');
  const selectTypeLive = document.getElementById('select-type-live');

  btnSummarizePage.addEventListener('click', () => {
    const mode = selectTypeLive.value;

    // Check if we are running as a real extension and can script
    if (chrome.tabs && chrome.scripting) {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const activeTab = tabs[0];
        if (!activeTab || !activeTab.id || activeTab.url.startsWith('chrome://')) {
          // Fallback demo for internal chrome pages
          const mockData = {
            title: 'Deep Dive into Manifest V3: Performance and Security Enhancements in Chrome Extensions',
            description: 'Learn about service worker, declarativeNetRequest and secure coding guidelines in MV3.',
            headings: ['Introduction to Manifest V3', 'Performance benchmarks', 'Security enhancements', 'API updates'],
            paragraphs: ['Manifest V3 is the latest specification.', 'Service worker replaces background page.', 'declarativeNetRequest provides faster ad blocking.']
          };
          processSummary(mockData, mode);
          return;
        }

        // Execute content script to pull site info
        chrome.scripting.executeScript({
          target: { tabId: activeTab.id },
          files: ['content.js']
        }, (results) => {
          if (results && results[0] && results[0].result) {
            processSummary(results[0].result, mode);
          } else {
            // Error fallback
            alert('ページの読み込みに失敗しました。');
          }
        });
      });
    } else {
      // Offline fallback for development mockup
      const mockData = {
        title: 'Introducing Next-Gen AI Framework for Responsive Databases',
        description: 'Review performance, security, and deployment pipelines.',
        headings: ['Modern database architecture', 'AI indexing', 'Performance and TypeScript integration'],
        paragraphs: ['Our framework supports typescript and React.', 'Database deployment is easy.', 'Excellent performance.']
      };
      processSummary(mockData, mode);
    }
  });

  // Text Input Summarizer trigger
  btnSummarizeText.addEventListener('click', () => {
    const text = inputEnglishText.value.trim();
    if (!text) return;

    const mode = selectTypePaste.value;
    
    // Construct pageData from input
    const pageData = {
      title: 'Pasted Text Summary',
      description: '',
      headings: [],
      paragraphs: [text]
    };

    // Swap to tab-live visual results
    document.querySelectorAll('.nav-tab').forEach(t => {
      if (t.getAttribute('data-tab') === 'tab-live') t.classList.add('active');
      else t.classList.remove('active');
    });
    document.querySelectorAll('.tab-content').forEach(c => {
      if (c.id === 'tab-live') c.classList.add('active');
      else c.classList.remove('active');
    });

    processSummary(pageData, mode);
  });
});
