



// popup.js - Japanese Traditional Color Picker Controller

// --- 1. Japanese Traditional Colors Database (60 historical colors) ---
const TRADITIONAL_COLORS = [
  // 赤・ピンク系 (Reds/Pinks)
  { name: "茜色", kana: "あかねいろ", hex: "#b7282e", desc: "アカネの根で染めた暗い赤色。万葉集でも夕日や朝日の形容に使われた最も古い伝統色の一つです。" },
  { name: "朱色", kana: "しゅいろ", hex: "#eb6100", desc: "天然の硫化水銀から作られる鮮やかな黄赤。魔除けの色として神社仏閣の鳥居などに塗られています。" },
  { name: "臙脂", kana: "えんじ", hex: "#9e2a2b", desc: "中国の燕国から伝わったコチニール等の染料による暗い赤。深く格調高い赤として衣服に好まれました。" },
  { name: "桜色", kana: "しくらいろ", hex: "#fef2f4", desc: "桜の花びらのような淡く優しいピンク色。平安時代から日本の春を象徴する高貴な色とされました。" },
  { name: "撫子色", kana: "なでしこいろ", hex: "#eebbcb", desc: "撫子の花にちなんだ少し紫がかったピンク。大和撫子（理想的な日本女性）の語源にもなった清楚な色です。" },
  { name: "珊瑚色", kana: "さんごいろ", hex: "#f5b1aa", desc: "赤珊瑚の骨格を粉末にしたような、イエローがかった明るいコーラルピンク。明治時代以降に定着しました。" },
  { name: "紅梅色", kana: "こうばいいろ", hex: "#e8a7a1", desc: "春先に先駆けて咲く紅梅の花びらのような色。少しくすんだ優しいピンクです。" },
  { name: "一斤染", kana: "いっきんぞめ", hex: "#f7c2bb", desc: "絹一斤に対し紅花一斤で染めた非常に淡いピンク。平安時代には庶民の使用が許された「聴し色（ゆるしいろ）」でした。" },
  
  // 黄・橙・茶系 (Yellows/Oranges/Browns)
  { name: "山吹色", kana: "やまぶきいろ", hex: "#ffa500", desc: "春に咲く山吹の花のような、赤みの強い黄金色。江戸時代には「小判（金貨）」の隠語としても使われました。" },
  { name: "黄金色", kana: "こがねいろ", hex: "#e6b422", desc: "稲穂が実った田園や、金属の金（ゴールド）を表す色彩。日本の豊かさと縁起の良さを象徴します。" },
  { name: "辛子色", kana: "からしいろ", hex: "#d0af4c", desc: "和からしをすりおろしたような、やや緑がかった渋い黄色。江戸時代の中期に流行しました。" },
  { name: "琥珀色", kana: "こはくいろ", hex: "#bf783a", desc: "天然樹脂の化石である「琥珀」のような、透明感のある温かい飴色。高級感漂うクラシックな色彩です。" },
  { name: "栗色", kana: "くりいろ", hex: "#762f07", desc: "栗の実の殻のような赤みがかった茶色。古くから髪の色や家具・木工の仕上げ色として親しまれました。" },
  { name: "煤竹色", kana: "すすたけいろ", hex: "#6f5436", desc: "長年囲炉裏の煤（すす）で燻された古い茅葺き屋根の竹の色。わびさびを感じる落ち着いた灰茶色です。" },
  { name: "朽葉色", kana: "くちばいろ", hex: "#917347", desc: "地面に落ちて枯れた落ち葉をイメージした渋い黄褐色。平安時代の貴族が衣服の重ね着に好みました。" },
  { name: "柿色", kana: "かきいろ", hex: "#ed6d3d", desc: "熟した柿の実のような、力強くも温かみのある赤橙色。歌舞伎の市川團十郎家の家色としても有名です。" },

  // 緑系 (Greens)
  { name: "萌黄色", kana: "もえぎいろ", hex: "#aacf53", desc: "春先に草木が芽吹く若葉のような、生命力あふれる鮮やかな黄緑色。平家物語の若武者が好んで着用した色です。" },
  { name: "鶯色", kana: "うぐいすいろ", hex: "#928c36", desc: "春を告げる鳥である「ウグイス」の羽のような、渋みのある暗い黄緑。江戸時代の洒落者に大変好まれました。" },
  { name: "若竹色", kana: "わかたけいろ", hex: "#76c494", desc: "すくすくと育つ若い竹の幹のような、さわやかで青みのある明るい緑。新鮮さや若々しさを演出します。" },
  { name: "常磐色", kana: "ときわいろ", hex: "#007b43", desc: "松や杉などの常緑樹の葉のように、年中変わらない深い緑。永久不変の長寿を祝う吉祥の色とされました。" },
  { name: "翡翠色", kana: "ひすいいろ", hex: "#38b48b", desc: "川を滑空する鳥「カワセミ（翡翠）」の羽や、宝石のヒスイのような透明感ある美しい青緑色です。" },
  { name: "抹茶色", kana: "まっちゃいろ", hex: "#c5c56a", desc: "茶道で用いる挽いた抹茶の粉末のような、渋く深みのある黄緑。落ち着いた和の和みを象徴する色です。" },
  { name: "山葵色", kana: "わさびいろ", hex: "#a8c97f", desc: "すりおろしたワサビの根のような、少し白みを帯びた淡い緑。ツンとした涼やかさを感じさせる色彩です。" },
  { name: "木賊色", kana: "とくさいろ", hex: "#3b5843", desc: "砥石代わりに物を磨くために使われた植物「トクサ」の幹のような、くすんだ深い常緑です。" },

  // 青系 (Blues)
  { name: "浅葱色", kana: "あさぎいろ", hex: "#00a3af", desc: "ネギの青い芽（ねぎま）のような、やや緑がかったさわやかな薄青。幕末には新選組の羽織の色として知られました。" },
  { name: "瑠璃色", kana: "るりいろ", hex: "#005caf", desc: "仏教の七宝の一つ、紺青の宝石「ラピスラズリ（瑠璃）」のような深く冴えた青。非常に高貴な色です。" },
  { name: "群青色", kana: "ぐんじょういろ", hex: "#4d5aaf", desc: "日本画でアズライト鉱石から作られる鮮やかで深いロイヤルブルー。「群れる青」という意味を持ちます。" },
  { name: "濃藍", kana: "こいあい", hex: "#0f2537", desc: "藍染めを幾度も重ねて染め上げた、非常に深い紺黒色。かつては勝色（かついろ）とも呼ばれ武士に愛されました。" },
  { name: "水色", kana: "みずいろ", hex: "#bce2e8", desc: "澄んだ水のように薄く透明感のある青。万葉集の時代から日本人に親しまれた清涼感ある色です。" },
  { name: "空色", kana: "そらいろ", hex: "#a0d8ef", desc: "晴天の澄み渡る昼の空のような青。明るく爽やかな広がりのある感情をもたらします。" },
  { name: "露草色", kana: "つゆくさいろ", hex: "#3da9fc", desc: "早朝に咲くツユクサの花弁から搾り取ったような、鮮やかでみずみずしい明るい青です。" },
  { name: "千歳緑", kana: "ちとせみどり", hex: "#314f3f", desc: "千年の長寿を願う「千歳」の名を冠した、松の葉のような極めて深く力強いオリーブ系の深緑です。" },

  // 紫系 (Purples)
  { name: "古代紫", kana: "こだいむらさき", hex: "#895b8a", desc: "紫草の根で染めた、少し赤みを帯びた古典的な深紫。冠位十二階でも最高位に置かれた高貴極まりない色です。" },
  { name: "藤色", kana: "ふじいろ", hex: "#bbbcde", desc: "春にしなやかに垂れ下がる藤の花のような淡い青紫。平安貴族の憧れの色として文学にも度々登場します。" },
  { name: "桔梗色", kana: "ききょういろ", hex: "#5654a2", desc: "秋の七草であるキキョウの花のような、青みが強いしっかりとした紫。凛とした涼しい気品があります。" },
  { name: "江戸紫", kana: "えどむらさき", hex: "#745399", desc: "江戸発祥の染料で染めた、青みの強い紫。歌舞伎の『助六』の鉢巻色として有名になり流行しました。" },
  { name: "京紫", kana: "きょうむらさき", hex: "#9d5b8b", desc: "江戸紫に対抗し、伝統的な京都で好まれた赤みがかった紫。おしろいに映える華やかな色です。" },
  { name: "鳩羽紫", kana: "はとばむらさき", hex: "#7a6f7e", desc: "鳩の羽に見られるような、灰色がかったくすんだ紫色。落ち着いた大人の渋みのあるパープルです。" },

  // 無彩色・中間色系 (Greys/Whites)
  { name: "鼠色", kana: "ねずみいろ", hex: "#949495", desc: "江戸時代に大流行したグレーの総称。当時は庶民の贅沢が制限され「四十八茶百鼠」と呼ばれる無数のグレーが生まれました。" },
  { name: "墨色", kana: "すみいろ", hex: "#2e2e30", desc: "書道で使う墨汁（スミ）の、少し黒みがかった深いグレー。純粋な黒とは異なり、吸い込まれるような温かみがあります。" },
  { name: "胡粉色", kana: "ごふんいろ", hex: "#ffffff", desc: "ホタテやカキの貝殻を風化させて作る白色絵の具に由来。純白よりも少し温かみと奥深さのあるマットな白です。" },
  { name: "生成色", kana: "きなりいろ", hex: "#fbfaf5", desc: "漂白する前の麻や綿の天然素材そのままの白。わずかに黄みがかっており、日本の無垢な美を表します。" },
  { name: "白木", kana: "しらき", hex: "#f4f1ea", desc: "伐採したてのヒノキやスギ等の樹木の内側のような、かすかに黄みを含む非常に明るいベージュ調です。" },
  { name: "消炭色", kana: "けしずみいろ", hex: "#434343", desc: "薪が燃えて炭になる手前の、水分を含まないサラサラした暗いグレー。静寂や沈黙のテーマによく似合います。" }
];

// Helper to pre-populate RGB numbers for quick calculations
TRADITIONAL_COLORS.forEach(color => {
  color.rgb = hexToRgb(color.hex);
});

// --- 2. Color Conversion Helpers ---
function hexToRgb(hex) {
  const h = hex.replace("#", "");
  const r = parseInt(h.substring(0, 2), 16);
  const g = parseInt(h.substring(2, 4), 16);
  const b = parseInt(h.substring(4, 6), 16);
  return [r, g, b];
}

// Euclidean Distance matching formula
function getClosestTraditionalColor(r, g, b) {
  let closest = null;
  let minDistance = Infinity;

  TRADITIONAL_COLORS.forEach(color => {
    const dist = Math.sqrt(
      Math.pow(r - color.rgb[0], 2) +
      Math.pow(g - color.rgb[1], 2) +
      Math.pow(b - color.rgb[2], 2)
    );

    if (dist < minDistance) {
      minDistance = dist;
      closest = color;
    }
  });

  return closest;
}

// --- 3. UI Controller Logic ---
document.addEventListener("DOMContentLoaded", () => {
  // Elements
  const btnPick = document.getElementById("btn-pick");
  const windowColor = document.getElementById("window-color");
  const colorNameJp = document.getElementById("color-name-jp");
  const colorNameKana = document.getElementById("color-name-kana");
  const valHex = document.getElementById("val-hex");
  const valRgb = document.getElementById("val-rgb");
  const colorDesc = document.getElementById("color-desc");
  const btnSaveColor = document.getElementById("btn-save-color");
  const paletteGrid = document.getElementById("palette-grid");
  const toast = document.getElementById("toast");

  const rowHex = document.getElementById("row-hex");
  const rowRgb = document.getElementById("row-rgb");

  // State
  let currentPickedHex = null;
  let currentMatchedColor = null;
  let savedPalette = [];

  // Show copy notification toast
  function showToast(message) {
    toast.textContent = message;
    toast.classList.add("show");
    setTimeout(() => {
      toast.classList.remove("show");
    }, 1500);
  }

  // Load Palette from chrome.storage
  function loadPalette() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.get(["colorPalette"], (result) => {
        savedPalette = result.colorPalette || [];
        renderPalette();
      });
    } else {
      renderPalette();
    }
  }

  // Save Palette to chrome.storage
  function savePalette() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.set({ colorPalette: savedPalette }, () => {
        renderPalette();
      });
    } else {
      renderPalette();
    }
  }

  // Render Palette Grid slots
  function renderPalette() {
    paletteGrid.innerHTML = "";

    // Fill up to 8 slots
    for (let i = 0; i < 8; i++) {
      const slot = document.createElement("div");
      slot.className = "palette-slot";

      if (savedPalette[i]) {
        const item = savedPalette[i];
        slot.style.backgroundColor = item.hex;
        slot.title = `${item.name} (${item.hex})`;

        // Delete button inside slot
        const removeBtn = document.createElement("span");
        removeBtn.className = "slot-remove";
        removeBtn.textContent = "×";
        removeBtn.addEventListener("click", (e) => {
          e.stopPropagation(); // prevent select action
          savedPalette.splice(i, 1);
          savePalette();
        });

        slot.appendChild(removeBtn);

        // Click slot to re-select color
        slot.addEventListener("click", () => {
          const rgb = hexToRgb(item.hex);
          selectColor(item.hex, rgb[0], rgb[1], rgb[2]);
        });
      } else {
        // Empty slot spacer
        slot.style.backgroundColor = "transparent";
        slot.style.border = "1.5px dashed rgba(223, 194, 153, 0.25)";
        slot.style.cursor = "default";
        slot.title = "未登録";
      }

      paletteGrid.appendChild(slot);
    }
  }

  // Set the selected color and match it
  function selectColor(hex, r, g, b) {
    currentPickedHex = hex;
    const matched = getClosestTraditionalColor(r, g, b);
    currentMatchedColor = matched;

    // Remove empty symbol
    const emptySym = windowColor.querySelector(".empty-symbol");
    if (emptySym) emptySym.remove();

    // 1. Update Preview round window color
    windowColor.style.backgroundColor = hex;

    // 2. Set details panel data
    colorNameJp.textContent = matched.name;
    colorNameKana.textContent = matched.kana;
    valHex.textContent = hex.toUpperCase();
    valRgb.textContent = `rgb(${r}, ${g}, ${b})`;
    colorDesc.textContent = matched.desc;

    // 3. Show save button
    btnSaveColor.classList.remove("hidden");
  }

  // --- Click Actions ---

  // Pick color button
  btnPick.addEventListener("click", () => {
    if (window.EyeDropper) {
      const eyeDropper = new EyeDropper();
      eyeDropper.open().then((result) => {
        const hex = result.sRGBHex;
        const rgb = hexToRgb(hex);
        selectColor(hex, rgb[0], rgb[1], rgb[2]);
      }).catch((err) => {
        console.log("Eyedropper closed or failed: ", err);
      });
    } else {
      // Fallback for browsers without EyeDropper (alert/mock fallback)
      alert("お使いのブラウザはEyeDropper APIに対応していません。デモ環境のテストパレットをご利用ください。");
    }
  });

  // Copy HEX action
  rowHex.addEventListener("click", () => {
    if (!currentPickedHex) return;
    navigator.clipboard.writeText(valHex.textContent).then(() => {
      showToast("HEXコードをコピーしました");
    });
  });

  // Copy RGB action
  rowRgb.addEventListener("click", () => {
    if (!currentPickedHex) return;
    navigator.clipboard.writeText(valRgb.textContent).then(() => {
      showToast("RGBコードをコピーしました");
    });
  });

  // Save color to favorite list
  btnSaveColor.addEventListener("click", () => {
    if (!currentPickedHex || !currentMatchedColor) return;

    // Check duplication
    const duplicated = savedPalette.some(item => item.hex.toLowerCase() === currentPickedHex.toLowerCase());
    if (duplicated) {
      showToast("既に登録されています");
      return;
    }

    // Insert to top (LIFO), limit to 8 colors
    savedPalette.unshift({
      name: currentMatchedColor.name,
      hex: currentPickedHex.toUpperCase()
    });

    if (savedPalette.length > 8) {
      savedPalette.pop();
    }

    savePalette();
    showToast("パレットに保存しました");
  });

  // Boot
  loadPalette();

  // Expose for sandbox simulator
  window.__selectColor = selectColor;

  // Keyboard shortcut listener to easily trigger picking mode again
  document.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " " || e.key.toLowerCase() === "s" || e.key.toLowerCase() === "p") {
      if (e.key === " ") e.preventDefault(); // Prevent page scroll
      btnPick.click();
    }
  });

  // Focus the color pick button initially
  btnPick.focus();
});
