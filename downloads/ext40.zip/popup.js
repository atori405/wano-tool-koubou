
// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  function openFallbackWindow() {
    // Fail-safe: open popup.html as a draggable Chrome popup window. No tab
    // id needs to be threaded through here — this extension never queries
    // chrome.tabs (EyeDropper works on the whole screen regardless of which
    // tab is active), so there's no "wrong tab" risk in this fallback.
    var w = Math.min(screen.availWidth, 380);
    var h = Math.min(screen.availHeight, 560);
    var left = Math.round((screen.availWidth - w) / 2);
    var top = Math.round((screen.availHeight - h) / 4);
    chrome.windows.create({
      url: chrome.runtime.getURL("popup.html?mode=window"),
      type: "popup",
      width: w,
      height: h,
      left: left,
      top: top,
      focused: true
    });
  }

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        var tabId = tabs[0].id;
        chrome.tabs.sendMessage(tabId, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Content script is likely stale/missing on this tab (e.g. it was
            // already open before the extension was installed/updated).
            // Re-inject and retry once before falling back to a separate
            // OS window (which can vanish and never reappear).
            if (chrome.scripting) {
              chrome.scripting.executeScript({
                target: { tabId: tabId },
                files: ["content.js"]
              }, function() {
                if (chrome.runtime.lastError) {
                  openFallbackWindow();
                  window.close();
                  return;
                }
                chrome.tabs.sendMessage(tabId, { action: "toggleFloatingPanel" }, function(response2) {
                  if (chrome.runtime.lastError || !response2 || response2.status !== "toggled") {
                    openFallbackWindow();
                  }
                  window.close();
                });
              });
              return;
            }
            openFallbackWindow();
          }
          window.close();
        });
      } else {
        openFallbackWindow();
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// popup.js - Japanese Traditional Color Picker Controller

// --- 1. Japanese Traditional Colors Database (465 historical colors) ---
// Names, readings, and hex values are taken directly from 和色大辞典
// (colordic.org, a Japanese traditional-color dictionary site citing the
// book「美しい日本の伝統色」), fetched and parsed on 2026-09-06 — all 465
// colors listed there. 44 of them carry a hand-written cultural/historical
// description; the rest show a generic note naming the source instead of an
// invented backstory, since no such description exists for them there.
const TRADITIONAL_COLORS = [
  { name: "桜色", kana: "さくらいろ", hex: "#fef4f4", desc: "桜の花びらのような淡く優しいピンク色。平安時代から日本の春を象徴する高貴な色とされました。" },
  { name: "小豆色", kana: "あずきいろ", hex: "#96514d", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "黄金", kana: "こがね", hex: "#e6b422", desc: "稲穂が実った田園や、金属の金（ゴールド）を表す色彩。日本の豊かさと縁起の良さを象徴します。" },
  { name: "萌葱色", kana: "もえぎいろ", hex: "#006e54", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "古代紫", kana: "こだいむらさき", hex: "#895b8a", desc: "紫草の根で染めた、少し赤みを帯びた古典的な深紫。冠位十二階でも最高位に置かれた高貴極まりない色です。" },
  { name: "薄桜", kana: "うすざくら", hex: "#fdeff2", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "枯茶", kana: "からちゃ", hex: "#8d6449", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "櫨染", kana: "はじぞめ", hex: "#d9a62e", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "花緑青", kana: "はなろくしょう", hex: "#00a381", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "茄子紺", kana: "なすこん", hex: "#824880", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "桜鼠", kana: "さくらねず", hex: "#e9dfe5", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "飴色", kana: "あめいろ", hex: "#deb068", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "黄朽葉色", kana: "きくちばいろ", hex: "#d3a243", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "翡翠色", kana: "ひすいいろ", hex: "#38b48b", desc: "川を滑空する鳥「カワセミ（翡翠）」の羽や、宝石のヒスイのような透明感ある美しい青緑色です。" },
  { name: "二藍", kana: "ふたあい", hex: "#915c8b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "鴇鼠", kana: "ときねず", hex: "#e4d2d8", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "駱駝色", kana: "らくだいろ", hex: "#bf794e", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "山吹茶", kana: "やまぶきちゃ", hex: "#c89932", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "青緑", kana: "あおみどり", hex: "#00a497", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "京紫", kana: "きょうむらさき", hex: "#9d5b8b", desc: "江戸紫に対抗し、伝統的な京都で好まれた赤みがかった紫。おしろいに映える華やかな色です。" },
  { name: "虹色", kana: "にじいろ", hex: "#f6bfbc", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "土色", kana: "つちいろ", hex: "#bc763c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "芥子色", kana: "からしいろ", hex: "#d0af4c", desc: "和からしをすりおろしたような、やや緑がかった渋い黄色。江戸時代の中期に流行しました。" },
  { name: "水浅葱", kana: "みずあさぎ", hex: "#80aba9", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "蒲葡", kana: "えびぞめ", hex: "#7a4171", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "珊瑚色", kana: "さんごいろ", hex: "#f5b1aa", desc: "赤珊瑚の骨格を粉末にしたような、イエローがかった明るいコーラルピンク。明治時代以降に定着しました。" },
  { name: "黄唐茶", kana: "きがらちゃ", hex: "#b98c46", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "豆がら茶", kana: "まめがらちゃ", hex: "#8b968d", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "錆浅葱", kana: "さびあさぎ", hex: "#5c9291", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "若紫", kana: "わかむらさき", hex: "#bc64a4", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "一斤染", kana: "いっこんぞめ", hex: "#f5b199", desc: "絹一斤に対し紅花一斤で染めた非常に淡いピンク。平安時代には庶民の使用が許された「聴し色（ゆるしいろ）」でした。" },
  { name: "桑染", kana: "くわぞめ", hex: "#b79b5b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "麹塵", kana: "きくじん", hex: "#6e7955", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "青碧", kana: "せいへき", hex: "#478384", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紅紫", kana: "べにむらさき", hex: "#b44c97", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "宍色", kana: "ししいろ", hex: "#efab93", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "櫨色", kana: "はじいろ", hex: "#b77b57", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "山鳩色", kana: "やまばといろ", hex: "#767c6b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "御召茶", kana: "おめしちゃ", hex: "#43676b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "梅紫", kana: "うめむらさき", hex: "#aa4c8f", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紅梅色", kana: "こうばいいろ", hex: "#f2a0a1", desc: "春先に先駆けて咲く紅梅の花びらのような色。少しくすんだ優しいピンクです。" },
  { name: "黄橡", kana: "きつるばみ", hex: "#b68d4c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "利休鼠", kana: "りきゅうねずみ", hex: "#888e7e", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "湊鼠", kana: "みなとねずみ", hex: "#80989b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "菖蒲色", kana: "あやめいろ", hex: "#cc7eb1", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "薄紅", kana: "うすべに", hex: "#f0908d", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "丁字染", kana: "ちょうじぞめ", hex: "#ad7d4c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "海松茶", kana: "みるちゃ", hex: "#5a544b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "高麗納戸", kana: "こうらいなんど", hex: "#2c4f54", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紅藤色", kana: "べにふじいろ", hex: "#cca6bf", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "甚三紅", kana: "じんざもみ", hex: "#ee827c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "香染", kana: "こうぞめ", hex: "#ad7d4c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "藍海松茶", kana: "あいみるちゃ", hex: "#56564b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "百入茶", kana: "ももしおちゃ", hex: "#1f3134", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "浅紫", kana: "あさむらさき", hex: "#c4a3bf", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "桃色", kana: "ももいろ", hex: "#f09199", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "枇杷茶", kana: "びわちゃ", hex: "#ae7c4f", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "藍媚茶", kana: "あいこびちゃ", hex: "#555647", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "錆鼠", kana: "さびねず", hex: "#47585c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紫水晶", kana: "むらさきすいしょう", hex: "#e7e7eb", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "鴇色", kana: "ときいろ", hex: "#f4b3c2", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "芝翫茶", kana: "しかんちゃ", hex: "#ad7e4e", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "千歳茶", kana: "せんさいちゃ", hex: "#494a41", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "錆鉄御納戸", kana: "さびてつおなんど", hex: "#485859", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "薄梅鼠", kana: "うすうめねず", hex: "#dcd6d9", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "撫子色", kana: "なでしこいろ", hex: "#eebbcb", desc: "撫子の花にちなんだ少し紫がかったピンク。大和撫子（理想的な日本女性）の語源にもなった清楚な色です。" },
  { name: "焦香", kana: "こがれこう", hex: "#ae7c58", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "岩井茶", kana: "いわいちゃ", hex: "#6b6f59", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "藍鼠", kana: "あいねず", hex: "#6c848d", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "暁鼠", kana: "あかつきねず", hex: "#d3cfd9", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "灰梅", kana: "はいうめ", hex: "#e8d3c7", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "胡桃色", kana: "くるみいろ", hex: "#a86f4c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "仙斎茶", kana: "せんさいちゃ", hex: "#474b42", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "錆御納戸", kana: "さびおなんど", hex: "#53727d", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "牡丹鼠", kana: "ぼたんねず", hex: "#d3ccd6", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "灰桜", kana: "はいざくら", hex: "#e8d3d1", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "渋紙色", kana: "しぶかみいろ", hex: "#946243", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "黒緑", kana: "くろみどり", hex: "#333631", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "舛花色", kana: "ますはないろ", hex: "#5b7e91", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "霞色", kana: "かすみいろ", hex: "#c8c2c6", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "淡紅藤", kana: "あわべにふじ", hex: "#e6cde3", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "朽葉色", kana: "くちばいろ", hex: "#917347", desc: "地面に落ちて枯れた落ち葉をイメージした渋い黄褐色。平安時代の貴族が衣服の重ね着に好みました。" },
  { name: "柳煤竹", kana: "やなぎすすたけ", hex: "#5b6356", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "熨斗目花色", kana: "のしめはないろ", hex: "#426579", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "藤鼠", kana: "ふじねず", hex: "#a6a5c4", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "石竹色", kana: "せきちくいろ", hex: "#e5abbe", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "桑茶", kana: "くわちゃ", hex: "#956f29", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "樺茶色", kana: "かばちゃいろ", hex: "#726250", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "御召御納戸", kana: "おめしおなんど", hex: "#4c6473", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "半色", kana: "はしたいろ", hex: "#a69abd", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "薄紅梅", kana: "うすこうばい", hex: "#e597b2", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "路考茶", kana: "ろこうちゃ", hex: "#8c7042", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "空五倍子色", kana: "うつぶしいろ", hex: "#9d896c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "鉄御納戸", kana: "てつおなんど", hex: "#455765", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "薄色", kana: "うすいろ", hex: "#a89dac", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "桃花色", kana: "ももはないろ", hex: "#e198b4", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "国防色", kana: "こくぼうしょく", hex: "#7b6c3e", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "生壁色", kana: "なまかべいろ", hex: "#94846a", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紺鼠", kana: "こんねず", hex: "#44617b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "薄鼠", kana: "うすねず", hex: "#9790a4", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "水柿", kana: "みずがき", hex: "#e4ab9b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "伽羅色", kana: "きゃらいろ", hex: "#d8a373", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "肥後煤竹", kana: "ひごすすたけ", hex: "#897858", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "藍鉄", kana: "あいてつ", hex: "#393f4c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "鳩羽鼠", kana: "はとばねずみ", hex: "#9e8b8e", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "ときがら茶", kana: "ときがらちゃ", hex: "#e09e87", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "江戸茶", kana: "えどちゃ", hex: "#cd8c5c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "媚茶", kana: "こびちゃ", hex: "#716246", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "青褐", kana: "あおかち", hex: "#393e4f", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "鳩羽色", kana: "はとばいろ", hex: "#95859c", desc: "鳩の羽に見られるような、灰色がかったくすんだ紫色。落ち着いた大人の渋みのあるパープルです。" },
  { name: "退紅", kana: "あらぞめ", hex: "#d69090", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "樺色", kana: "かばいろ", hex: "#cd5e3c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "白橡", kana: "しろつるばみ", hex: "#cbb994", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "褐返", kana: "かちかえし", hex: "#203744", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "桔梗鼠", kana: "ききょうねず", hex: "#95949a", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "薄柿", kana: "うすがき", hex: "#d4acad", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紅鬱金", kana: "べにうこん", hex: "#cb8347", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "亜麻色", kana: "あまいろ", hex: "#d6c6af", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "褐色", kana: "かちいろ", hex: "#4d4c61", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紫鼠", kana: "むらさきねず", hex: "#71686c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "長春色", kana: "ちょうしゅんいろ", hex: "#c97586", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "土器色", kana: "かわらけいろ", hex: "#c37854", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "榛色", kana: "はしばみいろ", hex: "#bfa46f", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "月白", kana: "げっぱく", hex: "#eaf4fc", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "葡萄鼠", kana: "ぶどうねずみ", hex: "#705b67", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "梅鼠", kana: "うめねず", hex: "#c099a0", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "狐色", kana: "きつねいろ", hex: "#c38743", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "灰汁色", kana: "あくいろ", hex: "#9e9478", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "白菫色", kana: "しろすみれいろ", hex: "#eaedf7", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "濃色", kana: "こきいろ", hex: "#634950", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "鴇浅葱", kana: "ときあさぎ", hex: "#b88884", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "黄土色", kana: "おうどいろ", hex: "#c39143", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "利休茶", kana: "りきゅうちゃ", hex: "#a59564", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "白花色", kana: "しらはないろ", hex: "#e8ecef", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紫鳶", kana: "むらさきとび", hex: "#5f414b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "梅染", kana: "うめぞめ", hex: "#b48a76", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "琥珀色", kana: "こはくいろ", hex: "#bf783a", desc: "天然樹脂の化石である「琥珀」のような、透明感のある温かい飴色。高級感漂うクラシックな色彩です。" },
  { name: "鶯茶", kana: "うぐいすちゃ", hex: "#715c1f", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "藍白", kana: "あいじろ", hex: "#ebf6f7", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "濃鼠", kana: "こいねず", hex: "#4f455c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "蘇芳香", kana: "すおうこう", hex: "#a86965", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "赤茶", kana: "あかちゃ", hex: "#bb5535", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "木蘭色", kana: "もくらんじき", hex: "#c7b370", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "白藍", kana: "しらあい", hex: "#c1e4e9", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "藤煤竹", kana: "ふじすすたけ", hex: "#5a5359", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "浅蘇芳", kana: "あさすおう", hex: "#a25768", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "代赭", kana: "たいしゃ", hex: "#bb5520", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "砂色", kana: "すないろ", hex: "#dcd3b2", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "水色", kana: "みずいろ", hex: "#bce2e8", desc: "澄んだ水のように薄く透明感のある青。万葉集の時代から日本人に親しまれた清涼感ある色です。" },
  { name: "滅紫", kana: "けしむらさき", hex: "#594255", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "真朱", kana: "まそお", hex: "#ec6d71", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "煉瓦色", kana: "れんがいろ", hex: "#b55233", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "油色", kana: "あぶらいろ", hex: "#a19361", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "瓶覗", kana: "かめのぞき", hex: "#a2d7dd", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紅消鼠", kana: "べにけしねずみ", hex: "#524748", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "赤紫", kana: "あかむらさき", hex: "#eb6ea5", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "雀茶", kana: "すずめちゃ", hex: "#aa4f37", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "利休色", kana: "りきゅういろ", hex: "#8f8667", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "秘色色", kana: "ひそくいろ", hex: "#abced8", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "似せ紫", kana: "にせむらさき", hex: "#513743", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "躑躅色", kana: "つつじいろ", hex: "#e95295", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "団十郎茶", kana: "だんじゅうろうちゃ", hex: "#9f563a", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "梅幸茶", kana: "ばいこうちゃ", hex: "#887938", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "空色", kana: "そらいろ", hex: "#a0d8ef", desc: "晴天の澄み渡る昼の空のような青。明るく爽やかな広がりのある感情をもたらします。" },
  { name: "灰黄緑", kana: "はいきみどり", hex: "#e6eae3", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "牡丹色", kana: "ぼたんいろ", hex: "#e7609e", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "柿渋色", kana: "かきしぶいろ", hex: "#9f563a", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "璃寛茶", kana: "りかんちゃ", hex: "#6a5d21", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "勿忘草色", kana: "わすれなぐさいろ", hex: "#89c3eb", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "蕎麦切色", kana: "そばきりいろ", hex: "#d4dcd6", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "今様色", kana: "いまよういろ", hex: "#d0576b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紅鳶", kana: "べにとび", hex: "#9a493f", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "黄海松茶", kana: "きみるちゃ", hex: "#918754", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "青藤色", kana: "あおふじいろ", hex: "#84a2d4", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "薄雲鼠", kana: "うすくもねず", hex: "#d4dcda", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "中紅", kana: "なかべに", hex: "#c85179", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "灰茶", kana: "はいちゃ", hex: "#98623c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "菜種油色", kana: "なたねゆいろ", hex: "#a69425", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "白群", kana: "びゃくぐん", hex: "#83ccd2", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "枯野色", kana: "かれのいろ", hex: "#d3cbc6", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "薔薇色", kana: "ばらいろ", hex: "#e9546b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "茶色", kana: "ちゃいろ", hex: "#965042", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "青朽葉", kana: "あおくちば", hex: "#ada250", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "浅縹", kana: "あさはなだ", hex: "#84b9cb", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "潤色", kana: "うるみいろ", hex: "#c8c2be", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "韓紅", kana: "からくれない", hex: "#e95464", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "檜皮色", kana: "ひわだいろ", hex: "#965036", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "根岸色", kana: "ねぎしいろ", hex: "#938b4b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "薄花色", kana: "うすはないろ", hex: "#698aab", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "利休白茶", kana: "りきゅうしろちゃ", hex: "#b3ada0", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "銀朱", kana: "ぎんしゅ", hex: "#c85554", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "鳶色", kana: "とびいろ", hex: "#95483f", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "鶸茶", kana: "ひわちゃ", hex: "#8c8861", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "納戸色", kana: "なんどいろ", hex: "#008899", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "茶鼠", kana: "ちゃねずみ", hex: "#a99e93", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "赤紅", kana: "あかべに", hex: "#c53d43", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "柿茶", kana: "かきちゃ", hex: "#954e2a", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "柳茶", kana: "やなぎちゃ", hex: "#a1a46d", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "浅葱色", kana: "あさぎいろ", hex: "#00a3af", desc: "ネギの青い芽（ねぎま）のような、やや緑がかったさわやかな薄青。幕末には新選組の羽織の色として知られました。" },
  { name: "胡桃染", kana: "くるみぞめ", hex: "#a58f86", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紅緋", kana: "べにひ", hex: "#e83929", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "弁柄色", kana: "べんがらいろ", hex: "#8f2e14", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "海松色", kana: "みるいろ", hex: "#726d40", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "花浅葱", kana: "はなあさぎ", hex: "#2a83a2", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "江戸鼠", kana: "えどねず", hex: "#928178", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "赤", kana: "あか", hex: "#e60033", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "赤錆色", kana: "あかさびいろ", hex: "#8a3319", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "鶯色", kana: "うぐいすいろ", hex: "#928c36", desc: "春を告げる鳥である「ウグイス」の羽のような、渋みのある暗い黄緑。江戸時代の洒落者に大変好まれました。" },
  { name: "新橋色", kana: "しんばしいろ", hex: "#59b9c6", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "煤色", kana: "すすいろ", hex: "#887f7a", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "猩々緋", kana: "しょうじょうひ", hex: "#e2041b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "褐色", kana: "かっしょく", hex: "#8a3b00", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "緑黄色", kana: "りょくおうしょく", hex: "#dccb18", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "天色", kana: "あまいろ", hex: "#2ca9e1", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "丁子茶", kana: "ちょうじちゃ", hex: "#b4866b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紅", kana: "くれない", hex: "#d7003a", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "栗梅", kana: "くりうめ", hex: "#852e19", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "鶸色", kana: "ひわいろ", hex: "#d7cf3a", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "露草色", kana: "つゆくさいろ", hex: "#38a1db", desc: "早朝に咲くツユクサの花弁から搾り取ったような、鮮やかでみずみずしい明るい青です。" },
  { name: "柴染", kana: "ふしぞめ", hex: "#b28c6e", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "深緋", kana: "こきひ", hex: "#c9171e", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紅檜皮", kana: "べにひはだ", hex: "#7b4741", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "抹茶色", kana: "まっちゃいろ", hex: "#c5c56a", desc: "茶道で用いる挽いた抹茶の粉末のような、渋く深みのある黄緑。落ち着いた和の和みを象徴する色です。" },
  { name: "青", kana: "あお", hex: "#0095d9", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "宗伝唐茶", kana: "そうでんからちゃ", hex: "#a16d5d", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "緋色", kana: "ひいろ", hex: "#d3381c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "海老茶", kana: "えびちゃ", hex: "#773c30", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "若草色", kana: "わかくさいろ", hex: "#c3d825", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "薄藍", kana: "うすあい", hex: "#0094c8", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "砺茶", kana: "とのちゃ", hex: "#9f6f55", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "赤丹", kana: "あかに", hex: "#ce5242", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "唐茶", kana: "からちゃ", hex: "#783c1d", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "黄緑", kana: "きみどり", hex: "#b8d200", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "縹色", kana: "はなだいろ", hex: "#2792c3", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "煎茶色", kana: "せんちゃいろ", hex: "#8c6450", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紅赤", kana: "べにあか", hex: "#d9333f", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "栗色", kana: "くりいろ", hex: "#762f07", desc: "栗の実の殻のような赤みがかった茶色。古くから髪の色や家具・木工の仕上げ色として親しまれました。" },
  { name: "若芽色", kana: "わかめいろ", hex: "#e0ebaf", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紺碧", kana: "こんぺき", hex: "#007bbb", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "銀煤竹", kana: "ぎんすすだけ", hex: "#856859", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "臙脂", kana: "えんじ", hex: "#b94047", desc: "中国の燕国から伝わったコチニール等の染料による暗い赤。深く格調高い赤として衣服に好まれました。" },
  { name: "赤銅色", kana: "しゃくどういろ", hex: "#752100", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "若菜色", kana: "わかないろ", hex: "#d8e698", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "薄群青", kana: "うすぐんじょう", hex: "#5383c3", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "黄枯茶", kana: "きがらちゃ", hex: "#765c47", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "朱・緋", kana: "あけ", hex: "#ba2636", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "錆色", kana: "さびいろ", hex: "#6c3524", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "若苗色", kana: "わかなえいろ", hex: "#c7dc68", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "薄花桜", kana: "うすはなざくら", hex: "#5a79ba", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "煤竹色", kana: "すすたけいろ", hex: "#6f514c", desc: "長年囲炉裏の煤（すす）で燻された古い茅葺き屋根の竹の色。わびさびを感じる落ち着いた灰茶色です。" },
  { name: "茜色", kana: "あかねいろ", hex: "#b7282e", desc: "アカネの根で染めた暗い赤色。万葉集でも夕日や朝日の形容に使われた最も古い伝統色の一つです。" },
  { name: "赤褐色", kana: "せっかっしょく", hex: "#683f36", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "青丹", kana: "あおに", hex: "#99ab4e", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "群青色", kana: "ぐんじょういろ", hex: "#4c6cb3", desc: "日本画でアズライト鉱石から作られる鮮やかで深いロイヤルブルー。「群れる青」という意味を持ちます。" },
  { name: "焦茶", kana: "こげちゃ", hex: "#6f4b3e", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紅海老茶", kana: "べにえびちゃ", hex: "#a73836", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "茶褐色", kana: "ちゃかっしょく", hex: "#664032", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "草色", kana: "くさいろ", hex: "#7b8d42", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "杜若色", kana: "かきつばたいろ", hex: "#3e62ad", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "黒橡", kana: "くろつるばみ", hex: "#544a47", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "蘇芳", kana: "すおう", hex: "#9e3d3f", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "栗皮茶", kana: "くりかわちゃ", hex: "#6d3c32", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "苔色", kana: "こけいろ", hex: "#69821b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "瑠璃色", kana: "るりいろ", hex: "#1e50a2", desc: "仏教の七宝の一つ、紺青の宝石「ラピスラズリ（瑠璃）」のような深く冴えた青。非常に高貴な色です。" },
  { name: "憲法色", kana: "けんぽういろ", hex: "#543f32", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "真紅", kana: "しんく", hex: "#a22041", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "黒茶", kana: "くろちゃ", hex: "#583822", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "萌黄", kana: "もえぎ", hex: "#aacf53", desc: "春先に草木が芽吹く若葉のような、生命力あふれる鮮やかな黄緑色。平家物語の若武者が好んで着用した色です。" },
  { name: "薄縹", kana: "うすはなだ", hex: "#507ea4", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "涅色", kana: "くりいろ", hex: "#554738", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "濃紅", kana: "こいくれない", hex: "#a22041", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "葡萄茶", kana: "えびちゃ", hex: "#6c2c2f", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "苗色", kana: "なえいろ", hex: "#b0ca71", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "瑠璃紺", kana: "るりこん", hex: "#19448e", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "檳榔子染", kana: "びんろうじぞめ", hex: "#433d3c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "象牙色", kana: "ぞうげいろ", hex: "#f8f5e3", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "葡萄色", kana: "えびいろ", hex: "#640125", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "若葉色", kana: "わかばいろ", hex: "#b9d08b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紺瑠璃", kana: "こんるり", hex: "#164a84", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "黒鳶", kana: "くろとび", hex: "#432f2f", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "練色", kana: "ねりいろ", hex: "#ede4cd", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "萱草色", kana: "かんぞういろ", hex: "#f8b862", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "松葉色", kana: "まつばいろ", hex: "#839b5c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "藍色", kana: "あいいろ", hex: "#165e83", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "赤墨", kana: "あかすみ", hex: "#3f312b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "灰白色", kana: "かいはくしょく", hex: "#e9e4d4", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "柑子色", kana: "こうじいろ", hex: "#f6ad49", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "夏虫色", kana: "なつむしいろ", hex: "#cee4ae", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "青藍", kana: "せいらん", hex: "#274a78", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "黒紅", kana: "くろべに", hex: "#302833", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "蒸栗色", kana: "むしぐりいろ", hex: "#ebe1a9", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "金茶", kana: "きんちゃ", hex: "#f39800", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "鶸萌黄", kana: "ひわもえぎ", hex: "#82ae46", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "深縹", kana: "こきはなだ", hex: "#2a4073", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "白", kana: "しろ", hex: "#ffffff", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "女郎花", kana: "おみなえし", hex: "#f2f2b0", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "蜜柑色", kana: "みかんいろ", hex: "#f08300", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "柳色", kana: "やなぎいろ", hex: "#a8c97f", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紺色", kana: "こんいろ", hex: "#223a70", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "胡粉色", kana: "ごふんいろ", hex: "#fffffc", desc: "ホタテやカキの貝殻を風化させて作る白色絵の具に由来。純白よりも少し温かみと奥深さのあるマットな白です。" },
  { name: "枯草色", kana: "かれくさいろ", hex: "#e4dc8a", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "鉛丹色", kana: "えんたんいろ", hex: "#ec6d51", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "青白橡", kana: "あおしろつるばみ", hex: "#9ba88d", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紺青", kana: "こんじょう", hex: "#192f60", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "卯の花色", kana: "うのはないろ", hex: "#f7fcfe", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "淡黄", kana: "たんこう", hex: "#f8e58c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "黄丹", kana: "おうに", hex: "#ee7948", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "柳鼠", kana: "やなぎねず", hex: "#c8d5bb", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "留紺", kana: "とめこん", hex: "#1c305c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "白磁", kana: "はくじ", hex: "#f8fbf8", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "白茶", kana: "しらちゃ", hex: "#ddbb99", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "柿色", kana: "かきいろ", hex: "#ed6d3d", desc: "熟した柿の実のような、力強くも温かみのある赤橙色。歌舞伎の市川團十郎家の家色としても有名です。" },
  { name: "裏葉柳", kana: "うらはやなぎ", hex: "#c1d8ac", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "濃藍", kana: "こいあい", hex: "#0f2350", desc: "藍染めを幾度も重ねて染め上げた、非常に深い紺黒色。かつては勝色（かついろ）とも呼ばれ武士に愛されました。" },
  { name: "生成り色", kana: "きなりいろ", hex: "#fbfaf5", desc: "漂白する前の麻や綿の天然素材そのままの白。わずかに黄みがかっており、日本の無垢な美を表します。" },
  { name: "赤白橡", kana: "あかしろつるばみ", hex: "#d7a98c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "黄赤", kana: "きあか", hex: "#ec6800", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "山葵色", kana: "わさびいろ", hex: "#a8bf93", desc: "すりおろしたワサビの根のような、少し白みを帯びた淡い緑。ツンとした涼やかさを感じさせる色彩です。" },
  { name: "鉄紺", kana: "てつこん", hex: "#17184b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "乳白色", kana: "にゅうはくしょく", hex: "#f3f3f3", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "洗柿", kana: "あらいがき", hex: "#f2c9ac", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "人参色", kana: "にんじんいろ", hex: "#ec6800", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "老竹色", kana: "おいたけいろ", hex: "#769164", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "漆黒", kana: "しっこく", hex: "#0d0015", desc: "漆器の艶やかな光沢を帯びた、一切の光を吸収するような深く純粋な黒色。格式高く引き締まった印象を与えます。" },
  { name: "白練", kana: "しろねり", hex: "#f3f3f2", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "鳥の子色", kana: "とりのこいろ", hex: "#fff1cf", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "橙色", kana: "だいだいいろ", hex: "#ee7800", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "白緑", kana: "びゃくろく", hex: "#d6e9ca", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "淡藤色", kana: "あわふじいろ", hex: "#bbc8e6", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "素色", kana: "そしょく", hex: "#eae5e3", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "蜂蜜色", kana: "はちみついろ", hex: "#fddea5", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "照柿", kana: "てりがき", hex: "#eb6238", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "淡萌黄", kana: "うすもえぎ", hex: "#93ca76", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "藤色", kana: "ふじいろ", hex: "#bbbcde", desc: "春にしなやかに垂れ下がる藤の花のような淡い青紫。平安貴族の憧れの色として文学にも度々登場します。" },
  { name: "白梅鼠", kana: "しらうめねず", hex: "#e5e4e6", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "肌色", kana: "はだいろ", hex: "#fce2c4", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "赤橙", kana: "あかだいだい", hex: "#ea5506", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "柳染", kana: "やなぎぞめ", hex: "#93b881", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紅掛空色", kana: "べにかけそらいろ", hex: "#8491c3", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "白鼠", kana: "しろねず", hex: "#dcdddd", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "薄卵色", kana: "うすたまごいろ", hex: "#fde8d0", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "金赤", kana: "きんあか", hex: "#ea5506", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "薄萌葱", kana: "うすもえぎ", hex: "#badcad", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紅碧", kana: "べにみどり", hex: "#8491c3", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "絹鼠", kana: "きぬねず", hex: "#dddcd6", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "雄黄", kana: "ゆうおう", hex: "#f9c89b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "朱色", kana: "しゅいろ", hex: "#eb6101", desc: "天然の硫化水銀から作られる鮮やかな黄赤。魔除けの色として神社仏閣の鳥居などに塗られています。" },
  { name: "深川鼠", kana: "ふかがわねずみ", hex: "#97a791", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紺桔梗", kana: "こんききょう", hex: "#4d5aaf", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "灰青", kana: "はいあお", hex: "#c0c6c9", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "洒落柿", kana: "しゃれがき", hex: "#f7bd8f", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "小麦色", kana: "こむぎいろ", hex: "#e49e61", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "若緑", kana: "わかみどり", hex: "#98d98e", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "花色", kana: "はないろ", hex: "#4d5aaf", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "銀鼠", kana: "ぎんねず", hex: "#afafb0", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "赤香", kana: "あかこう", hex: "#f6b894", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "丹色", kana: "にいろ", hex: "#e45e32", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "浅緑", kana: "あさみどり", hex: "#88cb7f", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紺藍", kana: "こんあい", hex: "#4a488e", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "薄鈍", kana: "うすにび", hex: "#adadad", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "砥粉色", kana: "とのこいろ", hex: "#f4dda5", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "黄茶", kana: "きちゃ", hex: "#e17b34", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "薄緑", kana: "うすみどり", hex: "#69b076", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紅桔梗", kana: "べにききょう", hex: "#4d4398", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "薄墨色", kana: "うすずみいろ", hex: "#a3a3a2", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "肉色", kana: "にくいろ", hex: "#f1bf99", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "肉桂色", kana: "にっけいいろ", hex: "#dd7a56", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "青鈍", kana: "あおにび", hex: "#6b7b6e", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "桔梗色", kana: "ききょういろ", hex: "#5654a2", desc: "秋の七草であるキキョウの花のような、青みが強いしっかりとした紫。凛とした涼しい気品があります。" },
  { name: "錫色", kana: "すずいろ", hex: "#9ea1a3", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "人色", kana: "ひといろ", hex: "#f1bf99", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "赤朽葉色", kana: "あかくちばいろ", hex: "#db8449", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "青磁鼠", kana: "せいじねず", hex: "#bed2c3", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "藤納戸", kana: "ふじなんど", hex: "#706caa", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "素鼠", kana: "すねずみ", hex: "#9fa0a0", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "丁子色", kana: "ちょうじいろ", hex: "#efcd9a", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "黄櫨染", kana: "こうろぜん", hex: "#d66a35", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "薄青", kana: "うすあお", hex: "#93b69c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紅掛花色", kana: "べにかけはないろ", hex: "#68699b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "鼠色", kana: "ねずみいろ", hex: "#949495", desc: "江戸時代に大流行したグレーの総称。当時は庶民の贅沢が制限され「四十八茶百鼠」と呼ばれる無数のグレーが生まれました。" },
  { name: "香色", kana: "こういろ", hex: "#efcd9a", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "蒲公英色", kana: "たんぽぽいろ", hex: "#ffd900", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "錆青磁", kana: "さびせいじ", hex: "#a6c8b2", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紫苑色", kana: "しおんいろ", hex: "#867ba9", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "源氏鼠", kana: "げんじねず", hex: "#888084", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "薄香", kana: "うすこう", hex: "#f0cfa0", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "黄色", kana: "きいろ", hex: "#ffd900", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "緑青色", kana: "ろくしょういろ", hex: "#47885e", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "白藤色", kana: "しらふじいろ", hex: "#dbd0e6", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "灰色", kana: "はいいろ", hex: "#7d7d7d", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "浅黄", kana: "うすき", hex: "#edd3a1", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "中黄", kana: "ちゅうき", hex: "#ffea00", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "千歳緑", kana: "ちとせみどり", hex: "#316745", desc: "千年の長寿を願う「千歳」の名を冠した、松の葉のような極めて深く力強いオリーブ系の深緑です。" },
  { name: "藤紫", kana: "ふじむらさき", hex: "#a59aca", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "鉛色", kana: "なまりいろ", hex: "#7b7c7d", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "枯色", kana: "かれいろ", hex: "#e0c38c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "菜の花色", kana: "なのはないろ", hex: "#ffec47", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "若竹色", kana: "わかたけいろ", hex: "#68be8d", desc: "すくすくと育つ若い竹の幹のような、さわやかで青みのある明るい緑。新鮮さや若々しさを演出します。" },
  { name: "菫色", kana: "すみれいろ", hex: "#7058a3", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "鈍色", kana: "にびいろ", hex: "#727171", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "淡香", kana: "うすこう", hex: "#f3bf88", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "黄檗色", kana: "きはだいろ", hex: "#fef263", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "緑", kana: "みどり", hex: "#3eb370", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "青紫", kana: "あおむらさき", hex: "#674598", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "墨", kana: "すみ", hex: "#595857", desc: "書道で使う墨汁（スミ）の、少し黒みがかった深いグレー。純粋な黒とは異なり、吸い込まれるような温かみがあります。" },
  { name: "杏色", kana: "あんずいろ", hex: "#f7b977", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "卵色", kana: "たまごいろ", hex: "#fcd575", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "常磐色", kana: "ときわいろ", hex: "#007b43", desc: "松や杉などの常緑樹の葉のように、年中変わらない深い緑。永久不変の長寿を祝う吉祥の色とされました。" },
  { name: "菖蒲色", kana: "しょうぶいろ", hex: "#674196", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "丼鼠", kana: "どぶねずみ", hex: "#595455", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "東雲色", kana: "しののめいろ", hex: "#f19072", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "花葉色", kana: "はなばいろ", hex: "#fbd26b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "千草鼠", kana: "ちぐさねず", hex: "#bed3ca", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "竜胆色", kana: "りんどういろ", hex: "#9079ad", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "消炭色", kana: "けしずみいろ", hex: "#524e4d", desc: "薪が燃えて炭になる手前の、水分を含まないサラサラした暗いグレー。静寂や沈黙のテーマによく似合います。" },
  { name: "曙色", kana: "あけぼのいろ", hex: "#f19072", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "刈安色", kana: "かりやすいろ", hex: "#f5e56b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "千草色", kana: "ちぐさいろ", hex: "#92b5a9", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "江戸紫", kana: "えどむらさき", hex: "#745399", desc: "江戸発祥の染料で染めた、青みの強い紫。歌舞伎の『助六』の鉢巻色として有名になり流行しました。" },
  { name: "藍墨茶", kana: "あいすみちゃ", hex: "#474a4d", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "珊瑚朱色", kana: "さんごしゅいろ", hex: "#ee836f", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "玉蜀黍色", kana: "とうもろこしいろ", hex: "#eec362", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "青磁色", kana: "せいじいろ", hex: "#7ebea5", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "本紫", kana: "ほんむらさき", hex: "#65318e", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "羊羹色", kana: "ようかんいろ", hex: "#383c3c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "深支子", kana: "こきくちなし", hex: "#eb9b6f", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "金糸雀色", kana: "かなりあいろ", hex: "#ebd842", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "青竹色", kana: "あおたけいろ", hex: "#7ebeab", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "葡萄色", kana: "ぶどういろ", hex: "#522f60", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "蝋色", kana: "ろういろ", hex: "#2b2b2b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "纁", kana: "そひ", hex: "#e0815e", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "黄支子色", kana: "きくちなしいろ", hex: "#ffdb4f", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "常磐緑", kana: "ときわみどり", hex: "#028760", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "深紫", kana: "ふかむらさき", hex: "#493759", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "黒", kana: "くろ", hex: "#2b2b2b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "浅緋", kana: "うすきひ", hex: "#df7163", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "支子色", kana: "くちなしいろ", hex: "#fbca4d", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "木賊色", kana: "とくさいろ", hex: "#3b7960", desc: "砥石代わりに物を磨くために使われた植物「トクサ」の幹のような、くすんだ深い常緑です。" },
  { name: "紫黒", kana: "しこく", hex: "#2e2930", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "烏羽色", kana: "からすばいろ", hex: "#180614", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "真赭", kana: "まそほ", hex: "#d57c6b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "向日葵色", kana: "ひまわりいろ", hex: "#fcc800", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "天鵞絨", kana: "びろうど", hex: "#2f5d50", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紫", kana: "むらさき", hex: "#884898", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "鉄黒", kana: "てつぐろ", hex: "#281a14", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "洗朱", kana: "あらいしゅ", hex: "#d0826c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "山吹色", kana: "やまぶきいろ", hex: "#f8b500", desc: "春に咲く山吹の花のような、赤みの強い黄金色。江戸時代には「小判（金貨）」の隠語としても使われました。" },
  { name: "虫襖", kana: "むしあお", hex: "#3a5b52", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "薄葡萄", kana: "うすぶどう", hex: "#c0a2c7", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "濡羽色", kana: "ぬればいろ", hex: "#000b00", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "遠州茶", kana: "えんしゅうちゃ", hex: "#ca8269", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "鬱金色", kana: "うこんいろ", hex: "#fabf14", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "革色", kana: "かわいろ", hex: "#475950", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紫紺", kana: "しこん", hex: "#460e44", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "黒檀", kana: "こくたん", hex: "#250d00", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "紅樺色", kana: "べにかばいろ", hex: "#bb5548", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "藤黄", kana: "とうおう", hex: "#f7c114", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "深緑", kana: "ふかみどり", hex: "#00552e", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "暗紅色", kana: "あんこうしょく", hex: "#74325c", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "憲法黒茶", kana: "けんぽうくろちゃ", hex: "#241a08", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "赭", kana: "そほ", hex: "#ab6953", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "金色", kana: "こんじき", hex: "#e6b422", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "鉄色", kana: "てついろ", hex: "#005243", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "桑の実色", kana: "くわのみいろ", hex: "#55295b", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" },
  { name: "暗黒色", kana: "あんこくしょく", hex: "#16160e", desc: "和色大辞典（colordic.org）に収録されている日本の伝統色の一つです。" }
];

// Helper to pre-populate RGB values for exact-match comparison
TRADITIONAL_COLORS.forEach(color => {
  color.rgb = hexToRgb(color.hex);
});

// --- 2. Color Conversion Helpers ---
function hexToRgb(hex) {
  const h = hex.replace("#", "");
  const r = parseInt(h.substring(0, 2), 16);
  const g = parseInt(h.substring(2, 4), 16);
  const b = parseInt(h.substring(4, 6), 16);
  return [r, g, b];
}

// A traditional color name is only shown when the picked pixel's RGB is
// byte-for-byte identical to a registered color's — not merely "close by
// some perceptual distance." A "closest match" framing (tried earlier, first
// with plain RGB distance, then with a Lab/Delta-E threshold) still displays
// a color name and its hex code next to a picked color that doesn't actually
// have that hex code, which reads as "this is that color" even when it
// isn't. Since Japanese traditional colors are precisely defined, showing a
// name at all is a claim that the code matches — so only an exact match
// earns one.
function getClosestTraditionalColor(r, g, b) {
  return TRADITIONAL_COLORS.find(
    (color) => color.rgb[0] === r && color.rgb[1] === g && color.rgb[2] === b
  ) || null;
}

// --- 3. UI Controller Logic ---
document.addEventListener("DOMContentLoaded", () => {
  // Elements
  const btnPick = document.getElementById("btn-pick");
  const windowColor = document.getElementById("window-color");
  const colorNameJp = document.getElementById("color-name-jp");
  const colorNameKana = document.getElementById("color-name-kana");
  const valHex = document.getElementById("val-hex");
  const valRgb = document.getElementById("val-rgb");
  const colorDesc = document.getElementById("color-desc");
  const btnSaveColor = document.getElementById("btn-save-color");
  const paletteGrid = document.getElementById("palette-grid");
  const toast = document.getElementById("toast");

  const rowHex = document.getElementById("row-hex");
  const rowRgb = document.getElementById("row-rgb");

  // State
  let currentPickedHex = null;
  let currentMatchedColor = null;
  let savedPalette = [];

  // Show copy notification toast
  function showToast(message) {
    toast.textContent = message;
    toast.classList.add("show");
    setTimeout(() => {
      toast.classList.remove("show");
    }, 1500);
  }

  // Load Palette from chrome.storage
  function loadPalette() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.get(["colorPalette"], (result) => {
        savedPalette = result.colorPalette || [];
        renderPalette();
      });
    } else {
      renderPalette();
    }
  }

  // Save Palette to chrome.storage
  function savePalette() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.set({ colorPalette: savedPalette }, () => {
        renderPalette();
      });
    } else {
      renderPalette();
    }
  }

  // Render Palette Grid slots
  function renderPalette() {
    paletteGrid.innerHTML = "";

    // Fill up to 8 slots
    for (let i = 0; i < 8; i++) {
      const slot = document.createElement("div");
      slot.className = "palette-slot";

      if (savedPalette[i]) {
        const item = savedPalette[i];
        slot.style.backgroundColor = item.hex;
        slot.title = `${item.name} (${item.hex})`;

        // Delete button inside slot
        const removeBtn = document.createElement("span");
        removeBtn.className = "slot-remove";
        removeBtn.textContent = "×";
        removeBtn.addEventListener("click", (e) => {
          e.stopPropagation(); // prevent select action
          savedPalette.splice(i, 1);
          savePalette();
        });

        slot.appendChild(removeBtn);

        // Click slot to re-select color
        slot.addEventListener("click", () => {
          const rgb = hexToRgb(item.hex);
          selectColor(item.hex, rgb[0], rgb[1], rgb[2]);
        });
      } else {
        // Empty slot spacer
        slot.style.backgroundColor = "transparent";
        slot.style.border = "1.5px dashed rgba(223, 194, 153, 0.25)";
        slot.style.cursor = "default";
        slot.title = "未登録";
      }

      paletteGrid.appendChild(slot);
    }
  }

  // Set the selected color and match it
  function selectColor(hex, r, g, b) {
    currentPickedHex = hex;
    const matched = getClosestTraditionalColor(r, g, b);
    currentMatchedColor = matched;

    // Remove empty symbol
    const emptySym = windowColor.querySelector(".empty-symbol");
    if (emptySym) emptySym.remove();

    // 1. Update Preview round window color
    windowColor.style.backgroundColor = hex;

    // 2. Set details panel data
    valHex.textContent = hex.toUpperCase();
    valRgb.textContent = `rgb(${r}, ${g}, ${b})`;

    if (matched) {
      colorNameJp.textContent = matched.name;
      colorNameKana.textContent = matched.kana;
      colorDesc.textContent = matched.desc;
      btnSaveColor.classList.remove("hidden");
    } else {
      // No registered color has this exact hex code: say so rather than
      // naming a "close" color next to a code that doesn't actually match it.
      colorNameJp.textContent = "一致する伝統色なし";
      colorNameKana.textContent = "";
      colorDesc.textContent = "このカラーコードと完全に一致する日本の伝統色はデータベース内にありませんでした。";
      btnSaveColor.classList.add("hidden");
    }
  }

  // --- Click Actions ---

  // Pick color button
  btnPick.addEventListener("click", () => {
    if (window.EyeDropper) {
      const eyeDropper = new EyeDropper();
      eyeDropper.open().then((result) => {
        const hex = result.sRGBHex;
        const rgb = hexToRgb(hex);
        selectColor(hex, rgb[0], rgb[1], rgb[2]);
      }).catch((err) => {
        console.log("Eyedropper closed or failed: ", err);
      });
    } else {
      // Fallback for browsers without EyeDropper (alert/mock fallback)
      alert("お使いのブラウザはEyeDropper APIに対応していません。デモ環境のテストパレットをご利用ください。");
    }
  });

  // Copy HEX action
  rowHex.addEventListener("click", () => {
    if (!currentPickedHex) return;
    navigator.clipboard.writeText(valHex.textContent).then(() => {
      showToast("HEXコードをコピーしました");
    });
  });

  // Copy RGB action
  rowRgb.addEventListener("click", () => {
    if (!currentPickedHex) return;
    navigator.clipboard.writeText(valRgb.textContent).then(() => {
      showToast("RGBコードをコピーしました");
    });
  });

  // Save color to favorite list
  btnSaveColor.addEventListener("click", () => {
    if (!currentPickedHex || !currentMatchedColor) return;

    // Check duplication
    const duplicated = savedPalette.some(item => item.hex.toLowerCase() === currentPickedHex.toLowerCase());
    if (duplicated) {
      showToast("既に登録されています");
      return;
    }

    // Insert to top (LIFO), limit to 8 colors
    savedPalette.unshift({
      name: currentMatchedColor.name,
      hex: currentPickedHex.toUpperCase()
    });

    if (savedPalette.length > 8) {
      savedPalette.pop();
    }

    savePalette();
    showToast("パレットに保存しました");
  });

  // Boot
  loadPalette();

  // Expose for sandbox simulator
  window.__selectColor = selectColor;

  // Keyboard shortcut listener to easily trigger picking mode again
  document.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " " || e.key.toLowerCase() === "s" || e.key.toLowerCase() === "p") {
      if (e.key === " ") e.preventDefault(); // Prevent page scroll
      btnPick.click();
    }
  });

  // Focus the color pick button initially
  btnPick.focus();
});
