// background.js - Service Worker for Japanese Traditional Color Picker

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["colorPalette"], (result) => {
    if (!result.colorPalette) {
      chrome.storage.local.set({ colorPalette: [] });
    }
  });
  console.log("日本の伝統色ピッカー 拡張機能が正常にインストールされました。");
});
