// ============================================
// 一発企業データ検索 — Content Script
// ============================================

(function () {
  // Listen for messages from background
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "showLoading") {
      showModalLoading(message.query);
    } else if (message.action === "showCandidates") {
      showCandidates(message.query, message.candidates);
    } else if (message.action === "displayCompanyResult") {
      displayResult(message.query, message.result);
    }
  });

  // Modal DOM reference
  let modalElement = null;

  // Create or retrieve modal element
  function getModal() {
    if (modalElement) return modalElement;

    modalElement = document.createElement("div");
    modalElement.id = "company-search-modal-root";
    document.body.appendChild(modalElement);
    return modalElement;
  }

  // Remove modal from DOM
  function removeModal() {
    if (modalElement) {
      modalElement.remove();
      modalElement = null;
    }
  }

  // Close modal when clicking outside
  document.addEventListener("mousedown", (e) => {
    if (modalElement && !modalElement.contains(e.target)) {
      removeModal();
    }
  });

  // Show loading spinner card
  function showModalLoading(query) {
    const modal = getModal();
    modal.innerHTML = `
      <div class="company-modal-header">
        <h2>${escapeHTML(query)}</h2>
        <button class="company-modal-close-btn" id="company-modal-close">✕</button>
      </div>
      <div class="company-modal-body">
        <div class="company-modal-loading-container">
          <div class="company-modal-spinner"></div>
          <span class="company-modal-loading-text">企業データを照会中...</span>
        </div>
      </div>
      <div class="company-modal-footer">
        <form class="company-modal-search-form" id="company-modal-form">
          <input type="text" class="company-modal-search-input" id="company-modal-input" placeholder="別の企業名を検索..." required>
          <button type="submit" class="company-modal-search-btn">検索</button>
        </form>
      </div>
    `;

    // Hook events
    modal.querySelector("#company-modal-close").addEventListener("click", removeModal);
    modal.querySelector("#company-modal-form").addEventListener("submit", handleSearchSubmit);
  }

  // Show disambiguation candidate list
  function showCandidates(query, candidates) {
    const modal = getModal();
    const headerTitle = modal.querySelector("h2");
    if (headerTitle) {
      headerTitle.textContent = `「${query}」 — 候補企業を選択`;
    }
    const body = modal.querySelector(".company-modal-body");
    if (!body) return;

    const items = candidates.map((c, i) => `
      <button class="company-candidate-btn" data-title="${escapeAttr(c.title)}" id="candidate-btn-${i}">
        <span class="company-candidate-name">${escapeHTML(c.title)}</span>
        <span class="company-candidate-snippet">${escapeHTML(c.snippet.slice(0, 60))}…</span>
      </button>
    `).join("");

    body.innerHTML = `
      <p class="company-candidate-lead">複数の候補が見つかりました。詳細を表示する企業を選んでください。</p>
      <div class="company-candidate-list">${items}</div>
    `;

    // Bind click events on candidate buttons
    body.querySelectorAll(".company-candidate-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const pageTitle = btn.dataset.title;
        showModalLoading(pageTitle);
        chrome.runtime.sendMessage({ action: "fetchCompanyPage", pageTitle }, (response) => {
          displayResult(pageTitle, response?.result || { found: false });
        });
      });
    });
  }

  // Display results from Wikipedia or show fallback search helpers
  function displayResult(query, result) {
    const modal = getModal();
    
    // Set Header
    const headerTitle = modal.querySelector("h2");
    if (headerTitle) {
      headerTitle.textContent = result.found ? result.pageTitle : query;
    }

    const body = modal.querySelector(".company-modal-body");
    if (!body) return;

    let contentHTML = "";

    if (result.found && result.htmlText) {
      // Parse Wikipedia Infobox
      const info = parseWikipediaInfobox(result.htmlText);
      
      if (Object.keys(info).length > 0) {
        contentHTML += `
          <div class="company-name-header">
            <span class="company-name-label">🔍 検索された企業名</span>
            <h3 class="company-name-title">${escapeHTML(result.pageTitle)}</h3>
          </div>
          <table class="company-modal-table">
            <tbody>
              ${info.market ? `<tr><th>上場状況</th><td>${escapeHTML(info.market)}</td></tr>` : ""}
              ${info.representative ? `<tr><th>代表者</th><td>${escapeHTML(info.representative)}</td></tr>` : ""}
              ${info.location ? `<tr><th>本社所在地</th><td>${escapeHTML(info.location)}</td></tr>` : ""}
              ${info.established ? `<tr><th>設立</th><td>${escapeHTML(info.established)}</td></tr>` : ""}
              ${info.capital ? `<tr><th>資本金</th><td>${escapeHTML(info.capital)}</td></tr>` : ""}
              ${info.industry ? `<tr><th>業種・事業</th><td>${escapeHTML(info.industry)}</td></tr>` : ""}
            </tbody>
          </table>
        `;
      } else {
        contentHTML += `
          <div class="company-modal-fallback">
            <p>Wikipediaページは見つかりましたが、会社基本データの自動抽出ができませんでした。</p>
          </div>
        `;
      }
    } else {
      contentHTML += `
        <div class="company-modal-fallback">
          <p>選択された企業の基本データが Wikipedia から見つかりませんでした。</p>
        </div>
      `;
    }

    // Add Fallback Search buttons (always show as helper links)
    const baseconnectUrl = `https://baseconnect.in/companies/search?keyword=${encodeURIComponent(query)}`;
    const ntaUrl = `https://www.houjin-bangou.nta.go.jp/kensaku-kekka.html?wt=kensaku&q=${encodeURIComponent(query)}`;
    const googleUrl = `https://www.google.com/search?q=${encodeURIComponent(query + " 企業情報 資本金 所在地")}`;

    contentHTML += `
      <div class="company-modal-btn-group">
        <a href="${googleUrl}" target="_blank" class="company-modal-link-btn">🔍 Google で企業情報を検索</a>
        <a href="${baseconnectUrl}" target="_blank" class="company-modal-link-btn">🏢 Baseconnect で検索</a>
        <a href="${ntaUrl}" target="_blank" class="company-modal-link-btn">📋 国税庁法人番号サイトで検索</a>
      </div>
    `;

    body.innerHTML = contentHTML;
  }

  // Parse Wikipedia HTML content and extract standard corporate metadata
  function parseWikipediaInfobox(htmlText) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlText, "text/html");
    
    // Wikipedia company infobox table selectors
    const infobox = doc.querySelector("table.infobox") || doc.querySelector("table.company") || doc.querySelector("table.wiki-template-demography");
    if (!infobox) return {};

    const info = {};
    const rows = infobox.querySelectorAll("tr");

    rows.forEach(row => {
      const th = row.querySelector("th");
      const td = row.querySelector("td");
      if (!th || !td) return;

      const label = th.textContent.trim().replace(/\s+/g, "");
      const val = cleanValue(td);

      if (label.includes("種類") || label.includes("会社種別")) {
        info.type = val;
      } else if (label.includes("市場") || label.includes("上場")) {
        info.market = val;
      } else if (label.includes("代表者") || label.includes("代表取締役") || label.includes("最高経営責任者") || label.includes("社長")) {
        // avoid duplicating Representative if we already have it
        if (!info.representative) info.representative = val;
      } else if (label.includes("本社所在地") || label.includes("本店所在地") || label.includes("所在地")) {
        if (!info.location) info.location = val;
      } else if (label.includes("設立") || label.includes("設置")) {
        info.established = val;
      } else if (label.includes("資本金")) {
        info.capital = val;
      } else if (label.includes("業種") || label.includes("事業内容") || label.includes("主要事業")) {
        info.industry = val;
      }
    });

    return info;
  }

  // Clean value by removing citations, extra whitespace, and footnote symbols
  function cleanValue(td) {
    // clone to avoid modifying original document parsed
    const clone = td.cloneNode(true);
    
    // Remove references [1], [2], etc.
    clone.querySelectorAll("sup.reference").forEach(el => el.remove());
    
    // Remove invisible edit templates
    clone.querySelectorAll("span.mw-editsection").forEach(el => el.remove());

    let text = clone.textContent.trim();
    // Normalize newlines and excess spacing
    text = text.replace(/\n+/g, " / ");
    text = text.replace(/\s+/g, " ");
    return text;
  }

  // Handle re-search submissions from modal footer
  function handleSearchSubmit(e) {
    e.preventDefault();
    const input = document.getElementById("company-modal-input");
    if (!input) return;

    const query = input.value.trim();
    if (query) {
      showModalLoading(query);
      chrome.runtime.sendMessage({ action: "searchCompany", query }, (response) => {
        if (response && response.result) {
          displayResult(query, response.result);
        } else {
          displayResult(query, { found: false });
        }
      });
    }
  }

  // Helper to escape HTML tags
  function escapeHTML(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  // Helper to escape HTML attribute values
  function escapeAttr(str) {
    return String(str).replace(/"/g, "&quot;").replace(/'/g, "&#039;");
  }
})();


// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // Add temporary shield to prevent iframe from stealing mouse events during dragging
      const existingShield = document.getElementById("wano-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = "wano-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      // Use getBoundingClientRect() for correct viewport-relative position
      // (element.offsetTop is unreliable for position:fixed elements on scrolled pages)
      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      // Restrict within window boundaries to prevent going offscreen
      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById("wano-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById("wano-universal-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "block" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = "wano-universal-floating-container";
    
    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 440) + "px !important; z-index:2147483647 !important; width:430px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="wano-u-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">Company Search</span>
        </div>
        <button id="wano-u-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#wano-u-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#wano-u-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
