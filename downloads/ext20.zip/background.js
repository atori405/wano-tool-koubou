// ============================================
// 一発企業データ検索 — Background Service Worker
// ============================================

// Register context menu on installation
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "searchCompanyData",
    title: "「%s」の企業情報を検索 企",
    contexts: ["selection"]
  });
});

// Listen for context menu clicks
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "searchCompanyData" && info.selectionText) {
    const query = info.selectionText.trim();
    if (query) {
      chrome.tabs.sendMessage(tab.id, { action: "showLoading", query });

      const result = await fetchCandidates(query);

      if (result.type === "candidates") {
        chrome.tabs.sendMessage(tab.id, { action: "showCandidates", query, candidates: result.candidates });
      } else {
        chrome.tabs.sendMessage(tab.id, { action: "displayCompanyResult", query, result });
      }
    }
  }
});

// Listen for messages from popup or content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "searchCompany") {
    fetchCandidates(message.query).then(result => {
      sendResponse({ result });
    });
    return true;
  }
  if (message.action === "fetchCompanyPage") {
    fetchPageData(message.pageTitle).then(result => {
      sendResponse({ result });
    });
    return true;
  }
});

// -----------------------------------------------
// String normalization helper
// -----------------------------------------------
function normalize(str) {
  return str
    .replace(/株式会社|有限会社|合資会社|合同会社|（株）|\(株\)/g, "")
    .replace(/\s+/g, "")
    .toLowerCase();
}

// -----------------------------------------------
// Helper: batch-check which of the given titles have a company infobox
// -----------------------------------------------
//   Japanese Wikipedia company pages use "Template:基礎情報 会社".
//   注: 以前は汎用の"Template:Infobox"もOR条件に含めていたが、これは
//   ほぼ全てのインフォボックス(車種ページやスポーツ部のページ等)にも
//   付与される極めて緩い判定基準で、実際に「トヨタ・プリウス」等の
//   車種ページや「トヨタ自動車工業サッカー部」が「会社」として誤判定
//   されることを確認したため、企業専用テンプレートのみに絞った。
async function filterCompanyTitles(titleList) {
  if (titleList.length === 0) return new Set();
  const titles = titleList.map(encodeURIComponent).join("|");
  const companyTemplates = [
    "Template:基礎情報 会社",
    "Template:Company-stub",
    "Template:上場情報"
  ].map(encodeURIComponent).join("|");
  const tmplUrl = `https://ja.wikipedia.org/w/api.php?action=query&format=json&prop=templates&titles=${titles}&tltemplates=${companyTemplates}&tllimit=50&utf8=1&origin=*`;
  const tmplRes = await fetch(tmplUrl);
  const tmplJson = await tmplRes.json();
  const companyPageTitles = new Set();
  const pages = tmplJson?.query?.pages || {};
  for (const page of Object.values(pages)) {
    if (page.templates && page.templates.length > 0) {
      companyPageTitles.add(page.title);
    }
  }
  return companyPageTitles;
}

function buildCandidateList(items) {
  return {
    type: "candidates",
    candidates: items.map(r => ({
      title: r.title,
      snippet: (r.snippet || "")
        .replace(/<[^>]+>/g, "")
        .replace(/&amp;/g, "&")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
    }))
  };
}

// -----------------------------------------------
// Step 1: Search Wikipedia and filter to real companies only
// -----------------------------------------------
// 注: 「ソニー」で検索すると本体の「ソニーグループ」ではなく、たまたま完全一致した
// 別の小さな子会社ページが単独ヒットして即決定されてしまう、「トヨタ自動車」では
// 逆に本体ページが全文検索の上位に出てこない、という実際の検証結果を踏まえ、
// あいまいさが残る場合は必ずユーザーに選ばせる方式にしている(自動で1件に
// 決め打ちするのは、確認できた会社が本当に1社しかない場合のみ)。
async function fetchCandidates(query) {
  try {
    // --- 1a. Prefix search: 会社名の前方一致で関連会社・子会社もまとめて拾う ---
    const prefixUrl = `https://ja.wikipedia.org/w/api.php?action=query&format=json&list=prefixsearch&pssearch=${encodeURIComponent(query)}&pslimit=15&origin=*`;
    const prefixRes = await fetch(prefixUrl);
    const prefixJson = await prefixRes.json();
    const prefixResults = prefixJson?.query?.prefixsearch || [];

    if (prefixResults.length > 0) {
      const companyTitles = await filterCompanyTitles(prefixResults.map(r => r.title));
      const verified = prefixResults.filter(r => companyTitles.has(r.title));
      if (verified.length === 1) {
        return await fetchPageData(verified[0].title);
      }
      if (verified.length > 1) {
        return buildCandidateList(verified.slice(0, 8));
      }
      // 前方一致では会社と判定できるページが1件も無かった場合のみ、
      // 全文検索にフォールバックする
    }

    // --- 1b. Fallback: full-text search (前方一致でヒットしない略称・通称など) ---
    const searchUrl = `https://ja.wikipedia.org/w/api.php?action=query&format=json&list=search&srsearch=${encodeURIComponent(query)}&srlimit=10&utf8=1&origin=*`;
    const searchRes = await fetch(searchUrl);
    const searchJson = await searchRes.json();
    const searchResults = searchJson?.query?.search || [];

    if (searchResults.length === 0) {
      return { found: false, reason: "notFound" };
    }

    const companyTitles = await filterCompanyTitles(searchResults.map(r => r.title));
    const verified = searchResults.filter(r => companyTitles.has(r.title));

    if (verified.length === 0) {
      return { found: false, reason: "notFound" };
    }
    if (verified.length === 1) {
      return await fetchPageData(verified[0].title);
    }
    return buildCandidateList(verified.slice(0, 8));

  } catch (e) {
    console.error("Error fetching candidates:", e);
    return { found: false, reason: "error", error: e.message };
  }
}

// -----------------------------------------------
// Step 2: Fetch full page data for a chosen title
// -----------------------------------------------
async function fetchPageData(pageTitle) {
  try {
    const parseUrl = `https://ja.wikipedia.org/w/api.php?action=parse&format=json&page=${encodeURIComponent(pageTitle)}&prop=text&origin=*`;
    const parseRes = await fetch(parseUrl);
    const parseJson = await parseRes.json();

    const htmlText = parseJson?.parse?.text?.["*"];
    if (!htmlText) {
      return { found: false, reason: "noContent", pageTitle };
    }
    return { found: true, pageTitle, htmlText };
  } catch (e) {
    console.error("Error fetching page data:", e);
    return { found: false, reason: "error", error: e.message };
  }
}
