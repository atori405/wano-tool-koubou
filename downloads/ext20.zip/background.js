// ============================================
// 一発企業データ検索 — Background Service Worker
// ============================================

// Register context menu on installation
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "searchCompanyData",
    title: "「%s」の企業情報を検索 企",
    contexts: ["selection"]
  });
});

// Listen for context menu clicks
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "searchCompanyData" && info.selectionText) {
    const query = info.selectionText.trim();
    if (query) {
      chrome.tabs.sendMessage(tab.id, { action: "showLoading", query });

      const result = await fetchCandidates(query);

      if (result.type === "candidates") {
        chrome.tabs.sendMessage(tab.id, { action: "showCandidates", query, candidates: result.candidates });
      } else {
        chrome.tabs.sendMessage(tab.id, { action: "displayCompanyResult", query, result });
      }
    }
  }
});

// Listen for messages from popup or content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "searchCompany") {
    fetchCandidates(message.query).then(result => {
      sendResponse({ result });
    });
    return true;
  }
  if (message.action === "fetchCompanyPage") {
    fetchPageData(message.pageTitle).then(result => {
      sendResponse({ result });
    });
    return true;
  }
});

// -----------------------------------------------
// String normalization helper
// -----------------------------------------------
function normalize(str) {
  return str
    .replace(/株式会社|有限会社|合資会社|合同会社|（株）|\(株\)/g, "")
    .replace(/\s+/g, "")
    .toLowerCase();
}

// -----------------------------------------------
// Step 1: Search Wikipedia and filter to real companies only
// Uses Template:Infobox_企業 presence as the "is a real company" gate
// -----------------------------------------------
async function fetchCandidates(query) {
  try {
    // --- 1a. Full-text search (up to 10 results) ---
    const searchUrl = `https://ja.wikipedia.org/w/api.php?action=query&format=json&list=search&srsearch=${encodeURIComponent(query)}&srlimit=10&utf8=1&origin=*`;
    const searchRes = await fetch(searchUrl);
    const searchJson = await searchRes.json();

    const searchResults = searchJson?.query?.search || [];
    if (searchResults.length === 0) {
      return { found: false, reason: "notFound" };
    }

    // --- 1b. Batch-verify which pages actually have a company Infobox ---
    //   Japanese Wikipedia company pages use "Template:基礎情報 会社" or
    //   the generic "Template:Infobox" wrapper (which 基礎情報 会社 resolves to).
    //   Product/series pages use neither.
    // NOTE: titles must be joined with raw "|" then each title encoded individually
    const titles = searchResults.map(r => encodeURIComponent(r.title)).join("|");
    const companyTemplates = [
      "Template:基礎情報 会社",
      "Template:Infobox",
      "Template:Company-stub",
      "Template:上場情報"
    ].map(encodeURIComponent).join("|");
    const tmplUrl = `https://ja.wikipedia.org/w/api.php?action=query&format=json&prop=templates&titles=${titles}&tltemplates=${companyTemplates}&tllimit=50&utf8=1&origin=*`;
    const tmplRes = await fetch(tmplUrl);
    const tmplJson = await tmplRes.json();

    // Build a Set of titles that have at least one of the target templates
    const companyPageTitles = new Set();
    const pages = tmplJson?.query?.pages || {};
    for (const page of Object.values(pages)) {
      if (page.templates && page.templates.length > 0) {
        companyPageTitles.add(page.title);
      }
    }

    // Keep only search results that passed the company filter
    const verified = searchResults.filter(r => companyPageTitles.has(r.title));

    // If no verified companies at all, fall back to unfiltered results
    const pool = verified.length > 0 ? verified : searchResults;

    // --- 1d. Trim to 6 candidates ---
    const candidates = pool.slice(0, 6);

    if (candidates.length === 1) {
      return await fetchPageData(candidates[0].title);
    }

    // --- 1e. Return candidate list for user selection ---
    return {
      type: "candidates",
      candidates: candidates.map(r => ({
        title: r.title,
        snippet: r.snippet
          .replace(/<[^>]+>/g, "")
          .replace(/&amp;/g, "&")
          .replace(/&lt;/g, "<")
          .replace(/&gt;/g, ">")
      }))
    };

  } catch (e) {
    console.error("Error fetching candidates:", e);
    return { found: false, reason: "error", error: e.message };
  }
}

// -----------------------------------------------
// Step 2: Fetch full page data for a chosen title
// -----------------------------------------------
async function fetchPageData(pageTitle) {
  try {
    const parseUrl = `https://ja.wikipedia.org/w/api.php?action=parse&format=json&page=${encodeURIComponent(pageTitle)}&prop=text&origin=*`;
    const parseRes = await fetch(parseUrl);
    const parseJson = await parseRes.json();

    const htmlText = parseJson?.parse?.text?.["*"];
    if (!htmlText) {
      return { found: false, reason: "noContent", pageTitle };
    }
    return { found: true, pageTitle, htmlText };
  } catch (e) {
    console.error("Error fetching page data:", e);
    return { found: false, reason: "error", error: e.message };
  }
}
