// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// ============================================
// 一発企業データ検索 — Popup Script
// ============================================

document.addEventListener("DOMContentLoaded", () => {
  const searchForm = document.getElementById("search-form");
  const searchInput = document.getElementById("search-input");
  const resultContainer = document.getElementById("result-container");

  searchForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const query = searchInput.value.trim();
    if (query) {
      performSearch(query);
    }
  });

  function performSearch(query) {
    // Show Loading
    resultContainer.innerHTML = `
      <div class="loading-container">
        <div class="spinner"></div>
        <span class="loading-text">企業データを照会中...</span>
      </div>
    `;

    // Send search message to background script
    chrome.runtime.sendMessage({ action: "searchCompany", query }, (response) => {
      if (response && response.result) {
        const result = response.result;
        if (result.type === "candidates") {
          renderCandidates(query, result.candidates);
        } else {
          renderResult(query, result);
        }
      } else {
        renderResult(query, { found: false });
      }
    });
  }

  function renderResult(query, result) {
    let html = "";

    if (result.found && result.htmlText) {
      // Parse Wikipedia Infobox
      const info = parseWikipediaInfobox(result.htmlText);

      if (Object.keys(info).length > 0) {
        html += `
          <div class="company-name-header">
            <span class="company-name-label">🔍 検索された企業名</span>
            <h3 class="company-name-title">${escapeHTML(result.pageTitle)}</h3>
          </div>
          <table class="company-table">
            <tbody>
              ${info.market ? `<tr><th>上場状況</th><td>${escapeHTML(info.market)}</td></tr>` : ""}
              ${info.representative ? `<tr><th>代表者</th><td>${escapeHTML(info.representative)}</td></tr>` : ""}
              ${info.location ? `<tr><th>本社所在地</th><td>${escapeHTML(info.location)}</td></tr>` : ""}
              ${info.established ? `<tr><th>設立</th><td>${escapeHTML(info.established)}</td></tr>` : ""}
              ${info.capital ? `<tr><th>資本金</th><td>${escapeHTML(info.capital)}</td></tr>` : ""}
              ${info.industry ? `<tr><th>業種・事業</th><td>${escapeHTML(info.industry)}</td></tr>` : ""}
            </tbody>
          </table>
        `;
      } else {
        html += `
          <div class="fallback-box">
            <p>Wikipediaページは見つかりましたが、基本データの自動抽出ができませんでした。</p>
          </div>
        `;
      }
    } else {
      html += `
        <div class="fallback-box">
          <p>Wikipedia から「${escapeHTML(query)}」の企業情報が見つかりませんでした。</p>
        </div>
      `;
    }

    // Add search links
    const baseconnectUrl = `https://baseconnect.in/companies/search?keyword=${encodeURIComponent(query)}`;
    const ntaUrl = `https://www.houjin-bangou.nta.go.jp/kensaku-kekka.html?wt=kensaku&q=${encodeURIComponent(query)}`;
    const googleUrl = `https://www.google.com/search?q=${encodeURIComponent(query + " 企業情報 資本金 所在地")}`;

    html += `
      <div class="btn-group">
        <a href="${googleUrl}" target="_blank" class="link-btn">🔍 Google で詳細を検索</a>
        <a href="${baseconnectUrl}" target="_blank" class="link-btn">🏢 Baseconnect で詳細を検索</a>
        <a href="${ntaUrl}" target="_blank" class="link-btn">📋 国税庁法人番号サイトで検索</a>
      </div>
    `;

    resultContainer.innerHTML = html;
  }

  // Render candidate disambiguation list
  function renderCandidates(query, candidates) {
    const items = candidates.map((c, i) => `
      <button class="candidate-btn" data-title="${escapeAttr(c.title)}" id="popup-candidate-${i}">
        <span class="candidate-name">${escapeHTML(c.title)}</span>
        <span class="candidate-snippet">${escapeHTML(c.snippet.slice(0, 55))}…</span>
      </button>
    `).join("");

    resultContainer.innerHTML = `
      <p class="candidate-lead">「${escapeHTML(query)}」の候補が複数見つかりました。詳細を表示する企業を選択してください。</p>
      <div class="candidate-list">${items}</div>
    `;

    resultContainer.querySelectorAll(".candidate-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const pageTitle = btn.dataset.title;
        resultContainer.innerHTML = `
          <div class="loading-container">
            <div class="spinner"></div>
            <span class="loading-text">${escapeHTML(pageTitle)}を取得中...</span>
          </div>
        `;
        chrome.runtime.sendMessage({ action: "fetchCompanyPage", pageTitle }, (response) => {
          renderResult(pageTitle, response?.result || { found: false });
        });
      });
    });
  }

  // Parse Wikipedia HTML content and extract standard corporate metadata
  function parseWikipediaInfobox(htmlText) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlText, "text/html");
    
    // Wikipedia company infobox table selectors
    const infobox = doc.querySelector("table.infobox") || doc.querySelector("table.company") || doc.querySelector("table.wiki-template-demography");
    if (!infobox) return {};

    const info = {};
    const rows = infobox.querySelectorAll("tr");

    rows.forEach(row => {
      const th = row.querySelector("th");
      const td = row.querySelector("td");
      if (!th || !td) return;

      const label = th.textContent.trim().replace(/\s+/g, "");
      const val = cleanValue(td);

      if (label.includes("種類") || label.includes("会社種別")) {
        info.type = val;
      } else if (label.includes("市場") || label.includes("上場")) {
        info.market = val;
      } else if (label.includes("代表者") || label.includes("代表取締役") || label.includes("最高経営責任者") || label.includes("社長")) {
        if (!info.representative) info.representative = val;
      } else if (label.includes("本社所在地") || label.includes("本店所在地") || label.includes("所在地")) {
        if (!info.location) info.location = val;
      } else if (label.includes("設立") || label.includes("設置")) {
        info.established = val;
      } else if (label.includes("資本金")) {
        info.capital = val;
      } else if (label.includes("業種") || label.includes("事業内容") || label.includes("主要事業")) {
        info.industry = val;
      }
    });

    return info;
  }

  // Clean value by removing citations, extra whitespace, and footnote symbols
  function cleanValue(td) {
    const clone = td.cloneNode(true);
    clone.querySelectorAll("sup.reference").forEach(el => el.remove());
    clone.querySelectorAll("span.mw-editsection").forEach(el => el.remove());

    let text = clone.textContent.trim();
    text = text.replace(/\n+/g, " / ");
    text = text.replace(/\s+/g, " ");
    return text;
  }

  function escapeHTML(str) {
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function escapeAttr(str) {
    return String(str).replace(/"/g, "&quot;").replace(/'/g, "&#039;");
  }
});
