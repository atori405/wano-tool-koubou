// content.js - Desktop Bonsai Widget and Sound Synthesizer

(function() {
  let widgetContainer = null;
  let shadowRoot = null;
  let warningOverlay = null;
  let warningShadowRoot = null;
  let localState = null;
  let tickInterval = null;

  // Initialize event listener
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'updateState') {
      localState = request.state;
      manageWidget();
      sendResponse({ success: true });
    } 
    else if (request.action === 'showWarning') {
      showDistractionWarning(request.secondsLeft);
      sendResponse({ success: true });
    } 
    else if (request.action === 'hideWarning') {
      hideDistractionWarning();
      sendResponse({ success: true });
    }
    else if (request.action === 'playSound') {
      if (request.type === 'drum') {
        playTaiko();
      } else if (request.type === 'wind_chime') {
        playFurin();
      }
      sendResponse({ success: true });
    }
    else if (request.action === 'penaltyTriggered') {
      playDeathSound();
      sendResponse({ success: true });
    }
    return true;
  });

  // Query initial state on load
  chrome.runtime.sendMessage({ action: 'getState' }, (response) => {
    if (chrome.runtime.lastError || !response) return;
    localState = response;
    manageWidget();
  });

  // Manage Widget DOM creation and deletion
  function manageWidget() {
    if (!localState) return;

    const shouldShow = localState.isRunning && 
                       localState.showWidget && 
                       (localState.mode === 'work' || localState.mode === 'break');

    if (shouldShow) {
      createWidget();
      updateWidgetUI();
      startLocalClock();
    } else {
      removeWidget();
      stopLocalClock();
    }
  }

  function startLocalClock() {
    if (tickInterval) return;
    tickInterval = setInterval(() => {
      if (localState && localState.isRunning && localState.endTime > 0) {
        localState.timeLeft = Math.max(0, Math.ceil((localState.endTime - Date.now()) / 1000));
        updateWidgetUI();
        
        if (localState.timeLeft <= 0) {
          stopLocalClock();
        }
      }
    }, 1000);
  }

  function stopLocalClock() {
    if (tickInterval) {
      clearInterval(tickInterval);
      tickInterval = null;
    }
  }

  // Create Floating Widget inside isolated Shadow DOM
  function createWidget() {
    if (widgetContainer) return;

    widgetContainer = document.createElement('div');
    widgetContainer.id = 'bonsai-desktop-widget-root';
    widgetContainer.style.position = 'fixed';
    widgetContainer.style.bottom = '15px';
    widgetContainer.style.right = '15px';
    widgetContainer.style.zIndex = '9999999';
    widgetContainer.style.transition = 'opacity 0.2s';
    
    // Fade out slightly when hovered so it doesn't block text reading
    widgetContainer.style.opacity = '0.9';
    widgetContainer.addEventListener('mouseenter', () => {
      widgetContainer.style.opacity = '0.15';
    });
    widgetContainer.addEventListener('mouseleave', () => {
      widgetContainer.style.opacity = '0.9';
    });

    document.body.appendChild(widgetContainer);

    shadowRoot = widgetContainer.attachShadow({ mode: 'closed' });

    // CSS styling inside Shadow DOM
    const style = document.createElement('style');
    style.textContent = `
      .widget-box {
        width: 80px;
        height: 100px;
        background-color: #faf7f0;
        border: 2px solid #5a4b41;
        border-radius: 4px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 4px;
        box-sizing: border-box;
        font-family: 'Hiragino Mincho ProN', 'Yu Mincho', serif;
        position: relative;
        overflow: hidden;
      }
      
      .washi-bg {
        position: absolute;
        top: 0; left: 0; right: 0; bottom: 0;
        opacity: 0.04;
        background-image: radial-gradient(circle at 50% 50%, #000 1%, transparent 1%);
        background-size: 30px 30px;
        pointer-events: none;
      }

      #canvas {
        width: 70px;
        height: 70px;
        background-color: #ffffff;
        border: 1px solid rgba(0,0,0,0.05);
        border-radius: 2px;
      }

      .timer-text {
        font-size: 11px;
        font-weight: bold;
        color: #2b2b29;
        margin-top: 4px;
        letter-spacing: 0.5px;
      }
      
      .timer-text.work {
        color: #345c32; /* green */
      }

      .timer-text.break {
        color: #a22b2b; /* red */
      }
    `;

    const widgetBox = document.createElement('div');
    widgetBox.className = 'widget-box';

    const washi = document.createElement('div');
    washi.className = 'washi-bg';

    const canvas = document.createElement('canvas');
    canvas.id = 'canvas';
    canvas.width = 70;
    canvas.height = 70;

    const timerText = document.createElement('div');
    timerText.className = 'timer-text';
    timerText.id = 'timer-text';

    widgetBox.appendChild(washi);
    widgetBox.appendChild(canvas);
    widgetBox.appendChild(timerText);
    
    shadowRoot.appendChild(style);
    shadowRoot.appendChild(widgetBox);
  }

  function removeWidget() {
    if (widgetContainer) {
      widgetContainer.remove();
      widgetContainer = null;
      shadowRoot = null;
    }
  }

  // Update Widget UI (Clock & Bonsai canvas draw)
  function updateWidgetUI() {
    if (!shadowRoot || !localState) return;

    const timerText = shadowRoot.getElementById('timer-text');
    const canvas = shadowRoot.getElementById('canvas');

    if (timerText) {
      const minutes = Math.floor(localState.timeLeft / 60);
      const seconds = localState.timeLeft % 60;
      timerText.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
      
      timerText.className = `timer-text ${localState.mode}`;
    }

    if (canvas) {
      drawBonsaiOnWidget(canvas, localState.bonsaiStage, localState.bonsaiHealth);
    }
  }

  // Draw scaled Bonsai inside mini widget canvas
  function drawBonsaiOnWidget(canvasEl, stage, health) {
    const ctx = canvasEl.getContext('2d');
    const w = canvasEl.width;
    const h = canvasEl.height;
    
    ctx.clearRect(0, 0, w, h);
    
    const cx = w / 2;
    const SoilY = h - 14;
    const potW = w * 0.7;
    const potH = h * 0.12;
    
    // Soil
    ctx.beginPath();
    ctx.ellipse(cx, SoilY, potW / 2 - 2, 4, 0, 0, 2 * Math.PI);
    ctx.fillStyle = '#6e503b';
    ctx.fill();
    
    // Pot
    ctx.beginPath();
    ctx.roundRect(cx - potW / 2, SoilY, potW, potH, 2);
    ctx.fillStyle = '#1c2e4a';
    ctx.fill();
    ctx.lineWidth = 0.5;
    ctx.strokeStyle = '#c5a059';
    ctx.stroke();

    if (health === 0) {
      // Withered
      ctx.beginPath();
      ctx.moveTo(cx, SoilY);
      ctx.quadraticCurveTo(cx - 5, SoilY - 10, cx + 2, SoilY - 20);
      ctx.quadraticCurveTo(cx + 10, SoilY - 30, cx, SoilY - 40);
      ctx.lineWidth = 2.0;
      ctx.strokeStyle = '#5a4b41';
      ctx.stroke();
    } else {
      switch(stage) {
        case 1: // Sprout
          ctx.beginPath();
          ctx.moveTo(cx, SoilY);
          ctx.quadraticCurveTo(cx - 1, SoilY - 5, cx + 1, SoilY - 9);
          ctx.lineWidth = 1.5;
          ctx.strokeStyle = '#5fa352';
          ctx.stroke();
          break;
        case 2: // Sapling
          ctx.beginPath();
          ctx.moveTo(cx, SoilY);
          ctx.quadraticCurveTo(cx - 2, SoilY - 10, cx + 1, SoilY - 25);
          ctx.lineWidth = 2;
          ctx.strokeStyle = '#5d4b3e';
          ctx.stroke();
          
          // Little leaves
          ctx.fillStyle = '#4c993f';
          ctx.fillRect(cx - 3, SoilY - 15, 3, 2);
          ctx.fillRect(cx + 1, SoilY - 22, 3, 2);
          break;
        case 3: // Small Bonsai
          ctx.beginPath();
          ctx.moveTo(cx, SoilY);
          ctx.quadraticCurveTo(cx - 5, SoilY - 10, cx + 1, SoilY - 20);
          ctx.quadraticCurveTo(cx + 7, SoilY - 28, cx + 2, SoilY - 35);
          ctx.lineWidth = 2.5;
          ctx.strokeStyle = '#5d4b3e';
          ctx.stroke();
          
          // Foliage clouds
          drawMiniFoliage(ctx, cx + 2, SoilY - 35, 8);
          drawMiniFoliage(ctx, cx - 7, SoilY - 22, 6);
          break;
        case 4: // Mature
        case 5: // Blooming
          ctx.beginPath();
          ctx.moveTo(cx, SoilY);
          ctx.quadraticCurveTo(cx - 8, SoilY - 10, cx + 2, SoilY - 24);
          ctx.quadraticCurveTo(cx + 10, SoilY - 35, cx + 5, SoilY - 45);
          ctx.lineWidth = 3.5;
          ctx.strokeStyle = '#5d4b3e';
          ctx.stroke();
          
          // Foliage clouds
          drawMiniFoliage(ctx, cx + 5, SoilY - 45, 12);
          drawMiniFoliage(ctx, cx - 12, SoilY - 28, 10);
          drawMiniFoliage(ctx, cx + 18, SoilY - 32, 8);

          if (stage === 5) {
            // メインパネル(popup.js)のdrawCherryBlossomsと見た目を揃えた小型の花房。
            // 以前は2x2pxの点3つだけで、満開でもほぼ緑一色にしか見えなかった。
            drawMiniBlossoms(ctx, cx + 5, SoilY - 45, 12);
            drawMiniBlossoms(ctx, cx - 12, SoilY - 28, 10);
            drawMiniBlossoms(ctx, cx + 18, SoilY - 32, 8);
          }
          break;
      }
    }
  }

  function drawMiniFoliage(ctx, x, y, r) {
    ctx.fillStyle = '#2c4c2d';
    ctx.beginPath();
    ctx.arc(x, y, r, 0, 2 * Math.PI);
    ctx.arc(x - r * 0.4, y + r * 0.1, r * 0.7, 0, 2 * Math.PI);
    ctx.arc(x + r * 0.4, y + r * 0.1, r * 0.6, 0, 2 * Math.PI);
    ctx.fill();
  }

  function drawMiniBlossoms(ctx, x, y, r) {
    ctx.fillStyle = '#ffb6c1';
    ctx.beginPath();
    ctx.arc(x - r * 0.4, y - r * 0.2, r * 0.45, 0, 2 * Math.PI);
    ctx.arc(x + r * 0.4, y - r * 0.1, r * 0.4, 0, 2 * Math.PI);
    ctx.arc(x, y - r * 0.5, r * 0.4, 0, 2 * Math.PI);
    ctx.fill();
  }

  // Show a full screen warning when visiting a blacklisted tab
  function showDistractionWarning(secondsLeft) {
    if (!warningOverlay) {
      warningOverlay = document.createElement('div');
      warningOverlay.id = 'bonsai-warning-overlay-root';
      warningOverlay.style.position = 'fixed';
      warningOverlay.style.top = '0';
      warningOverlay.style.left = '0';
      warningOverlay.style.width = '100vw';
      warningOverlay.style.height = '100vh';
      warningOverlay.style.zIndex = '99999999';
      document.body.appendChild(warningOverlay);

      warningShadowRoot = warningOverlay.attachShadow({ mode: 'closed' });

      const style = document.createElement('style');
      style.textContent = `
        .overlay {
          width: 100%;
          height: 100%;
          background-color: rgba(162, 43, 43, 0.95); /* Deep warning red */
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          color: #ffffff;
          font-family: 'Hiragino Mincho ProN', 'Yu Mincho', serif;
          text-align: center;
          animation: pulseBg 2s infinite alternate;
        }

        @keyframes pulseBg {
          0% { background-color: rgba(130, 20, 20, 0.95); }
          100% { background-color: rgba(185, 40, 40, 0.97); }
        }

        h2 {
          font-size: 32px;
          margin: 0 0 20px 0;
          letter-spacing: 2px;
          text-shadow: 0 2px 4px rgba(0,0,0,0.5);
        }

        p {
          font-size: 16px;
          line-height: 1.6;
          margin: 0 0 30px 0;
          color: #fce4e4;
        }

        .countdown {
          font-size: 80px;
          font-weight: bold;
          margin-bottom: 20px;
          text-shadow: 0 4px 10px rgba(0,0,0,0.4);
        }

        .alert-icon {
          font-size: 40px;
          margin-bottom: 10px;
        }
      `;

      const overlay = document.createElement('div');
      overlay.className = 'overlay';

      const icon = document.createElement('div');
      icon.className = 'alert-icon';
      icon.textContent = '🏮 雑念感知 🏮';

      const h2 = document.createElement('h2');
      h2.textContent = '雑念が侵入しています！';

      const p = document.createElement('p');
      p.innerHTML = 'このままこのサイト（誘惑サイト）に滞在し続けると、<br>あなたの修行中の盆栽が枯れてしまいます。早く戻りましょう！';

      const counter = document.createElement('div');
      counter.className = 'countdown';
      counter.id = 'countdown-num';

      overlay.appendChild(icon);
      overlay.appendChild(h2);
      overlay.appendChild(p);
      overlay.appendChild(counter);

      warningShadowRoot.appendChild(style);
      warningShadowRoot.appendChild(overlay);
    }

    const numEl = warningShadowRoot.getElementById('countdown-num');
    if (numEl) {
      numEl.textContent = secondsLeft;
    }
  }

  function hideDistractionWarning() {
    if (warningOverlay) {
      warningOverlay.remove();
      warningOverlay = null;
      warningShadowRoot = null;
    }
  }

  // --- Web Audio API Synthesizers (Offline Electronic Sound Engine) ---
  let audioCtx = null;

  function initAudio() {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    // resume context if suspended (browser security autoplay policy)
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
  }

  // Synthesize Japanese Temple Bell/Drum (和太鼓 - Taiko)
  function playTaiko() {
    try {
      initAudio();
      const now = audioCtx.currentTime;

      // Drum oscillator (Sine wave with dramatic pitch drop)
      const osc = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      
      osc.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      
      osc.type = 'sine';
      // Deep thumping drum frequency
      osc.frequency.setValueAtTime(160, now);
      osc.frequency.exponentialRampToValueAtTime(35, now + 0.35);
      
      gainNode.gain.setValueAtTime(1.2, now);
      gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.8);
      
      osc.start(now);
      osc.stop(now + 0.95);

      // Low end resonance (Sub-drum)
      const subOsc = audioCtx.createOscillator();
      const subGain = audioCtx.createGain();
      
      subOsc.connect(subGain);
      subGain.connect(audioCtx.destination);
      
      subOsc.type = 'sine';
      subOsc.frequency.setValueAtTime(75, now);
      subOsc.frequency.exponentialRampToValueAtTime(30, now + 0.4);
      
      subGain.gain.setValueAtTime(0.8, now);
      subGain.gain.exponentialRampToValueAtTime(0.001, now + 1.2);
      
      subOsc.start(now);
      subOsc.stop(now + 1.3);

    } catch (e) {
      console.warn("AudioContext failed to initialize or play sound:", e);
    }
  }

  // Synthesize Japanese Wind Chime (風鈴 - Furin)
  function playFurin() {
    try {
      initAudio();
      const now = audioCtx.currentTime;

      // Furin is synthesized via multiple clean, high frequencies that decay slowly
      // and strike at slightly different times (simulating metal chime hitting glass).
      const chimeFrequencies = [
        { f: 1400, delay: 0, decay: 1.8, vol: 0.35 },
        { f: 1850, delay: 0.02, decay: 1.4, vol: 0.2 },
        { f: 2300, delay: 0.05, decay: 1.0, vol: 0.15 },
        { f: 2800, delay: 0.08, decay: 0.8, vol: 0.1 }
      ];

      chimeFrequencies.forEach(chime => {
        const strikeTime = now + chime.delay;
        const osc = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        
        osc.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        
        osc.type = 'sine';
        osc.frequency.setValueAtTime(chime.f, strikeTime);
        
        // Pitch modulation representing movement
        osc.frequency.linearRampToValueAtTime(chime.f + 10, strikeTime + chime.decay);

        gainNode.gain.setValueAtTime(0, now);
        gainNode.gain.setValueAtTime(chime.vol, strikeTime);
        gainNode.gain.exponentialRampToValueAtTime(0.001, strikeTime + chime.decay);
        
        osc.start(strikeTime);
        osc.stop(strikeTime + chime.decay + 0.1);
      });
      
    } catch (e) {
      console.warn("AudioContext failed to play wind chime:", e);
    }
  }

  // Play a sad withered sound when Bonsai dies
  function playDeathSound() {
    try {
      initAudio();
      const now = audioCtx.currentTime;

      // Sad detuned descending oscillators
      const frequencies = [180, 175, 170];
      frequencies.forEach((f, idx) => {
        const osc = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        
        osc.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(f, now);
        osc.frequency.linearRampToValueAtTime(f - 80, now + 1.5);
        
        gainNode.gain.setValueAtTime(0.15, now);
        gainNode.gain.linearRampToValueAtTime(0.001, now + 1.5);
        
        osc.start(now);
        osc.stop(now + 1.6);
      });
    } catch (e) {
      console.warn("AudioContext failed to play death sound:", e);
    }
  }

})();


// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  // 拡張機能ごとに一意なDOM ID接頭辞。この接頭辞を使わずリテラル文字列のIDのままだと、
  // 同じ仕組みを使う他の拡張機能(ext04/ext10/ext32等)と同じページ上でIDが衝突し、
  // document.getElementByIdが他拡張機能のコンテナを誤って見つけてしまう
  // (アイコンをクリックすると別の拡張機能のパネルが開くバグの原因だった)。
  const NS_ID = "wano-" + chrome.runtime.id;

  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // パネル自身が持つiframeは、ドラッグ中に一時的にpointer-eventsを無効化する。
      // 有効なままだと、ドラッグでマウスがiframe上を通った瞬間にmousemove/mouseup
      // がiframe側に奪われ、親ドキュメントがドラッグ終了を検知できなくなる。
      const iframeEl = element.querySelector("iframe");
      if (iframeEl) iframeEl.style.setProperty("pointer-events", "none", "important");

      // Add temporary shield to prevent iframe from stealing mouse events during dragging
      const existingShield = document.getElementById(NS_ID + "-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = NS_ID + "-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      // Use getBoundingClientRect() for correct viewport-relative position
      // (element.offsetTop is unreliable for position:fixed elements on scrolled pages)
      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      // Restrict within window boundaries to prevent going offscreen
      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const iframeEl = element.querySelector("iframe");
      if (iframeEl) iframeEl.style.removeProperty("pointer-events");
      const shield = document.getElementById(NS_ID + "-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById(NS_ID + "-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "block" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = NS_ID + "-floating-container";

    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 552) + "px !important; z-index:2147483647 !important; width:542px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="${NS_ID}-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">Bonsai Timer</span>
        </div>
        <button id="${NS_ID}-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#" + NS_ID + "-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#" + NS_ID + "-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
