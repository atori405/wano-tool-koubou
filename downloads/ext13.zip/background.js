// background.js - Focused Bonsai Timer State Manager

let timerState = {
  isRunning: false,
  mode: 'idle', // 'work', 'break', 'idle'
  timeLeft: 25 * 60, // remaining seconds
  totalDuration: 25 * 60,
  endTime: 0, // timestamp when current session ends
  bonsaiStage: 1, // 1: Sprout, 2: Sapling, 3: Small, 4: Mature, 5: Blooming
  bonsaiHealth: 100, // 0 to 100
  currentCycle: 0, // completed work cycles
  blacklist: ['youtube.com', 'twitter.com', 'x.com', 'instagram.com', 'facebook.com', 'netflix.com'],
  showWidget: true,
  debugMode: false,
  workDuration: 25, // minutes
  breakDuration: 5   // minutes
};

// Warning timer state for blacklisted pages
let warningTimer = null;
let warningSecondsLeft = 10;
let warningTabId = null;

// Initialize on install or startup
chrome.runtime.onInstalled.addListener(async () => {
  const result = await chrome.storage.local.get('bonsaiTimerState');
  if (result.bonsaiTimerState) {
    timerState = { ...timerState, ...result.bonsaiTimerState };
  } else {
    await saveState();
  }
});

chrome.runtime.onStartup.addListener(async () => {
  await loadState();
  
  // If browser was closed during active run, recover remaining time or reset
  if (timerState.isRunning && timerState.endTime > 0) {
    const now = Date.now();
    if (now >= timerState.endTime) {
      handleSessionComplete();
    } else {
      timerState.timeLeft = Math.max(0, Math.ceil((timerState.endTime - now) / 1000));
      chrome.alarms.create("pomodoro_end", { when: timerState.endTime });
    }
  }
});

async function loadState() {
  const result = await chrome.storage.local.get('bonsaiTimerState');
  if (result.bonsaiTimerState) {
    timerState = { ...timerState, ...result.bonsaiTimerState };
  }
}

async function saveState() {
  await chrome.storage.local.set({ bonsaiTimerState: timerState });
  
  // Sync state to any open content script widgets
  chrome.tabs.query({}, tabs => {
    tabs.forEach(tab => {
      chrome.tabs.sendMessage(tab.id, { action: 'updateState', state: timerState }).catch(e => {});
    });
  });
}

// Start Timer
async function startTimer() {
  await loadState();
  
  const now = Date.now();
  timerState.isRunning = true;
  
  if (timerState.mode === 'idle' || timerState.mode === 'break_ended' || timerState.mode === 'work_ended') {
    timerState.mode = 'work';
    timerState.totalDuration = timerState.debugMode ? 10 : timerState.workDuration * 60;
  } else if (timerState.mode === 'break') {
    const isLongBreak = timerState.currentCycle % 4 === 0 && timerState.currentCycle > 0;
    timerState.totalDuration = timerState.debugMode ? 5 : (isLongBreak ? timerState.breakDuration * 3 * 60 : timerState.breakDuration * 60);
  }
  
  timerState.timeLeft = timerState.totalDuration;
  timerState.endTime = now + (timerState.timeLeft * 1000);
  
  chrome.alarms.create("pomodoro_end", { when: timerState.endTime });
  
  // Play Start Sound
  triggerSound('drum');
  
  await saveState();
  
  // Check active tab immediately
  checkCurrentTab();
}

// Stop / Reset Timer
async function stopTimer() {
  chrome.alarms.clear("pomodoro_end");
  stopWarning();
  
  timerState.isRunning = false;
  timerState.mode = 'idle';
  timerState.timeLeft = timerState.debugMode ? 10 : timerState.workDuration * 60;
  timerState.totalDuration = timerState.timeLeft;
  timerState.endTime = 0;
  
  await saveState();
}

// Alarm Handler (Session Completion)
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "pomodoro_end") {
    handleSessionComplete();
  }
});

// Handle Pomodoro session completion
async function handleSessionComplete() {
  await loadState();
  stopWarning();
  chrome.alarms.clear("pomodoro_end");
  
  timerState.isRunning = false;
  
  if (timerState.mode === 'work') {
    timerState.currentCycle++;
    timerState.mode = 'break';
    
    // Bonsai growth logic
    if (timerState.bonsaiHealth < 100) {
      timerState.bonsaiHealth = 100; // Restore health
    } else {
      timerState.bonsaiStage = Math.min(5, timerState.bonsaiStage + 1); // Grow
    }
    
    // Setup break timer (long break every 4 cycles)
    const isLongBreak = timerState.currentCycle % 4 === 0;
    timerState.totalDuration = timerState.debugMode ? 5 : (isLongBreak ? timerState.breakDuration * 3 * 60 : timerState.breakDuration * 60);
    timerState.timeLeft = timerState.totalDuration;
    timerState.endTime = Date.now() + (timerState.timeLeft * 1000);
    timerState.isRunning = true;
    chrome.alarms.create("pomodoro_end", { when: timerState.endTime });
    
    triggerSound('wind_chime');
    
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: '集中終了（修行達成）',
      message: '集中時間が終了しました！盆栽が成長しました。休憩に入りましょう。'
    });
    
  } else if (timerState.mode === 'break') {
    timerState.mode = 'work';
    timerState.totalDuration = timerState.debugMode ? 10 : timerState.workDuration * 60;
    timerState.timeLeft = timerState.totalDuration;
    timerState.endTime = Date.now() + (timerState.timeLeft * 1000);
    timerState.isRunning = true;
    chrome.alarms.create("pomodoro_end", { when: timerState.endTime });
    
    triggerSound('drum');
    
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: '休憩終了（修行再開）',
      message: '休憩時間が終了しました！新しい集中セッションを開始します。'
    });
  }
  
  await saveState();
}

// Blacklist distraction monitoring
chrome.tabs.onActivated.addListener(() => {
  checkCurrentTab();
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' || changeInfo.url) {
    checkCurrentTab();
  }
});

async function checkCurrentTab() {
  await loadState();
  
  if (!timerState.isRunning || timerState.mode !== 'work') {
    stopWarning();
    return;
  }
  
  const activeTabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  const activeTab = activeTabs[0];
  if (!activeTab || !activeTab.url) {
    stopWarning();
    return;
  }
  
  try {
    const url = new URL(activeTab.url);
    const hostname = url.hostname.toLowerCase();
    
    const isBlocked = timerState.blacklist.some(domain => {
      const trimmed = domain.trim().toLowerCase();
      return hostname === trimmed || hostname.endsWith('.' + trimmed);
    });
    
    if (isBlocked) {
      startWarning(activeTab.id);
    } else {
      stopWarning();
    }
  } catch (e) {
    stopWarning();
  }
}

function startWarning(tabId) {
  if (warningTimer) {
    if (warningTabId === tabId) return;
    clearInterval(warningTimer);
  }
  
  warningTabId = tabId;
  warningSecondsLeft = 10;
  
  chrome.tabs.sendMessage(tabId, { action: 'showWarning', secondsLeft: warningSecondsLeft }).catch(e => {});
  
  warningTimer = setInterval(async () => {
    warningSecondsLeft--;
    
    chrome.tabs.sendMessage(tabId, { action: 'showWarning', secondsLeft: warningSecondsLeft }).catch(e => {});
    
    if (warningSecondsLeft <= 0) {
      clearInterval(warningTimer);
      warningTimer = null;
      await triggerPenalty(tabId);
    }
  }, 1000);
}

function stopWarning() {
  if (warningTimer) {
    clearInterval(warningTimer);
    warningTimer = null;
  }
  warningTabId = null;
  
  chrome.tabs.query({}, tabs => {
    tabs.forEach(tab => {
      chrome.tabs.sendMessage(tab.id, { action: 'hideWarning' }).catch(e => {});
    });
  });
}

// Trigger penalty (wither Bonsai)
async function triggerPenalty(tabId) {
  chrome.alarms.clear("pomodoro_end");
  
  timerState.isRunning = false;
  timerState.mode = 'idle';
  timerState.bonsaiHealth = 0;
  timerState.endTime = 0;
  timerState.timeLeft = timerState.debugMode ? 10 : timerState.workDuration * 60;
  timerState.totalDuration = timerState.timeLeft;
  
  await saveState();
  
  chrome.tabs.sendMessage(tabId, { action: 'penaltyTriggered' }).catch(e => {});
  
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: '修行失敗（盆栽枯死）',
    message: '雑念に負けてしまいました！盆栽が枯れてしまいました。もう一度精神統一を行いましょう。'
  });
}

function triggerSound(type) {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const activeTab = tabs[0];
    if (activeTab) {
      chrome.tabs.sendMessage(activeTab.id, { action: 'playSound', type }).catch(e => {});
    }
  });
}

// Handle Popup Messages
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getState') {
    if (timerState.isRunning && timerState.endTime > 0) {
      timerState.timeLeft = Math.max(0, Math.ceil((timerState.endTime - Date.now()) / 1000));
    }
    sendResponse(timerState);
  } 
  else if (request.action === 'start') {
    startTimer();
    sendResponse({ success: true });
  } 
  else if (request.action === 'stop') {
    stopTimer();
    sendResponse({ success: true });
  }
  else if (request.action === 'toggleWidget') {
    timerState.showWidget = request.value;
    saveState();
    sendResponse({ success: true });
  }
  else if (request.action === 'updateBlacklist') {
    timerState.blacklist = request.list;
    saveState();
    sendResponse({ success: true });
  }
  else if (request.action === 'toggleDebug') {
    timerState.debugMode = request.value;
    timerState.timeLeft = timerState.debugMode ? 10 : timerState.workDuration * 60;
    timerState.totalDuration = timerState.timeLeft;
    saveState();
    sendResponse({ success: true });
  }
  else if (request.action === 'updateDuration') {
    timerState.workDuration = request.workDuration;
    timerState.breakDuration = request.breakDuration;
    if (!timerState.isRunning && timerState.mode !== 'break') {
      timerState.timeLeft = request.workDuration * 60;
      timerState.totalDuration = request.workDuration * 60;
    }
    saveState();
    sendResponse({ success: true });
  }
  return true;
});
