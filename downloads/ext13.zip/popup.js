// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // フローティングパネル(iframe)表示のときは、body側のCSSで固定340px/overflow:hiddenの
  // 制約を外す(下のpopup.css参照)。この固定値はネイティブポップアップ用の設計で、
  // フローティングパネルの実際の高さ(~580px)よりずっと小さいため、そのままだと
  // 「時間の設定」「デスクトップ卓上盆栽を表示」欄が隠れて見えなくなってしまう。
  if (mode === "floating") {
    document.body.classList.add("wano-mode-floating");
  }

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  function openFallbackWindow() {
    // Fail-safe: Open popup.html as a draggable Chrome popup window
    var w = Math.min(screen.availWidth, 536);
    var h = Math.min(screen.availHeight, 390);
    var left = Math.round((screen.availWidth - w) / 2);
    var top = Math.round((screen.availHeight - h) / 4);
    chrome.windows.create({
      url: chrome.runtime.getURL("popup.html?mode=window"),
      type: "popup",
      width: w,
      height: h,
      left: left,
      top: top,
      focused: true
    });
  }

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        var tabId = tabs[0].id;
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabId, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Content script is likely stale/missing on this tab (e.g. the tab was
            // already open before the extension was installed/updated). Re-inject it
            // on demand and retry once before falling back to a separate OS window
            // (the separate-window fallback can vanish and never reappear).
            if (chrome.scripting) {
              chrome.scripting.executeScript({
                target: { tabId: tabId },
                files: ["draggable.js", "content.js"]
              }, function() {
                if (chrome.runtime.lastError) {
                  openFallbackWindow();
                  window.close();
                  return;
                }
                chrome.tabs.sendMessage(tabId, { action: "toggleFloatingPanel" }, function(response2) {
                  if (chrome.runtime.lastError || !response2 || response2.status !== "toggled") {
                    openFallbackWindow();
                  }
                  window.close();
                });
              });
              return;
            }
            openFallbackWindow();
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 536,
          height: 390,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// popup.js - Focused Bonsai Timer Controller

document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const canvas = document.getElementById('bonsai-canvas');
  const timerClock = document.getElementById('timer-clock');
  const timerMode = document.getElementById('timer-mode');
  const startBtn = document.getElementById('start-btn');
  const stopBtn = document.getElementById('stop-btn');
  const resetBonsaiBtn = document.getElementById('reset-bonsai-btn');
  const showWidgetCheck = document.getElementById('show-widget-check');
  const debugModeCheck = document.getElementById('debug-mode-check');
  const blacklistInput = document.getElementById('blacklist-input');
  const addBlacklistBtn = document.getElementById('add-blacklist-btn');
  const blacklistList = document.getElementById('blacklist-list');
  const pomodoroCycles = document.getElementById('pomodoro-cycles');
  const stageNameEl = document.getElementById('bonsai-stage-name');
  const healthFillEl = document.getElementById('bonsai-health-fill');
  const healthValEl = document.getElementById('bonsai-health-val');
  
  // New Settings Elements
  const workDurationSelect = document.getElementById('work-duration-select');
  const breakDurationSelect = document.getElementById('break-duration-select');

  // Standalone Mode flag (when running as page iframe or extension not installed)
  let isStandalone = true;
  let localTimerInterval = null;

  let state = {
    isRunning: false,
    mode: 'idle',
    timeLeft: 25 * 60,
    totalDuration: 25 * 60,
    endTime: 0,
    bonsaiStage: 1,
    bonsaiHealth: 100,
    currentCycle: 0,
    blacklist: [],
    showWidget: true,
    debugMode: false,
    workDuration: 25, // minutes
    breakDuration: 5   // minutes
  };

  // Check if extension API is available
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) {
    isStandalone = false;
  }

  // Stage Names dictionary
  const STAGE_NAMES = {
    1: "第一段階：若芽",
    2: "第二段階：若木",
    3: "第三段階：小品盆栽",
    4: "第四段階：中品盆栽",
    5: "最高段階：満開桜"
  };

  // Request state from background and update UI
  async function refreshState() {
    if (isStandalone) {
      updateUI();
      return;
    }
    chrome.runtime.sendMessage({ action: 'getState' }, (response) => {
      if (chrome.runtime.lastError || !response) {
        // Fallback to standalone mode if background communication fails
        isStandalone = true;
        updateUI();
        return;
      }
      state = response;
      updateUI();
    });
  }

  // Draw the Bonsai dynamically on the HTML5 Canvas
  function drawBonsai(canvasEl, stage, health) {
    const ctx = canvasEl.getContext('2d');
    const w = canvasEl.width;
    const h = canvasEl.height;
    
    // Clear canvas
    ctx.clearRect(0, 0, w, h);
    
    const cx = w / 2;
    const SoilY = h - 35;
    const potW = w * 0.65;
    const potH = h * 0.12;
    
    // 1. Draw soil hill
    ctx.beginPath();
    ctx.ellipse(cx, SoilY, potW / 2 - 2, 8, 0, 0, 2 * Math.PI);
    ctx.fillStyle = '#6e503b'; // soil brown
    ctx.fill();
    
    // 2. Draw traditional ceramic pot (deep blue)
    ctx.beginPath();
    ctx.roundRect(cx - potW / 2, SoilY, potW, potH, 4);
    ctx.fillStyle = '#1c2e4a'; // indigo blue
    ctx.fill();
    ctx.lineWidth = 1;
    ctx.strokeStyle = '#c5a059'; // gold trim
    ctx.stroke();
    
    // Pot legs
    ctx.fillStyle = '#1c2e4a';
    ctx.fillRect(cx - potW / 3, SoilY + potH, 6, 4);
    ctx.fillRect(cx + potW / 3 - 6, SoilY + potH, 6, 4);
    
    // Soil layer top border inside pot
    ctx.beginPath();
    ctx.moveTo(cx - potW / 2 + 1, SoilY);
    ctx.lineTo(cx + potW / 2 - 1, SoilY);
    ctx.strokeStyle = '#523a2a';
    ctx.lineWidth = 2;
    ctx.stroke();

    // 3. Draw Bonsai Tree (depending on health and stage)
    if (health === 0) {
      drawWitheredTree(ctx, cx, SoilY, h);
    } else {
      switch(stage) {
        case 1:
          drawSprout(ctx, cx, SoilY);
          break;
        case 2:
          drawSapling(ctx, cx, SoilY, h);
          break;
        case 3:
          drawSmallBonsai(ctx, cx, SoilY, h);
          break;
        case 4:
          drawMatureBonsai(ctx, cx, SoilY, h, false);
          break;
        case 5:
          drawMatureBonsai(ctx, cx, SoilY, h, true);
          break;
      }
    }
  }

  // Withered Tree Drawer
  function drawWitheredTree(ctx, cx, SoilY, h) {
    ctx.beginPath();
    ctx.moveTo(cx, SoilY);
    ctx.quadraticCurveTo(cx - 10, SoilY - 20, cx + 5, SoilY - 40);
    ctx.quadraticCurveTo(cx + 20, SoilY - 60, cx, SoilY - 80);
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#5a4b41'; // dry bark
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(cx + 1, SoilY - 40);
    ctx.quadraticCurveTo(cx - 15, SoilY - 50, cx - 20, SoilY - 65);
    ctx.lineWidth = 2.5;
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(cx + 10, SoilY - 60);
    ctx.quadraticCurveTo(cx + 25, SoilY - 68, cx + 30, SoilY - 80);
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.fillStyle = '#8a654e';
    ctx.beginPath();
    ctx.arc(cx - 20, SoilY + 2, 2, 0, 2*Math.PI);
    ctx.arc(cx + 15, SoilY + 3, 1.5, 0, 2*Math.PI);
    ctx.arc(cx + 2, SoilY + 4, 2, 0, 2*Math.PI);
    ctx.fill();
  }

  // Stage 1 Sprout Drawer
  function drawSprout(ctx, cx, SoilY) {
    ctx.beginPath();
    ctx.moveTo(cx, SoilY);
    ctx.quadraticCurveTo(cx - 2, SoilY - 10, cx + 2, SoilY - 18);
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = '#5fa352'; // green stem
    ctx.stroke();

    ctx.beginPath();
    ctx.ellipse(cx + 2, SoilY - 18, 5, 2.5, -Math.PI / 6, 0, 2 * Math.PI);
    ctx.fillStyle = '#78c662';
    ctx.fill();

    ctx.beginPath();
    ctx.ellipse(cx - 2, SoilY - 16, 4.5, 2.5, Math.PI / 4, 0, 2 * Math.PI);
    ctx.fillStyle = '#78c662';
    ctx.fill();
  }

  // Stage 2 Sapling Drawer
  function drawSapling(ctx, cx, SoilY, h) {
    ctx.beginPath();
    ctx.moveTo(cx, SoilY);
    ctx.quadraticCurveTo(cx - 5, SoilY - 18, cx, SoilY - 35);
    ctx.quadraticCurveTo(cx + 5, SoilY - 48, cx + 1, SoilY - 55);
    ctx.lineWidth = 3.5;
    ctx.strokeStyle = '#5d4b3e'; // brown stem
    ctx.stroke();

    const leafPoints = [
      { x: cx, y: SoilY - 22, rot: -Math.PI / 4 },
      { x: cx + 2, y: SoilY - 38, rot: Math.PI / 4 },
      { x: cx + 1, y: SoilY - 55, rot: -Math.PI / 6 }
    ];

    leafPoints.forEach(pt => {
      ctx.beginPath();
      ctx.ellipse(pt.x, pt.y, 7, 3, pt.rot, 0, 2 * Math.PI);
      ctx.fillStyle = '#4c993f';
      ctx.fill();
      ctx.strokeStyle = '#32662a';
      ctx.lineWidth = 0.5;
      ctx.stroke();
    });
  }

  // Stage 3 Small Bonsai Drawer
  function drawSmallBonsai(ctx, cx, SoilY, h) {
    ctx.beginPath();
    ctx.moveTo(cx, SoilY);
    ctx.quadraticCurveTo(cx - 12, SoilY - 22, cx + 2, SoilY - 45);
    ctx.quadraticCurveTo(cx + 15, SoilY - 60, cx + 5, SoilY - 72);
    ctx.lineWidth = 5.5;
    ctx.strokeStyle = '#5d4b3e';
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(cx - 4, SoilY - 35);
    ctx.quadraticCurveTo(cx - 20, SoilY - 42, cx - 25, SoilY - 52);
    ctx.lineWidth = 2.5;
    ctx.stroke();

    drawFoliageCloud(ctx, cx + 5, SoilY - 72, 16);
    drawFoliageCloud(ctx, cx - 25, SoilY - 52, 13);
  }

  // Stage 4 & 5 Mature/Master Bonsai Drawer
  function drawMatureBonsai(ctx, cx, SoilY, h, isBlooming) {
    ctx.beginPath();
    ctx.moveTo(cx, SoilY);
    ctx.quadraticCurveTo(cx - 22, SoilY - 25, cx + 5, SoilY - 55);
    ctx.quadraticCurveTo(cx + 25, SoilY - 78, cx + 10, SoilY - 95);
    ctx.lineWidth = 8.5;
    ctx.strokeStyle = '#5d4b3e';
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(cx - 2, SoilY - 8);
    ctx.quadraticCurveTo(cx - 18, SoilY - 25, cx + 2, SoilY - 53);
    ctx.strokeStyle = '#43342b';
    ctx.lineWidth = 1;
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(cx - 8, SoilY - 40);
    ctx.quadraticCurveTo(cx - 30, SoilY - 48, cx - 42, SoilY - 62);
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#5d4b3e';
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(cx + 12, SoilY - 68);
    ctx.quadraticCurveTo(cx + 38, SoilY - 75, cx + 46, SoilY - 88);
    ctx.lineWidth = 3;
    ctx.stroke();

    drawFoliageCloud(ctx, cx + 10, SoilY - 95, 26);
    drawFoliageCloud(ctx, cx - 42, SoilY - 62, 20);
    drawFoliageCloud(ctx, cx + 46, SoilY - 88, 16);

    if (isBlooming) {
      drawCherryBlossoms(ctx, cx + 10, SoilY - 95, 28);
      drawCherryBlossoms(ctx, cx - 42, SoilY - 62, 22);
      drawCherryBlossoms(ctx, cx + 46, SoilY - 88, 18);
      
      ctx.fillStyle = '#ffc0cb'; // light pink
      ctx.beginPath();
      ctx.arc(cx - 22, SoilY - 22, 2, 0, 2*Math.PI);
      ctx.arc(cx + 28, SoilY - 45, 1.5, 0, 2*Math.PI);
      ctx.arc(cx - 32, SoilY + 3, 2, 0, 2*Math.PI);
      ctx.arc(cx + 18, SoilY + 2, 1.5, 0, 2*Math.PI);
      ctx.fill();
    }
  }

  function drawFoliageCloud(ctx, x, y, r) {
    ctx.fillStyle = '#2c4c2d'; // Pine green
    ctx.beginPath();
    ctx.arc(x, y, r, 0, 2 * Math.PI);
    ctx.arc(x - r * 0.5, y + r * 0.1, r * 0.8, 0, 2 * Math.PI);
    ctx.arc(x + r * 0.5, y + r * 0.1, r * 0.7, 0, 2 * Math.PI);
    ctx.fill();

    ctx.fillStyle = '#3f6740';
    ctx.beginPath();
    ctx.arc(x - r * 0.1, y - r * 0.2, r * 0.6, 0, 2 * Math.PI);
    ctx.fill();
  }

  function drawCherryBlossoms(ctx, x, y, r) {
    ctx.fillStyle = '#ffb6c1'; // Cherry pink
    ctx.beginPath();
    ctx.arc(x - r*0.4, y - r*0.2, r*0.4, 0, 2*Math.PI);
    ctx.arc(x + r*0.4, y - r*0.1, r*0.35, 0, 2*Math.PI);
    ctx.arc(x, y - r*0.5, r*0.35, 0, 2*Math.PI);
    ctx.arc(x - r*0.7, y + r*0.1, r*0.3, 0, 2*Math.PI);
    ctx.arc(x + r*0.7, y + r*0.1, r*0.3, 0, 2*Math.PI);
    ctx.fill();

    ctx.fillStyle = '#ff69b4';
    ctx.beginPath();
    ctx.arc(x - r*0.4, y - r*0.2, 1.5, 0, 2*Math.PI);
    ctx.arc(x + r*0.4, y - r*0.1, 1.2, 0, 2*Math.PI);
    ctx.arc(x, y - r*0.5, 1.2, 0, 2*Math.PI);
    ctx.fill();
  }

  // Sync state variables to the popup UI elements
  function updateUI() {
    // Sync Select elements if not focused
    if (document.activeElement !== workDurationSelect) {
      workDurationSelect.value = state.workDuration;
    }
    if (document.activeElement !== breakDurationSelect) {
      breakDurationSelect.value = state.breakDuration;
    }

    // 1. Mode display
    if (state.isRunning) {
      if (state.mode === 'work') {
        timerMode.textContent = "精神統一中 (作業)";
        timerMode.style.color = "var(--color-matsu)";
        startBtn.disabled = true;
        stopBtn.disabled = false;
      } else if (state.mode === 'break') {
        timerMode.textContent = "修行休憩中 (休息)";
        timerMode.style.color = "var(--color-shu)";
        startBtn.disabled = true;
        stopBtn.disabled = false;
      }
    } else {
      timerMode.textContent = "待機中";
      timerMode.style.color = "var(--color-susu)";
      startBtn.disabled = false;
      stopBtn.disabled = true;
      
      if (state.mode === 'work_ended') {
        timerMode.textContent = "修行達成！";
      } else if (state.mode === 'break_ended') {
        timerMode.textContent = "休憩終了";
      }
    }

    // 2. Format timer clock
    const minutes = Math.floor(state.timeLeft / 60);
    const seconds = state.timeLeft % 60;
    timerClock.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

    // 3. Update Bonsai status panel
    if (state.bonsaiHealth === 0) {
      stageNameEl.textContent = "枯れてしまった盆栽";
      stageNameEl.style.backgroundColor = "var(--color-shu-light)";
      stageNameEl.style.color = "var(--color-shu)";
    } else {
      stageNameEl.textContent = STAGE_NAMES[state.bonsaiStage] || "盆栽";
      stageNameEl.style.backgroundColor = "var(--color-matsu-light)";
      stageNameEl.style.color = "var(--color-matsu)";
    }

    healthValEl.textContent = `${state.bonsaiHealth}%`;
    healthFillEl.style.width = `${state.bonsaiHealth}%`;
    
    if (state.bonsaiHealth <= 30) {
      healthFillEl.style.backgroundColor = "var(--color-shu)";
    } else {
      healthFillEl.style.backgroundColor = "var(--color-matsu)";
    }

    // 4. Draw Bonsai Canvas
    drawBonsai(canvas, state.bonsaiStage, state.bonsaiHealth);

    // 5. Render Pomodoro cycles
    const dots = pomodoroCycles.querySelectorAll('.cycle-dot');
    dots.forEach((dot, index) => {
      if (index < state.currentCycle % 4) {
        dot.className = 'cycle-dot filled';
      } else {
        dot.className = 'cycle-dot empty';
      }
    });

    // 6. Checkboxes settings
    showWidgetCheck.checked = state.showWidget;
    debugModeCheck.checked = state.debugMode;

    // 7. Render Blacklist
    renderBlacklist();
  }

  // Render Blacklist domains
  function renderBlacklist() {
    blacklistList.innerHTML = '';
    
    if (state.blacklist.length === 0) {
      blacklistList.innerHTML = '<div style="font-size: 8px; color: #aaa; text-align: center; padding: 10px;">登録されていません</div>';
      return;
    }

    state.blacklist.forEach((domain, idx) => {
      const item = document.createElement('div');
      item.className = 'blacklist-item';
      
      const domainSpan = document.createElement('span');
      domainSpan.className = 'blacklist-domain';
      domainSpan.textContent = domain;
      domainSpan.title = domain;

      const removeBtn = document.createElement('button');
      removeBtn.className = 'remove-blacklist-btn';
      removeBtn.textContent = '×';
      removeBtn.addEventListener('click', () => {
        if (isStandalone) {
          state.blacklist = state.blacklist.filter((_, i) => i !== idx);
          updateUI();
          return;
        }
        const newList = state.blacklist.filter((_, i) => i !== idx);
        chrome.runtime.sendMessage({ action: 'updateBlacklist', list: newList }, refreshState);
      });

      item.appendChild(domainSpan);
      item.appendChild(removeBtn);
      blacklistList.appendChild(item);
    });
  }

  // --- Standalone Timer Logic (Demo fallback) ---
  function startLocalTimer() {
    if (localTimerInterval) clearInterval(localTimerInterval);
    
    state.isRunning = true;
    if (state.mode === 'idle' || state.mode === 'work_ended' || state.mode === 'break_ended') {
      state.mode = 'work';
      state.totalDuration = state.debugMode ? 10 : state.workDuration * 60;
      state.timeLeft = state.totalDuration;
    }

    updateUI();

    localTimerInterval = setInterval(() => {
      if (!state.isRunning) {
        clearInterval(localTimerInterval);
        return;
      }

      state.timeLeft--;
      if (state.timeLeft <= 0) {
        clearInterval(localTimerInterval);
        
        // Cycle transition
        if (state.mode === 'work') {
          state.mode = 'break';
          state.currentCycle++;
          
          // Growth bonsai
          if (state.bonsaiStage < 5 && state.bonsaiHealth > 0) {
            state.bonsaiStage++;
          }
          state.bonsaiHealth = Math.min(100, state.bonsaiHealth + 10);
          
          state.totalDuration = state.debugMode ? 5 : state.breakDuration * 60;
          state.timeLeft = state.totalDuration;
          
          alert("集中修行が達成されました！盆栽が成長しました。休憩に入ります。");
          startLocalTimer();
        } else {
          state.mode = 'idle';
          state.isRunning = false;
          alert("休憩が終了しました。次の修行を開始しましょう！");
          updateUI();
        }
      } else {
        updateUI();
      }
    }, 1000);
  }

  function stopLocalTimer() {
    if (localTimerInterval) clearInterval(localTimerInterval);
    state.isRunning = false;
    state.mode = 'idle';
    // Penalty
    state.bonsaiHealth = Math.max(0, state.bonsaiHealth - 25);
    state.totalDuration = state.workDuration * 60;
    state.timeLeft = state.totalDuration;
    updateUI();
  }

  function resetLocalBonsai() {
    state.bonsaiStage = 1;
    state.bonsaiHealth = 100;
    updateUI();
  }

  // Button Action: Start Timer
  startBtn.addEventListener('click', () => {
    if (isStandalone) {
      startLocalTimer();
      return;
    }
    chrome.runtime.sendMessage({ action: 'start' }, refreshState);
  });

  // Button Action: Stop Timer
  stopBtn.addEventListener('click', () => {
    const confirmMsg = "修行（集中）を途中で辞めると盆栽の健康状態が損なわれる恐れがあります。本当に中断しますか？";
    if (confirm(confirmMsg)) {
      if (isStandalone) {
        stopLocalTimer();
        return;
      }
      chrome.runtime.sendMessage({ action: 'stop' }, refreshState);
    }
  });

  // Button Action: Reset Bonsai to initial state
  resetBonsaiBtn.addEventListener('click', () => {
    const confirmMsg = "盆栽をリセットすると、これまでの成長段階と樹勢が最初の状態（第一段階・樹勢100%）に戻ります。よろしいですか？";
    if (confirm(confirmMsg)) {
      if (isStandalone) {
        resetLocalBonsai();
        return;
      }
      chrome.runtime.sendMessage({ action: 'resetBonsai' }, refreshState);
    }
  });

  // Duration Select events
  workDurationSelect.addEventListener('change', (e) => {
    const val = parseInt(e.target.value, 10);
    state.workDuration = val;
    if (!state.isRunning && state.mode !== 'break') {
      state.totalDuration = val * 60;
      state.timeLeft = val * 60;
      updateUI();
    }
    if (!isStandalone) {
      chrome.runtime.sendMessage({ 
        action: 'updateDuration', 
        workDuration: state.workDuration, 
        breakDuration: state.breakDuration 
      }, refreshState);
    }
  });

  breakDurationSelect.addEventListener('change', (e) => {
    const val = parseInt(e.target.value, 10);
    state.breakDuration = val;
    if (!isStandalone) {
      chrome.runtime.sendMessage({ 
        action: 'updateDuration', 
        workDuration: state.workDuration, 
        breakDuration: state.breakDuration 
      }, refreshState);
    }
  });

  // Toggle Action: Floating Widget Visibility
  showWidgetCheck.addEventListener('change', (e) => {
    if (isStandalone) {
      state.showWidget = e.target.checked;
      updateUI();
      return;
    }
    chrome.runtime.sendMessage({ action: 'toggleWidget', value: e.target.checked }, refreshState);
  });

  // Toggle Action: Debug mode
  debugModeCheck.addEventListener('change', (e) => {
    if (isStandalone) {
      state.debugMode = e.target.checked;
      if (!state.isRunning) {
        state.totalDuration = state.debugMode ? 10 : state.workDuration * 60;
        state.timeLeft = state.totalDuration;
      }
      updateUI();
      return;
    }
    chrome.runtime.sendMessage({ action: 'toggleDebug', value: e.target.checked }, refreshState);
  });

  // Action: Add Blacklist domain
  addBlacklistBtn.addEventListener('click', () => {
    const domain = blacklistInput.value.trim().toLowerCase();
    if (!domain) return;

    const domainRegex = /^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!domainRegex.test(domain)) {
      alert("有効なドメイン名を入力してください（例: youtube.com ）。");
      return;
    }

    if (state.blacklist.includes(domain)) {
      alert("すでに登録されているドメインです。");
      return;
    }

    if (isStandalone) {
      state.blacklist.push(domain);
      blacklistInput.value = '';
      updateUI();
      return;
    }

    const newList = [...state.blacklist, domain];
    chrome.runtime.sendMessage({ action: 'updateBlacklist', list: newList }, () => {
      blacklistInput.value = '';
      refreshState();
    });
  });

  blacklistInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      addBlacklistBtn.click();
    }
  });

  // Refresh interval while popup is open
  refreshState();
  const pollInterval = setInterval(refreshState, 1000);

  // Clear interval on unload
  window.addEventListener('unload', () => {
    clearInterval(pollInterval);
    if (localTimerInterval) clearInterval(localTimerInterval);
  });
});
