// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  // 拡張機能ごとに一意なDOM ID接頭辞。この接頭辞を使わずリテラル文字列のIDのままだと、
  // 同じ仕組みを使う他の拡張機能と同じページ上でIDが衝突し、
  // document.getElementByIdが他拡張機能のコンテナを誤って見つけてしまう。
  const NS_ID = "wano-" + chrome.runtime.id;

  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #e06a3b", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // パネル自身が持つiframeは、ドラッグ中に一時的にpointer-eventsを無効化する。
      // 有効なままだと、ドラッグでマウスがiframe上を通った瞬間にmousemove/mouseup
      // がiframe側に奪われ、親ドキュメントがドラッグ終了を検知できなくなる。
      const iframeEl = element.querySelector("iframe");
      if (iframeEl) iframeEl.style.setProperty("pointer-events", "none", "important");

      const existingShield = document.getElementById(NS_ID + "-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = NS_ID + "-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const iframeEl = element.querySelector("iframe");
      if (iframeEl) iframeEl.style.removeProperty("pointer-events");
      const shield = document.getElementById(NS_ID + "-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById(NS_ID + "-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "flex" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = NS_ID + "-floating-container";

    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:30px !important; left:" + Math.max(10, window.innerWidth - 820) + "px !important; z-index:2147483647 !important; width:806px !important; height:706px !important; background-color:#faf7f0 !important; border:1.5px solid rgba(90, 75, 65, 0.35) !important; border-radius:8px !important; box-shadow:0 10px 45px rgba(0,0,0,0.5) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="${NS_ID}-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#5a4b41; border-bottom:1px solid rgba(90,75,65,0.4); padding:8px 14px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:15px;">稿</span>
          <span style="font-size:12px; font-weight:700; color:#faf7f0; font-family:sans-serif;">原稿用紙 換算君</span>
        </div>
        <button id="${NS_ID}-close" style="background:none; border:none; color:#faf7f0; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    const header = container.querySelector("#" + NS_ID + "-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#" + NS_ID + "-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
