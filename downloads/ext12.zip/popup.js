// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  function openFallbackWindow() {
    // Fail-safe: Open popup.html as a draggable Chrome popup window
    var w = Math.min(screen.availWidth, 800);
    var h = Math.min(screen.availHeight, 720);
    var left = Math.round((screen.availWidth - w) / 2);
    var top = Math.round((screen.availHeight - h) / 4);
    chrome.windows.create({
      url: chrome.runtime.getURL("popup.html?mode=window"),
      type: "popup",
      width: w,
      height: h,
      left: left,
      top: top,
      focused: true
    });
  }

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        var tabId = tabs[0].id;
        chrome.tabs.sendMessage(tabId, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Content script is likely stale/missing on this tab (e.g. the tab was
            // already open before the extension was installed/updated). Re-inject it
            // on demand and retry once before falling back to a separate OS window
            // (the separate-window fallback can vanish and never reappear).
            if (chrome.scripting) {
              chrome.scripting.executeScript({
                target: { tabId: tabId },
                files: ["content.js"]
              }, function() {
                if (chrome.runtime.lastError) {
                  openFallbackWindow();
                  window.close();
                  return;
                }
                chrome.tabs.sendMessage(tabId, { action: "toggleFloatingPanel" }, function(response2) {
                  if (chrome.runtime.lastError || !response2 || response2.status !== "toggled") {
                    openFallbackWindow();
                  }
                  window.close();
                });
              });
              return;
            }
            openFallbackWindow();
          }
          window.close();
        });
      } else {
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 800,
          height: 720,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// popup.js - Manuscript counter and checker logic

document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const textarea = document.getElementById('manuscript-input');
  const excludeSpacesCheck = document.getElementById('exclude-spaces');
  const charCountEl = document.getElementById('char-count');
  const pageCountEl = document.getElementById('page-count');
  const readTimeEl = document.getElementById('read-time');
  const previewCanvas = document.getElementById('preview-canvas');
  const themeDots = document.querySelectorAll('.theme-dot');
  const mannerResultsList = document.getElementById('manner-results-list');
  
  // Actions
  const copyBtn = document.getElementById('copy-btn');
  const downloadBtn = document.getElementById('download-btn');
  const clearBtn = document.getElementById('clear-btn');
  const fixIndentBtn = document.getElementById('fix-indent-btn');
  const fixAlphaBtn = document.getElementById('fix-alpha-btn');

  // Configuration & State
  let activeTheme = 'orange';

  // Load saved draft and options
  chrome.storage.local.get(['manuscriptDraft', 'excludeSpaces', 'activeTheme'], (result) => {
    if (result.manuscriptDraft) {
      textarea.value = result.manuscriptDraft;
    }
    if (result.excludeSpaces !== undefined) {
      excludeSpacesCheck.checked = result.excludeSpaces;
    }
    if (result.activeTheme) {
      activeTheme = result.activeTheme;
      setTheme(activeTheme);
    }
    updateAll();
  });

  // Theme changing
  themeDots.forEach(dot => {
    dot.addEventListener('click', () => {
      const theme = dot.getAttribute('data-theme');
      setTheme(theme);
      chrome.storage.local.set({ activeTheme: theme });
    });
  });

  function setTheme(theme) {
    themeDots.forEach(d => d.classList.remove('active'));
    const activeDot = document.querySelector(`.theme-dot.${theme}`);
    if (activeDot) activeDot.classList.add('active');

    // Update active-grid color
    let colorValue = '#e06a3b'; // Default orange
    if (theme === 'green') colorValue = '#3e6040';
    if (theme === 'gray') colorValue = '#7f8c8d';

    document.documentElement.style.setProperty('--active-grid', colorValue);

    // Faint version of the same color for the inner cell grid lines only,
    // so the sheet border/gyobi stay bold while the repeated cell lines
    // don't visually compete with the written characters.
    const r = parseInt(colorValue.slice(1, 3), 16);
    const g = parseInt(colorValue.slice(3, 5), 16);
    const b = parseInt(colorValue.slice(5, 7), 16);
    document.documentElement.style.setProperty('--active-grid-line', `rgba(${r}, ${g}, ${b}, 0.35)`);

    activeTheme = theme;
  }

  // Update logic helper
  function updateAll() {
    const text = textarea.value;
    
    // Save draft
    chrome.storage.local.set({ manuscriptDraft: text });

    // Calculate stats
    const stats = calculateStats(text);
    charCountEl.textContent = stats.charCount;
    pageCountEl.textContent = `${stats.pages.toFixed(1)} 枚`;
    readTimeEl.textContent = `約 ${stats.readTime}分`;

    // Perform Layout & Render
    renderManuscriptGrid(text);

    // Manner Check
    runMannerCheck(text, stats.columns);
  }

  // Trigger update on events
  textarea.addEventListener('input', updateAll);
  excludeSpacesCheck.addEventListener('change', () => {
    chrome.storage.local.set({ excludeSpaces: excludeSpacesCheck.checked });
    updateAll();
  });

  // Calculate statistics
  function calculateStats(text) {
    let charCountText = text;
    if (excludeSpacesCheck.checked) {
      // Remove spaces, tabs, and newlines
      charCountText = text.replace(/\s/g, '');
    }
    const charCount = charCountText.length;

    // Estimate read time: ~400 characters per minute
    const readTime = Math.ceil(charCount / 400) || 0;

    // Simulate column breakdown (used for the visual preview and manner check)
    const columns = layoutTextToColumns(text);
    // 原稿用紙換算枚数: 単純な文字数÷400ではなく、段落末尾の余白（改行による
    // 行の消費）や行頭禁則処理を反映した列数ベースで算出する。これにより、
    // 実際に原稿用紙に書き写したときに消費する枚数に忠実な値になる
    // （記事で謳っている「段落改行を反映した正確な枚数換算」の実装）。
    // 20列 = 1枚（400字詰め原稿用紙）
    const pages = columns.length / 20;

    return {
      charCount,
      readTime,
      pages,
      columns
    };
  }

  // Simulate text layout onto 20-character vertical columns
  function layoutTextToColumns(text) {
    const columns = [];
    let currentColumn = [];
    
    // Punctuation that shouldn't go to the top of a column (Kinsoku Shori)
    const kinsokuChars = new Set(['。', '、', '」', '』', '）', '｝', '】', '？', '！', '…', 'ー']);

    // Split text into paragraphs
    const paragraphs = text.split('\n');

    paragraphs.forEach((para, pIdx) => {
      // Skip last empty item if it's just a terminal newline
      if (pIdx === paragraphs.length - 1 && para === "") return;

      let chars = Array.from(para);
      
      // Genko Yoshi rule: Paragraph starts with a space (Indentation)
      // If paragraph is empty, it's just a blank line
      if (chars.length === 0) {
        // Empty paragraph represents a blank line, i.e., 1 blank column
        columns.push(Array(20).fill(""));
        return;
      }

      // We read through the paragraph character by character
      for (let i = 0; i < chars.length; i++) {
        const char = chars[i];

        // If current column is full, wrap it
        if (currentColumn.length === 20) {
          // Check if next character is a punctuation (Kinsoku Shori)
          if (kinsokuChars.has(char)) {
            // Push the punctuation to the bottom of the current column (overlaying or margin concept)
            // In physical paper it sits on the bottom border or same cell. We append it to the last cell.
            const lastIdx = currentColumn.length - 1;
            currentColumn[lastIdx] = currentColumn[lastIdx] + char;
            continue; // Go to next character
          }

          // Otherwise wrap to a new column
          columns.push(currentColumn);
          currentColumn = [];
        }

        // If current column is empty and we encounter a punctuation (Kinsoku Shori at top of column)
        if (currentColumn.length === 0 && kinsokuChars.has(char)) {
          // Append to previous column's bottom cell
          if (columns.length > 0) {
            const prevCol = columns[columns.length - 1];
            const lastIdx = prevCol.length - 1;
            prevCol[lastIdx] = prevCol[lastIdx] + char;
            continue;
          }
        }

        currentColumn.push(char);
      }

      // Finish paragraph: pad current column and add it
      if (currentColumn.length > 0) {
        while (currentColumn.length < 20) {
          currentColumn.push("");
        }
        columns.push(currentColumn);
        currentColumn = [];
      }
    });

    return columns;
  }

  // Render Horizontal pages of Genko Yoshi
  function renderManuscriptGrid(text) {
    previewCanvas.innerHTML = '';
    
    const columns = layoutTextToColumns(text);
    
    // Group columns into sheets of 20
    const columnsPerSheet = 20;
    const sheetCount = Math.max(1, Math.ceil(columns.length / columnsPerSheet));

    // Limit preview to 10 sheets to prevent browser crash for huge text
    const maxSheets = 10;
    const sheetsToRender = Math.min(sheetCount, maxSheets);

    for (let s = 0; s < sheetsToRender; s++) {
      const sheetDiv = document.createElement('div');
      sheetDiv.className = 'genko-sheet';

      // Title/fold middle indicator (Gyobi)
      const gyobiDiv = document.createElement('div');
      gyobiDiv.className = 'gyobi-column';
      gyobiDiv.innerHTML = `
        <div class="gyobi-mark"></div>
        <div class="gyobi-text">四〇〇字</div>
        <div class="gyobi-page-num">${s + 1}</div>
        <div class="gyobi-mark bottom"></div>
      `;

      // Extract 20 columns for this sheet
      const sheetCols = [];
      for (let c = 0; c < 20; c++) {
        const globalColIdx = s * columnsPerSheet + c;
        if (globalColIdx < columns.length) {
          sheetCols.push(columns[globalColIdx]);
        } else {
          sheetCols.push(Array(20).fill("")); // empty column padding
        }
      }

      // Render columns 1 to 10 (Right side of sheet)
      for (let c = 0; c < 10; c++) {
        const colDiv = document.createElement('div');
        colDiv.className = 'genko-column';
        
        sheetCols[c].forEach(char => {
          const cellDiv = document.createElement('div');
          cellDiv.className = 'genko-cell';
          cellDiv.textContent = char;
          colDiv.appendChild(cellDiv);
        });
        sheetDiv.appendChild(colDiv);
      }

      // Render Gyobi center divider
      sheetDiv.appendChild(gyobiDiv);

      // Render columns 11 to 20 (Left side of sheet)
      for (let c = 10; c < 20; c++) {
        const colDiv = document.createElement('div');
        colDiv.className = 'genko-column';
        
        sheetCols[c].forEach(char => {
          const cellDiv = document.createElement('div');
          cellDiv.className = 'genko-cell';
          cellDiv.textContent = char;
          colDiv.appendChild(cellDiv);
        });
        sheetDiv.appendChild(colDiv);
      }

      previewCanvas.appendChild(sheetDiv);
    }

    // Show indicator if some sheets are hidden
    if (sheetCount > maxSheets) {
      const moreDiv = document.createElement('div');
      moreDiv.style.display = 'flex';
      moreDiv.style.alignItems = 'center';
      moreDiv.style.padding = '0 20px';
      moreDiv.style.color = 'var(--color-susu)';
      moreDiv.style.fontFamily = 'serif';
      moreDiv.style.fontSize = '12px';
      moreDiv.style.writingMode = 'vertical-rl';
      moreDiv.textContent = `...以下省略（計 ${sheetCount} 枚）`;
      previewCanvas.appendChild(moreDiv);
    }
  }

  //推敲マナーチェックの実行
  function runMannerCheck(text, columns) {
    mannerResultsList.innerHTML = '';
    const warnings = [];

    if (!text.trim()) {
      mannerResultsList.innerHTML = `
        <div class="manner-item info">
          <span class="manner-icon">✓</span>
          <span class="manner-msg">文章を入力すると、段落の字下げや行頭禁則などの推敲チェックが実行されます。</span>
        </div>
      `;
      return;
    }

    // 1. Check Paragraph Indentations
    const paragraphs = text.split('\n');
    let indentErrors = 0;
    paragraphs.forEach((para, idx) => {
      // Ignore empty lines
      if (!para.trim()) return;
      
      const firstChar = para.charAt(0);
      // Check if first char is full-width space or half-width space
      if (firstChar !== '　' && firstChar !== ' ') {
        indentErrors++;
      }
    });

    if (indentErrors > 0) {
      warnings.push({
        type: 'warn',
        msg: `段落の冒頭が一字下げ（全角スペース）されていない箇所が ${indentErrors} 箇所あります。「一字下げを自動適用」で修正できます。`
      });
    }

    // 2. Check Half-width letters and digits (Alphanumeric)
    const halfWidthRegex = /[a-zA-Z0-9]/g;
    const matches = text.match(halfWidthRegex);
    if (matches && matches.length > 0) {
      // Find unique matches to show examples
      const uniqueMatches = Array.from(new Set(matches)).slice(0, 5);
      warnings.push({
        type: 'warn',
        msg: `半角英数字（${uniqueMatches.join(', ')}など）が検出されました。縦書き原稿では全角（または漢数字）表記が推奨されます。「英数記号を全角に変換」で自動置換できます。`
      });
    }

    // 3. Punctuation wrapping verification
    // Since our layoutTextToColumns handles Kinsoku Shori by overlaying punctuation 
    // at the bottom of the previous line, we check if there are columns where punctuation 
    // somehow ended up at row index 0 (top of the line).
    const kinsokuChars = new Set(['。', '、', '」', '』', '）', '｝', '】', '？', '！', '…', 'ー']);
    let kinsokuErrors = 0;
    
    columns.forEach((col, idx) => {
      if (col && col[0] && kinsokuChars.has(col[0].charAt(0))) {
        kinsokuErrors++;
      }
    });

    if (kinsokuErrors > 0) {
      warnings.push({
        type: 'warn',
        msg: `禁則文字（句読点や閉じ括弧）が行頭（升目の最上部）に配置されている箇所が ${kinsokuErrors} 箇所あります。自動で前行の末尾に収められますが、推敲をおすすめします。`
      });
    }

    // Render results
    if (warnings.length === 0) {
      mannerResultsList.innerHTML = `
        <div class="manner-item info" style="color: var(--grid-green)">
          <span class="manner-icon">✓</span>
          <span class="manner-msg">素晴らしい！段落の字下げや英数字の表記など、原稿執筆マナーに合致しています。</span>
        </div>
      `;
    } else {
      warnings.forEach(w => {
        const item = document.createElement('div');
        item.className = `manner-item ${w.type}`;
        item.innerHTML = `
          <span class="manner-icon">⚠️</span>
          <span class="manner-msg">${w.msg}</span>
        `;
        mannerResultsList.appendChild(item);
      });
    }
  }

  // Action: Copy Text
  copyBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(textarea.value).then(() => {
      const originalText = copyBtn.textContent;
      copyBtn.textContent = 'コピー完了！';
      setTimeout(() => {
        copyBtn.textContent = originalText;
      }, 1500);
    });
  });

  // Action: Download Text file
  downloadBtn.addEventListener('click', () => {
    const text = textarea.value;
    if (!text) {
      alert("ダウンロードするテキストがありません。");
      return;
    }
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    // Name with current timestamp
    const now = new Date();
    const dateStr = `${now.getFullYear()}${String(now.getMonth()+1).padStart(2,'0')}${String(now.getDate()).padStart(2,'0')}_${String(now.getHours()).padStart(2,'0')}${String(now.getMinutes()).padStart(2,'0')}`;
    a.download = `manuscript_${dateStr}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  });

  // Action: Clear text
  clearBtn.addEventListener('click', () => {
    if (confirm("入力した文章をすべて消去しますか？")) {
      textarea.value = '';
      updateAll();
    }
  });

  // Action: Fix Indentations
  fixIndentBtn.addEventListener('click', () => {
    const text = textarea.value;
    const paragraphs = text.split('\n');
    
    const fixedParas = paragraphs.map(para => {
      if (!para.trim()) return para; // Keep empty lines as is
      
      const firstChar = para.charAt(0);
      if (firstChar !== '　' && firstChar !== ' ') {
        return '　' + para; // Prepend full-width space
      }
      return para;
    });

    textarea.value = fixedParas.join('\n');
    updateAll();
  });

  // Action: Convert Alphanumeric to Full-width
  fixAlphaBtn.addEventListener('click', () => {
    const text = textarea.value;
    
    // Function to convert half-width to full-width
    const toFullWidth = (str) => {
      return str.replace(/[A-Za-z0-9]/g, (s) => {
        return String.fromCharCode(s.charCodeAt(0) + 0xFEE0);
      });
    };

    textarea.value = toFullWidth(text);
    updateAll();
  });
});
