chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "getItemDetails") {
    try {
      const details = getItemDetails();
      sendResponse(details);
    } catch (e) {
      sendResponse({ error: e.message });
    }
  }
  return true;
});

function parsePrice(text) {
  if (!text) return null;
  // Remove currency symbols, commas, Japanese yen, and spaces
  const cleaned = text.replace(/[¥￥,円\s]/g, "");
  const num = parseInt(cleaned, 10);
  return isNaN(num) ? null : num;
}

function parseShipping(text) {
  if (!text) return null;
  if (text.includes("送料無料") || text.includes("無料")) {
    return 0;
  }
  // Extract first group of digits (ignoring commas)
  const match = text.replace(/,/g, "").match(/(\d+)/);
  if (match) {
    return parseInt(match[1], 10);
  }
  return null;
}

function getItemDetails() {
  const hostname = window.location.hostname;
  let price = null;
  let shipping = 0; // Default to free shipping
  let title = document.title || "商品";

  // Attempt to extract cleaner product title from h1
  const h1 = document.querySelector("h1");
  if (h1) {
    title = h1.innerText.trim();
  }

  if (hostname.includes("amazon.co.jp")) {
    // 1. Amazon Price Selectors
    const priceSelectors = [
      ".a-price .a-offscreen",
      "#price_inside_buybox",
      "#priceblock_ourprice",
      "#priceblock_dealprice",
      ".sw-price-landing-value",
      ".a-price-whole"
    ];
    for (let sel of priceSelectors) {
      const el = document.querySelector(sel);
      if (el && el.innerText) {
        price = parsePrice(el.innerText);
        if (price) break;
      }
    }
    
    // 2. Amazon Shipping Selectors
    const shippingSelectors = [
      "#ourprice_shippingmessage",
      "#price-shipping-message",
      ".shipping-message",
      "#price_inside_buybox_shipping",
      "#fast-track-message",
      ".delivery-block"
    ];
    let shippingText = "";
    for (let sel of shippingSelectors) {
      const el = document.querySelector(sel);
      if (el && el.innerText) {
        shippingText = el.innerText;
        break;
      }
    }
    // Try checking standard delivery blocks if not matched
    if (!shippingText) {
      const deliveryEl = document.querySelector("#deliveryBlockMessage");
      if (deliveryEl) shippingText = deliveryEl.innerText;
    }

    if (shippingText) {
      if (shippingText.includes("通常配送無料") || shippingText.includes("送料無料") || shippingText.includes("無料")) {
        shipping = 0;
      } else {
        const parsed = parseShipping(shippingText);
        if (parsed !== null) shipping = parsed;
      }
    }

  } else if (hostname.includes("rakuten.co.jp")) {
    // 1. Rakuten Price Selectors
    const priceSelectors = [
      ".price--3j817",
      "#price2",
      ".price2",
      "[data-price]"
    ];
    for (let sel of priceSelectors) {
      const el = document.querySelector(sel);
      if (sel === "[data-price]" && el) {
        price = parsePrice(el.getAttribute("data-price"));
        if (price) break;
      }
      if (el && el.innerText) {
        price = parsePrice(el.innerText);
        if (price) break;
      }
    }
    
    // 2. Rakuten Shipping Selectors
    const shippingSelectors = [
      ".shipping--3p2e_",
      ".postage",
      ".tax-postage-shipping",
      ".shipping-fee",
      ".purchase-shipping-fee"
    ];
    let shippingText = "";
    for (let sel of shippingSelectors) {
      const el = document.querySelector(sel);
      if (el && el.innerText) {
        shippingText = el.innerText;
        break;
      }
    }
    
    if (shippingText) {
      if (shippingText.includes("送料無料")) {
        shipping = 0;
      } else {
        const parsed = parseShipping(shippingText);
        if (parsed !== null) shipping = parsed;
      }
    }

  } else if (hostname.includes("yahoo.co.jp")) {
    // 1. Yahoo Shopping Price Selectors
    const priceSelectors = [
      ".elPriceValue",
      ".elPrice",
      ".priceValue",
      "[data-price]"
    ];
    for (let sel of priceSelectors) {
      const el = document.querySelector(sel);
      if (el && el.innerText) {
        price = parsePrice(el.innerText);
        if (price) break;
      }
    }
    
    // 2. Yahoo Shipping Selectors
    const shippingSelectors = [
      ".elPostageValue",
      ".elDeliveryFee",
      ".elShippingFee",
      ".postage"
    ];
    let shippingText = "";
    for (let sel of shippingSelectors) {
      const el = document.querySelector(sel);
      if (el && el.innerText) {
        shippingText = el.innerText;
        break;
      }
    }
    
    if (shippingText) {
      if (shippingText.includes("送料無料")) {
        shipping = 0;
      } else {
        const parsed = parseShipping(shippingText);
        if (parsed !== null) shipping = parsed;
      }
    }
  }

  // Clean and truncate product title for UI display
  if (title) {
    title = title.replace(/\n/g, " ").trim();
    if (title.length > 35) {
      title = title.substring(0, 35) + "...";
    }
  }

  return {
    price: price,
    shipping: shipping,
    title: title,
    url: window.location.href,
    shop: hostname.includes("amazon") ? "Amazon" : (hostname.includes("rakuten") ? "楽天市場" : "Yahoo!ショッピング")
  };
}


// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // Add temporary shield to prevent iframe from stealing mouse events during dragging
      const existingShield = document.getElementById("wano-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = "wano-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      // Use getBoundingClientRect() for correct viewport-relative position
      // (element.offsetTop is unreliable for position:fixed elements on scrolled pages)
      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      // Restrict within window boundaries to prevent going offscreen
      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById("wano-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById("wano-universal-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "block" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = "wano-universal-floating-container";
    
    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 440) + "px !important; z-index:2147483647 !important; width:430px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="wano-u-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">Shipping Calculator</span>
        </div>
        <button id="wano-u-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#wano-u-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#wano-u-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
