// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

document.addEventListener("DOMContentLoaded", () => {
  // UI Elements
  const prefSelect = document.getElementById("prefecture-select");
  const thresholdSelect = document.getElementById("threshold-select");
  const customThresholdGroup = document.getElementById("custom-threshold-group");
  const customThresholdInput = document.getElementById("custom-threshold-input");
  
  const meterMessage = document.getElementById("meter-message");
  const trackFill = document.getElementById("track-fill");
  const truckIcon = document.getElementById("truck-icon");
  
  const itemTitleInput = document.getElementById("item-title-input");
  const itemPriceInput = document.getElementById("item-price-input");
  const itemShippingInput = document.getElementById("item-shipping-input");
  const addItemBtn = document.getElementById("add-item-btn");
  
  const cartCount = document.getElementById("cart-count");
  const cartItemsList = document.getElementById("cart-items-list");
  
  const shippingRuleSelect = document.getElementById("shipping-rule-select");
  const flatShippingGroup = document.getElementById("flat-shipping-group");
  const flatShippingInput = document.getElementById("flat-shipping-input");
  const subtotalDisplay = document.getElementById("subtotal-display");
  const shippingDisplay = document.getElementById("shipping-display");
  const totalDisplay = document.getElementById("total-display");
  
  const clearCartBtn = document.getElementById("clear-cart-btn");
  const searchSimilarBtn = document.getElementById("search-similar-btn");
  const detectionBadge = document.getElementById("detection-badge");

  // State
  let cart = [];
  let currentPageDetails = null;

  // 1. Load preferences from local storage
  chrome.storage.local.get(["prefecture", "threshold", "shippingRule", "customThreshold", "flatShipping"], (data) => {
    if (data.prefecture) {
      prefSelect.value = data.prefecture;
    }
    if (data.threshold) {
      thresholdSelect.value = data.threshold;
      if (data.threshold === "custom") {
        customThresholdGroup.classList.remove("hidden");
        if (data.customThreshold) {
          customThresholdInput.value = data.customThreshold;
        }
      }
    }
    if (data.shippingRule) {
      shippingRuleSelect.value = data.shippingRule;
      if (data.shippingRule === "flat") {
        flatShippingGroup.classList.remove("hidden");
      }
    }
    if (data.flatShipping) {
      flatShippingInput.value = data.flatShipping;
    }
    updateCalculation();
  });

  // 2. Query active tab for product data via Content Script
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs && tabs[0]) {
      // Basic URL verification to only request from supported pages
      const url = tabs[0].url || "";
      if (url.includes("amazon.co.jp") || url.includes("rakuten.co.jp") || url.includes("yahoo.co.jp")) {
        chrome.tabs.sendMessage(tabs[0].id, { action: "getItemDetails" }, (response) => {
          if (response && !response.error && response.price) {
            currentPageDetails = response;
            
            // Auto pre-fill UI input fields
            itemTitleInput.value = response.title || "";
            itemPriceInput.value = response.price || "";
            itemShippingInput.value = response.shipping !== null ? response.shipping : "";
            
            // Set badge status to active
            detectionBadge.innerText = `自動取得: ${response.shop}`;
            detectionBadge.className = "badge badge-active";
          }
        });
      }
    }
  });

  // 3. Save Prefs on Changes
  prefSelect.addEventListener("change", () => {
    chrome.storage.local.set({ prefecture: prefSelect.value });
  });

  thresholdSelect.addEventListener("change", () => {
    const val = thresholdSelect.value;
    chrome.storage.local.set({ threshold: val });
    if (val === "custom") {
      customThresholdGroup.classList.remove("hidden");
    } else {
      customThresholdGroup.classList.add("hidden");
    }
    updateCalculation();
  });

  customThresholdInput.addEventListener("input", () => {
    const customVal = parseInt(customThresholdInput.value, 10) || 0;
    chrome.storage.local.set({ customThreshold: customVal });
    updateCalculation();
  });

  shippingRuleSelect.addEventListener("change", () => {
    const val = shippingRuleSelect.value;
    chrome.storage.local.set({ shippingRule: val });
    if (val === "flat") {
      flatShippingGroup.classList.remove("hidden");
    } else {
      flatShippingGroup.classList.add("hidden");
    }
    updateCalculation();
  });

  flatShippingInput.addEventListener("input", () => {
    const val = parseInt(flatShippingInput.value, 10) || 0;
    chrome.storage.local.set({ flatShipping: val });
    updateCalculation();
  });

  // 4. Cart Logic: Add item to list
  addItemBtn.addEventListener("click", () => {
    const title = itemTitleInput.value.trim() || "商品";
    const price = parseInt(itemPriceInput.value, 10);
    const shipping = parseInt(itemShippingInput.value, 10) || 0;

    if (isNaN(price) || price < 0) {
      alert("正しい商品単価を入力してください。");
      return;
    }

    const newItem = {
      id: Date.now(),
      title: title,
      price: price,
      shipping: shipping,
      qty: 1
    };

    cart.push(newItem);
    updateCalculation();
    renderCart();

    // Reset input fields but preserve details
    itemTitleInput.value = "";
    itemPriceInput.value = "";
    itemShippingInput.value = "";
  });

  // 5. Render list items in Cart area
  function renderCart() {
    cartItemsList.innerHTML = "";
    if (cart.length === 0) {
      cartItemsList.innerHTML = '<div class="empty-cart-message">カートは空です。</div>';
      cartCount.innerText = "0";
      return;
    }

    cartCount.innerText = cart.length;

    cart.forEach(item => {
      const card = document.createElement("div");
      card.className = "cart-item";
      card.innerHTML = `
        <div class="item-details">
          <div class="item-title" title="${item.title}">${item.title}</div>
          <div class="item-sub">単価: ¥${item.price.toLocaleString()} | 送料: ¥${item.shipping.toLocaleString()}</div>
        </div>
        <div class="item-controls">
          <div class="qty-controls">
            <button class="qty-btn btn-minus" data-id="${item.id}">-</button>
            <span class="qty-num">${item.qty}</span>
            <button class="qty-btn btn-plus" data-id="${item.id}">+</button>
          </div>
          <button class="delete-btn" data-id="${item.id}" title="削除">🗑️</button>
        </div>
      `;
      cartItemsList.appendChild(card);
    });

    // Register button event handlers inside list
    document.querySelectorAll(".btn-plus").forEach(btn => {
      btn.addEventListener("click", (e) => {
        const id = parseInt(e.target.getAttribute("data-id"), 10);
        const item = cart.find(x => x.id === id);
        if (item) {
          item.qty++;
          renderCart();
          updateCalculation();
        }
      });
    });

    document.querySelectorAll(".btn-minus").forEach(btn => {
      btn.addEventListener("click", (e) => {
        const id = parseInt(e.target.getAttribute("data-id"), 10);
        const item = cart.find(x => x.id === id);
        if (item && item.qty > 1) {
          item.qty--;
          renderCart();
          updateCalculation();
        }
      });
    });

    document.querySelectorAll(".delete-btn").forEach(btn => {
      btn.addEventListener("click", (e) => {
        const button = e.target.closest("button");
        const id = parseInt(button.getAttribute("data-id"), 10);
        cart = cart.filter(x => x.id !== id);
        renderCart();
        updateCalculation();
      });
    });
  }

  // 6. Calculate Subtotal, Shipping, and Final Total
  function updateCalculation() {
    let subtotal = 0;
    cart.forEach(item => {
      subtotal += item.price * item.qty;
    });

    // Check 送料無料 line threshold
    let threshold = 0;
    const thresholdType = thresholdSelect.value;
    if (thresholdType === "custom") {
      threshold = parseInt(customThresholdInput.value, 10) || 0;
    } else {
      threshold = parseInt(thresholdType, 10) || 0;
    }

    // Determine basic shipping cost before thresholds
    const rule = shippingRuleSelect.value;
    let baseShipping = 0;

    if (rule === "flat") {
      // 一律: 注文全体に対してユーザーが入力した固定送料を1つだけ適用する
      // (カート内商品の個別送料は使わない。ショップが「送料一律◯円」と
      //  提示しているケース向け)
      baseShipping = parseInt(flatShippingInput.value, 10) || 0;
    } else if (cart.length > 0) {
      if (rule === "sum") {
        // 個口別: 各商品の個別送料をすべて加算
        cart.forEach(item => {
          baseShipping += item.shipping * item.qty;
        });
      } else {
        // "max" (通常・既定): カート内で最も高い個別送料を採用
        let maxShipping = 0;
        cart.forEach(item => {
          if (item.shipping > maxShipping) maxShipping = item.shipping;
        });
        baseShipping = maxShipping;
      }
    }

    // Apply Free Shipping override if limit reached
    let finalShipping = baseShipping;
    if (threshold > 0 && subtotal >= threshold) {
      finalShipping = 0;
    }

    const total = subtotal + finalShipping;

    // Update displays
    subtotalDisplay.innerText = `¥${subtotal.toLocaleString()}`;
    shippingDisplay.innerText = `¥${finalShipping.toLocaleString()}`;
    totalDisplay.innerText = `¥${total.toLocaleString()}`;

    // Update Progress bar and truck position
    if (threshold === 0) {
      meterMessage.innerHTML = "送料無料ライン設定なし";
      trackFill.style.width = "0%";
      truckIcon.style.left = "8px";
    } else {
      const remaining = Math.max(0, threshold - subtotal);
      const percent = Math.min(100, Math.floor((subtotal / threshold) * 100));
      
      trackFill.style.width = `${percent}%`;
      // Smooth linear truck positioning towards goal
      truckIcon.style.left = `calc(8px + (84% - 8px) * (${percent} / 100))`;
      
      if (remaining === 0) {
        meterMessage.innerHTML = "🎉 <strong>送料無料達成！</strong> 🚚💨";
        trackFill.style.background = "linear-gradient(90deg, #48bb78 0%, #38a169 100%)";
      } else {
        meterMessage.innerHTML = `送料無料まであと <strong>¥${remaining.toLocaleString()}</strong>`;
        trackFill.style.background = "linear-gradient(90deg, #ff7d00 0%, #ffa852 100%)";
      }
    }
  }

  // 7. Clear Cart list
  clearCartBtn.addEventListener("click", () => {
    cart = [];
    renderCart();
    updateCalculation();
  });

  // 8. Search similar items with free shipping
  searchSimilarBtn.addEventListener("click", () => {
    let query = itemTitleInput.value.trim();
    if (!query && cart.length > 0) {
      query = cart[cart.length - 1].title;
    }
    if (!query && currentPageDetails) {
      query = currentPageDetails.title;
    }
    if (!query) {
      alert("商品名を入力してください。");
      return;
    }
    
    // Clean search text slightly (remove brackets)
    const cleanedQuery = query.replace(/[\[\]\(\)]/g, " ").trim();
    const searchUrl = `https://search.rakuten.co.jp/search/mall/${encodeURIComponent(cleanedQuery + " 送料無料")}/`;
    window.open(searchUrl, "_blank");
  });
});
