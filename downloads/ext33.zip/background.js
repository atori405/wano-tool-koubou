// background.js - Vertical Web Reader background service worker

const DEFAULT_SETTINGS = {
  fontFamily: "serif",
  fontSize: "medium",
  theme: "dark"
};

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["verticalReaderSettings"], (result) => {
    if (!result.verticalReaderSettings) {
      chrome.storage.local.set({ verticalReaderSettings: DEFAULT_SETTINGS }, () => {
        console.log("Vertical Web Reader: Default settings initialized.");
      });
    }
  });
});
