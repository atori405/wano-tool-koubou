// content.js - Vertical Web Reader Content Script

(function () {
  const OVERLAY_ID = "v-reader-screen";
  let activeOverlay = null;

  let currentSettings = {
    fontFamily: "serif",
    fontSize: "medium",
    theme: "dark"
  };

  // --- 1. Message Listener ---
  if (window.chrome && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "launchVerticalReader") {
        currentSettings = message.settings;
        launchReader();
        sendResponse({ status: "success" });
      } 
      else if (message.action === "updateReaderSettings") {
        currentSettings = message.settings;
        applySettingsToOverlay();
        sendResponse({ status: "updated" });
      }
      return true;
    });
  }

  // --- 2. Main Reader Launcher ---
  function launchReader() {
    // If already running, clean up first
    closeReader();

    // Prevent body scrolling behind the overlay
    document.documentElement.style.overflow = "hidden";
    document.body.style.overflow = "hidden";

    // Extract content
    const pageTitle = getPageTitle();
    const bodyContentHTML = extractMainContentHTML();

    // Create Overlay structure
    const overlay = document.createElement("div");
    overlay.id = OVERLAY_ID;
    
    // Smooth fade-in wrapper (z-index lowered to avoid ad-blockers)
    overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 9999;
      display: flex;
      flex-direction: row-reverse;
      opacity: 0;
      transition: opacity 0.3s ease-out;
    `;

    overlay.innerHTML = `
      <!-- Back Button -->
      <button id="v-reader-close-btn" title="リーダーを閉じる">
        <span class="v-btn-arrow">←</span>
        <span class="v-btn-text">戻る</span>
      </button>

      <!-- Scroll Wrapper (Verticalrl) -->
      <div id="v-reader-scroll-box" class="v-scroll-box">
        <div id="v-reader-book-container" class="v-book-container">
          
          <!-- Cover/Header Section -->
          <div class="v-book-cover">
            <h1 class="v-book-title">${pageTitle}</h1>
            <div class="v-book-author">${getPageAuthor()}</div>
            <div class="v-book-crest">🎴</div>
          </div>

          <!-- Main Text Section -->
          <div class="v-book-body">
            ${bodyContentHTML}
          </div>
          
        </div>
      </div>
    `;

    document.body.appendChild(overlay);
    activeOverlay = overlay;

    // Trigger transition
    setTimeout(() => {
      overlay.style.opacity = "1";
    }, 50);

    // Apply Styles (Font, Size, Theme)
    applySettingsToOverlay();

    // Bind Close Event
    overlay.querySelector("#v-reader-close-btn").addEventListener("click", () => {
      closeReader();
    });

    // Bind Mouse Wheel to Horizontal Scroll (UX Enhancement)
    const scrollBox = overlay.querySelector("#v-reader-scroll-box");
    scrollBox.addEventListener("wheel", (e) => {
      // Prevent default vertical scroll behavior
      e.preventDefault();
      // Translate vertical delta to horizontal scroll in RL direction
      // scrollLeft is negative under RTL/vertical-rl containers
      scrollBox.scrollLeft -= e.deltaY * 0.95;
    }, { passive: false });
  }

  function closeReader() {
    const existing = document.getElementById(OVERLAY_ID);
    if (existing) {
      existing.style.opacity = "0";
      setTimeout(() => {
        existing.remove();
        document.documentElement.style.overflow = "";
        document.body.style.overflow = "";
      }, 300);
    }
    activeOverlay = null;
  }

  // --- 3. Synchronize Settings (Dynamic CSS adjustments) ---
  function applySettingsToOverlay() {
    if (!activeOverlay) return;

    const scrollBox = activeOverlay.querySelector("#v-reader-scroll-box");
    const closeBtn = activeOverlay.querySelector("#v-reader-close-btn");

    // Clean previous themes/fonts
    scrollBox.className = "v-scroll-box";
    closeBtn.className = "";

    // 1. Apply Theme classes
    const theme = currentSettings.theme || "white";
    scrollBox.classList.add(`theme-${theme}`);
    closeBtn.classList.add(`theme-${theme}`);

    // 2. Apply Font classes
    const font = currentSettings.fontFamily || "serif";
    scrollBox.classList.add(`font-${font}`);

    // 3. Apply Font Size classes
    const size = currentSettings.fontSize || "medium";
    scrollBox.classList.add(`size-${size}`);
  }

  // --- 4. Page Content Extractors ---
  function getPageTitle() {
    const h1 = document.querySelector("h1");
    if (h1 && h1.textContent.trim()) {
      return sanitize(h1.textContent.trim());
    }
    return sanitize(document.title || "無題の書物");
  }

  function getPageAuthor() {
    // Attempt common metadata or author classes
    const metaAuthor = document.querySelector("meta[name='author']");
    if (metaAuthor && metaAuthor.getAttribute("content")) {
      return sanitize(metaAuthor.getAttribute("content"));
    }
    const authorEl = document.querySelector(".author, [class*='author'], .byline");
    if (authorEl && authorEl.textContent.trim()) {
      return sanitize(authorEl.textContent.trim());
    }
    // Fallback based on domain
    return sanitize(window.location.hostname);
  }

  function extractMainContentHTML() {
    // Find the primary text container by heuristic scores
    let bestContainer = null;
    let maxParagraphs = 0;

    // Check containers
    const candidates = document.querySelectorAll("article, section, [class*='content'], [class*='article'], main, div");
    candidates.forEach(cand => {
      const pCount = cand.querySelectorAll("p").length;
      if (pCount > maxParagraphs) {
        maxParagraphs = pCount;
        bestContainer = cand;
      }
    });

    // Fallback container
    if (!bestContainer || maxParagraphs < 2) {
      bestContainer = document.body;
    }

    // Get nodes inside container
    const nodes = bestContainer.querySelectorAll("h2, h3, p");
    let contentHTML = "";

    if (nodes.length > 0) {
      nodes.forEach(node => {
        // Skip nodes inside sidebars/footers/nav
        const parentString = (node.parentElement ? node.parentElement.className + " " + node.parentElement.id : "").toLowerCase();
        if (parentString.includes("sidebar") || parentString.includes("footer") || parentString.includes("nav") || parentString.includes("menu")) {
          return;
        }

        const tag = node.tagName.toLowerCase();
        
        // Clone node to avoid modifying original page DOM
        const clone = node.cloneNode(true);
        applyTateChuYokoToElement(clone);
        let text = clone.innerHTML.trim();
        
        if (!text) return;

        if (tag === "h2") {
          contentHTML += `<h2 class="v-section-title">${text}</h2>`;
        } else if (tag === "h3") {
          contentHTML += `<h3 class="v-sub-title">${text}</h3>`;
        } else {
          contentHTML += `<p class="v-paragraph">${text}</p>`;
        }
      });
    }

    // Fallback if no text blocks extracted
    if (!contentHTML || contentHTML.trim().length < 50) {
      const fallbackDiv = document.createElement("div");
      fallbackDiv.textContent = document.body.textContent.substring(0, 1500) + "...";
      applyTateChuYokoToElement(fallbackDiv);
      contentHTML = `<p class="v-paragraph">${fallbackDiv.innerHTML}</p>`;
    }

    return contentHTML;
  }

  // --- 5. Tate-Chu-Yoko Text processing (Combines 1-3 digits & short latin acronyms) ---
  function applyTateChuYokoToElement(element) {
    const children = Array.from(element.childNodes);

    children.forEach(node => {
      if (node.nodeType === 3) { // TEXT_NODE
        const text = node.nodeValue;
        const hasMatch = /\b(\d{1,3})\b/.test(text) || /\b([A-Z]{2,3})\b/.test(text);
        if (!hasMatch) return;

        // Escape raw text content safely
        const escaped = sanitize(text);

        // Perform safe replacements
        let newHTML = escaped
          .replace(/\b(\d{1,3})\b/g, '<span class="v-tcy">$1</span>')
          .replace(/\b([A-Z]{2,3})\b/g, '<span class="v-tcy">$1</span>');

        const temp = document.createElement("span");
        temp.innerHTML = newHTML;

        const parent = node.parentNode;
        if (parent) {
          while (temp.firstChild) {
            parent.insertBefore(temp.firstChild, node);
          }
          parent.removeChild(node);
        }
      } else if (node.nodeType === 1) { // ELEMENT_NODE
        if (node.classList.contains("v-tcy")) return;
        applyTateChuYokoToElement(node); // Recursive traversal
      }
    });
  }

  function sanitize(str) {
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }
})();


// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // Add temporary shield to prevent iframe from stealing mouse events during dragging
      const existingShield = document.getElementById("wano-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = "wano-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      // Use getBoundingClientRect() for correct viewport-relative position
      // (element.offsetTop is unreliable for position:fixed elements on scrolled pages)
      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      // Restrict within window boundaries to prevent going offscreen
      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById("wano-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById("wano-universal-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "block" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = "wano-universal-floating-container";
    
    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 440) + "px !important; z-index:2147483647 !important; width:430px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="wano-u-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">Vertical Web Reader</span>
        </div>
        <button id="wano-u-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#wano-u-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#wano-u-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
