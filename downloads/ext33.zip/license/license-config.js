/**
 * license-config.js
 * 
 * 拡張機能ごとの個別ライセンス商品ID設定。
 * 自動生成されたファイルです。手動で変更しないでください。
 */
window.LicenseConfig = {
  productId: "1319029",
  allToolsProductId: "1318293",
  singleCheckoutUrl: "https://wafuu-koubou.lemonsqueezy.com/checkout/buy/835fff28-6a3a-4907-baad-7706c18bc9b7",
  bundleCheckoutUrl: "https://wafuu-koubou.lemonsqueezy.com/checkout/buy/d2530690-2049-4779-8a24-0a15c803bb24"
};
