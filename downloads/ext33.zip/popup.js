// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// popup.js - Vertical Web Reader Settings Logic

document.addEventListener("DOMContentLoaded", () => {
  // --- Elements ---
  const launchBtn = document.getElementById("launch-reader-btn");
  const fontSelect = document.getElementById("reader-font-select");
  const sizeButtons = document.querySelectorAll(".segment-btn");
  const themeCells = document.querySelectorAll(".theme-cell");
  const statusText = document.getElementById("footer-status-text");

  let settings = {
    fontFamily: "serif",     // "serif", "klee", "maru"
    fontSize: "medium",      // "small", "medium", "large"
    theme: "dark"            // "white", "washi", "sepia", "dark"
  };

  let activeTabId = null;

  // --- 1. Get Current Active Tab ---
  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0]) {
        activeTabId = tabs[0].id;
        // Check if tab is http/https to enable/disable launch
        const url = tabs[0].url || "";
        if (!url.startsWith("http")) {
          launchBtn.disabled = true;
          launchBtn.style.opacity = "0.5";
          statusText.textContent = "適用不可 (Webページのみ)";
        }
      }
    });
  }

  // --- 2. Load Settings from Storage ---
  function loadSettings() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.get(["verticalReaderSettings"], (result) => {
        if (result.verticalReaderSettings) {
          settings = { ...settings, ...result.verticalReaderSettings };
        }
        applySettingsToUI();
      });
    } else {
      // Sandbox local fallback
      const saved = localStorage.getItem("verticalReaderSettings");
      if (saved) {
        settings = JSON.parse(saved);
      }
      applySettingsToUI();
    }
  }

  function saveSettings() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.set({ verticalReaderSettings: settings }, () => {
        notifyReaderSettings();
      });
    } else {
      localStorage.setItem("verticalReaderSettings", JSON.stringify(settings));
      console.log("Sandbox Saved settings:", settings);
    }
    // Sandbox parent window relay
    if (window.parent && window.parent !== window) {
      window.parent.postMessage({
        action: "updateReaderSettings",
        settings: settings
      }, "*");
    }
  }

  // --- 3. Bind UI states ---
  function applySettingsToUI() {
    // Dropdown fontFamily
    fontSelect.value = settings.fontFamily;

    // Segmented Size buttons
    sizeButtons.forEach(btn => {
      btn.classList.remove("active");
      if (btn.getAttribute("data-size") === settings.fontSize) {
        btn.classList.add("active");
      }
    });

    // Theme cells
    themeCells.forEach(cell => {
      cell.classList.remove("active");
      if (cell.getAttribute("data-theme") === settings.theme) {
        cell.classList.add("active");
      }
    });
  }

  // --- 4. Event Listeners ---
  // Font Select
  fontSelect.addEventListener("change", (e) => {
    settings.fontFamily = e.target.value;
    saveSettings();
  });

  // Size buttons click
  sizeButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      sizeButtons.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      settings.fontSize = btn.getAttribute("data-size");
      saveSettings();
    });
  });

  // Theme cells click
  themeCells.forEach(cell => {
    cell.addEventListener("click", () => {
      themeCells.forEach(c => c.classList.remove("active"));
      cell.classList.add("active");
      settings.theme = cell.getAttribute("data-theme");
      saveSettings();
    });
  });

  // Launch Reader Button Click
  launchBtn.addEventListener("click", () => {
    if (window.chrome && chrome.tabs && activeTabId) {
      statusText.textContent = "起動処理中...";
      chrome.tabs.sendMessage(activeTabId, {
        action: "launchVerticalReader",
        settings: settings
      }, (response) => {
        if (chrome.runtime.lastError) {
          statusText.textContent = "起動失敗 (再読み込みしてください)";
        } else if (response && response.status === "success") {
          statusText.textContent = "起動完了";
          setTimeout(() => { window.close(); }, 800); // Auto close popup on success
        }
      });
    } else {
      // Sandbox fallback triggers postMessage
      if (window.parent && window.parent !== window) {
        window.parent.postMessage({
          action: "launchVerticalReaderInSandbox",
          settings: settings
        }, "*");
      }
    }
  });

  // --- 5. Message updates for already running readers ---
  function notifyReaderSettings() {
    if (window.chrome && chrome.tabs && activeTabId) {
      chrome.tabs.sendMessage(activeTabId, {
        action: "updateReaderSettings",
        settings: settings
      }, () => {
        if (chrome.runtime.lastError) {
          // Ignored if reader isn't running on the page
        }
      });
    }
  }

  // Init
  loadSettings();
});
