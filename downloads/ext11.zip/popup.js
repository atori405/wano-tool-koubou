// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 640);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 640,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------



// popup.js - Tab Group Organizer Controller

document.addEventListener('DOMContentLoaded', async () => {
  // Elements
  const storeAllTabsBtn = document.getElementById('store-all-tabs');
  const storeCurrentTabBtn = document.getElementById('store-current-tab');
  const totalStoredTabsEl = document.getElementById('total-stored-tabs');
  const memorySavedEl = document.getElementById('memory-saved');
  const kuraContainer = document.getElementById('kura-container');
  const newKuraNameInput = document.getElementById('new-kura-name');
  const addKuraBtn = document.getElementById('add-kura-btn');
  const sleepEnabledCheckbox = document.getElementById('sleep-enabled');
  const sleepDurationSelect = document.getElementById('sleep-duration');

  // State
  let kuraList = [];
  let sleepSettings = { enabled: true, duration: 15 };

  // Load data from local storage
  async function loadData() {
    const data = await chrome.storage.local.get(['kuraList', 'sleepSettings']);
    
    // Fallback if not initialized by background worker
    if (data.kuraList && data.kuraList.length > 0) {
      kuraList = data.kuraList;
    } else {
      kuraList = [
        { id: "kura_1", name: "壱の蔵（仕事）", tabs: [], isDefault: true },
        { id: "kura_2", name: "弐の蔵（学習・資料）", tabs: [], isDefault: false },
        { id: "kura_3", name: "参の蔵（買い物）", tabs: [], isDefault: false },
        { id: "kura_4", name: "四の蔵（一時保存）", tabs: [], isDefault: false }
      ];
      await chrome.storage.local.set({ kuraList });
    }

    if (data.sleepSettings) {
      sleepSettings = data.sleepSettings;
    }

    // Set settings UI
    sleepEnabledCheckbox.checked = sleepSettings.enabled;
    sleepDurationSelect.value = sleepSettings.duration;
    sleepDurationSelect.disabled = !sleepSettings.enabled;
  }

  // Save kuraList to local storage and refresh UI
  async function saveKura() {
    await chrome.storage.local.set({ kuraList });
    renderKura();
  }

  // Calculate memory saved and render stats
  function renderStats() {
    let totalTabs = 0;
    kuraList.forEach(kura => {
      totalTabs += kura.tabs.length;
    });

    totalStoredTabsEl.textContent = totalTabs;
    // Estimate 50MB per tab saved
    memorySavedEl.textContent = `${totalTabs * 50} MB`;
  }

  // Get default kura ID
  function getDefaultKuraId() {
    const def = kuraList.find(k => k.isDefault);
    return def ? def.id : (kuraList[0] ? kuraList[0].id : null);
  }

  // Render Kura List
  function renderKura() {
    kuraContainer.innerHTML = '';
    renderStats();

    kuraList.forEach(kura => {
      const card = document.createElement('div');
      card.className = `kura-card ${kura.isDefault ? 'default-kura' : ''}`;
      
      // Header
      const header = document.createElement('div');
      header.className = 'kura-header';
      
      const titleGroup = document.createElement('div');
      titleGroup.className = 'kura-title-group';
      
      const badge = document.createElement('span');
      badge.className = 'kura-badge';
      badge.textContent = `${kura.tabs.length}丁`; // Japanese counter for flat objects/sheets/tabs
      
      const title = document.createElement('span');
      title.className = 'kura-title';
      title.textContent = kura.name;
      
      titleGroup.appendChild(badge);
      titleGroup.appendChild(title);
      
      if (kura.isDefault) {
        const defaultLabel = document.createElement('span');
        defaultLabel.style.fontSize = '9px';
        defaultLabel.style.color = 'var(--color-shu)';
        defaultLabel.style.fontWeight = 'bold';
        defaultLabel.textContent = '（指定蔵）';
        titleGroup.appendChild(defaultLabel);
      }
      
      // Actions
      const actions = document.createElement('div');
      actions.className = 'kura-actions';

      // "Make Default" action
      if (!kura.isDefault) {
        const makeDefaultLink = document.createElement('a');
        makeDefaultLink.className = 'kura-action-link';
        makeDefaultLink.textContent = '指定蔵にする';
        makeDefaultLink.addEventListener('click', () => {
          kuraList.forEach(k => k.isDefault = (k.id === kura.id));
          saveKura();
        });
        actions.appendChild(makeDefaultLink);
      }

      // "Restore all" action
      if (kura.tabs.length > 0) {
        const restoreAllLink = document.createElement('a');
        restoreAllLink.className = 'kura-action-link';
        restoreAllLink.textContent = '全て取り出す';
        restoreAllLink.addEventListener('click', async () => {
          for (const tab of kura.tabs) {
            await chrome.tabs.create({ url: tab.url, active: false });
          }
          kura.tabs = [];
          saveKura();
        });
        actions.appendChild(restoreAllLink);

        // "Clear Kura" action
        const clearLink = document.createElement('a');
        clearLink.className = 'kura-action-link';
        clearLink.textContent = '空にする';
        clearLink.style.color = '#c0392b';
        clearLink.addEventListener('click', () => {
          if (confirm(`${kura.name}の荷物（タブ）をすべて処分してよろしいですか？`)) {
            kura.tabs = [];
            saveKura();
          }
        });
        actions.appendChild(clearLink);
      }

      // "Delete Kura" action
      if (!kura.isDefault) {
        const deleteKuraLink = document.createElement('a');
        deleteKuraLink.className = 'kura-action-link';
        deleteKuraLink.textContent = '取り壊す';
        deleteKuraLink.style.color = '#7f8c8d';
        deleteKuraLink.addEventListener('click', () => {
          if (kura.tabs.length > 0) {
            if (!confirm(`${kura.name}にはまだタブが残っています。取り壊して中身も削除しますか？`)) {
              return;
            }
          }
          kuraList = kuraList.filter(k => k.id !== kura.id);
          saveKura();
        });
        actions.appendChild(deleteKuraLink);
      }

      header.appendChild(titleGroup);
      header.appendChild(actions);
      card.appendChild(header);

      // Tab List
      const tabListEl = document.createElement('div');
      tabListEl.className = 'tab-list';
      
      kura.tabs.forEach((tab, index) => {
        const item = document.createElement('div');
        item.className = 'tab-item';
        
        const mainInfo = document.createElement('a');
        mainInfo.className = 'tab-main-info';
        mainInfo.title = tab.title;
        mainInfo.addEventListener('click', async (e) => {
          e.preventDefault();
          await chrome.tabs.create({ url: tab.url });
          // Remove from list
          kura.tabs.splice(index, 1);
          saveKura();
        });

        // Favicon
        const favImg = document.createElement('img');
        favImg.className = 'tab-fav';
        favImg.src = tab.favIconUrl || 'chrome://favicon/';
        favImg.onerror = () => {
          favImg.src = 'icons/icon16.png'; // Fallback
        };

        const titleText = document.createElement('span');
        titleText.className = 'tab-title-text';
        titleText.textContent = tab.title || '（無題の帳面）';

        mainInfo.appendChild(favImg);
        mainInfo.appendChild(titleText);
        item.appendChild(mainInfo);

        // Actions (Move dropdown & Delete)
        const itemActions = document.createElement('div');
        itemActions.className = 'tab-item-actions';

        // Move dropdown
        const moveSelect = document.createElement('select');
        moveSelect.className = 'tab-move-select';
        
        // Add a placeholder/header option
        const placeholderOpt = document.createElement('option');
        placeholderOpt.value = "";
        placeholderOpt.textContent = "蔵移動";
        placeholderOpt.disabled = true;
        placeholderOpt.selected = true;
        moveSelect.appendChild(placeholderOpt);

        kuraList.forEach(k => {
          if (k.id !== kura.id) {
            const opt = document.createElement('option');
            opt.value = k.id;
            opt.textContent = k.name;
            moveSelect.appendChild(opt);
          }
        });

        moveSelect.addEventListener('change', (e) => {
          const targetKuraId = e.target.value;
          const targetKura = kuraList.find(k => k.id === targetKuraId);
          if (targetKura) {
            // Remove from current kura, add to target kura
            const [movedTab] = kura.tabs.splice(index, 1);
            targetKura.tabs.push(movedTab);
            saveKura();
          }
        });
        itemActions.appendChild(moveSelect);

        // Delete tab button
        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'tab-btn';
        deleteBtn.title = '削除';
        deleteBtn.textContent = '×';
        deleteBtn.addEventListener('click', () => {
          kura.tabs.splice(index, 1);
          saveKura();
        });
        itemActions.appendChild(deleteBtn);

        item.appendChild(itemActions);
        tabListEl.appendChild(item);
      });

      card.appendChild(tabListEl);
      kuraContainer.appendChild(card);
    });
  }

  // Button: Store All Tabs except active
  storeAllTabsBtn.addEventListener('click', async () => {
    const defaultKuraId = getDefaultKuraId();
    const targetKura = kuraList.find(k => k.id === defaultKuraId);
    if (!targetKura) return;

    // Get active tabs (to avoid closing active tabs)
    const activeTabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const activeTab = activeTabs[0];
    
    // Get all tabs in current window
    const windowTabs = await chrome.tabs.query({ currentWindow: true });
    
    const tabsToStore = [];
    const tabIdsToClose = [];

    windowTabs.forEach(tab => {
      // Don't store or close active tab, pinned tabs, or internal system urls
      if (activeTab && tab.id === activeTab.id) return;
      if (tab.pinned) return;
      
      const url = tab.url || "";
      if (!url || 
          url.startsWith("chrome://") || 
          url.startsWith("chrome-extension://") || 
          url.startsWith("edge://") ||
          url.startsWith("about:")) {
        return;
      }

      tabsToStore.push({
        url: tab.url,
        title: tab.title || tab.url,
        favIconUrl: tab.favIconUrl || '',
        addedAt: Date.now()
      });
      tabIdsToClose.push(tab.id);
    });

    if (tabsToStore.length === 0) {
      alert("蔵に入れることができる他のタブが見つかりません。（ピン留めされたタブやシステムページは蔵に入れられません）");
      return;
    }

    targetKura.tabs.push(...tabsToStore);
    await chrome.tabs.remove(tabIdsToClose);
    saveKura();
  });

  // Button: Store only current active tab
  storeCurrentTabBtn.addEventListener('click', async () => {
    const defaultKuraId = getDefaultKuraId();
    const targetKura = kuraList.find(k => k.id === defaultKuraId);
    if (!targetKura) return;

    const activeTabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const activeTab = activeTabs[0];
    if (!activeTab) return;

    const url = activeTab.url || "";
    if (!url || 
        url.startsWith("chrome://") || 
        url.startsWith("chrome-extension://") || 
        url.startsWith("edge://") ||
        url.startsWith("about:")) {
      alert("システム設定ページや拡張機能ページは蔵に入れることができません。");
      return;
    }

    // Add to storage
    targetKura.tabs.push({
      url: activeTab.url,
      title: activeTab.title || activeTab.url,
      favIconUrl: activeTab.favIconUrl || '',
      addedAt: Date.now()
    });

    // Check if it's the last tab in the window. If so, create a new tab before closing this one.
    const allTabs = await chrome.tabs.query({ currentWindow: true });
    if (allTabs.length <= 1) {
      await chrome.tabs.create({});
    }

    await chrome.tabs.remove(activeTab.id);
    saveKura();
  });

  // Button: Create a new custom Kura
  addKuraBtn.addEventListener('click', () => {
    const name = newKuraNameInput.value.trim();
    if (!name) {
      alert("蔵の名前を入力してください。");
      return;
    }

    const id = `kura_custom_${Date.now()}`;
    kuraList.push({
      id,
      name,
      tabs: [],
      isDefault: false
    });

    newKuraNameInput.value = '';
    saveKura();
  });

  newKuraNameInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      addKuraBtn.click();
    }
  });

  // Settings change: Sleep enabled
  sleepEnabledCheckbox.addEventListener('change', async (e) => {
    sleepSettings.enabled = e.target.checked;
    sleepDurationSelect.disabled = !sleepSettings.enabled;
    await chrome.storage.local.set({ sleepSettings });
  });

  // Settings change: Sleep duration
  sleepDurationSelect.addEventListener('change', async (e) => {
    sleepSettings.duration = parseInt(e.target.value, 10);
    await chrome.storage.local.set({ sleepSettings });
  });

  // Load and Render initial state
  await loadData();
  renderKura();
});
