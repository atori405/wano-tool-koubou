// background.js - Tab sleep manager

// Set up alarm check and defaults on installation
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("sleep_check", { periodInMinutes: 0.5 });
  
  chrome.storage.local.get(['sleepSettings', 'kuraList'], (result) => {
    if (!result.sleepSettings) {
      chrome.storage.local.set({
        sleepSettings: { enabled: true, duration: 15 } // default 15 minutes
      });
    }
    
    // Set default warehouses (壱, 弐, 参, 四)
    if (!result.kuraList || result.kuraList.length === 0) {
      chrome.storage.local.set({
        kuraList: [
          { id: "kura_1", name: "壱の蔵（仕事）", tabs: [], isDefault: true },
          { id: "kura_2", name: "弐の蔵（学習・資料）", tabs: [], isDefault: false },
          { id: "kura_3", name: "参の蔵（買い物）", tabs: [], isDefault: false },
          { id: "kura_4", name: "四の蔵（一時保存）", tabs: [], isDefault: false }
        ]
      });
    }
  });
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create("sleep_check", { periodInMinutes: 0.5 });
});

// Helper to update last active timestamp of a tab
async function updateTimestamp(tabId) {
  try {
    const data = await chrome.storage.local.get('tabActivity');
    const activity = data.tabActivity || {};
    activity[tabId] = Date.now();
    await chrome.storage.local.set({ tabActivity: activity });
  } catch (e) {
    console.error("Error updating tab timestamp:", e);
  }
}

// Helper to clean up tab ID from activity tracking
async function cleanTab(tabId) {
  try {
    const data = await chrome.storage.local.get('tabActivity');
    const activity = data.tabActivity || {};
    if (activity[tabId]) {
      delete activity[tabId];
      await chrome.storage.local.set({ tabActivity: activity });
    }
  } catch (e) {
    console.error("Error cleaning tab timestamp:", e);
  }
}

// Monitor tab activity events
chrome.tabs.onActivated.addListener(activeInfo => {
  updateTimestamp(activeInfo.tabId);
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete') {
    updateTimestamp(tabId);
  }
});

chrome.tabs.onRemoved.addListener(tabId => {
  cleanTab(tabId);
});

// Run sleep check alarm
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "sleep_check") {
    checkTabsToSleep();
  }
});

// Main logic to determine which tabs can sleep
async function checkTabsToSleep() {
  try {
    const data = await chrome.storage.local.get(['sleepSettings', 'tabActivity']);
    const settings = data.sleepSettings || { enabled: true, duration: 15 };
    if (!settings.enabled) return;

    const durationMs = settings.duration * 60 * 1000;
    const activity = data.tabActivity || {};
    const now = Date.now();

    // Do not sleep currently active tabs in any window
    const activeTabs = await chrome.tabs.query({ active: true });
    const activeTabIds = new Set(activeTabs.map(t => t.id));

    // Get all tabs
    const allTabs = await chrome.tabs.query({});
    let activityUpdated = false;

    for (const tab of allTabs) {
      // Mark active tabs as accessed "now"
      if (activeTabIds.has(tab.id)) {
        activity[tab.id] = now;
        activityUpdated = true;
        continue;
      }

      // Skip criteria:
      // - Pinned tabs
      // - Tabs playing audio (audible)
      // - Internal/System/Extension pages
      if (tab.pinned) continue;
      if (tab.audible) continue;

      const url = tab.url || "";
      if (!url || 
          url.startsWith("chrome://") || 
          url.startsWith("chrome-extension://") || 
          url.startsWith("edge://") ||
          url.startsWith("about:")) {
        continue;
      }

      let lastAccess = activity[tab.id];
      if (!lastAccess) {
        // Initialize timestamp if missing
        activity[tab.id] = now;
        activityUpdated = true;
        lastAccess = now;
      }

      // Check if inactive limit is exceeded
      if (now - lastAccess >= durationMs) {
        const sleepUrl = chrome.runtime.getURL("sleep.html") + 
          `?url=${encodeURIComponent(url)}` + 
          `&title=${encodeURIComponent(tab.title || '')}`;
        
        try {
          await chrome.tabs.update(tab.id, { url: sleepUrl });
          // Stop tracking it, as it is now sleeping
          delete activity[tab.id];
          activityUpdated = true;
        } catch (e) {
          console.error(`Failed to sleep tab ${tab.id}:`, e);
        }
      }
    }

    if (activityUpdated) {
      await chrome.storage.local.set({ tabActivity: activity });
    }
  } catch (e) {
    console.error("Error in checkTabsToSleep:", e);
  }
}
