document.addEventListener('DOMContentLoaded', () => {
  const urlParams = new URLSearchParams(window.location.search);
  const origUrl = urlParams.get('url');
  const origTitle = urlParams.get('title') || '不明な帳面';

  const titleEl = document.getElementById('orig-title');
  const urlEl = document.getElementById('orig-url');

  if (origTitle) {
    titleEl.textContent = decodeURIComponent(origTitle);
    // Also update document title to show original title so user knows which tab it is!
    document.title = `💤 ${decodeURIComponent(origTitle)}`;
  }
  
  if (origUrl) {
    urlEl.textContent = decodeURIComponent(origUrl);
  }

  // Restore action
  const restore = () => {
    if (origUrl) {
      const targetUrl = decodeURIComponent(origUrl);
      window.location.replace(targetUrl);
    } else {
      // Fallback
      window.location.replace('https://www.google.co.jp');
    }
  };

  // Listen to click on body or container
  document.body.addEventListener('click', restore);
});
