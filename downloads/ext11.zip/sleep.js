document.addEventListener('DOMContentLoaded', () => {
  const urlParams = new URLSearchParams(window.location.search);
  const origUrl = urlParams.get('url');
  const origTitle = urlParams.get('title') || '不明な帳面';

  const titleEl = document.getElementById('orig-title');
  const urlEl = document.getElementById('orig-url');

  // urlParams.get() already decodes percent-encoding once; decoding again
  // here corrupted or threw on any URL containing a literal "%" (e.g. most
  // search-result URLs), leaving the click-to-restore handler unreachable.
  if (origTitle) {
    titleEl.textContent = origTitle;
    // Also update document title to show original title so user knows which tab it is!
    document.title = `💤 ${origTitle}`;
  }

  if (origUrl) {
    urlEl.textContent = origUrl;
  }

  // Restore action
  const restore = () => {
    if (origUrl) {
      window.location.replace(origUrl);
    } else {
      // Fallback
      window.location.replace('https://www.google.co.jp');
    }
  };

  // Listen to click on body or container
  document.body.addEventListener('click', restore);
});
