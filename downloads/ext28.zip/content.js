(function() {
  let activeSite = "";
  let storeName = "";
  let extractedDeliveryFee = 0;
  let activeCoupons = [];
  
  // Detect current platform
  const url = window.location.href;
  if (url.includes("ubereats.com")) {
    activeSite = "UberEats";
  } else if (url.includes("demae-can.com")) {
    activeSite = "出前館";
  } else if (url.includes("wolt.com")) {
    activeSite = "Wolt";
  }

  if (!activeSite) return;

  // Initialize extension elements
  window.addEventListener("load", () => {
    // Wait for SPA hydration
    setTimeout(() => {
      extractPageData();
      injectFloatingButton();
      injectSlidePanel();
      loadCoupons();
    }, 2000);
  });

  // Extract store name and delivery fee dynamically
  function extractPageData() {
    const bodyText = document.body.innerText || "";
    
    // 1. Extract Store Name
    const h1 = document.querySelector("h1");
    if (h1) {
      // Clean up extra inner elements
      storeName = h1.textContent.split("\n")[0].replace(/★|☆/g, "").trim();
    } else {
      storeName = document.title.split("|")[0].split("-")[0].trim();
    }

    // 2. Extract Delivery Fee from DOM
    if (activeSite === "UberEats") {
      const m = bodyText.match(/(?:配送|配達)手数料\s*[¥￥\s]*(\d+)/) || bodyText.match(/[¥￥\s]*(\d+)\s*の(?:配送|配達)手数料/);
      extractedDeliveryFee = m ? parseInt(m[1], 10) : 150;
    } else if (activeSite === "出前館") {
      if (bodyText.includes("送料無料") || bodyText.includes("送料無")) {
        extractedDeliveryFee = 0;
      } else {
        const m = bodyText.match(/(?:送料|配送料)\s*[:：]?\s*[¥￥\s]*(\d+)/) || bodyText.match(/(?:送料|配送料)\s*[:：]?\s*(\d+)\s*円/);
        extractedDeliveryFee = m ? parseInt(m[1], 10) : 310;
      }
    } else if (activeSite === "Wolt") {
      if (bodyText.includes("配達無料") || bodyText.includes("配達料無料")) {
        extractedDeliveryFee = 0;
      } else {
        const m = bodyText.match(/配達(?:料)?\s*[¥￥\s]*(\d+)/) || bodyText.match(/配達(?:料)?\s*(\d+)\s*円/);
        extractedDeliveryFee = m ? parseInt(m[1], 10) : 199;
      }
    }
  }

  // Inject circular floating button on mid-right edge of screen
  function injectFloatingButton() {
    if (document.getElementById("dc-floating-btn")) return;

    const btn = document.createElement("div");
    btn.id = "dc-floating-btn";
    btn.innerHTML = `
      <span class="dc-btn-icon">🛵</span>
      <span class="dc-btn-tooltip">出前最安比較 比較する</span>
    `;
    document.body.appendChild(btn);

    btn.addEventListener("click", () => {
      extractPageData(); // Refresh data in case they navigated to a different page in SPA
      updatePanelUI();
      togglePanel(true);
    });
  }

  // Inject Slide-in Comparison Sidebar Panel
  function injectSlidePanel() {
    if (document.getElementById("dc-slide-panel")) return;

    const panel = document.createElement("div");
    panel.id = "dc-slide-panel";
    panel.className = "dc-panel-hidden";
    panel.innerHTML = `
      <div class="dc-panel-header">
        <div class="dc-panel-title-area">
          <span class="dc-logo-icon">🍱</span>
          <h3>出前最安比較</h3>
        </div>
        <button id="dc-panel-close-btn">&times;</button>
      </div>

      <div class="dc-panel-body">
        <!-- Store details -->
        <div class="dc-store-card">
          <div class="dc-store-site-badge badge-${activeSite.toLowerCase()}">${activeSite}</div>
          <h4 id="dc-panel-store-name">店舗情報読み込み中...</h4>
          <div class="dc-delivery-detection-note">
            送料自動検出: <strong id="dc-panel-detected-fee">¥0</strong>
            <button id="dc-refresh-data-btn" title="ページ情報を再スキャン">🔄 再検出</button>
          </div>
        </div>

        <!-- Simulation input -->
        <div class="dc-sim-card">
          <div class="dc-card-title">商品小計シミュレーション</div>
          <div class="dc-input-row">
            <span class="dc-input-currency">¥</span>
            <input type="number" id="dc-subtotal-input" value="2000" min="500" max="20000" step="100">
          </div>
          <input type="range" id="dc-subtotal-slider" min="500" max="10000" step="100" value="2000">
        </div>

        <!-- Comparison Results -->
        <div class="dc-results-card">
          <div class="dc-card-title">支払金額シミュレーション結果</div>
          
          <!-- Column Comparison Chart -->
          <div class="dc-chart-container">
            <!-- Uber Eats Column -->
            <div class="dc-chart-col" id="col-ubereats">
              <div class="dc-crown-badge">👑最安</div>
              <div class="dc-bar-outer">
                <div class="dc-bar-fill fill-ubereats">
                  <span class="dc-bar-text">¥0</span>
                </div>
              </div>
              <div class="dc-col-label">Uber Eats</div>
              <div class="dc-breakdown">
                <div>小計: <span class="bd-sub">¥0</span></div>
                <div>手数料: <span class="bd-service">¥0</span></div>
                <div>送料: <span class="bd-delivery">¥0</span></div>
                <div class="bd-discount-row">割引: <span class="bd-discount">-¥0</span></div>
              </div>
            </div>

            <!-- Demae-can Column -->
            <div class="dc-chart-col" id="col-demaecan">
              <div class="dc-crown-badge">👑最安</div>
              <div class="dc-bar-outer">
                <div class="dc-bar-fill fill-demaecan">
                  <span class="dc-bar-text">¥0</span>
                </div>
              </div>
              <div class="dc-col-label">出前館</div>
              <div class="dc-breakdown">
                <div>小計: <span class="bd-sub">¥0</span></div>
                <div>手数料: <span class="bd-service">¥0</span></div>
                <div>送料: <span class="bd-delivery">¥0</span></div>
                <div class="bd-discount-row">割引: <span class="bd-discount">-¥0</span></div>
              </div>
            </div>

            <!-- Wolt Column -->
            <div class="dc-chart-col" id="col-wolt">
              <div class="dc-crown-badge">👑最安</div>
              <div class="dc-bar-outer">
                <div class="dc-bar-fill fill-wolt">
                  <span class="dc-bar-text">¥0</span>
                </div>
              </div>
              <div class="dc-col-label">Wolt</div>
              <div class="dc-breakdown">
                <div>小計: <span class="bd-sub">¥0</span></div>
                <div>手数料: <span class="bd-service">¥0</span></div>
                <div>送料: <span class="bd-delivery">¥0</span></div>
                <div class="bd-discount-row">割引: <span class="bd-discount">-¥0</span></div>
              </div>
            </div>
          </div>
        </div>

        <!-- Store search cross-platform -->
        <div class="dc-search-card">
          <div class="dc-card-title">他デリバリーでこの店舗を検索</div>
          <div class="dc-search-btn-group" id="dc-search-buttons">
            <!-- Dynamic search links -->
          </div>
        </div>

        <!-- Coupons List -->
        <div class="dc-coupons-card">
          <div class="dc-card-title">
            <span>クーポン設定 (自動適用)</span>
            <button id="dc-add-coupon-toggle-btn" class="dc-small-btn">+ 追加</button>
          </div>
          
          <!-- Add coupon inline form -->
          <form id="dc-add-coupon-form" class="dc-hidden">
            <div class="dc-form-row">
              <select id="dc-new-site">
                <option value="UberEats">Uber Eats</option>
                <option value="出前館">出前館</option>
                <option value="Wolt">Wolt</option>
              </select>
              <input type="text" id="dc-new-name" placeholder="クーポン名" required>
            </div>
            <div class="dc-form-row">
              <select id="dc-new-type">
                <option value="discount">額面割引 (円)</option>
                <option value="free_delivery">配送料タダ</option>
              </select>
              <input type="number" id="dc-new-val" placeholder="割引額 (円)" min="0" value="500">
            </div>
            <div class="dc-form-row">
              <input type="number" id="dc-new-min" placeholder="最低注文金額 (円以上)" min="0" value="1500">
              <button type="submit" class="dc-btn dc-btn-submit">登録</button>
            </div>
          </form>

          <div id="dc-coupons-list-container">
            <!-- Active coupons checkboxes -->
          </div>
        </div>
      </div>
    </div>
  `;
  document.body.appendChild(panel);

  // Hook UI events
  document.getElementById("dc-panel-close-btn").addEventListener("click", () => togglePanel(false));
  document.getElementById("dc-refresh-data-btn").addEventListener("click", () => {
    extractPageData();
    updatePanelUI();
  });

  const subtotalInput = document.getElementById("dc-subtotal-input");
  const subtotalSlider = document.getElementById("dc-subtotal-slider");

  subtotalInput.addEventListener("input", (e) => {
    let val = parseInt(e.target.value, 10) || 500;
    subtotalSlider.value = val;
    calculateComparison(val);
  });

  subtotalSlider.addEventListener("input", (e) => {
    let val = parseInt(e.target.value, 10);
    subtotalInput.value = val;
    calculateComparison(val);
  });

  // Toggle add coupon form
  const addToggle = document.getElementById("dc-add-coupon-toggle-btn");
  const addForm = document.getElementById("dc-add-coupon-form");
  addToggle.addEventListener("click", () => {
    addForm.classList.toggle("dc-hidden");
  });

  // Submit coupon
  addForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const site = document.getElementById("dc-new-site").value;
    const name = document.getElementById("dc-new-name").value.trim();
    const type = document.getElementById("dc-new-type").value;
    const value = parseInt(document.getElementById("dc-new-val").value, 10) || 0;
    const minOrder = parseInt(document.getElementById("dc-new-min").value, 10) || 0;

    const newCoupon = {
      id: "user-" + Date.now(),
      site,
      name,
      type,
      value,
      minOrder,
      isEnabled: true
    };

    chrome.storage.local.get(["delivery_coupons"], (res) => {
      const list = res.delivery_coupons || [];
      list.push(newCoupon);
      chrome.storage.local.set({ delivery_coupons: list }, () => {
        addForm.reset();
        addForm.classList.add("dc-hidden");
        loadCoupons();
      });
    });
  });
}

  function togglePanel(open) {
    const panel = document.getElementById("dc-slide-panel");
    if (!panel) return;
    if (open) {
      panel.className = "dc-panel-visible";
    } else {
      panel.className = "dc-panel-hidden";
    }
  }

  // Load and listen for coupons
  function loadCoupons() {
    chrome.storage.local.get(["delivery_coupons"], (res) => {
      activeCoupons = res.delivery_coupons || [];
      renderCouponsList();
      
      const val = parseInt(document.getElementById("dc-subtotal-input").value, 10) || 2000;
      calculateComparison(val);
    });
  }

  function renderCouponsList() {
    const container = document.getElementById("dc-coupons-list-container");
    if (!container) return;
    container.innerHTML = "";

    if (activeCoupons.length === 0) {
      container.innerHTML = `<div class="dc-empty-coupons">登録されたクーポンはありません。</div>`;
      return;
    }

    activeCoupons.forEach(coupon => {
      const row = document.createElement("div");
      row.className = "dc-coupon-row";
      
      const badgeClass = `badge-${coupon.site.toLowerCase()}`;
      const typeText = coupon.type === "free_delivery" ? "送料無料" : `¥${coupon.value.toLocaleString()}引`;
      const minText = coupon.minOrder > 0 ? `(¥${coupon.minOrder.toLocaleString()}〜)` : "(無制限)";
      
      row.innerHTML = `
        <label class="dc-coupon-label">
          <input type="checkbox" data-id="${coupon.id}" ${coupon.isEnabled ? 'checked' : ''}>
          <span class="dc-coupon-site-badge ${badgeClass}">${coupon.site}</span>
          <span class="dc-coupon-name-span" title="${coupon.name}">${coupon.name} ${minText}</span>
        </label>
      `;

      row.querySelector("input").addEventListener("change", (e) => {
        const id = e.target.getAttribute("data-id");
        const enabled = e.target.checked;
        
        activeCoupons = activeCoupons.map(c => {
          if (c.id === id) c.isEnabled = enabled;
          return c;
        });

        chrome.storage.local.set({ delivery_coupons: activeCoupons }, () => {
          const val = parseInt(document.getElementById("dc-subtotal-input").value, 10) || 2000;
          calculateComparison(val);
        });
      });

      container.appendChild(row);
    });
  }

  // Update static store detail elements in sliding panel
  function updatePanelUI() {
    document.getElementById("dc-panel-store-name").innerText = storeName || "吉野家 渋谷店";
    document.getElementById("dc-panel-detected-fee").innerText = `¥${extractedDeliveryFee}`;

    // Render search buttons for other sites
    const btnGroup = document.getElementById("dc-search-buttons");
    if (!btnGroup) return;
    btnGroup.innerHTML = "";

    const sites = [
      { name: "UberEats", searchUrl: `https://www.ubereats.com/jp/search?q=${encodeURIComponent(storeName)}` },
      { name: "出前館", searchUrl: `https://demae-can.com/search/chain/?chainName=${encodeURIComponent(storeName)}` },
      { name: "Wolt", searchUrl: `https://wolt.com/ja/search?q=${encodeURIComponent(storeName)}` }
    ];

    sites.forEach(site => {
      // Exclude current site
      if (site.name === activeSite) return;

      const a = document.createElement("a");
      a.href = site.searchUrl;
      a.target = "_blank";
      a.className = `dc-search-link-btn btn-${site.name.toLowerCase()}`;
      a.innerHTML = `🔍 ${site.name}で探す`;
      btnGroup.appendChild(a);
    });
  }

  // Main price computation & side-by-side rendering
  function calculateComparison(subtotal) {
    const platforms = ["UberEats", "出前館", "Wolt"];
    const results = {};

    platforms.forEach(site => {
      let deliveryFee = 200; // default fallback
      let serviceFee = 0;

      // 1. Service Fee & Base Delivery Fee calculations
      if (site === "UberEats") {
        deliveryFee = (site === activeSite) ? extractedDeliveryFee : 150;
        // Uber Eats: 10% of subtotal, Min ¥50, Max ¥350
        serviceFee = Math.min(350, Math.max(50, Math.round(subtotal * 0.1)));
      } else if (site === "出前館") {
        deliveryFee = (site === activeSite) ? extractedDeliveryFee : 310;
        // Demaecan: No service fee
        serviceFee = 0;
      } else if (site === "Wolt") {
        deliveryFee = (site === activeSite) ? extractedDeliveryFee : 199;
        // Wolt: 10% of subtotal, Max ¥300
        serviceFee = Math.min(300, Math.round(subtotal * 0.1));
      }

      // 2. Select optimal enabled coupon
      let bestDiscount = 0;
      let appliedCouponId = null;

      const eligibleCoupons = activeCoupons.filter(c => c.site === site && c.isEnabled && subtotal >= c.minOrder);
      eligibleCoupons.forEach(coupon => {
        let discount = 0;
        if (coupon.type === "free_delivery") {
          discount = deliveryFee;
        } else if (coupon.type === "discount") {
          discount = coupon.value;
        }

        if (discount > bestDiscount) {
          bestDiscount = discount;
          appliedCouponId = coupon.id;
        }
      });

      // Clamp discount to subtotal + service + delivery
      const rawTotal = subtotal + serviceFee + deliveryFee;
      const actualDiscount = Math.min(rawTotal, bestDiscount);
      const total = Math.max(0, rawTotal - actualDiscount);

      results[site] = {
        subtotal,
        serviceFee,
        deliveryFee,
        discount: actualDiscount,
        total,
        appliedCouponId
      };
    });

    // Determine the cheapest option
    let minTotal = Infinity;
    let cheapestSite = "";
    platforms.forEach(site => {
      if (results[site].total < minTotal) {
        minTotal = results[site].total;
        cheapestSite = site;
      }
    });

    // Update the visual columns
    platforms.forEach(site => {
      const data = results[site];
      const colId = site === "UberEats" ? "col-ubereats" : (site === "出前館" ? "col-demaecan" : "col-wolt");
      const col = document.getElementById(colId);
      if (!col) return;

      // Update Breakdown Texts
      col.querySelector(".bd-sub").innerText = `¥${data.subtotal.toLocaleString()}`;
      col.querySelector(".bd-service").innerText = `¥${data.serviceFee.toLocaleString()}`;
      col.querySelector(".bd-delivery").innerText = `¥${data.deliveryFee.toLocaleString()}`;
      col.querySelector(".bd-discount").innerText = `-¥${data.discount.toLocaleString()}`;

      // Show/Hide discount row
      const discRow = col.querySelector(".bd-discount-row");
      if (data.discount > 0) {
        discRow.style.display = "block";
      } else {
        discRow.style.display = "none";
      }

      // Height logic (proportional to total, max ¥8,000 as 100%)
      const maxRange = 8000;
      const heightPercent = Math.min(100, Math.max(25, (data.total / maxRange) * 100));
      
      const barFill = col.querySelector(".dc-bar-fill");
      barFill.style.height = `${heightPercent}%`;
      barFill.querySelector(".dc-bar-text").innerText = `¥${data.total.toLocaleString()}`;

      // Crown / Cheapest Highlight
      const crown = col.querySelector(".dc-crown-badge");
      if (site === cheapestSite) {
        col.classList.add("cheapest-highlight");
        crown.style.display = "block";
      } else {
        col.classList.remove("cheapest-highlight");
        crown.style.display = "none";
      }
    });
  }

  // Listen for storage changes from popup coupon updates
  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === "local" && changes.delivery_coupons) {
      loadCoupons();
    }
  });
})();


// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // Add temporary shield to prevent iframe from stealing mouse events during dragging
      const existingShield = document.getElementById("wano-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = "wano-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      // Use getBoundingClientRect() for correct viewport-relative position
      // (element.offsetTop is unreliable for position:fixed elements on scrolled pages)
      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      // Restrict within window boundaries to prevent going offscreen
      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById("wano-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById("wano-universal-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "block" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = "wano-universal-floating-container";
    
    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 440) + "px !important; z-index:2147483647 !important; width:430px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="wano-u-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">Delivery Comparer</span>
        </div>
        <button id="wano-u-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#wano-u-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#wano-u-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
