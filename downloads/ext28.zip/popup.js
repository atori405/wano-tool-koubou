// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

document.addEventListener("DOMContentLoaded", () => {
  const subtotalInput = document.getElementById("subtotal-input");
  const subtotalSlider = document.getElementById("subtotal-slider");
  const couponsContainer = document.getElementById("coupons-list-container");
  const addToggleBtn = document.getElementById("add-coupon-toggle-btn");
  const addCouponForm = document.getElementById("add-coupon-form");
  const resetBtn = document.getElementById("reset-coupons-btn");

  let activeCoupons = [];

  // Default presets for reset
  const presetCoupons = [
    { id: "uber-preset-1", site: "UberEats", name: "Uber One (¥1,200以上で配送料タダ)", type: "free_delivery", value: 0, minOrder: 1200, isEnabled: true },
    { id: "uber-preset-2", site: "UberEats", name: "初回限定プロモ (¥1,000割引)", type: "discount", value: 1000, minOrder: 1500, isEnabled: false },
    { id: "demae-preset-1", site: "出前館", name: "送料無料キャンペーン (¥2,000以上)", type: "free_delivery", value: 0, minOrder: 2000, isEnabled: true },
    { id: "demae-preset-2", site: "出前館", name: "店舗限定 400円割引", type: "discount", value: 400, minOrder: 1800, isEnabled: false },
    { id: "wolt-preset-1", site: "Wolt", name: "Wolt+ (¥1,200以上で配送料タダ)", type: "free_delivery", value: 0, minOrder: 1200, isEnabled: true },
    { id: "wolt-preset-2", site: "Wolt", name: "初回プロモコード (¥800割引)", type: "discount", value: 800, minOrder: 1500, isEnabled: false }
  ];

  // Sync inputs
  subtotalInput.addEventListener("input", (e) => {
    let val = parseInt(e.target.value, 10) || 500;
    subtotalSlider.value = val;
    calculateComparison(val);
  });

  subtotalSlider.addEventListener("input", (e) => {
    let val = parseInt(e.target.value, 10);
    subtotalInput.value = val;
    calculateComparison(val);
  });

  // Toggle form
  addToggleBtn.addEventListener("click", () => {
    addCouponForm.classList.toggle("hidden");
  });

  // Reset coupons
  resetBtn.addEventListener("click", () => {
    if (confirm("クーポン設定を初期状態（デフォルト）に戻しますか？")) {
      chrome.storage.local.set({ delivery_coupons: presetCoupons }, () => {
        loadCoupons();
      });
    }
  });

  // Submit coupon
  addCouponForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const site = document.getElementById("new-site").value;
    const name = document.getElementById("new-name").value.trim();
    const type = document.getElementById("new-type").value;
    const value = parseInt(document.getElementById("new-val").value, 10) || 0;
    const minOrder = parseInt(document.getElementById("new-min").value, 10) || 0;

    const newCoupon = {
      id: "user-" + Date.now(),
      site,
      name,
      type,
      value,
      minOrder,
      isEnabled: true
    };

    chrome.storage.local.get(["delivery_coupons"], (res) => {
      const list = res.delivery_coupons || [];
      list.push(newCoupon);
      chrome.storage.local.set({ delivery_coupons: list }, () => {
        addCouponForm.reset();
        addCouponForm.classList.add("hidden");
        loadCoupons();
      });
    });
  });

  // Load coupons from storage
  function loadCoupons() {
    chrome.storage.local.get(["delivery_coupons"], (res) => {
      activeCoupons = res.delivery_coupons || presetCoupons;
      renderCouponsList();
      calculateComparison(parseInt(subtotalInput.value, 10) || 2000);
    });
  }

  function renderCouponsList() {
    couponsContainer.innerHTML = "";

    if (activeCoupons.length === 0) {
      couponsContainer.innerHTML = `<div class="empty-coupons">登録されたクーポンはありません。</div>`;
      return;
    }

    activeCoupons.forEach(coupon => {
      const row = document.createElement("div");
      row.className = "coupon-row";
      
      const badgeClass = `badge-${coupon.site.toLowerCase()}`;
      const minText = coupon.minOrder > 0 ? `(¥${coupon.minOrder.toLocaleString()}〜)` : "(無制限)";
      
      row.innerHTML = `
        <label class="coupon-label">
          <input type="checkbox" data-id="${coupon.id}" ${coupon.isEnabled ? 'checked' : ''}>
          <span class="coupon-site-badge ${badgeClass}">${coupon.site}</span>
          <span class="coupon-name-span" title="${coupon.name}">${coupon.name} ${minText}</span>
        </label>
      `;

      row.querySelector("input").addEventListener("change", (e) => {
        const id = e.target.getAttribute("data-id");
        const enabled = e.target.checked;
        
        activeCoupons = activeCoupons.map(c => {
          if (c.id === id) c.isEnabled = enabled;
          return c;
        });

        chrome.storage.local.set({ delivery_coupons: activeCoupons }, () => {
          calculateComparison(parseInt(subtotalInput.value, 10) || 2000);
        });
      });

      couponsContainer.appendChild(row);
    });
  }

  // Calculate pricing & update bar heights
  function calculateComparison(subtotal) {
    const platforms = ["UberEats", "出前館", "Wolt"];
    const results = {};

    platforms.forEach(site => {
      let deliveryFee = 200; // default generic fallback for popup
      let serviceFee = 0;

      // 1. Service Fee & Delivery Fee settings for general simulator
      if (site === "UberEats") {
        deliveryFee = 150;
        serviceFee = Math.min(350, Math.max(50, Math.round(subtotal * 0.1)));
      } else if (site === "出前館") {
        deliveryFee = 310;
        serviceFee = 0;
      } else if (site === "Wolt") {
        deliveryFee = 199;
        serviceFee = Math.min(300, Math.round(subtotal * 0.1));
      }

      // 2. Select optimal enabled coupon
      let bestDiscount = 0;
      let appliedCouponId = null;

      const eligibleCoupons = activeCoupons.filter(c => c.site === site && c.isEnabled && subtotal >= c.minOrder);
      eligibleCoupons.forEach(coupon => {
        let discount = 0;
        if (coupon.type === "free_delivery") {
          discount = deliveryFee;
        } else if (coupon.type === "discount") {
          discount = coupon.value;
        }

        if (discount > bestDiscount) {
          bestDiscount = discount;
          appliedCouponId = coupon.id;
        }
      });

      const rawTotal = subtotal + serviceFee + deliveryFee;
      const actualDiscount = Math.min(rawTotal, bestDiscount);
      const total = Math.max(0, rawTotal - actualDiscount);

      results[site] = {
        subtotal,
        serviceFee,
        deliveryFee,
        discount: actualDiscount,
        total,
        appliedCouponId
      };
    });

    // Determine the cheapest option
    let minTotal = Infinity;
    let cheapestSite = "";
    platforms.forEach(site => {
      if (results[site].total < minTotal) {
        minTotal = results[site].total;
        cheapestSite = site;
      }
    });

    // Update columns
    platforms.forEach(site => {
      const data = results[site];
      const colId = site === "UberEats" ? "col-ubereats" : (site === "出前館" ? "col-demaecan" : "col-wolt");
      const col = document.getElementById(colId);
      if (!col) return;

      // Update Texts
      col.querySelector(".bd-sub").innerText = `¥${data.subtotal.toLocaleString()}`;
      col.querySelector(".bd-service").innerText = `¥${data.serviceFee.toLocaleString()}`;
      col.querySelector(".bd-delivery").innerText = `¥${data.deliveryFee.toLocaleString()}`;
      col.querySelector(".bd-discount").innerText = `-¥${data.discount.toLocaleString()}`;

      const discRow = col.querySelector(".bd-discount-row");
      if (data.discount > 0) {
        discRow.style.display = "block";
      } else {
        discRow.style.display = "none";
      }

      // Height logic
      const maxRange = 8000;
      const heightPercent = Math.min(100, Math.max(25, (data.total / maxRange) * 100));
      
      const barFill = col.querySelector(".bar-fill");
      barFill.style.height = `${heightPercent}%`;
      barFill.querySelector(".bar-text").innerText = `¥${data.total.toLocaleString()}`;

      // Crown
      const crown = col.querySelector(".crown-badge");
      if (site === cheapestSite) {
        col.classList.add("cheapest-highlight");
        crown.style.display = "block";
      } else {
        col.classList.remove("cheapest-highlight");
        crown.style.display = "none";
      }
    });
  }

  // Initial load
  loadCoupons();
});
