chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["delivery_coupons"], (res) => {
    if (!res.delivery_coupons) {
      const presetCoupons = [
        { id: "uber-preset-1", site: "UberEats", name: "Uber One (¥1,200以上で配送料タダ)", type: "free_delivery", value: 0, minOrder: 1200, isEnabled: true },
        { id: "uber-preset-2", site: "UberEats", name: "初回限定プロモ (¥1,000割引)", type: "discount", value: 1000, minOrder: 1500, isEnabled: false },
        { id: "demae-preset-1", site: "出前館", name: "送料無料キャンペーン (¥2,000以上)", type: "free_delivery", value: 0, minOrder: 2000, isEnabled: true },
        { id: "demae-preset-2", site: "出前館", name: "店舗限定 400円割引", type: "discount", value: 400, minOrder: 1800, isEnabled: false },
        { id: "wolt-preset-1", site: "Wolt", name: "Wolt+ (¥1,200以上で配送料タダ)", type: "free_delivery", value: 0, minOrder: 1200, isEnabled: true },
        { id: "wolt-preset-2", site: "Wolt", name: "初回プロモコード (¥800割引)", type: "discount", value: 800, minOrder: 1500, isEnabled: false }
      ];
      chrome.storage.local.set({ delivery_coupons: presetCoupons });
    }
  });
});
