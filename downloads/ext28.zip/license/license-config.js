/**
 * license-config.js
 * 
 * 拡張機能ごとの個別ライセンス商品ID設定。
 * 自動生成されたファイルです。手動で変更しないでください。
 */
window.LicenseConfig = {
  productId: "1318974",
  allToolsProductId: "1318293",
  singleCheckoutUrl: "https://wafuu-koubou.lemonsqueezy.com/checkout/buy/013ad990-1da6-4a23-b171-5742eb600ac6",
  bundleCheckoutUrl: "https://wafuu-koubou.lemonsqueezy.com/checkout/buy/d2530690-2049-4779-8a24-0a15c803bb24"
};
