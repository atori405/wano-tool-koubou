// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  const urlParams = new URLSearchParams(window.location.search);
  const isFloatingMode = urlParams.get("mode") === "floating";

  if (!isFloatingMode && window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0] && tabs[0].id) {
        // Send message to show floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, (response) => {
          // If receiver is present and processed successfully, close the toolbar bubble
          if (response && response.status === "toggled") {
            window.close();
          } else {
            // Otherwise, fail-safe: show the popup bubble interface normally
            document.body.style.display = "block";
          }
        });
      }
    });
    return;
  }
})();
// -----------------------------------------------------------------



document.addEventListener("DOMContentLoaded", () => {
  const btnCapture = document.getElementById("btn-capture-trigger");
  const statusMessage = document.getElementById("status-message");

  if (btnCapture) {
    btnCapture.addEventListener("click", () => {
      // Set loading state
      btnCapture.disabled = true;
      btnCapture.style.opacity = "0.7";
      btnCapture.innerHTML = `<span class="btn-icon">⏳</span><span class="btn-text">撮影中...</span>`;
      
      if (statusMessage) {
        statusMessage.textContent = "画面をキャプチャ中...";
        statusMessage.style.color = "#dfc299";
      }

      // Send message to service worker background.js
      if (window.chrome && chrome.runtime) {
        chrome.runtime.sendMessage({ action: "capture_tab" }, (response) => {
          if (response && response.success) {
            // Close popup once captured successfully as editor tab opens
            window.close();
          } else {
            console.error("Capture request error response:", response);
            resetButtonState("撮影に失敗しました");
          }
        });
      } else {
        // Mock fallback for browser testing
        setTimeout(() => {
          resetButtonState("環境未対応");
        }, 1000);
      }
    });
  }

  function resetButtonState(errorMessage) {
    if (btnCapture) {
      btnCapture.disabled = false;
      btnCapture.style.opacity = "";
      btnCapture.innerHTML = `<span class="btn-icon">📷</span><span class="btn-text">画面を撮影して注釈</span>`;
    }
    if (statusMessage) {
      statusMessage.textContent = errorMessage;
      statusMessage.style.color = "#ff5252";
    }
  }
});
