let lastCapturedImage = null;

// Listen for captured tab requests or image queries
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "capture_tab") {
    // Capture the visible area of the active tab
    chrome.tabs.captureVisibleTab(null, { format: "png" }, (dataUrl) => {
      if (chrome.runtime.lastError || !dataUrl) {
        console.error("Capture failed:", chrome.runtime.lastError);
        sendResponse({ success: false, error: "Capture failed" });
        return;
      }
      
      // Store the image data in background memory
      lastCapturedImage = dataUrl;

      // Open the annotation editor in a new tab
      chrome.tabs.create({ url: chrome.runtime.getURL("annotate.html") }, () => {
        sendResponse({ success: true });
      });
    });
    return true; // Keep message channel open for async response
  }

  if (message.action === "get_captured_image") {
    sendResponse({ image: lastCapturedImage });
    // Keep it in memory or clear it after response
    return false;
  }
});
