document.addEventListener("DOMContentLoaded", () => {
  const canvas = document.getElementById("annotation-canvas");
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  const wrapper = document.getElementById("canvas-wrapper");
  const dimensionsText = document.getElementById("dimensions-text");

  // State
  let isDrawing = false;
  let lastX = 0;
  let lastY = 0;
  let lastTime = 0;
  let brushColor = "#15110e"; // default sumi black
  let brushSize = 7;          // default medium fude
  let selectedStamp = "none"; // default no stamp
  let backgroundImage = new Image();

  // Undo system
  const undoStack = [];
  const MAX_UNDO = 25;

  // Tools Selection Buttons
  const colorCircles = document.querySelectorAll(".color-circle");
  const sizeBtns = document.querySelectorAll(".size-btn");
  const stampBtns = document.querySelectorAll(".stamp-btn");
  const btnUndo = document.getElementById("btn-undo");
  const btnClear = document.getElementById("btn-clear");
  const btnCopy = document.getElementById("btn-copy");
  const btnSave = document.getElementById("btn-save");

  // --- 1. Load Captured Image ---
  if (window.chrome && chrome.runtime) {
    chrome.runtime.sendMessage({ action: "get_captured_image" }, (response) => {
      if (response && response.image) {
        loadBaseImage(response.image);
      } else {
        // Fallback for direct opening or testing
        loadBaseImage("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='600'><rect width='100%' height='100%' fill='%23fafbfc'/><text x='50%' y='50%' font-family='sans-serif' font-size='20' fill='%23999' text-anchor='middle'>スクリーンショット画像がありません</text></svg>");
      }
    });
  } else {
    // Local development fallback
    loadBaseImage("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='600'><rect width='100%' height='100%' fill='%23fafbfc'/><text x='50%' y='50%' font-family='sans-serif' font-size='20' fill='%23999' text-anchor='middle'>スクリーンショット画像がありません</text></svg>");
  }

  function loadBaseImage(src) {
    backgroundImage.onload = () => {
      canvas.width = backgroundImage.width;
      canvas.height = backgroundImage.height;
      if (dimensionsText) {
        dimensionsText.textContent = `${canvas.width} × ${canvas.height}`;
      }
      
      // Draw background image
      ctx.drawImage(backgroundImage, 0, 0);

      // Save initial state for undo
      saveState();
    };
    backgroundImage.src = src;
  }

  // --- 2. Undo State Manager ---
  function saveState() {
    if (undoStack.length >= MAX_UNDO) {
      undoStack.shift();
    }
    undoStack.push(ctx.getImageData(0, 0, canvas.width, canvas.height));
  }

  function performUndo() {
    if (undoStack.length > 1) {
      undoStack.pop(); // Pop current state
      const previousState = undoStack[undoStack.length - 1];
      ctx.putImageData(previousState, 0, 0);
    }
  }

  function clearAllCanvas() {
    saveState();
    // Redraw base image
    ctx.drawImage(backgroundImage, 0, 0);
  }

  // --- 3. Brush Physics (Sumi Brush Drawing Engine) ---
  function getMousePos(e) {
    const rect = canvas.getBoundingClientRect();
    // Support mouse and touch coordinate mapping
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    return {
      x: (clientX - rect.left) * (canvas.width / rect.width),
      y: (clientY - rect.top) * (canvas.height / rect.height)
    };
  }

  function startDrawing(e) {
    if (selectedStamp !== "none") {
      // Stamp Mode
      const pos = getMousePos(e);
      saveState();
      drawHankoStamp(pos.x, pos.y, selectedStamp);
      return;
    }

    isDrawing = true;
    const pos = getMousePos(e);
    lastX = pos.x;
    lastY = pos.y;
    lastTime = Date.now();
    saveState();
    
    // Draw initial dot
    drawSumiLineSegment(lastX, lastY, lastX, lastY, brushSize, brushColor);
  }

  function draw(e) {
    if (!isDrawing) return;
    e.preventDefault();

    const pos = getMousePos(e);
    const now = Date.now();
    const dt = now - lastTime || 1;
    
    // Calculate distance and speed to determine brush dynamics
    const dx = pos.x - lastX;
    const dy = pos.y - lastY;
    const dist = Math.sqrt(dx * dx + dy * dy);
    const speed = dist / dt; // pixels per ms

    // Dynamic width logic: faster move -> thinner line, slower move -> thicker line
    // Cap velocity between 0.1 and 3 px/ms
    const speedFactor = Math.max(0.1, Math.min(3, speed));
    const targetSize = Math.max(2, brushSize * (1.3 - (speedFactor / 3)));

    drawSumiLineSegment(lastX, lastY, pos.x, pos.y, targetSize, brushColor, speed);

    lastX = pos.x;
    lastY = pos.y;
    lastTime = now;
  }

  function stopDrawing() {
    isDrawing = false;
  }

  // Speed-sensitive sumi ink brush algorithm
  function drawSumiLineSegment(x1, y1, x2, y2, size, color, speed = 0) {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const dist = Math.sqrt(dx * dx + dy * dy);
    
    // Interpolation steps to avoid gaps in fast movements
    const steps = Math.max(1, Math.ceil(dist / 1.5));
    
    ctx.save();
    
    // Speed determines "dryness" (kasure)
    const isDry = speed > 1.2;
    
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const cx = x1 + dx * t;
      const cy = y1 + dy * t;
      
      if (isDry) {
        // --- Speed Brush (Kasure: Dry splash dot rendering) ---
        // Render brush as cluster of bristles with random transparency
        const bristleCount = Math.floor(size * 1.5);
        ctx.fillStyle = color;
        for (let j = 0; j < bristleCount; j++) {
          const angle = Math.random() * Math.PI * 2;
          const radius = Math.random() * (size * 0.5);
          const px = cx + Math.cos(angle) * radius;
          const py = cy + Math.sin(angle) * radius;
          
          // Random scatter dot size and opacity
          const dotSize = Math.random() * 1.2 + 0.3;
          ctx.globalAlpha = Math.random() * 0.4 + 0.1;
          
          ctx.beginPath();
          ctx.arc(px, py, dotSize, 0, Math.PI * 2);
          ctx.fill();
        }
      } else {
        // --- Slower Brush (Nijimi: Heavy wet ink) ---
        // Render fuzzy circle with soft edges
        const radialGrad = ctx.createRadialGradient(cx, cy, size * 0.1, cx, cy, size * 0.5);
        radialGrad.addColorStop(0, color);
        radialGrad.addColorStop(0.7, color);
        // Soft edge gradient bleed
        radialGrad.addColorStop(1.0, "rgba(0, 0, 0, 0)");
        
        ctx.fillStyle = radialGrad;
        ctx.globalAlpha = 0.95;
        
        ctx.beginPath();
        ctx.arc(cx, cy, size * 0.5, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    
    ctx.restore();
  }

  // --- 4. Draw Hanko (Red Vermillion Seal) ---
  function drawHankoStamp(x, y, text) {
    const size = 64; // Seal size
    ctx.save();
    
    // Position stamp centered on mouse click
    ctx.translate(x, y);
    
    // 朱肉赤のブレンドグラデーション (Shuniku Red vermillion ink texture)
    const grad = ctx.createLinearGradient(-size/2, -size/2, size/2, size/2);
    grad.addColorStop(0, "#d32f2f");
    grad.addColorStop(0.5, "#c62828");
    grad.addColorStop(1, "#b71c1c");
    
    ctx.strokeStyle = grad;
    ctx.fillStyle = grad;
    ctx.lineWidth = 4;
    
    // Hanko Border: Round or square depending on text length
    const isSquare = text.length > 1;
    if (isSquare) {
      // Draw square hanko border
      ctx.strokeRect(-size/2 + 2, -size/2 + 2, size - 4, size - 4);
    } else {
      // Draw circle hanko border
      ctx.beginPath();
      ctx.arc(0, 0, size/2 - 2, 0, Math.PI * 2);
      ctx.stroke();
    }
    
    // Draw text inside stamp
    ctx.font = "bold 26px 'Noto Serif JP', serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    
    if (text.length === 1) {
      // Single character: Center perfectly
      ctx.fillText(text, 0, 1.5);
    } else if (text.length === 2) {
      // Two characters: Vertical layout
      ctx.font = "bold 20px 'Noto Serif JP', serif";
      ctx.fillText(text[0], 0, -11);
      ctx.fillText(text[1], 0, 11);
    }

    // --- Stamp Distress Texture (Ink Kasure / Aging Effect) ---
    // Sprinkle fine random white dots to simulate uneven paper press
    ctx.fillStyle = "#ffffff"; // match background paper or transparent erasure
    ctx.globalCompositeOperation = "destination-out"; // erase particles
    
    const distressParticles = Math.floor(Math.random() * 40) + 30;
    for (let i = 0; i < distressParticles; i++) {
      const rx = (Math.random() - 0.5) * (size - 6);
      const ry = (Math.random() - 0.5) * (size - 6);
      const rSize = Math.random() * 1.5 + 0.4;
      
      ctx.beginPath();
      ctx.arc(rx, ry, rSize, 0, Math.PI * 2);
      ctx.fill();
    }
    
    ctx.restore();
  }

  // --- 5. Event Listeners for controls ---

  // Brush Color Selection
  colorCircles.forEach(circle => {
    circle.addEventListener("click", () => {
      colorCircles.forEach(c => c.style.borderColor = "transparent");
      circle.style.borderColor = "#dfc299";
      brushColor = circle.getAttribute("data-color");
      
      // Auto cancel stamp if picking brush color
      selectedStamp = "none";
      stampBtns.forEach(b => b.classList.remove("active"));
      stampBtns[0].classList.add("active");
    });
  });

  // Brush Size Selection
  sizeBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      sizeBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      brushSize = parseInt(btn.getAttribute("data-size"));
    });
  });

  // Stamp Selection
  stampBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      stampBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      selectedStamp = btn.getAttribute("data-stamp");
    });
  });

  // Undo click
  btnUndo.addEventListener("click", performUndo);

  // Clear click
  btnClear.addEventListener("click", clearAllCanvas);

  // Copy to Clipboard (Nav Clipboard API)
  btnCopy.addEventListener("click", () => {
    canvas.toBlob((blob) => {
      if (!blob) {
        alert("画像のコピーに失敗しました。");
        return;
      }
      try {
        navigator.clipboard.write([
          new ClipboardItem({ "image/png": blob })
        ]).then(() => {
          showGuideNotification("クリップボードに注釈付き画像をコピーしました！");
        }).catch((err) => {
          console.error("Clipboard copy failed:", err);
          alert("クリップボードへのアクセスが拒否されました。");
        });
      } catch (err) {
        console.error(err);
        alert("ブラウザがクリップボードへの直接画像コピーに対応していません。");
      }
    }, "image/png");
  });

  // Save to Disk (PNG Download)
  btnSave.addEventListener("click", () => {
    const link = document.createElement("a");
    link.download = `annotation_${Date.now()}.png`;
    link.href = canvas.toDataURL("image/png");
    link.click();
  });

  function showGuideNotification(text) {
    const guide = document.getElementById("guide-text");
    if (guide) {
      const originalText = guide.textContent;
      guide.textContent = `🌟 ${text}`;
      guide.style.color = "#dfc299";
      setTimeout(() => {
        guide.textContent = originalText;
        guide.style.color = "";
      }, 3000);
    }
  }

  // --- 6. Attach Canvas Draw Events (Touch support) ---
  canvas.addEventListener("mousedown", startDrawing);
  canvas.addEventListener("mousemove", draw);
  canvas.addEventListener("mouseup", stopDrawing);
  canvas.addEventListener("mouseout", stopDrawing);

  canvas.addEventListener("touchstart", (e) => {
    if (e.touches.length === 1) {
      startDrawing(e);
    }
  }, { passive: false });
  
  canvas.addEventListener("touchmove", (e) => {
    if (e.touches.length === 1) {
      draw(e);
    }
  }, { passive: false });

  canvas.addEventListener("touchend", stopDrawing);
  canvas.addEventListener("touchcancel", stopDrawing);
});
