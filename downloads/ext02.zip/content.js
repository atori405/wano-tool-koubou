// content.js - 丁寧メール査定AI の常設ページ内パネル
// ツールバーアイコンのクリックで表示/非表示を切り替える、ドラッグ移動できる
// 独立パネルです。ネイティブのブラウザ拡張ポップアップは、コピー先アプリに
// 切り替えた瞬間に自動で閉じてしまう仕様(拡張機能側では回避不可)のため、
// 通常のDOM要素としてページ上に直接差し込むことで解決しています。
// 影響範囲は Shadow DOM 内 + このコンテナ要素だけに限定し、閲覧中のページ
// 本体には一切手を加えません。

(function () {
  'use strict';
  if (window.__wanoExt02Injected) return;
  window.__wanoExt02Injected = true;

  var container = null;
  var shadow = null;

  chrome.runtime.onMessage.addListener(function (msg) {
    if (msg && msg.action === 'toggleWidget') {
      toggleWidget();
    }
  });

  function toggleWidget() {
    try {
      if (container) {
        removeWidget();
      } else {
        createWidget();
      }
    } catch (e) {
      console.error('[wano-ext02] toggleWidget failed:', e);
    }
  }

  function removeWidget() {
    if (container) { container.remove(); }
    container = null;
    shadow = null;
  }

  function createWidget() {
    container = document.createElement('div');
    container.id = 'wano-ext02-widget-root';
    container.style.cssText = 'position:fixed; top:20px; right:20px; z-index:2147483647; width:340px; font-size:13px;';
    document.body.appendChild(container);
    shadow = container.attachShadow({ mode: 'open' });
    shadow.innerHTML = baseTemplate();
    document.body.appendChild(container); // ensure top of stacking order
    wireBase();
    wireAssessTab();
    wireGreetingsTab();
    if (window.makeDraggable) {
      window.makeDraggable(container, shadow.querySelector('#drag-handle'));
    }
    applyLicenseGate();
  }

  function $(sel) { return shadow.querySelector(sel); }
  function $all(sel) { return shadow.querySelectorAll(sel); }

  // ========================= Shell / Template =========================
  function baseTemplate() {
    return (
      '<style>' + baseCSS() + '</style>' +
      '<div class="wano-panel" id="wano-panel">' +
        '<div class="head" id="drag-handle">' +
          '<span class="head-title"><span class="dot">✓</span> 丁寧メール査定AI</span>' +
          '<button class="close-btn" id="close-btn" title="閉じる">✕</button>' +
        '</div>' +
        '<div id="trial-banner-slot"></div>' +
        '<div class="tabs">' +
          '<button class="tab-btn active" data-tab="tab-assess">📄 メール査定</button>' +
          '<button class="tab-btn" data-tab="tab-seasons">💬 時候の挨拶</button>' +
        '</div>' +
        '<div class="tab-content active" id="tab-assess">' +
          '<label class="field-label">作成したメール本文（査定する文章）</label>' +
          '<div class="textarea-wrap">' +
            '<textarea id="input-email" placeholder="例：鈴木様、お疲れ様です。昨日言ってた見積書を送ります。ご確認していただけますでしょうか。"></textarea>' +
            '<button class="clear-btn" id="clear-input" title="入力をクリア">✕</button>' +
          '</div>' +
          '<div class="row-between">' +
            '<span class="char-count"><span id="char-count">0</span> 文字</span>' +
            '<button class="primary-btn" id="btn-assess"><span>メールを査定する</span> 🔍</button>' +
          '</div>' +
          '<div class="result hidden" id="assess-result">' +
            '<div class="score-block">' +
              '<div class="score-num" id="score-num">0%</div>' +
              '<div class="score-meta">' +
                '<div class="rating-label">総合評価</div>' +
                '<span class="rating-badge" id="rating-badge">-</span>' +
                '<div class="rating-desc" id="rating-desc"></div>' +
              '</div>' +
            '</div>' +
            '<div class="section-title">改善ポイント (<span id="findings-count">0</span>)</div>' +
            '<div id="findings-list"></div>' +
          '</div>' +
        '</div>' +
        '<div class="tab-content" id="tab-seasons">' +
          '<label class="field-label">月を選択</label>' +
          '<select id="select-month" class="select-input"></select>' +
          '<div class="greet-section"><div class="greet-title">格式高い書き出し</div><div id="list-formal" class="greet-list"></div></div>' +
          '<div class="greet-section"><div class="greet-title">柔らかい書き出し</div><div id="list-soft" class="greet-list"></div></div>' +
          '<div class="greet-section"><div class="greet-title">結びの言葉</div><div id="list-closing" class="greet-list"></div></div>' +
        '</div>' +
        '<div class="toast hidden" id="toast">コピーしました</div>' +
      '</div>'
    );
  }

  function baseCSS() {
    return (
      ':host{all:initial;}' +
      '*{box-sizing:border-box; font-family:-apple-system,BlinkMacSystemFont,"Hiragino Sans","Yu Gothic",sans-serif;}' +
      '.wano-panel{background:#fff; border-radius:14px; box-shadow:0 12px 32px rgba(0,0,0,.2); border:1px solid #e5e7eb; overflow:hidden; color:#111827;}' +
      '.head{cursor:move; display:flex; align-items:center; justify-content:space-between; padding:10px 12px; background:linear-gradient(135deg,#14b8a6,#0d9488); color:#fff;}' +
      '.head-title{font-size:13px; font-weight:700; display:flex; align-items:center; gap:6px;}' +
      '.dot{background:rgba(255,255,255,.25); border-radius:50%; width:18px; height:18px; display:inline-flex; align-items:center; justify-content:center; font-size:11px;}' +
      '.close-btn{cursor:pointer; background:rgba(255,255,255,.25); border:none; color:#fff; width:22px; height:22px; border-radius:6px; font-size:13px; line-height:1;}' +
      '.close-btn:hover{background:rgba(255,255,255,.4);}' +
      '#trial-banner-slot:empty{display:none;}' +
      '.tabs{display:flex; gap:4px; padding:8px 10px 0;}' +
      '.tab-btn{flex:1; background:#f3f4f6; border:none; border-radius:8px; padding:7px 6px; font-size:11.5px; font-weight:600; color:#111827; cursor:pointer;}' +
      '.tab-btn.active{background:#0d948822; color:#0f766e;}' +
      '.tab-content{display:none; padding:12px; max-height:70vh; overflow-y:auto;}' +
      '.tab-content.active{display:block;}' +
      '.field-label{display:block; font-size:11px; font-weight:700; color:#111827; margin-bottom:5px;}' +
      '.textarea-wrap{position:relative;}' +
      'textarea{width:100%; min-height:90px; resize:vertical; border:1px solid #e5e7eb; border-radius:10px; padding:10px 28px 10px 10px; font-size:12.5px; line-height:1.6; color:#111827;}' +
      '.clear-btn{position:absolute; top:8px; right:8px; background:#f3f4f6; border:none; border-radius:50%; width:20px; height:20px; font-size:11px; cursor:pointer; color:#111827;}' +
      '.row-between{display:flex; align-items:center; justify-content:space-between; margin-top:8px;}' +
      '.char-count{font-size:11px; color:#111827;}' +
      '.primary-btn{background:linear-gradient(135deg,#14b8a6,#0d9488); color:#fff; border:none; border-radius:10px; padding:9px 16px; font-size:12.5px; font-weight:600; cursor:pointer; display:flex; align-items:center; gap:6px;}' +
      '.result{margin-top:14px; border-top:1px solid #f3f4f6; padding-top:12px;}' +
      '.result.hidden{display:none;}' +
      '.score-block{display:flex; align-items:center; gap:12px; margin-bottom:10px;}' +
      '.score-num{font-size:30px; font-weight:800; color:#0d9488; min-width:70px;}' +
      '.rating-label{font-size:10.5px; color:#111827;}' +
      '.rating-badge{display:inline-block; font-size:11.5px; font-weight:700; padding:2px 10px; border-radius:999px; margin:2px 0; background:#0d948822; color:#0f766e;}' +
      '.rating-desc{font-size:11px; color:#111827; line-height:1.5; margin-top:2px;}' +
      '.section-title{font-size:11.5px; font-weight:700; color:#111827; margin-bottom:6px;}' +
      '.finding{border-top:1px dashed #e5e7eb; padding:8px 0; font-size:11.5px;}' +
      '.finding:first-child{border-top:none;}' +
      '.flabel{display:inline-block; font-weight:700; color:#fff; background:#e11d48; padding:1px 8px; border-radius:999px; font-size:10.5px; margin-bottom:4px;}' +
      '.fcompare{display:flex; align-items:center; gap:6px; margin:3px 0; flex-wrap:wrap;}' +
      '.bad{color:#e11d48; text-decoration:line-through;}' +
      '.good{color:#0f9d78; font-weight:600;}' +
      '.arrow{color:#111827;}' +
      '.fexpl{color:#111827; line-height:1.5;}' +
      '.empty{font-size:12px; color:#111827; text-align:center; padding:8px 0;}' +
      '.select-input{width:100%; border:1px solid #e5e7eb; border-radius:8px; padding:7px 8px; font-size:12.5px; margin-bottom:10px;}' +
      '.greet-section{margin-bottom:10px;}' +
      '.greet-title{font-size:11px; font-weight:700; color:#111827; margin-bottom:4px;}' +
      '.greet-list{display:flex; flex-direction:column; gap:4px;}' +
      '.greet-item{border:1px solid #e5e7eb; border-radius:8px; padding:6px 8px; font-size:11.5px; cursor:pointer; line-height:1.5;}' +
      '.greet-item:hover{background:#f0fdfa; border-color:#0d9488;}' +
      '.toast{position:absolute; bottom:10px; left:50%; transform:translateX(-50%); background:#111827; color:#fff; font-size:11px; padding:6px 14px; border-radius:999px;}' +
      '.toast.hidden{display:none;}' +
      '.hidden{display:none;}' +
      '.lock-screen{padding:24px 18px; text-align:center; background:linear-gradient(135deg,#0f172a,#1e1b4b); color:#f8fafc;}' +
      '.lock-screen h3{font-size:14px; color:#f59e0b; margin:0 0 8px;}' +
      '.lock-screen p{font-size:11.5px; color:#94a3b8; line-height:1.6; margin:0 0 14px;}' +
      '.lock-screen button{background:#d97706; color:#fff; border:none; border-radius:8px; padding:9px 16px; font-size:12px; font-weight:600; cursor:pointer;}'
    );
  }

  function wireBase() {
    $('#close-btn').addEventListener('click', removeWidget);
    $all('.tab-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        $all('.tab-btn').forEach(function (b) { b.classList.remove('active'); });
        $all('.tab-content').forEach(function (c) { c.classList.remove('active'); });
        btn.classList.add('active');
        $('#' + btn.dataset.tab).classList.add('active');
      });
    });
  }

  // ========================= Tab 1: 査定 =========================
  var assessmentRules = [
    { pattern: /おっしゃられる/g, label: '二重敬語', badText: 'おっしゃられる', goodText: 'おっしゃる / 言われる', explanation: '「おっしゃる」という尊敬語と、尊敬の助動詞「れる」を重ねた二重敬語です。' },
    { pattern: /ご覧になられる/g, label: '二重敬語', badText: 'ご覧になられる', goodText: 'ご覧になる', explanation: '「ご覧になる」という尊敬語に「れる」を重ねた二重敬語です。' },
    { pattern: /伺わせていただきます/g, label: '過剰敬語', badText: '伺わせていただきます', goodText: '伺います / 訪問いたします', explanation: '「伺う」で十分へりくだる表現になります。「〜させていただきます」をつけると冗長です。' },
    { pattern: /拝見させていただきます/g, label: '過剰敬語', badText: '拝見させていただきます', goodText: '拝見します / 拝見いたします', explanation: '「拝見する」自体が謙譲語ですので、「〜させていただきます」を重ねる必要はありません。' },
    { pattern: /ご苦労様です/g, label: '不躾な表現', badText: 'ご苦労様です', goodText: 'お疲れ様です', explanation: '「ご苦労様」は目上の人が目下の人をねぎらう言葉です。上司や取引先には「お疲れ様です」を使いましょう。' },
    { pattern: /了解いたしました/g, label: '不適切表現', badText: '了解いたしました', goodText: 'かしこまりました / 承知いたしました', explanation: '「了解」は立場が対等もしくは下の人に使う表現です。お客様や上司には「かしこまりました」「承知いたしました」が適切です。' },
    { pattern: /どうしますか/g, label: '言葉不足', badText: 'どうしますか', goodText: 'いかがなさいますか', explanation: 'ビジネスシーンでの質問としてはカジュアルすぎて、不躾な印象を与える恐れがあります。' },
    { pattern: /(やってください|やって欲しい|やってほしい)/g, label: '不躾な表現', badText: 'やってください', goodText: 'ご対応いただけますでしょうか', explanation: '命令口調に近く、相手に対して押し付けがましい印象を与えます。依頼調の表現に改めましょう。' },
    { pattern: /できません/g, label: '表現改善', badText: 'できません', goodText: 'いたしかねます / 差し支えがございます', explanation: '「できません」と直接断ると冷たい印象を与えます。「いたしかねます」などクッション言葉を含めて和らげます。' },
    { pattern: /参考になりました/g, label: '不適切表現', badText: '参考になりました', goodText: '大変勉強になりました', explanation: '目上の人に対して「参考にする」は評価を下すようなニュアンスになり失礼にあたります。「勉強になりました」が適切です。' },
    { pattern: /送ります/g, label: '表現改善', badText: '送ります', goodText: '送付いたします / お送りいたします', explanation: 'メール送付の際は、よりへりくだった「送付いたします」や「お送りいたします」を使うと丁寧です。' },
    { pattern: /確認してください/g, label: '表現改善', badText: '確認してください', goodText: 'ご確認いただけますと幸いです', explanation: '「〜してください」は指示的に聞こえることがあるため、「〜いただけますと幸いです」などの表現が好まれます。' },
    { pattern: /なる早で/g, label: '不適切表現', badText: 'なる早で', goodText: 'お急ぎのところ恐縮ですが / 〇日までに', explanation: '「なる早（なるべく早く）」は口語的かつ雑な指示になり、相手を急かす無礼な印象になります。具体的な日程を指定しましょう。' }
  ];
  var politeMarkerPattern = /(です|ます|ございます|いたし|ください|お願い|恐れ入り|お世話に|お疲れ様)/;
  var casualEndingPattern = /(だよ|だね|るね|るよ|くね|くよ|じゃん|でしょ|かな)[。！\s]*$/m;

  function wireAssessTab() {
    var inputEmail = $('#input-email');
    var charCount = $('#char-count');
    var clearBtn = $('#clear-input');
    var btnAssess = $('#btn-assess');
    var resultBox = $('#assess-result');

    inputEmail.addEventListener('input', function () { charCount.textContent = inputEmail.value.length; });
    clearBtn.addEventListener('click', function () {
      inputEmail.value = '';
      charCount.textContent = '0';
      resultBox.classList.add('hidden');
    });

    btnAssess.addEventListener('click', function () {
      var text = inputEmail.value.trim();
      if (!text) return;

      var findings = [];
      var score = 100;

      assessmentRules.forEach(function (rule) {
        if (text.match(rule.pattern)) { findings.push(rule); score -= 15; }
      });

      if (text.length >= 10 && !politeMarkerPattern.test(text)) {
        findings.push({ label: '敬語表現なし', badText: text.length > 20 ? text.slice(0, 20) + '…' : text, goodText: '「です・ます」調 + 適切な敬語表現', explanation: 'ビジネスメールとして最低限必要な「です・ます」調や敬語表現が一切見つかりません。友人向けのカジュアルな文章になっている可能性があります。' });
        score -= 60;
      } else if (casualEndingPattern.test(text)) {
        findings.push({ label: 'タメ口表現', badText: '〜だよ／〜だね等の話し言葉', goodText: '〜です／〜ます調に統一', explanation: '文末が友人同士のような話し言葉（タメ口）になっています。ビジネスメールでは「です・ます」調に統一しましょう。' });
        score -= 30;
      }

      if (score < 20) score = 20;
      if (text.length < 10) score = 50;

      var grade = '要改善', gradeClass = 'poor', desc = '相手への敬意や配慮が不足した表現が含まれています。すぐに修正しましょう。';
      if (score >= 90) { grade = '秀'; gradeClass = 'excellent'; desc = '素晴らしいビジネスメールです！このまま送信して問題ありません。'; }
      else if (score >= 75) { grade = '優'; gradeClass = 'good'; desc = '良好なメールです。一部の細かい言い回しを見直すことで、さらに良くなります。'; }
      else if (score >= 50) { grade = '良'; gradeClass = 'fair'; desc = '敬語表現としていくつか不十分な点があります。提案されている改善案を適用してください。'; }

      $('#score-num').textContent = score + '%';
      var badge = $('#rating-badge');
      badge.textContent = grade;
      $('#rating-desc').textContent = desc;
      $('#findings-count').textContent = findings.length;

      var list = $('#findings-list');
      if (findings.length === 0) {
        list.innerHTML = '<div class="empty">指摘事項はありません。完璧です！</div>';
      } else {
        list.innerHTML = findings.map(function (f) {
          return '<div class="finding"><span class="flabel">' + f.label + '</span>' +
            '<div class="fcompare"><span class="bad">' + f.badText + '</span><span class="arrow">→</span><span class="good">' + f.goodText + '</span></div>' +
            '<div class="fexpl">' + f.explanation + '</div></div>';
        }).join('');
      }
      resultBox.classList.remove('hidden');
    });
  }

  // ========================= Tab 2: 時候の挨拶 =========================
  var greetingsData = {
    1: { formal: ['新春の候、貴社ますますご清栄のこととお慶び申し上げます。', '初春の候、貴社ますますご清栄のこととお慶び申し上げます。', '小寒の候、貴社ますますご清栄のこととお慶び申し上げます。', '松の内も明け、貴社ますますご清栄のこととお慶び申し上げます。'], soft: ['清々しい新春の朝を迎え、いかがお過ごしでしょうか。', '初空が美しく澄み渡る頃、いかがお過ごしでしょうか。', '寒さ厳しき折ではございますが、いかがお過ごしでしょうか。', 'まだ松の内の賑やかさが残る頃、いかがお過ごしでしょうか。'], closing: ['寒さ厳しき折、皆様の温かいご健康をお祈り申し上げます。', '本年も変わらぬご指導とご鞭撻のほど、よろしくお願い申し上げます。', '風邪など召されませぬよう、どうぞご自愛ください。'] },
    2: { formal: ['晩冬の候、貴社ますますご清栄のこととお慶び申し上げます。', '立春の候、貴社ますますご清栄のこととお慶び申し上げます。', '余寒の候、貴社ますますご清栄のこととお慶び申し上げます。', '向春の候、貴社ますますご清栄のこととお慶び申し上げます。'], soft: ['暦の上では春とはいえ寒さの厳しい日々ですが、いかがお過ごしでしょうか。', '梅のつぼみもようやくほころび始め、いかがお過ごしでしょうか。', '立春を過ぎ、どことなく春の気配が感じられますが、いかがお過ごしでしょうか。', '寒明けてなお寒さの厳しい今日この頃、いかがお過ごしでしょうか。'], closing: ['春寒のみぎり、風邪など引かれませんよう温かくしてお過ごしください。', '体調を崩しやすい季節ですので、どうぞご自愛ください。', '春の訪れを心待ちにしつつ、皆様のご健康をお祈り申し上げます。'] },
    3: { formal: ['早春の候、貴社ますますご清栄のこととお慶び申し上げます。', '浅春の候、貴社ますますご清栄のこととお慶び申し上げます。', '春暖の候、貴社ますますご清栄のこととお慶び申し上げます。', '弥生の候、貴社ますますご清栄のこととお慶び申し上げます。'], soft: ['日ごとに暖かさを増し、春めいてまいりましたが、いかがお過ごしでしょうか。', '街のいたる所で花が咲き始め、心弾む季節となりましたが、いかがお過ごしでしょうか。', '木の芽吹く暖かい季節を迎えましたが、いかがお過ごしでしょうか。', '暖かな日差しが差し込む今日この頃、いかがお過ごしでしょうか。'], closing: ['季節の変わり目ですので、お体には十分お気をつけください。', '新年度に向けてご多忙の折とは存じますが、何卒ご自愛ください。', '実り多き春を迎えられますよう、心よりお祈り申し上げます。'] },
    4: { formal: ['陽春の候、貴社ますますご清栄のこととお慶び申し上げます。', '仲春の候、貴社ますますご清栄のこととお慶び申し上げます。', '惜春の候、貴社ますますご清栄のこととお慶び申し上げます。', '花時の候、貴社ますますご清栄のこととお慶び申し上げます。'], soft: ['桜の花も満開を迎え、麗らかな春の日和となりましたが、いかがお過ごしでしょうか。', '爽やかな春風が吹き抜ける季節となり、いかがお過ごしでしょうか。', '葉桜が目に鮮やかな今日この頃、いかがお過ごしでしょうか。', '新入社員の初々しい姿を見かける季節となりましたが、いかがお過ごしでしょうか。'], closing: ['新生活スタートの折、貴社のますますのご発展を心よりお祈り申し上げます。', '花冷えのする日もございますので、どうぞお体にはご自愛ください。', '今後とも変わらぬご愛顧を賜りますようお願い申し上げます。'] },
    5: { formal: ['新緑の候、貴社ますますご清栄のこととお慶び申し上げます。', '薫風の候、貴社ますますご清栄のこととお慶び申し上げます。', '立夏の候、貴社ますますご清栄のこととお慶び申し上げます。', '若葉の候、貴社ますますご清栄のこととお慶び申し上げます。'], soft: ['風薫るさわやかな季節を迎えましたが、いかがお過ごしでしょうか。', '五月晴れの青空が心地よく澄み渡る今日この頃、いかがお過ごしでしょうか。', 'つつじの花が街を彩り、初夏の気配が感じられる頃、いかがお過ごしでしょうか。', '青葉が日差しに映える清々しい季節となりましたが、いかがお過ごしでしょうか。'], closing: ['五月雨の降る肌寒い日もございますので、お体にはお気をつけください。', '気持ちの良い五月晴れのように、皆様の心弾む日々をお祈り申し上げます。', '末筆ながら、貴社のますますのご繁栄をお祈り申し上げます。'] },
    6: { formal: ['初夏の候、貴社ますますご清栄のこととお慶び申し上げます。', '梅雨の候、貴社ますますご清栄のこととお慶び申し上げます。', '向夏の候、貴社ますますご清栄のこととお慶び申し上げます。', '長雨の候、貴社ますますご清栄のこととお慶び申し上げます。'], soft: ['梅雨空が続く長雨の季節となりましたが、いかがお過ごしでしょうか。', 'あじさいの花が雨に濡れて美しく咲き誇る頃、いかがお過ごしでしょうか。', '衣替えの季節を迎え、すがすがしい今日この頃、いかがお過ごしでしょうか。', '夏至を過ぎ、日増しに暑さを覚える頃ですが、いかがお過ごしでしょうか。'], closing: ['梅雨冷えのする日もございますので、体調管理には十分ご注意ください。', 'うっとうしい梅雨の季節ですが、皆様がお元気で過ごされますようお祈り申し上げます。', '本格的な夏の到来を前に、どうぞご自愛ください。'] },
    7: { formal: ['盛夏の候、貴社ますますご清栄のこととお慶び申し上げます。', '酷暑の候、貴社ますますご清栄のこととお慶び申し上げます。', '仲夏の候、貴社ますますご清栄のこととお慶び申し上げます。', '大暑の候、貴社ますますご清栄のこととお慶び申し上げます。'], soft: ['梅雨も明け、本格的な夏がやってまいりましたが、いかがお過ごしでしょうか。', '日差しがますます厳しくなり、青空に入道雲の映える頃、いかがお過ごしでしょうか。', 'ひぐらしの声が涼を誘う夕暮れ時となりましたが、いかがお過ごしでしょうか。', '海山が恋しい夏本番の季節となりましたが、いかがお過ごしでしょうか。'], closing: ['猛暑厳しき折、体調を崩されませぬようお健やかにお過ごしください。', '寝苦しい夜が続きますが、どうぞゆっくりとお体をお休めください。', 'この夏を元気に乗り切られますよう、心よりお祈り申し上げます。'] },
    8: { formal: ['残暑の候、貴社ますますご清栄のこととお慶び申し上げます。', '晩夏の候、貴社ますますご清栄のこととお慶び申し上げます。', '立秋の候、貴社ますますご清栄のこととお慶び申し上げます。', '秋涼の候、貴社ますますご清栄のこととお慶び申し上げます。'], soft: ['立秋を過ぎてもなお厳しい暑さが続いておりますが、いかがお過ごしでしょうか。', '夕暮れには秋の虫の声が聞こえ始め、季節の移ろいを感じますが、いかがお過ごしでしょうか。', '朝夕の風にどことなく秋の気配が混じる今日この頃、いかがお過ごしでしょうか。', '夏休みの賑やかさも一段落し、落ち着きを取り戻す頃ですが、いかがお過ごしでしょうか。'], closing: ['残暑なお厳しき折、くれぐれもご自愛いただけますようお願い申し上げます。', '夏の疲れが出やすい時期ですので、どうぞお体を大切にしてください。', '秋に向けて貴社の一層のご活躍をお祈り申し上げます。'] },
    9: { formal: ['新秋の候、貴社ますますご清栄のこととお慶び申し上げます。', '初秋の候、貴社ますますご清栄のこととお慶び申し上げます。', '秋涼の候、貴社ますますご清栄のこととお慶び申し上げます。', '長月の候、貴社ますますご清栄のこととお慶び申し上げます。'], soft: ['朝夕はだいぶ涼しくなり、秋の気配が深まってまいりましたが、いかがお過ごしでしょうか。', '秋晴れの心地よい風が吹く清々しい季節となりましたが、いかがお過ごしでしょうか。', '虫の音に秋の深まりを感じる今日この頃、いかがお過ごしでしょうか。', '台風一過の青空が澄み渡る季節ですが、いかがお過ごしでしょうか。'], closing: ['朝晩は冷え込むようになりますので、お風邪など召されませぬようご自愛ください。', '秋冷の折、皆様の健康とますますのご活躍をお祈り申し上げます。', '実り多き豊かな秋をお迎えください。'] },
    10: { formal: ['仲秋の候、貴社ますますご清栄のこととお慶び申し上げます。', '秋麗の候、貴社ますますご清栄のこととお慶び申し上げます。', '神無月の候、貴社ますますご清栄のこととお慶び申し上げます。', '紅葉の候、貴社ますますご清栄のこととお慶び申し上げます。'], soft: ['木の葉も赤や黄色に色づき始め、秋たけなわの季節となりましたが、いかがお過ごしでしょうか。', '澄み渡る秋晴れの空が気持ちの良い今日この頃、いかがお過ごしでしょうか。', '夜長を鈴虫の音とともに楽しむ季節となりましたが、いかがお過ごしでしょうか。', 'さわやかな秋晴れの好季節を迎えましたが、いかがお過ごしでしょうか。'], closing: ['実り多き秋となりますよう、皆様のご健勝をお祈り申し上げます。', '日増しに肌寒くなってまいりますので、お風邪など引かれませんようご注意ください。', '今後とも変わらぬご指導・ご鞭撻を賜りますようお願い申し上げます。'] },
    11: { formal: ['晩秋の候、貴社ますますご清栄のこととお慶び申し上げます。', '向寒の候、貴社ますますご清栄のこととお慶び申し上げます。', '初冬の候、貴社ますますご清栄のこととお慶び申し上げます。', '霜降の候、貴社ますますご清栄のこととお慶び申し上げます。'], soft: ['朝晩の冷え込みが一段と厳しくなり、冬の訪れを感じる今日この頃、いかがお過ごしでしょうか。', '街路樹の葉も散り始め、冬枯れの景色が広がる頃、いかがお過ごしでしょうか。', '暦の上ではもう冬、木枯らしが吹き抜ける季節となりましたが、いかがお過ごしでしょうか。', '小春日和のうららかな陽射しが心地よい頃ですが、いかがお過ごしでしょうか。'], closing: ['木枯らしが吹く季節となりました。温かくして風邪などを防いでください。', '年の瀬も近づきお忙しい日々とは存じますが、何卒ご自愛ください。', '貴社のますますのご発展と皆様のご多幸をお祈り申し上げます。'] },
    12: { formal: ['初冬の候、貴社ますますご清栄のこととお慶び申し上げます。', '師走の候、貴社ますますご清栄のこととお慶び申し上げます。', '歳末の候、貴社ますますご清栄のこととお慶び申し上げます。', '寒冷の候、貴社ますますご清栄のこととお慶び申し上げます。'], soft: ['今年も残すところあとわずかとなり、街も慌ただしさを増しておりますが、いかがお過ごしでしょうか。', '寒さが一段と本格化し、コートの手放せない今日この頃、いかがお過ごしでしょうか。', '年の瀬の忙しい季節、皆様におかれましてはいかがお過ごしでしょうか。', '初雪の便りが聞かれる本格的な冬の到来を迎えましたが、いかがお過ごしでしょうか。'], closing: ['年末年始を控えご多忙のことと存じますが、どうぞよいお年をお迎えください。', '来年も変わらぬご愛顧を賜りますよう、お願い申し上げます。', '寒さ厳しき折、お体には十分気をつけて良い年をお迎えください。'] }
  };

  function wireGreetingsTab() {
    var selectMonth = $('#select-month');
    for (var m = 1; m <= 12; m++) {
      var opt = document.createElement('option');
      opt.value = String(m);
      opt.textContent = m + '月';
      selectMonth.appendChild(opt);
    }

    function createItem(text) {
      var div = document.createElement('div');
      div.className = 'greet-item';
      div.textContent = text;
      div.addEventListener('click', function () {
        navigator.clipboard.writeText(text).then(function () {
          var toast = $('#toast');
          toast.classList.remove('hidden');
          setTimeout(function () { toast.classList.add('hidden'); }, 2000);
        });
      });
      return div;
    }

    function populate() {
      var data = greetingsData[selectMonth.value];
      var listFormal = $('#list-formal'), listSoft = $('#list-soft'), listClosing = $('#list-closing');
      listFormal.innerHTML = ''; listSoft.innerHTML = ''; listClosing.innerHTML = '';
      if (!data) return;
      data.formal.forEach(function (g) { listFormal.appendChild(createItem(g)); });
      data.soft.forEach(function (g) { listSoft.appendChild(createItem(g)); });
      data.closing.forEach(function (g) { listClosing.appendChild(createItem(g)); });
    }

    selectMonth.addEventListener('change', populate);
    selectMonth.value = String(new Date().getMonth() + 1);
    populate();
  }

  // ========================= ライセンス / トライアル =========================
  // license-checker.js は「popup.html全体をロックする」実装(document.body全体を
  // 対象にする)なので、そのままでは閲覧中のページ本体を巻き込んでしまう。
  // ここではパネルの Shadow DOM 内だけをロック/バナー表示の対象にする。
  function applyLicenseGate() {
    if (typeof LicenseManager === 'undefined') return;
    LicenseManager.checkStatus().then(function (status) {
      if (!shadow) return; // パネルが既に閉じられていた場合
      if (status.status === 'expired') {
        lockPanel();
      } else if (status.status === 'trial') {
        showTrialBanner(status.daysLeft);
      }
    });
  }

  function lockPanel() {
    var panel = $('#wano-panel');
    var head = panel.querySelector('.head');
    Array.prototype.forEach.call(panel.children, function (child) {
      if (child !== head) child.remove();
    });
    var lock = document.createElement('div');
    lock.className = 'lock-screen';
    lock.innerHTML =
      '<h3>🔒 無料体験期間が終了しました</h3>' +
      '<p>この機能を引き続きご利用いただくには、ライセンスキーの入力、またはメールアドレスの登録（無料期間の延長）が必要です。</p>' +
      '<button id="open-license-btn">ライセンスを設定する</button>';
    panel.appendChild(lock);
    lock.querySelector('#open-license-btn').addEventListener('click', function () {
      chrome.runtime.sendMessage({ action: 'openOptionsPage' });
    });
  }

  function showTrialBanner(daysLeft) {
    var slot = $('#trial-banner-slot');
    slot.innerHTML =
      '<div style="background:#1e293b;color:#94a3b8;padding:6px 12px;font-size:11px;display:flex;justify-content:space-between;align-items:center;">' +
        '<span>無料体験中（残り ' + daysLeft + ' 日）</span>' +
        '<a href="#" id="upgrade-link" style="color:#f59e0b;text-decoration:none;font-weight:700;">プロ版へ有効化 ➔</a>' +
      '</div>';
    slot.querySelector('#upgrade-link').addEventListener('click', function (e) {
      e.preventDefault();
      chrome.runtime.sendMessage({ action: 'openOptionsPage' });
    });
  }
})();
