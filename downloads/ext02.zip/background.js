// background.js - toolbar icon click relay
// No default_popup is set (see manifest.json), so a left-click on the
// toolbar icon fires this instead. We forward it to the content script
// running on that tab, which shows/hides its on-page panel.
//
// A tab that was already open BEFORE this extension was installed/reloaded
// never gets the statically-declared content_scripts injected into it
// (Chrome does not retroactively inject into existing tabs). So if the
// first message fails, we inject the content script into that tab right
// now (using the "activeTab" permission granted by this very click) and
// retry — this removes the "reload the page first" requirement entirely.
var CONTENT_FILES = ['draggable.js', 'license/license-config.js', 'license/license-manager.js', 'content.js'];

async function ensureContentScriptAndToggle(tab) {
  if (!tab || !tab.id) return;
  try {
    await chrome.tabs.sendMessage(tab.id, { action: 'toggleWidget' });
  } catch (e) {
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: CONTENT_FILES });
      await chrome.tabs.sendMessage(tab.id, { action: 'toggleWidget' });
    } catch (e2) {
      // 対象ページで拡張機能の実行が許可されていない場合など(chrome://等)。
      console.warn('[wano] could not inject content script:', e2 && e2.message);
    }
  }
}

chrome.action.onClicked.addListener(ensureContentScriptAndToggle);

chrome.runtime.onMessage.addListener((request) => {
  if (request && request.action === 'openOptionsPage') {
    if (chrome.runtime.openOptionsPage) {
      chrome.runtime.openOptionsPage();
    } else {
      chrome.tabs.create({ url: chrome.runtime.getURL('license/license-options.html') });
    }
  }
});
