// Draggable Panel Utility (viewport-relative, robust for position:fixed elements)
// getBoundingClientRect() ベースに変更。element.offsetTop/offsetLeft は
// position:fixed 要素では信頼できない(offsetParentがnullになるため)ため使わない。
(function() {
  window.makeDraggable = function(element, handleElement) {
    if (!element) return;
    let startX = 0, startY = 0;
    const handle = handleElement || element;

    handle.style.cursor = "move";
    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (["INPUT", "BUTTON", "SELECT", "TEXTAREA", "A"].includes(e.target.tagName)) return;
      e.preventDefault();

      startX = e.clientX;
      startY = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // シールドはページの document.body に直接追加する(Shadow DOMの
      // ホスト要素に追加すると、slot が無いと描画されず機能しないため)
      const existingShield = document.getElementById("wano-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = "wano-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      startX = e.clientX;
      startY = e.clientY;

      const rect = element.getBoundingClientRect();
      let newTop = rect.top + dy;
      let newLeft = rect.left + dx;

      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById("wano-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  };
})();
