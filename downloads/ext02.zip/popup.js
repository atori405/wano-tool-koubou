



document.addEventListener('DOMContentLoaded', () => {
  // --- State ---
  let currentTheme = 'light';

  // --- Theme Toggle ---
  const themeToggle = document.getElementById('theme-toggle');
  const sunIcon = themeToggle.querySelector('.sun-icon');
  const moonIcon = themeToggle.querySelector('.moon-icon');

  const applyTheme = (theme) => {
    if (theme === 'dark') {
      document.body.classList.remove('light-theme');
      document.body.classList.add('dark-theme');
      sunIcon.style.display = 'none';
      moonIcon.style.display = 'block';
    } else {
      document.body.classList.remove('dark-theme');
      document.body.classList.add('light-theme');
      sunIcon.style.display = 'block';
      moonIcon.style.display = 'none';
    }
    currentTheme = theme;
    localStorage.setItem('assessor-theme', theme);
  };

  const savedTheme = localStorage.getItem('assessor-theme') || 'light';
  applyTheme(savedTheme);

  themeToggle.addEventListener('click', () => {
    applyTheme(currentTheme === 'light' ? 'dark' : 'light');
  });

  // --- Tab Navigation ---
  const navTabs = document.querySelectorAll('.nav-tab');
  const tabContents = document.querySelectorAll('.tab-content');

  navTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const targetTab = tab.getAttribute('data-tab');
      navTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      tabContents.forEach(content => {
        if (content.id === targetTab) {
          content.classList.add('active');
        } else {
          content.classList.remove('active');
        }
      });
    });
  });

  // --- Tab 1: Email Assessment Logic ---
  const inputEmail = document.getElementById('input-email');
  const clearInputBtn = document.getElementById('clear-input');
  const charCountSpan = document.getElementById('char-count');
  const btnAssess = document.getElementById('btn-assess');
  const resultContainer = document.getElementById('assess-result-container');
  const scoreRing = document.getElementById('score-ring');
  const scoreNum = document.getElementById('score-num');
  const ratingBadge = document.getElementById('rating-badge');
  const ratingDesc = document.getElementById('rating-desc');
  const findingsCountSpan = document.getElementById('findings-count');
  const findingsList = document.getElementById('findings-list');
  const toast = document.getElementById('toast');

  // SVG Progress Ring Circumference
  const radius = 34;
  const circumference = 2 * Math.PI * radius; // 213.63
  scoreRing.style.strokeDasharray = circumference;
  scoreRing.style.strokeDashoffset = circumference;

  const setProgress = (percent) => {
    const offset = circumference - (percent / 100) * circumference;
    scoreRing.style.strokeDashoffset = offset;
  };

  // Real-time character counter
  inputEmail.addEventListener('input', () => {
    charCountSpan.textContent = inputEmail.value.length;
  });

  clearInputBtn.addEventListener('click', () => {
    inputEmail.value = '';
    charCountSpan.textContent = 0;
    resultContainer.classList.add('hidden');
    inputEmail.focus();
  });

  // Heuristic rule patterns
  const assessmentRules = [
    {
      pattern: /おっしゃられる/g,
      type: 'double-keigo',
      label: '二重敬語',
      badText: 'おっしゃられる',
      goodText: 'おっしゃる / 言われる',
      explanation: '「おっしゃる」という尊敬語と、尊敬の助動詞「れる」を重ねた二重敬語です。'
    },
    {
      pattern: /ご覧になられる/g,
      type: 'double-keigo',
      label: '二重敬語',
      badText: 'ご覧になられる',
      goodText: 'ご覧になる',
      explanation: '「ご覧になる」という尊敬語に「れる」を重ねた二重敬語です。'
    },
    {
      pattern: /伺わせていただきます/g,
      type: 'double-keigo',
      label: '過剰敬語',
      badText: '伺わせていただきます',
      goodText: '伺います / 訪問いたします',
      explanation: '「伺う」で十分へりくだる表現になります。「〜させていただきます」をつけると冗長です。'
    },
    {
      pattern: /拝見させていただきます/g,
      type: 'double-keigo',
      label: '過剰敬語',
      badText: '拝見させていただきます',
      goodText: '拝見します / 拝見いたします',
      explanation: '「拝見する」自体が謙譲語ですので、「〜させていただきます」を重ねる必要はありません。'
    },
    {
      pattern: /ご苦労様です/g,
      type: 'rude',
      label: '不躾な表現',
      badText: 'ご苦労様です',
      goodText: 'お疲れ様です',
      explanation: '「ご苦労様」は目上の人が目下の人をねぎらう言葉です。上司や取引先には「お疲れ様です」を使いましょう。'
    },
    {
      pattern: /了解いたしました/g,
      type: 'rude',
      label: '不適切表現',
      badText: '了解いたしました',
      goodText: 'かしこまりました / 承知いたしました',
      explanation: '「了解」は立場が対等もしくは下の人に使う表現です。お客様や上司には「かしこまりました」「承知いたしました」が適切です。'
    },
    {
      pattern: /どうしますか/g,
      type: 'rude',
      label: '言葉不足',
      badText: 'どうしますか',
      goodText: 'いかがなさいますか',
      explanation: 'ビジネスシーンでの質問としてはカジュアルすぎて、不躾な印象を与える恐れがあります。'
    },
    {
      pattern: /(やってください|やって欲しい|やってほしい)/g,
      type: 'rude',
      label: '不躾な表現',
      badText: 'やってください',
      goodText: 'ご対応いただけますでしょうか',
      explanation: '命令口調に近く、相手に対して押し付けがましい印象を与えます。依頼調の表現に改めましょう。'
    },
    {
      pattern: /できません/g,
      type: 'rude',
      label: '表現改善',
      badText: 'できません',
      goodText: 'いたしかねます / 差し支えがございます',
      explanation: '「できません」と直接断ると冷たい印象を与えます。「いたしかねます」などクッション言葉を含めて和らげます。'
    },
    {
      pattern: /参考になりました/g,
      type: 'rude',
      label: '不適切表現',
      badText: '参考になりました',
      goodText: '大変勉強になりました',
      explanation: '目上の人に対して「参考にする」は評価を下すようなニュアンスになり失礼にあたります。「勉強になりました」が適切です。'
    },
    {
      pattern: /送ります/g,
      type: 'better',
      label: '表現改善',
      badText: '送ります',
      goodText: '送付いたします / お送りいたします',
      explanation: 'メール送付の際は、よりへりくだった「送付いたします」や「お送りいたします」を使うと丁寧です。'
    },
    {
      pattern: /確認してください/g,
      type: 'better',
      label: '表現改善',
      badText: '確認してください',
      goodText: 'ご確認いただけますと幸いです',
      explanation: '「〜してください」は指示的に聞こえることがあるため、「〜いただけますと幸いです」などの表現が好まれます。'
    },
    {
      pattern: /なる早で/g,
      type: 'rude',
      label: '不適切表現',
      badText: 'なる早で',
      goodText: 'お急ぎのところ恐縮ですが / 〇日までに',
      explanation: '「なる早（なるべく早く）」は口語的かつ雑な指示になり、相手を急かす無礼な印象になります。具体的な日程を指定しましょう。'
    }
  ];

  btnAssess.addEventListener('click', () => {
    const text = inputEmail.value.trim();
    if (!text) return;

    btnAssess.innerHTML = '<span>査定スキャン中...</span>';
    btnAssess.classList.add('loading');

    setTimeout(() => {
      const findings = [];
      let score = 100;

      assessmentRules.forEach(rule => {
        if (text.match(rule.pattern)) {
          findings.push(rule);
          score -= 15; // deduct 15 points per issue
        }
      });

      // General politeness check: catch text with no keigo at all (plain/casual speech),
      // which the phrase-blocklist rules above can't detect on their own.
      const politeMarkerPattern = /(です|ます|ございます|いたし|ください|お願い|恐れ入り|お世話に|お疲れ様)/;
      const casualEndingPattern = /(だよ|だね|るね|るよ|くね|くよ|じゃん|でしょ|かな)[。！\s]*$/m;

      if (text.length >= 10 && !politeMarkerPattern.test(text)) {
        findings.push({
          type: 'rude',
          label: '敬語表現なし',
          badText: text.length > 20 ? text.slice(0, 20) + '…' : text,
          goodText: '「です・ます」調 + 適切な敬語表現',
          explanation: 'ビジネスメールとして最低限必要な「です・ます」調や敬語表現が一切見つかりません。友人向けのカジュアルな文章になっている可能性があります。'
        });
        score -= 60;
      } else if (casualEndingPattern.test(text)) {
        findings.push({
          type: 'rude',
          label: 'タメ口表現',
          badText: '〜だよ／〜だね等の話し言葉',
          goodText: '〜です／〜ます調に統一',
          explanation: '文末が友人同士のような話し言葉（タメ口）になっています。ビジネスメールでは「です・ます」調に統一しましょう。'
        });
        score -= 30;
      }

      // Clamp score
      if (score < 20) score = 20;
      if (text.length < 10) score = 50; // too short email is not ideal

      // Display score and rings
      scoreNum.textContent = score;
      setProgress(score);

      // Determine Grade
      ratingBadge.className = 'rating-badge';
      let grade = '要改善';
      let gradeClass = 'poor';
      let desc = '相手への敬意や配慮が不足した表現が含まれています。すぐに修正しましょう。';

      if (score >= 90) {
        grade = '秀';
        gradeClass = 'excellent';
        desc = '素晴らしいビジネスメールです！このまま送信して問題ありません。';
      } else if (score >= 75) {
        grade = '優';
        gradeClass = 'good';
        desc = '良好なメールです。一部の細かい言い回しを見直すことで、さらに良くなります。';
      } else if (score >= 50) {
        grade = '良';
        gradeClass = 'fair';
        desc = '敬語表現としていくつか不十分な点があります。提案されている改善案を適用してください。';
      }

      ratingBadge.textContent = grade;
      ratingBadge.classList.add(gradeClass);
      ratingDesc.textContent = desc;

      // Populate Findings list
      findingsCountSpan.textContent = findings.length;
      findingsList.innerHTML = '';

      if (findings.length === 0) {
        findingsList.innerHTML = `
          <div style="text-align: center; color: var(--text-muted); font-size: 12px; padding: 20px 0;">
            指摘事項はありません。完璧です！
          </div>
        `;
      } else {
        findings.forEach(find => {
          const card = document.createElement('div');
          card.className = 'finding-card';

          card.innerHTML = `
            <div class="finding-card-header">
              <span class="finding-type-badge ${find.type}">${find.label}</span>
            </div>
            <div class="compare-box">
              <div class="comp-text original">${find.badText}</div>
              <div class="comp-arrow">→</div>
              <div class="comp-text suggestion">${find.goodText}</div>
            </div>
            <div class="finding-explanation">${find.explanation}</div>
          `;
          findingsList.appendChild(card);
        });
      }

      // Show Result Panel
      resultContainer.classList.remove('hidden');

      // Reset Button State
      btnAssess.innerHTML = `
        <span>メールを査定する</span>
        <svg class="scan-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="11" cy="11" r="8"/>
          <line x1="21" y1="21" x2="16.65" y2="16.65"/>
        </svg>
      `;
      btnAssess.classList.remove('loading');
    }, 500);
  });

  // --- Tab 2: Seasonal Greetings Logic ---
  const selectMonth = document.getElementById('select-month');
  const listFormal = document.getElementById('list-formal');
  const listSoft = document.getElementById('list-soft');
  const listClosing = document.getElementById('list-closing');

  const greetingsData = {
    1: {
      formal: ['新春の候、', '初春の候、', '小寒の候、', '松の内も明け、'],
      soft: ['清々しい新春の朝を迎え、', '初空が美しく澄み渡る頃、', '寒さ厳しき折ではございますが、', 'まだ松の内の賑やかさが残る頃、'],
      closing: ['寒さ厳しき折、皆様の温かいご健康をお祈り申し上げます。', '本年も変わらぬご指導とご鞭撻のほど、よろしくお願い申し上げます。', '風邪など召されませぬよう、どうぞご自愛ください。']
    },
    2: {
      formal: ['晩冬の候、', '立春の候、', '余寒の候、', '向春の候、'],
      soft: ['暦の上では春とはいえ寒さの厳しい日々ですが、', '梅のつぼみもようやくほころび始め、', '立春を過ぎ、どことなく春の気配が感じられますが、', '寒明けてなお寒さの厳しい今日この頃、'],
      closing: ['春寒のみぎり、風邪など引かれませんよう温かくしてお過ごしください。', '体調を崩しやすい季節ですので、どうぞご自愛ください。', '春の訪れを心待ちにしつつ、皆様のご健康をお祈り申し上げます。']
    },
    3: {
      formal: ['早春の候、', '浅春の候、', '春暖の候、', '弥生の候、'],
      soft: ['日ごとに暖かさを増し、春めいてまいりましたが、', '街のいたる所で花が咲き始め、心弾む季節となりましたが、', '木の芽吹く暖かい季節を迎えましたが、', '暖かな日差しが差し込む今日この頃、'],
      closing: ['季節の変わり目ですので、お体には十分お気をつけください。', '新年度に向けてご多忙の折とは存じますが、何卒ご自愛ください。', '実り多き春を迎えられますよう、心よりお祈り申し上げます。']
    },
    4: {
      formal: ['陽春の候、', '仲春の候、', '惜春の候、', '花時の候、'],
      soft: ['桜の花も満開を迎え、麗らかな春の日和となりましたが、', '爽やかな春風が吹き抜ける季節となり、', '葉桜が目に鮮やかな今日この頃、', '新入社員の初々しい姿を見かける季節となりましたが、'],
      closing: ['新生活スタートの折、貴社のますますのご発展を心よりお祈り申し上げます。', '花冷えのする日もございますので、どうぞお体にはご自愛ください。', '今後とも変わらぬご愛顧を賜りますようお願い申し上げます。']
    },
    5: {
      formal: ['新緑の候、', '薫風の候、', '立夏の候、', '若葉の候、'],
      soft: ['風薫るさわやかな季節を迎えましたが、', '五月晴れの青空が心地よく澄み渡る今日この頃、', 'つつじの花が街を彩り、初夏の気配が感じられる頃、', '青葉が日差しに映える清々しい季節となりましたが、'],
      closing: ['五月雨の降る肌寒い日もございますので、お体にはお気をつけください。', '気持ちの良い五月晴れのように、皆様の心弾む日々をお祈り申し上げます。', '末筆ながら、貴社のますますのご繁栄をお祈り申し上げます。']
    },
    6: {
      formal: ['初夏の候、', '梅雨の候、', '向夏の候、', '長雨の候、'],
      soft: ['梅雨空が続く長雨の季節となりましたが、', 'あじさいの花が雨に濡れて美しく咲き誇る頃、', '衣替えの季節を迎え、すがすがしい今日この頃、', '夏至を過ぎ、日増しに暑さを覚える頃ですが、'],
      closing: ['梅雨冷えのする日もございますので、体調管理には十分ご注意ください。', 'うっとうしい梅雨の季節ですが、皆様がお元気で過ごされますようお祈り申し上げます。', '本格的な夏の到来を前に、どうぞご自愛ください。']
    },
    7: {
      formal: ['盛夏の候、', '酷暑の候、', '仲夏の候,', '大暑の候、'],
      soft: ['梅雨も明け、本格的な夏がやってまいりましたが、', '日差しがますます厳しくなり、青空に入道雲の映える頃、', 'ひぐらしの声が涼を誘う夕暮れ時となりましたが、', '海山が恋しい夏本番の季節となりましたが、'],
      closing: ['猛暑厳しき折、体調を崩されませぬようお健やかにお過ごしください。', '寝苦しい夜が続きますが、どうぞゆっくりとお体をお休めください。', 'この夏を元気に乗り切られますよう、心よりお祈り申し上げます。']
    },
    8: {
      formal: ['残暑の候、', '晩夏の候、', '立秋の候、', '秋涼の候、'],
      soft: ['立秋を過ぎてもなお厳しい暑さが続いておりますが、', '夕暮れには秋の虫の声が聞こえ始め、季節の移ろいを感じますが、', '朝夕の風にどことなく秋の気配が混じる今日この頃、', '夏休みの賑やかさも一段落し、落ち着きを取り戻す頃ですが、'],
      closing: ['残暑なお厳しき折、くれぐれもご自愛いただけますようお願い申し上げます。', '夏の疲れが出やすい時期ですので、どうぞお体を大切にしてください。', '秋に向けて貴社の一層のご活躍をお祈り申し上げます。']
    },
    9: {
      formal: ['新秋の候、', '初秋の候、', '秋涼の候、', '長月の候、'],
      soft: ['朝夕はだいぶ涼しくなり、秋の気配が深まってまいりましたが、', '秋晴れの心地よい風が吹く清々しい季節となりましたが、', '虫の音に秋の深まりを感じる今日この頃、', '台風一過の青空が澄み渡る季節ですが、'],
      closing: ['朝晩は冷え込むようになりますので、お風邪など召されませぬようご自愛ください。', '秋冷の折、皆様の健康とますますのご活躍をお祈り申し上げます。', '実り多き豊かな秋をお迎えください。']
    },
    10: {
      formal: ['仲秋の候、', '秋麗の候、', '神無月の候、', '紅葉の候、'],
      soft: ['木の葉も赤や黄色に色づき始め、秋たけなわの季節となりましたが、', '澄み渡る秋晴れの空が気持ちの良い今日この頃、', '夜長を鈴虫の音とともに楽しむ季節となりましたが、', 'さわやかな秋晴れの好季節を迎えましたが、'],
      closing: ['実り多き秋となりますよう、皆様のご健勝をお祈り申し上げます。', '日増しに肌寒くなってまいりますので、お風邪など引かれませんようご注意ください。', '今後とも変わらぬご指導・ご鞭撻を賜りますようお願い申し上げます。']
    },
    11: {
      formal: ['晩秋の候、', '向寒の候、', '初冬の候、', '霜降の候、'],
      soft: ['朝晩の冷え込みが一段と厳しくなり、冬の訪れを感じる今日この頃、', '街路樹の葉も散り始め、冬枯れの景色が広がる頃、', '暦の上ではもう冬、木枯らしが吹き抜ける季節となりましたが、', '小春日和のうららかな陽射しが心地よい頃ですが、'],
      closing: ['木枯らしが吹く季節となりました。温かくして風邪などを防いでください。', '年の瀬も近づきお忙しい日々とは存じますが、何卒ご自愛ください。', '貴社のますますのご発展と皆様のご多幸をお祈り申し上げます。']
    },
    12: {
      formal: ['初冬の候、', '師走の候、', '歳末の候、', '寒冷の候、'],
      soft: ['今年も残すところあとわずかとなり、街も慌ただしさを増しておりますが、', '寒さが一段と本格化し、コートの手放せない今日この頃、', '年の瀬の忙しい季節、皆様におかれましてはいかがお過ごしでしょうか。', '初雪の便りが聞かれる本格的な冬の到来を迎えましたが、'],
      closing: ['年末年始を控えご多忙のことと存じますが、どうぞよいお年をお迎えください。', '来年も変わらぬご愛顧を賜りますよう、お願い申し上げます。', '寒さ厳しき折、お体には十分気をつけて良い年をお迎えください。']
    }
  };

  const populateGreetings = () => {
    const month = selectMonth.value;
    const data = greetingsData[month];

    listFormal.innerHTML = '';
    listSoft.innerHTML = '';
    listClosing.innerHTML = '';

    if (!data) return;

    const createItem = (text) => {
      const div = document.createElement('div');
      div.className = 'greeting-item';
      div.textContent = text;
      div.addEventListener('click', () => {
        navigator.clipboard.writeText(text).then(() => {
          toast.classList.remove('hidden');
          setTimeout(() => {
            toast.classList.add('hidden');
          }, 2000);
        });
      });
      return div;
    };

    data.formal.forEach(g => listFormal.appendChild(createItem(g)));
    data.soft.forEach(g => listSoft.appendChild(createItem(g)));
    data.closing.forEach(g => listClosing.appendChild(createItem(g)));
  };

  selectMonth.addEventListener('change', populateGreetings);

  // Default to current month
  const currentMonth = new Date().getMonth() + 1; // 1-12
  selectMonth.value = currentMonth;
  populateGreetings();
});
