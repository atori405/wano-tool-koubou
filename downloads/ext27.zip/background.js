chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "captureReceipt") {
    const { date, partner, amount, orderId, closeTab, targetTabId } = request;

    // 1. Capture the target tab as a PNG data URL.
    // captureVisibleTab always shoots whichever tab is active in the given
    // (or, if omitted, the currently focused) window. When the request comes
    // from the "mode=window" standalone popup fallback, that popup is itself
    // the focused window, so we must resolve targetTabId's own windowId
    // explicitly instead of capturing the popup by mistake.
    const runCapture = (windowId) => {
      chrome.tabs.captureVisibleTab(windowId, { format: "png" }, (dataUrl) => {
        if (chrome.runtime.lastError || !dataUrl) {
          sendResponse({ success: false, error: chrome.runtime.lastError?.message || "キャプチャに失敗しました。" });
          return;
        }
        finishCapture(dataUrl);
      });
    };

    const finishCapture = (dataUrl) => {
      // 2. Normalize metadata for windows safe filename
      const safePartner = partner.replace(/[\\/:*?"<>|\s]/g, "_");
      const safeOrderId = orderId ? "_" + orderId.replace(/[\\/:*?"<>|\s]/g, "_") : "";
      const filename = `${date}_${safePartner}_¥${amount}${safeOrderId}.png`;
      const subfolder = "領収書保存/"; // Dedicated folder name inside Downloads
      
      // 3. Download the captured file inside the subfolder
      chrome.downloads.download({
        url: dataUrl,
        filename: subfolder + filename,
        saveAs: false
      }, (downloadId) => {
        if (chrome.runtime.lastError) {
          sendResponse({ success: false, error: chrome.runtime.lastError.message });
          return;
        }
        
        // 4. Save to local storage history
        saveToHistory({
          id: Date.now(),
          date: date,
          partner: partner,
          amount: parseInt(amount, 10) || 0,
          orderId: orderId || "",
          filename: filename,
          downloadId: downloadId
        });
        
        // 5. Automatically close the tab if requested (Automation mode)
        if (closeTab && sender.tab) {
          setTimeout(() => {
            chrome.tabs.remove(sender.tab.id);
          }, 800);
        }
        
        sendResponse({ success: true, filename: filename });
      });
    };

    if (targetTabId) {
      chrome.tabs.get(targetTabId, (tab) => {
        if (chrome.runtime.lastError || !tab) {
          sendResponse({ success: false, error: "対象のタブが見つかりませんでした。" });
          return;
        }
        runCapture(tab.windowId);
      });
    } else {
      runCapture(null);
    }

    return true; // Keep message channel open for async response
  }
  
  // Close the requesting tab (used for automatic clean up of history tab)
  else if (request.action === "closeCurrentTab" && sender.tab) {
    chrome.tabs.remove(sender.tab.id);
    sendResponse({ success: true });
    return true;
  }
});

function saveToHistory(newItem) {
  chrome.storage.local.get(["receipt_history"], (data) => {
    let history = data.receipt_history || [];
    history.unshift(newItem);
    
    if (history.length > 100) {
      history = history.slice(0, 100);
    }
    
    chrome.storage.local.set({ receipt_history: history });
  });
}
