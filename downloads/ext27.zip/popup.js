// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window.
            // Pass the original tab's id through so the standalone window can
            // still target the right tab (it becomes its own focused window,
            // so it can no longer rely on "currentWindow"/"activeTab" queries
            // to find the page the user actually wants to capture).
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window&tabId=" + tabs[0].id),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

document.addEventListener("DOMContentLoaded", () => {
  // UI Elements
  const savedCount = document.getElementById("saved-count");
  const savedSum = document.getElementById("saved-sum");
  const historyList = document.getElementById("history-list");
  
  const amazonOrderIdInput = document.getElementById("amazon-order-id");
  const autoSaveBtn = document.getElementById("auto-save-btn");

  const manualForm = document.getElementById("manual-form");
  const partnerInput = document.getElementById("receipt-partner");
  const amountInput = document.getElementById("receipt-amount");
  const dateInput = document.getElementById("receipt-date");
  const orderIdInput = document.getElementById("receipt-orderid");
  
  const captureBtn = document.getElementById("capture-btn");
  const clearHistoryBtn = document.getElementById("clear-history-btn");

  // 1. Initialize Date input to today's date
  const today = new Date();
  const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
  dateInput.value = todayStr;

  // Determine which tab this popup instance should actually operate on.
  // In the "mode=window" fail-safe (this popup opened as its own standalone
  // OS window because the in-page floating panel could not be reached), this
  // window becomes the focused window, so chrome.tabs.query({currentWindow:true})
  // would resolve to itself rather than the page the user wants to capture.
  // The originating tab's id is passed explicitly in that case.
  const popupUrlParams = new URLSearchParams(window.location.search);
  const explicitTabId = popupUrlParams.get("tabId");
  let targetTabId = explicitTabId ? parseInt(explicitTabId, 10) : null;

  function withTargetTab(callback) {
    if (targetTabId) {
      chrome.tabs.get(targetTabId, (tab) => {
        callback(chrome.runtime.lastError ? null : tab);
      });
    } else {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const tab = tabs && tabs[0] ? tabs[0] : null;
        targetTabId = tab ? tab.id : null;
        callback(tab);
      });
    }
  }

  // 2. Query active tab for metadata to auto-prefill the manual form
  withTargetTab((tab) => {
    if (tab) {
      const url = tab.url || "";
      if (url.includes("amazon.co.jp") || url.includes("rakuten.co.jp") || url.includes("yahoo.co.jp")) {
        chrome.tabs.sendMessage(tab.id, { action: "getReceiptMetadata" }, (response) => {
          if (response && !response.error) {
            partnerInput.value = response.partner || "";
            amountInput.value = response.amount || "";
            orderIdInput.value = response.orderId || "";
            if (response.date) {
              const formattedDate = `${response.date.substring(0, 4)}-${response.date.substring(4, 6)}-${response.date.substring(6, 8)}`;
              dateInput.value = formattedDate;
            }
          }
        });
      }
    }
  });

  // 3. Universal Order ID Auto-Save Automation
  autoSaveBtn.addEventListener("click", () => {
    const orderId = amazonOrderIdInput.value.trim();
    if (!orderId) {
      alert("注文番号を入力してください。");
      return;
    }
    
    let url = "";
    let isHistoryRequired = false;
    
    // 1. Amazon pattern: 3 digits - 7 digits - 7 digits
    const amazonPattern = /^\d{3}-\d{7}-\d{7}$/;
    // 2. Rakuten pattern: digits - 8-digit date - digits
    const rakutenPattern = /^\d+-\d{8}-\d+$/;
    // 3. Yahoo Shopping pattern: storeID (alphanumeric) - digits
    const yahooPattern = /^[a-zA-Z0-9]+-\d+$/;

    if (amazonPattern.test(orderId)) {
      url = `https://www.amazon.co.jp/gp/css/summary/print.html?orderID=${orderId}`;
      isHistoryRequired = false;
    } else if (rakutenPattern.test(orderId)) {
      url = "https://order.my.rakuten.co.jp/";
      isHistoryRequired = true;
    } else if (yahooPattern.test(orderId)) {
      url = "https://odhistory.shopping.yahoo.co.jp/OS/stat/list";
      isHistoryRequired = true;
    } else {
      alert("対応する注文番号の形式ではありません。\n・Amazon: 250-5569347-2882264\n・楽天市場: 384013-20260517-0398028165\n・Yahoo: bestone1-12949229");
      return;
    }

    autoSaveBtn.disabled = true;
    autoSaveBtn.innerText = "処理中... ⏳";

    // Set storage target for both auto-clicking (if history is opened) and auto-saving (receipt page)
    const storageObj = { autoSaveTargetOrderId: orderId };
    if (isHistoryRequired) {
      storageObj.autoClickOrderId = orderId;
    }

    chrome.storage.local.set(storageObj, () => {
      chrome.tabs.create({ url: url, active: true }, (tab) => {
        const tabId = tab.id;
        
        // Watch for the tab closing to clean up UI (fallback if popup stays open)
        const tabRemovalListener = (removedTabId) => {
          if (removedTabId === tabId) {
            autoSaveBtn.disabled = false;
            autoSaveBtn.innerText = "自動保存 🚀";
            amazonOrderIdInput.value = "";
            setTimeout(loadHistory, 500);
            chrome.tabs.onRemoved.removeListener(tabRemovalListener);
          }
        };
        
        chrome.tabs.onRemoved.addListener(tabRemovalListener);
      });
    });
  });

  // 4. Load history and render statistics
  function loadHistory() {
    chrome.storage.local.get(["receipt_history"], (data) => {
      const history = data.receipt_history || [];
      renderHistoryList(history);
      renderStatistics(history);
    });
  }

  function renderHistoryList(history) {
    historyList.innerHTML = "";
    
    if (history.length === 0) {
      historyList.innerHTML = '<div class="empty-history-message">保存履歴はありません。</div>';
      return;
    }

    const recent = history.slice(0, 10);
    
    recent.forEach(item => {
      const card = document.createElement("div");
      card.className = "history-item";
      card.style.cursor = "pointer";
      card.title = "クリックで保存したスクショ画像を開く";
      
      const formattedDate = `${item.date.substring(0, 4)}/${item.date.substring(4, 6)}/${item.date.substring(6, 8)}`;
      
      card.innerHTML = `
        <div class="item-details">
          <div class="item-title" title="${item.filename}">${item.partner}</div>
          <div class="item-sub">金額: <strong>¥${item.amount.toLocaleString()}</strong></div>
        </div>
        <div class="item-date">${formattedDate}</div>
      `;

      // Open the downloaded file using Chrome Downloads API when clicked
      card.addEventListener("click", () => {
        if (item.downloadId) {
          chrome.downloads.open(item.downloadId, () => {
            if (chrome.runtime.lastError) {
              console.log("Could not open file: " + chrome.runtime.lastError.message);
              alert("ファイルを開けませんでした。(ファイルが削除・移動されているか、ダウンロード履歴から消去されている可能性があります)");
            }
          });
        } else {
          alert("このアイテムにはダウンロードIDがありません。");
        }
      });

      historyList.appendChild(card);
    });
  }

  function renderStatistics(history) {
    const curDate = new Date();
    const curYearMonth = `${curDate.getFullYear()}${String(curDate.getMonth() + 1).padStart(2, '0')}`;
    
    let count = 0;
    let sum = 0;

    history.forEach(item => {
      if (item.date && item.date.startsWith(curYearMonth)) {
        count++;
        sum += item.amount;
      }
    });

    savedCount.innerHTML = `${count}<span class="stat-unit">枚</span>`;
    savedSum.innerText = `¥${sum.toLocaleString()}`;
  }

  // 5. Form Submit for Manual Capture
  manualForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const partner = partnerInput.value.trim();
    const amount = parseInt(amountInput.value, 10);
    const dateRaw = dateInput.value;
    const orderId = orderIdInput.value.trim();

    if (!partner || isNaN(amount) || amount < 0 || !dateRaw) {
      alert("入力項目を確認してください。");
      return;
    }

    const dateCleaned = dateRaw.replace(/-/g, "");

    captureBtn.disabled = true;
    captureBtn.innerText = "キャプチャ処理中...";

    chrome.runtime.sendMessage({
      action: "captureReceipt",
      date: dateCleaned,
      partner: partner,
      amount: amount,
      orderId: orderId,
      targetTabId: targetTabId
    }, (response) => {
      captureBtn.disabled = false;
      captureBtn.innerText = "表示画面をスクショ保存 📸";

      if (response && response.success) {
        partnerInput.value = "";
        amountInput.value = "";
        orderIdInput.value = "";
        dateInput.value = todayStr;
        loadHistory();
      } else {
        alert("キャプチャ保存に失敗しました: " + (response?.error || "不明なエラー"));
      }
    });
  });

  // 6. Clear history
  clearHistoryBtn.addEventListener("click", () => {
    if (confirm("これまでの領収書保存履歴をすべてクリアしますか？(ローカルファイル自体は削除されません)")) {
      chrome.storage.local.remove("receipt_history", () => {
        loadHistory();
      });
    }
  });

  // Initial load
  loadHistory();
});
