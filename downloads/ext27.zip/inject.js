// Override window.print to prevent the native print preview dialog from blocking the UI
if (window.location.href.includes("print.html") || window.location.href.includes("receipt")) {
  window._originalPrint = window.print;
  window.print = function() {
    console.log("Native print preview dialog blocked by Receipt Screenshot Auto-Saver extension.");
  };
}
