// Listen for messages from popup to pre-fill manual form
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "getReceiptMetadata") {
    try {
      const url = window.location.href;
      let shopName = "その他";
      if (url.includes("amazon.co.jp")) shopName = "Amazon";
      else if (url.includes("rakuten.co.jp")) shopName = "楽天市場";
      else if (url.includes("yahoo.co.jp")) shopName = "Yahoo!ショッピング";

      const metadata = extractMetadata(shopName);
      sendResponse(metadata);
    } catch (e) {
      sendResponse({ error: e.message });
    }
  }
  return true;
});

// Run extraction and auto-click check when DOM is fully settled
window.addEventListener("load", () => {
  setTimeout(initReceiptSaver, 1000);
  setTimeout(checkAutoClickTarget, 1500);
});

function initReceiptSaver() {
  const url = window.location.href;
  let matched = false;
  let shopName = "その他";

  // Check if current URL matches a supported receipt page or order details page
  if (url.includes("amazon.co.jp") && (url.includes("print.html") || url.includes("order-details"))) {
    matched = true;
    shopName = "Amazon";
  } else if (url.includes("rakuten.co.jp") && (url.includes("receipt/show") || url.includes("ord/detail") || url.includes("history.step.rakuten.co.jp"))) {
    matched = true;
    shopName = "楽天市場";
  } else if (url.includes("yahoo.co.jp") && (url.includes("receipt") || url.includes("odhistory.shopping.yahoo.co.jp"))) {
    matched = true;
    shopName = "Yahoo!ショッピング";
  }

  if (!matched) return;

  const metadata = extractMetadata(shopName);

  // Check storage if this order matches the autoSave target
  chrome.storage.local.get(["autoSaveTargetOrderId"], (res) => {
    if (res.autoSaveTargetOrderId && metadata.orderId === res.autoSaveTargetOrderId) {
      
      // Special logic for Rakuten: Automatically click "発行する" (Issue) if name-input screen is shown
      if (shopName === "楽天市場") {
        let issueBtn = null;
        const buttons = document.querySelectorAll("input, button, a");
        for (let btn of buttons) {
          if (btn.value === "発行する" || btn.innerText === "発行する" || (btn.innerText && btn.innerText.includes("発行する"))) {
            issueBtn = btn;
            break;
          }
        }
        
        if (issueBtn) {
          // Automatically trigger the form submit to issue the receipt
          setTimeout(() => {
            issueBtn.click();
          }, 300);
          return; // Do not capture yet. Wait for the page to submit and reload to the actual receipt.
        }
      }
      
      // Clear the target so it won't double trigger
      chrome.storage.local.remove("autoSaveTargetOrderId");
      injectFloatingButton(metadata);
      triggerAutoSave(metadata);
    } else {
      // Normal manual view
      injectFloatingButton(metadata);
    }
  });
}

// -------------------------------------------------------------
// History Page Auto-Click Agent
// -------------------------------------------------------------
function checkAutoClickTarget() {
  chrome.storage.local.get(["autoClickOrderId"], (res) => {
    if (res.autoClickOrderId) {
      const orderId = res.autoClickOrderId;
      const url = window.location.href;
      
      let clicked = false;
      if (url.includes("rakuten.co.jp")) {
        clicked = clickRakutenReceipt(orderId);
      } else if (url.includes("yahoo.co.jp")) {
        clicked = clickYahooReceipt(orderId);
      }
      
      if (clicked) {
        // Clear click target so we don't click it again
        chrome.storage.local.remove("autoClickOrderId");
        
        // Clean up this history tab after 2.5 seconds (gives browser time to launch receipt tab)
        setTimeout(() => {
          chrome.runtime.sendMessage({ action: "closeCurrentTab" });
        }, 2500);
      }
    }
  });
}

function clickRakutenReceipt(orderId) {
  const allElements = document.querySelectorAll("body *");
  let orderEl = null;
  for (let el of allElements) {
    if (el.children.length === 0 && el.innerText && el.innerText.includes(orderId)) {
      orderEl = el;
      break;
    }
  }
  if (!orderEl) return false;

  // Traverse up to find the order container card (table or specific element)
  let parent = orderEl;
  while (parent && parent !== document.body) {
    if (parent.tagName === "TABLE" || parent.classList.contains("order-box") || parent.classList.contains("purchase-history-item") || parent.classList.contains("order-card")) {
      break;
    }
    parent = parent.parentElement;
  }
  if (!parent) parent = document.body;

  const buttons = parent.querySelectorAll("a, button, input");
  for (let btn of buttons) {
    const text = btn.innerText || btn.value || "";
    if (text.includes("領収書") || text.includes("請求書") || text.includes("発行")) {
      btn.click();
      return true;
    }
  }
  return false;
}

function clickYahooReceipt(orderId) {
  const allElements = document.querySelectorAll("body *");
  let orderEl = null;
  for (let el of allElements) {
    if (el.children.length === 0 && el.innerText && el.innerText.includes(orderId)) {
      orderEl = el;
      break;
    }
  }
  if (!orderEl) return false;

  let parent = orderEl;
  while (parent && parent !== document.body) {
    if (parent.classList.contains("elOrderHistoryItem") || parent.classList.contains("OrderHistoryItem") || parent.tagName === "LI" || parent.tagName === "DIV") {
      const hasReceipt = Array.from(parent.querySelectorAll("a, button, input")).some(btn => {
        const text = btn.innerText || btn.value || "";
        return text.includes("領収書") || text.includes("発行");
      });
      if (hasReceipt) break;
    }
    parent = parent.parentElement;
  }
  if (!parent) parent = document.body;

  const buttons = parent.querySelectorAll("a, button, input");
  for (let btn of buttons) {
    const text = btn.innerText || btn.value || "";
    if (text.includes("領収書") || text.includes("発行")) {
      btn.click();
      return true;
    }
  }
  return false;
}

// -------------------------------------------------------------
// Helpers & Parsers
// -------------------------------------------------------------
function parseNumber(text) {
  if (!text) return 0;
  const cleaned = text.replace(/[¥￥,円\s]/g, "");
  const num = parseInt(cleaned, 10);
  return isNaN(num) ? 0 : num;
}

function parseDate(text) {
  if (!text) return null;
  
  // 1. Matches YYYY年MM月DD日
  let match = text.match(/(\d{4})年\s*(\d{1,2})月\s*(\d{1,2})日/);
  if (match) {
    return `${match[1]}${match[2].padStart(2, '0')}${match[3].padStart(2, '0')}`;
  }
  
  // 2. Matches YYYY/MM/DD
  match = text.match(/(\d{4})[/\-](\d{1,2})[/\-](\d{1,2})/);
  if (match) {
    return `${match[1]}${match[2].padStart(2, '0')}${match[3].padStart(2, '0')}`;
  }
  
  // 3. Matches English format (e.g. July 2, 2026)
  const months = {
    jan: "01", feb: "02", mar: "03", apr: "04", may: "05", jun: "06",
    jul: "07", aug: "08", sep: "09", oct: "10", nov: "11", dec: "12"
  };
  match = text.match(/([A-Za-z]+)\s+(\d{1,2}),\s*(\d{4})/);
  if (match) {
    const monthName = match[1].toLowerCase().substring(0, 3);
    const month = months[monthName] || "01";
    return `${match[3]}${month}${match[2].padStart(2, '0')}`;
  }
  
  return null;
}

function extractAmazonAmount(bodyText) {
  const priorities = [
    /ご請求額\s*[:：]?\s*[¥￥\s]*([\d,]+)/i,
    /注文合計\s*[:：]?\s*[¥￥\s]*([\d,]+)/i,
    /注文の合計\s*[:：]?\s*[¥￥\s]*([\d,]+)/i,
    /総計\s*[:：]?\s*[¥￥\s]*([\d,]+)/i,
    /Grand\s*Total\s*[:：]?\s*[¥￥\s]*([\d,]+)/i
  ];
  
  for (let regex of priorities) {
    const match = bodyText.match(regex);
    if (match) {
      const val = parseNumber(match[1]);
      if (val > 0) return val;
    }
  }
  return 0;
}

function extractYahooAmount(bodyText) {
  const amountEl = document.querySelector(".elTotalAmount, .elPrice, .receipt-amount");
  if (amountEl) {
    const val = parseNumber(amountEl.innerText);
    if (val > 0) return val;
  }

  const priorities = [
    /合計金額\s*(?:\(税込\))?\s*[:：]?\s*[¥￥\s]*([\d,]+)/i,
    /領収金額\s*[:：]?\s*[¥￥\s]*([\d,]+)/i,
    /合計金額\s*[:：]?\s*[¥￥\s]*([\d,]+)/i,
    /合計\s*[:：]?\s*[¥￥\s]*([\d,]+)/i
  ];
  
  for (let regex of priorities) {
    const match = bodyText.match(regex);
    if (match) {
      const val = parseNumber(match[1]);
      if (val > 0) return val;
    }
  }
  return 0;
}

function extractMetadata(shopName) {
  let date = "";
  let amount = 0;
  let orderId = "";
  let partner = shopName;

  const bodyText = document.body.innerText;

  if (shopName === "Amazon") {
    // 1. Extract Order ID directly using pattern (3-7-7 digits)
    const amazonOrderMatch = bodyText.match(/\b\d{3}-\d{7}-\d{7}\b/);
    if (amazonOrderMatch) {
      orderId = amazonOrderMatch[0];
    }

    // 2. Extract Date
    const dateMatch = bodyText.match(/注文日：?\s*([^\n|]+)/i) || bodyText.match(/Order\s*Date：?\s*([^\n|]+)/i);
    if (dateMatch) {
      const parsed = parseDate(dateMatch[1]);
      if (parsed) date = parsed;
    }

    // 3. Extract Amount strictly associated with grand total labels
    amount = extractAmazonAmount(bodyText);
  } 
  
  else if (shopName === "楽天市場") {
    // 1. Extract Shop Name (Partner)
    // First, look for direct store links on the page (highly specific for order details / history)
    const links = document.querySelectorAll("a");
    for (let link of links) {
      const href = link.href || "";
      const text = link.innerText || "";
      if (href.includes("rakuten.co.jp/") || href.includes("rakuten.ne.jp/")) {
        if (text.includes("楽天市場店") || text.includes("店")) {
          partner = text.replace(/御中/g, "").trim();
          break;
        }
      }
    }
    
    // Fallback: Look for elements ending with "楽天市場店" (Limit element length to prevent outer containers)
    if (!partner || partner === "楽天市場") {
      const shopCandidates = document.querySelectorAll("a, h2, h3, b, th, td, span");
      for (let el of shopCandidates) {
        const t = el.innerText || "";
        if (t.includes("楽天市場店") && t.length < 50) {
          partner = t.replace(/御中/g, "").trim();
          break;
        }
      }
    }
    
    // Fallback to receipt selectors
    if (!partner || partner === "楽天市場") {
      const shopEl = document.querySelector(".shop-name, .merchant-name") || document.querySelector("td[align='left'] font[size='+1']");
      if (shopEl) partner = shopEl.innerText.replace(/御中/g, "").trim();
    }

    // 2. Extract Date
    // Try to find "注文日時" or "注文日"
    const dateMatch = bodyText.match(/注文日時\s*[:：]?\s*([^\s(]+)/) || bodyText.match(/注文日\s*[:：]?\s*([^\s(]+)/);
    if (dateMatch) {
      const parsed = parseDate(dateMatch[1]);
      if (parsed) date = parsed;
    }
    
    // Fallback date detection
    if (!date) {
      const dateEl = document.querySelector(".receipt-date, td[align='right']") || document.evaluate(
        "//*[contains(text(), '発行日') or contains(text(), '取引日')]",
        document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null
      ).singleNodeValue;
      
      if (dateEl) {
        const parsed = parseDate(dateEl.innerText);
        if (parsed) date = parsed;
      }
    }

    // 3. Extract Order ID directly using pattern (Rakuten format: storeID-YYYYMMDD-sequence)
    const rakutenOrderMatch = bodyText.match(/\b\d+-\d{8}-\d+\b/);
    if (rakutenOrderMatch) {
      orderId = rakutenOrderMatch[0];
    }

    // 4. Extract Amount (checks cell-spanning amounts with newlines)
    const amountRegexes = [
      /(?:支払い金額|お支払い金額|支払金額|合計金額|合計|ご請求額)\s*[:：]?\s*[\s\n]*[¥￥\s]*([\d,]+)/i
    ];
    for (let regex of amountRegexes) {
      const match = bodyText.match(regex);
      if (match) {
        const val = parseNumber(match[1]);
        if (val > 0) {
          amount = val;
          break;
        }
      }
    }
    
    // Fallback amount detection
    if (!amount) {
      const amountEl = document.querySelector(".total-price, .receipt-total, #amount") || document.evaluate(
        "//*[contains(text(), '金額') or contains(text(), '領収金額')]/following::*[1]",
        document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null
      ).singleNodeValue;
      
      if (amountEl) {
        amount = parseNumber(amountEl.innerText);
      }
    }
  } 
  
  else if (shopName === "Yahoo!ショッピング") {
    // 1. Extract Order ID (handles optional colons or spacing next to 注文番号 label)
    const orderMatch = bodyText.match(/注文番号：?\s*([a-zA-Z0-9\-]+)/i) || bodyText.match(/注文番号\s*([a-zA-Z0-9\-]+)/i);
    if (orderMatch) {
      orderId = orderMatch[1].trim();
    } else {
      // Direct pattern match fallback for Yahoo order ID: storeID-orderNumber
      const yahooOrderPattern = bodyText.match(/\b([a-zA-Z0-9]+-\d+)\b/);
      if (yahooOrderPattern) {
        orderId = yahooOrderPattern[0];
      }
    }

    // 2. Extract Date
    const dateMatch = bodyText.match(/注文日：?\s*([^\n]+)/i) || bodyText.match(/注文日\s*([^\n]+)/i) || bodyText.match(/発行日：?\s*([^\n]+)/i) || bodyText.match(/注文日：?\s*([^\n]+)/i);
    if (dateMatch) {
      const parsed = parseDate(dateMatch[1]);
      if (parsed) date = parsed;
    }

    // 3. Extract Amount
    amount = extractYahooAmount(bodyText);

    // 4. Determine Partner (append Yahoo store ID prefix if available)
    if (orderId && orderId.includes("-")) {
      const shopId = orderId.split("-")[0];
      if (isNaN(shopId)) {
        partner = `Yahoo!ショッピング_${shopId}`;
      }
    }
  }

  // Fallbacks if not detected
  if (!date) {
    const d = new Date();
    date = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  }
  if (!amount) amount = 0;

  return { date, partner, amount, orderId };
}

function injectFloatingButton(metadata) {
  // Create UI Container
  const container = document.createElement("div");
  container.id = "receipt-saver-container";
  container.innerHTML = `
    <div class="receipt-saver-btn-group">
      <div id="receipt-saver-floating-btn" class="receipt-saver-btn">
        <span class="rs-btn-icon">📸</span>
        <span class="rs-btn-text">電帳法対応・領収書保存</span>
        
        <!-- Hover Metadata Tooltip -->
        <div class="rs-tooltip">
          <div class="rs-tooltip-title">🔍 検出された領収データ</div>
          <div class="rs-tooltip-item"><span>取引日:</span> <strong>${metadata.date}</strong></div>
          <div class="rs-tooltip-item"><span>取引先:</span> <strong>${metadata.partner}</strong></div>
          <div class="rs-tooltip-item"><span>金額:</span> <strong>¥${metadata.amount.toLocaleString()}</strong></div>
          ${metadata.orderId ? `<div class="rs-tooltip-item"><span>注文番号:</span> <strong>${metadata.orderId}</strong></div>` : ''}
          <div class="rs-tooltip-footer">クリックで自動スクショ ＆ 保存します</div>
        </div>
      </div>
      
      <!-- Manual Print Fallback Button -->
      <div id="receipt-saver-print-btn" class="receipt-saver-print-btn" title="通常の印刷ダイアログを開きます">
        🖨️ 印刷
      </div>
    </div>
    
    <!-- Success Toast Notification -->
    <div id="receipt-saver-toast" class="rs-toast hidden">
      <span class="rs-toast-icon">🎉</span>
      <span class="rs-toast-text">保存完了しました！</span>
    </div>
  `;
  document.body.appendChild(container);

  // Hook Click Events
  const btn = document.getElementById("receipt-saver-floating-btn");
  const printBtn = document.getElementById("receipt-saver-print-btn");
  const toast = document.getElementById("receipt-saver-toast");

  btn.addEventListener("click", () => {
    container.style.display = "none";
    document.documentElement.classList.add("receipt-saver-capturing");
    
    setTimeout(() => {
      chrome.runtime.sendMessage({
        action: "captureReceipt",
        date: metadata.date,
        partner: metadata.partner,
        amount: metadata.amount,
        orderId: metadata.orderId
      }, (response) => {
        container.style.display = "block";
        document.documentElement.classList.remove("receipt-saver-capturing");

        if (response && response.success) {
          toast.classList.remove("hidden");
          setTimeout(() => {
            toast.classList.add("hidden");
          }, 3500);
        } else {
          alert("領収書の保存に失敗しました: " + (response?.error || "不明なエラー"));
        }
      });
    }, 150);
  });

  if (printBtn) {
    printBtn.addEventListener("click", () => {
      const script = document.createElement("script");
      script.textContent = "if (window._originalPrint) window._originalPrint(); else window.print();";
      document.body.appendChild(script);
      script.remove();
    });
  }
}

function triggerAutoSave(metadata) {
  setTimeout(() => {
    const container = document.getElementById("receipt-saver-container");
    if (container) container.style.display = "none";
    document.documentElement.classList.add("receipt-saver-capturing");

    setTimeout(() => {
      chrome.runtime.sendMessage({
        action: "captureReceipt",
        date: metadata.date,
        partner: metadata.partner,
        amount: metadata.amount,
        orderId: metadata.orderId,
        closeTab: true
      }, (response) => {
        if (!response || !response.success) {
          if (container) container.style.display = "block";
          document.documentElement.classList.remove("receipt-saver-capturing");
          alert("全自動保存に失敗しました: " + (response?.error || "不明なエラー"));
        }
      });
    }, 250);
  }, 1000);
}


// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  const NS_ID = "wano-" + chrome.runtime.id;

  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // Add temporary shield to prevent iframe from stealing mouse events during dragging
      const existingShield = document.getElementById(NS_ID + "-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = NS_ID + "-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      // Use getBoundingClientRect() for correct viewport-relative position
      // (element.offsetTop is unreliable for position:fixed elements on scrolled pages)
      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      // Restrict within window boundaries to prevent going offscreen
      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById(NS_ID + "-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById(NS_ID + "-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "block" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = NS_ID + "-floating-container";
    
    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 440) + "px !important; z-index:2147483647 !important; width:430px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="${NS_ID}-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">Receipt Saver</span>
        </div>
        <button id="${NS_ID}-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#" + NS_ID + "-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#" + NS_ID + "-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
