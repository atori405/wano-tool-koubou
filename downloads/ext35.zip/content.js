(() => {
  const OVERLAY_ID = "jpop-privacy-filter-overlay";
  let activeOverlay = null;
  let currentSettings = null;
  let isTrackingMouse = false;

  // --- 1. Init Overlay Element ---
  function initOverlay() {
    if (activeOverlay && document.getElementById(OVERLAY_ID)) return;

    let overlay = document.getElementById(OVERLAY_ID);
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = OVERLAY_ID;
      overlay.style.position = "fixed";
      overlay.style.top = "0";
      overlay.style.left = "0";
      overlay.style.right = "0";
      overlay.style.bottom = "0";
      overlay.style.pointerEvents = "none"; // Crucial: Let clicks propagate to the page below
      overlay.style.zIndex = "2147483647"; // Float on very top
      overlay.style.display = "none";
    }

    if (document.body) {
      if (overlay.parentNode !== document.body) {
        document.body.appendChild(overlay);
      }
      activeOverlay = overlay;
    } else {
      if (overlay.parentNode !== document.documentElement) {
        document.documentElement.appendChild(overlay);
      }
      activeOverlay = overlay;

      // Migrate to body once DOM renders
      const observer = new MutationObserver((mutations, obs) => {
        if (document.body) {
          if (overlay.parentNode !== document.body) {
            document.body.appendChild(overlay);
          }
          obs.disconnect();
        }
      });
      observer.observe(document.documentElement, { childList: true, subtree: true });
    }
  }

  // --- 2. Mouse Move Tracker (Spotlight update) ---
  function updateSpotlightCoords(e) {
    if (!activeOverlay) return;
    activeOverlay.style.setProperty("--spot-x", `${e.clientX}px`);
    activeOverlay.style.setProperty("--spot-y", `${e.clientY}px`);
  }

  function startMouseTracking() {
    if (isTrackingMouse) return;
    document.addEventListener("mousemove", updateSpotlightCoords, { passive: true });
    isTrackingMouse = true;
  }

  function stopMouseTracking() {
    if (!isTrackingMouse) return;
    document.removeEventListener("mousemove", updateSpotlightCoords);
    isTrackingMouse = false;
  }

  // --- 3. Apply settings & pattern styles ---
  function applyFilter() {
    if (!activeOverlay) return;

    if (!currentSettings || !currentSettings.enabled) {
      activeOverlay.style.display = "none";
      stopMouseTracking();
      return;
    }

    const hostname = window.location.hostname.toLowerCase();
    if (isWhitelisted(hostname, currentSettings.whitelist || [])) {
      activeOverlay.style.display = "none";
      stopMouseTracking();
      return;
    }

    // Set classes and custom CSS variables
    const pattern = currentSettings.pattern || "sudare";
    activeOverlay.className = `privacy-pattern-${pattern}`;

    // Apply intensity variable (used by CSS to adjust opacity or blur radius)
    activeOverlay.style.setProperty("--privacy-intensity", (currentSettings.intensity / 100).toString());
    activeOverlay.style.setProperty("--privacy-blur-radius", `${Math.round(currentSettings.intensity * 0.15)}px`);

    // Mode handling
    if (currentSettings.mode === "spotlight") {
      activeOverlay.classList.add("mode-spotlight");
      activeOverlay.style.setProperty("--spot-size", `${currentSettings.spotlightSize}px`);
      startMouseTracking();
    } else {
      activeOverlay.classList.remove("mode-spotlight");
      stopMouseTracking();
    }

    activeOverlay.style.display = "block";
  }

  // --- 4. Helper: Check Whitelist ---
  function isWhitelisted(hostname, whitelist) {
    return whitelist.some(domain => {
      const cleaned = domain.trim().toLowerCase();
      if (!cleaned) return false;
      return hostname === cleaned || hostname.endsWith("." + cleaned);
    });
  }

  // --- 5. Main Flow ---
  initOverlay();

  // Load settings with fallback defaults
  chrome.storage.local.get(["privacyFilterSettings"], (result) => {
    if (result.privacyFilterSettings) {
      currentSettings = result.privacyFilterSettings;
    } else {
      currentSettings = {
        enabled: true,
        mode: "spotlight",
        pattern: "sudare",
        intensity: 50,
        spotlightSize: 80,
        whitelist: []
      };
    }
    applyFilter();
  });

  // Watch for settings changes
  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === "local" && changes.privacyFilterSettings) {
      currentSettings = changes.privacyFilterSettings.newValue;
      applyFilter();
    }
  });

  // Re-check on DOM loaded
  document.addEventListener("DOMContentLoaded", () => {
    initOverlay();
    applyFilter();
  });
})();


// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // Add temporary shield to prevent iframe from stealing mouse events during dragging
      const existingShield = document.getElementById("wano-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = "wano-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      // Use getBoundingClientRect() for correct viewport-relative position
      // (element.offsetTop is unreliable for position:fixed elements on scrolled pages)
      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      // Restrict within window boundaries to prevent going offscreen
      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById("wano-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  function toggleFloatingPanel() {
    let container = document.getElementById("wano-universal-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "block" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = "wano-universal-floating-container";
    
    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 440) + "px !important; z-index:2147483647 !important; width:430px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="wano-u-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">Commuter Privacy</span>
        </div>
        <button id="wano-u-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#wano-u-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#wano-u-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
