// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window.
            // Pass the original tab's id through so the standalone window can
            // still target the right tab for "exclude this site" (it becomes
            // its own focused window, so chrome.tabs.query({currentWindow:true})
            // would otherwise resolve to itself instead of the page the user
            // wants to whitelist).
            var w = Math.min(screen.availWidth, 420);
            var h = Math.min(screen.availHeight, 620);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window&tabId=" + tabs[0].id),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 420,
          height: 620,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

document.addEventListener("DOMContentLoaded", () => {
  // Elements
  const masterToggle = document.getElementById("master-toggle");
  const modeSpotlightBtn = document.getElementById("mode-spotlight");
  const modeFullBtn = document.getElementById("mode-full");
  const patternGrid = document.getElementById("pattern-grid");
  
  const intensitySlider = document.getElementById("intensity-slider");
  const intensityValue = document.getElementById("intensity-value");
  
  const spotlightSlider = document.getElementById("spotlight-slider");
  const spotlightValue = document.getElementById("spotlight-value");
  const spotlightSizeGroup = document.getElementById("spotlight-size-group");

  const addCurrentSiteBtn = document.getElementById("add-current-site-btn");
  const whitelistList = document.getElementById("whitelist-list");
  const statusDot = document.getElementById("status-dot");
  const statusText = document.getElementById("footer-status-text");

  // State
  let settings = {
    enabled: true,
    mode: "spotlight",
    pattern: "sudare",
    intensity: 50,
    spotlightSize: 80,
    whitelist: []
  };

  let currentTabUrl = "";
  let currentTabHostname = "";

  // In the "mode=window" fail-safe (this popup opened as its own standalone
  // OS window because the in-page floating panel could not be reached), this
  // window becomes the focused window, so chrome.tabs.query({currentWindow:true})
  // would resolve to itself rather than the page the user wants to exclude.
  // The originating tab's id is passed explicitly in that case.
  const popupUrlParams = new URLSearchParams(window.location.search);
  const explicitTabId = popupUrlParams.get("tabId");

  function applyTabInfo(tab) {
    if (tab) {
      currentTabUrl = tab.url || "";
      try {
        if (currentTabUrl.startsWith("http")) {
          const urlObj = new URL(currentTabUrl);
          currentTabHostname = urlObj.hostname.toLowerCase();
          if (addCurrentSiteBtn) {
            addCurrentSiteBtn.innerHTML = `<span>🚫</span> <strong>${currentTabHostname}</strong> を除外`;
          }
        } else {
          if (addCurrentSiteBtn) {
            addCurrentSiteBtn.disabled = true;
            addCurrentSiteBtn.style.opacity = "0.5";
            addCurrentSiteBtn.innerHTML = "<span>🚫</span> このサイトは除外不可";
          }
        }
      } catch (e) {
        console.error("Error parsing tab URL:", e);
      }
    }
    loadSettings();
  }

  // --- 1. Get Current Tab URL & Domain (Defensive) ---
  if (window.chrome && chrome.tabs) {
    if (explicitTabId) {
      chrome.tabs.get(parseInt(explicitTabId, 10), (tab) => applyTabInfo(tab));
    } else {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => applyTabInfo(tabs && tabs[0]));
    }
  } else {
    loadSettings();
  }

  // --- 2. Load & Save Settings ---
  function loadSettings() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.get(["privacyFilterSettings"], (result) => {
        if (result.privacyFilterSettings) {
          settings = { ...settings, ...result.privacyFilterSettings };
        }
        applySettingsToUI();
      });
    } else {
      applySettingsToUI();
    }
  }

  function saveSettings() {
    if (window.chrome && chrome.storage) {
      chrome.storage.local.set({ privacyFilterSettings: settings }, () => {
        updateStatus();
      });
    } else {
      updateStatus();
    }
  }

  // --- 3. UI Synchronization ---
  function applySettingsToUI() {
    if (masterToggle) masterToggle.checked = settings.enabled;

    // Mode Buttons & Spotlight Slider locking
    if (settings.mode === "spotlight") {
      if (modeSpotlightBtn) modeSpotlightBtn.classList.add("active");
      if (modeFullBtn) modeFullBtn.classList.remove("active");
      if (spotlightSizeGroup) {
        spotlightSizeGroup.style.opacity = "1";
        spotlightSizeGroup.style.pointerEvents = "auto";
      }
    } else {
      if (modeSpotlightBtn) modeSpotlightBtn.classList.remove("active");
      if (modeFullBtn) modeFullBtn.classList.add("active");
      if (spotlightSizeGroup) {
        spotlightSizeGroup.style.opacity = "0.4";
        spotlightSizeGroup.style.pointerEvents = "none";
      }
    }

    // Pattern Cells Choice
    if (patternGrid) {
      const cells = patternGrid.querySelectorAll(".theme-cell");
      cells.forEach(cell => {
        if (cell.getAttribute("data-pattern") === settings.pattern) {
          cell.classList.add("active");
        } else {
          cell.classList.remove("active");
        }
      });
    }

    // Intensity Slider
    if (intensitySlider) intensitySlider.value = settings.intensity;
    if (intensityValue) intensityValue.textContent = `${settings.intensity}%`;

    // Spotlight size Slider
    if (spotlightSlider) spotlightSlider.value = settings.spotlightSize;
    if (spotlightValue) spotlightValue.textContent = `${settings.spotlightSize}px`;

    // Whitelist List
    renderWhitelist();
    updateStatus();
  }

  function renderWhitelist() {
    if (!whitelistList) return;
    whitelistList.innerHTML = "";
    const list = settings.whitelist || [];

    if (list.length === 0) {
      whitelistList.innerHTML = `<span class="empty-list-text">除外登録されているサイトはありません。</span>`;
      return;
    }

    list.forEach(domain => {
      const item = document.createElement("div");
      item.className = "whitelist-item";
      item.innerHTML = `
        <span class="whitelist-item-domain" title="${domain}">${domain}</span>
        <span class="whitelist-item-remove" data-domain="${domain}">×</span>
      `;
      whitelistList.appendChild(item);
    });

    // Bind remove event
    whitelistList.querySelectorAll(".whitelist-item-remove").forEach(btn => {
      btn.addEventListener("click", (e) => {
        const domainToRemove = e.target.getAttribute("data-domain");
        settings.whitelist = settings.whitelist.filter(d => d !== domainToRemove);
        saveSettings();
        renderWhitelist();
      });
    });
  }

  function updateStatus() {
    if (!statusDot || !statusText) return;

    if (!settings.enabled) {
      statusDot.className = "status-dot inactive";
      statusText.textContent = "保護シールド停止中";
      return;
    }

    const isWhitelisted = settings.whitelist && settings.whitelist.some(domain => {
      const cleaned = domain.trim().toLowerCase();
      if (!cleaned || !currentTabHostname) return false;
      return currentTabHostname === cleaned || currentTabHostname.endsWith("." + cleaned);
    });

    if (isWhitelisted) {
      statusDot.className = "status-dot whitelisted";
      statusText.textContent = "適用対象外 (除外リスト)";
    } else {
      statusDot.className = "status-dot";
      const modeName = settings.mode === "spotlight" ? "スポットライト" : "全面保護";
      statusText.textContent = `のぞき見防止稼働中 (${modeName})`;
    }
  }

  // --- 4. Event Listeners (Safe binds) ---

  if (masterToggle) {
    masterToggle.addEventListener("change", (e) => {
      settings.enabled = e.target.checked;
      saveSettings();
    });
  }

  if (modeSpotlightBtn) {
    modeSpotlightBtn.addEventListener("click", () => {
      settings.mode = "spotlight";
      saveSettings();
      applySettingsToUI();
    });
  }

  if (modeFullBtn) {
    modeFullBtn.addEventListener("click", () => {
      settings.mode = "full";
      saveSettings();
      applySettingsToUI();
    });
  }

  if (patternGrid) {
    patternGrid.querySelectorAll(".theme-cell").forEach(cell => {
      cell.addEventListener("click", () => {
        settings.pattern = cell.getAttribute("data-pattern");
        saveSettings();
        applySettingsToUI();
      });
    });
  }

  if (intensitySlider) {
    intensitySlider.addEventListener("input", (e) => {
      settings.intensity = parseInt(e.target.value);
      if (intensityValue) intensityValue.textContent = `${settings.intensity}%`;
    });
    intensitySlider.addEventListener("change", (e) => {
      settings.intensity = parseInt(e.target.value);
      saveSettings();
    });
  }

  if (spotlightSlider) {
    spotlightSlider.addEventListener("input", (e) => {
      settings.spotlightSize = parseInt(e.target.value);
      if (spotlightValue) spotlightValue.textContent = `${settings.spotlightSize}px`;
    });
    spotlightSlider.addEventListener("change", (e) => {
      settings.spotlightSize = parseInt(e.target.value);
      saveSettings();
    });
  }

  if (addCurrentSiteBtn) {
    addCurrentSiteBtn.addEventListener("click", () => {
      if (!currentTabHostname) return;
      if (!settings.whitelist) settings.whitelist = [];

      if (!settings.whitelist.includes(currentTabHostname)) {
        settings.whitelist.push(currentTabHostname);
        saveSettings();
        renderWhitelist();
      }
    });
  }
});
