const DEFAULT_SETTINGS = {
  enabled: true,
  mode: "spotlight",      // "spotlight" or "full"
  pattern: "sudare",      // "sudare", "ichimatsu", "kasumi", "shikkoku"
  intensity: 50,          // 10 to 90
  spotlightSize: 80,      // 30 to 150 (radius in px)
  whitelist: []           // list of domains to exclude
};

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["privacyFilterSettings"], (result) => {
    if (!result.privacyFilterSettings) {
      chrome.storage.local.set({ privacyFilterSettings: DEFAULT_SETTINGS }, () => {
        console.log("Commuter Privacy Filter default settings initialized.");
      });
    }
  });
});
