



// --- Heartfelt Apology Letter Maker JS ---

// --- 1. Preset Dictionary ---
const PRESETS = {
  delay: [
    {
      id: "delay-oversight",
      label: "進行管理不足",
      reason: "進行管理の確認不足により、作業工程に想定以上の時間を要してしまいました。",
      measure: "進行スケジュールの進捗状況をチーム内で毎日ダブルチェックし、遅延リスクを早期に検知できる体制を構築いたします。"
    },
    {
      id: "delay-system",
      label: "システム不具合",
      reason: "予期せぬシステムの動作不良が発生し、復旧作業に時間を要したためでございます。",
      measure: "システム障害時の代替フローをマニュアル化し、万が一の事態でも遅滞なく代替対応が進むよう体制を整備いたします。"
    },
    {
      id: "delay-sickness",
      label: "急病・体調不良",
      reason: "不測の体調不良により急遽お休みをいただくことになり、進行管理が一時的に滞ってしまいました。",
      measure: "日頃の体調管理の徹底に加え、チーム内でタスク状況を常時共有し、突発的な人員欠如時でもバックアップが機能する体制を構築いたします。"
    },
    {
      id: "delay-rush",
      label: "急な他案件対応",
      reason: "急を要する緊急案件への対応が重なり、タスクの優先順位設定に手違いが生じてしまいました。",
      measure: "案件の抱え込みを防ぐため、チーム全体の作業負荷状況を週次で共有し、必要に応じて人員を再配分する体制を敷きます。"
    }
  ],
  bug: [
    {
      id: "bug-test",
      label: "検証不足",
      reason: "リリース前の検証作業において、特定の環境下におけるテストが不足しておりました。",
      measure: "テストケースを大幅に拡充し、実機環境や様々な条件下での検証チェックリストを策定・徹底いたします。"
    },
    {
      id: "bug-server",
      label: "サーバー負荷",
      reason: "想定を超える一時的なアクセス集中に伴い、サーバーに過度な負荷がかかったためでございます。",
      measure: "サーバー監視体制の強化およびロードバランサー等の負荷分散設定を見直し、耐障害性を高める対策を講じます。"
    },
    {
      id: "bug-human",
      label: "作業ミス",
      reason: "データ移行（設定変更）の作業時において、手順書に記載された確認項目の誤認がございました。",
      measure: "リリース作業手順書を刷新し、作業時は必ず複数名で読み合わせと指差し確認を行うダブルチェックを義務化します。"
    }
  ],
  meeting: [
    {
      id: "meeting-forgot",
      label: "予定の失念",
      reason: "カレンダーへの登録ミスおよびスケジュール管理のアラート設定漏れが原因でございます。",
      measure: "アポイント確定時のスケジュール登録を即時化し、前日と1時間前に自動リマインド通知を行う設定を徹底いたします。"
    },
    {
      id: "meeting-traffic",
      label: "電車の遅延",
      reason: "利用路線の不慮の人身事故に伴う運転見合わせが発生し、迂回経路の確保に時間を要してしまいました。",
      measure: "予定の30分前には現地周辺に到着するスケジュールを組み、交通乱れの際も別ルートで迅速に対応できるよう余裕を持って行動します。"
    },
    {
      id: "meeting-long",
      label: "前アポ長引き",
      reason: "前段の会議が予期せず長引いてしまい、移動時間の見積もりにズレが生じてしまいました。",
      measure: "前後の予定の間に最低でも30分のバッファ時間を確保するようスケジュール調整ルールを厳格化いたします。"
    }
  ],
  misdeliver: [
    {
      id: "misdeliver-email",
      label: "宛先間違い",
      reason: "送信前の宛先メールアドレスの目視チェックが不十分であり、誤って別の宛先に送信してしまいました。",
      measure: "メールクライアントに送信遅延ルール（送信後5分間保留）を設定し、送信直後の誤りに自己解決できる猶予を作ります。"
    },
    {
      id: "misdeliver-file",
      label: "添付間違い",
      reason: "同名ファイルの取り違え、および送信前の添付ファイル内容の確認不足でございます。",
      measure: "送付用ファイルの命名規則を明確にし、送信前にファイルを一度開いて内容を指差し確認することをルール化します。"
    }
  ],
  response: [
    {
      id: "response-oversight",
      label: "メール見落とし",
      reason: "受信メールの一時的な自動振り分け設定の不備により、ご返信の優先順位を見落としておりました。",
      measure: "受信フォルダの巡回チェック時間を毎朝・昼・夕の3回ルール化し、24時間以内の一次返答（受領報告）を徹底いたします。"
    },
    {
      id: "response-busy",
      label: "緊急対応による遅れ",
      reason: "緊急の別件トラブル対応に追われ、迅速な一次返信を行うことができておりませんでした。",
      measure: "業務多忙時でも一次返信を代行・共有できる体制（不在時の自動応答設定、またはサポートメンバーへの共有）を確立いたします。"
    }
  ],
  custom: [
    {
      id: "custom-generic",
      label: "汎用お詫び",
      reason: "こちらの確認作業の手違いにより、ご迷惑をおかけする事態となってしまいました。",
      measure: "今後はチェックフローを見直し、各作業工程での確認を徹底して再発防止に努めます。"
    }
  ]
};

// State flag to allow live updates
let isGenerated = false;

document.addEventListener("DOMContentLoaded", () => {
  // Elements
  const themeToggle = document.getElementById("theme-toggle");
  const tabs = document.querySelectorAll(".nav-tab");
  const tabContents = document.querySelectorAll(".tab-content");
  
  const selectRecipient = document.getElementById("select-recipient");
  const selectSeverity = document.getElementById("select-severity");
  const selectTrouble = document.getElementById("select-trouble");
  const presetHelperCard = document.getElementById("preset-helper-card");
  const presetButtonsContainer = document.getElementById("preset-buttons");
  
  const inputTargetCompany = document.getElementById("input-target-company");
  const inputTargetName = document.getElementById("input-target-name");
  const inputTroubleDetail = document.getElementById("input-trouble-detail");
  const textareaReason = document.getElementById("textarea-reason");
  const textareaMeasure = document.getElementById("textarea-measure");
  const inputSender = document.getElementById("input-sender");
  const inputSenderCompany = document.getElementById("input-sender-company");
  const groupSenderCompany = document.getElementById("group-sender-company");
  
  const btnGenerate = document.getElementById("btn-generate");
  const resultContainer = document.getElementById("result-container");
  const badgeSeverity = document.getElementById("badge-severity");
  const outputSubject = document.getElementById("output-subject");
  const outputBody = document.getElementById("output-body");
  
  const btnCopySubject = document.getElementById("btn-copy-subject");
  const btnCopyAll = document.getElementById("btn-copy-all");
  const btnCopyBody = document.getElementById("btn-copy-body");
  const toast = document.getElementById("toast");

  // Label fields
  const labelTargetCompany = document.getElementById("label-target-company");
  const labelTargetName = document.getElementById("label-target-name");

  // --- 2. Theme Init ---
  const activeTheme = localStorage.getItem("theme") || "dark";
  if (activeTheme === "light") {
    document.body.classList.remove("dark-theme");
    document.body.classList.add("light-theme");
    themeToggle.querySelector(".sun-icon").style.display = "none";
    themeToggle.querySelector(".moon-icon").style.display = "block";
  } else {
    document.body.classList.remove("light-theme");
    document.body.classList.add("dark-theme");
    themeToggle.querySelector(".sun-icon").style.display = "block";
    themeToggle.querySelector(".moon-icon").style.display = "none";
  }

  themeToggle.addEventListener("click", () => {
    if (document.body.classList.contains("dark-theme")) {
      document.body.classList.remove("dark-theme");
      document.body.classList.add("light-theme");
      themeToggle.querySelector(".sun-icon").style.display = "none";
      themeToggle.querySelector(".moon-icon").style.display = "block";
      localStorage.setItem("theme", "light");
    } else {
      document.body.classList.remove("light-theme");
      document.body.classList.add("dark-theme");
      themeToggle.querySelector(".sun-icon").style.display = "block";
      themeToggle.querySelector(".moon-icon").style.display = "none";
      localStorage.setItem("theme", "dark");
    }
  });

  // --- 3. Persistent Sender Data Loading ---
  inputSender.value = localStorage.getItem("apology_sender_name") || "";
  inputSenderCompany.value = localStorage.getItem("apology_sender_company") || "";

  // --- 4. Navigation Logic ---
  tabs.forEach(tab => {
    tab.addEventListener("click", () => {
      tabs.forEach(t => t.classList.remove("active"));
      tabContents.forEach(tc => tc.classList.remove("active"));

      tab.classList.add("active");
      const targetTab = tab.getAttribute("data-tab");
      document.getElementById(targetTab).classList.add("active");
    });
  });

  // --- 5. Cushion Words Copying ---
  const cushionCards = document.querySelectorAll(".cushion-card");
  cushionCards.forEach(card => {
    card.addEventListener("click", () => {
      const textToCopy = card.getAttribute("data-copy");
      navigator.clipboard.writeText(textToCopy)
        .then(() => showToast("クッション言葉をコピーしました！"))
        .catch(err => console.error("Copy failed", err));
    });
  });

  // --- 6. Form Adjustments based on Recipient Type ---
  function adjustFormLabels() {
    const recipient = selectRecipient.value;
    if (recipient === "internal") {
      labelTargetCompany.style.display = "none";
      inputTargetCompany.style.display = "none";
      groupSenderCompany.style.display = "none";
      labelTargetName.textContent = "相手の役職・名前";
      inputTargetName.placeholder = "例：佐藤部長、鈴木先輩";
    } else if (recipient === "consumer") {
      labelTargetCompany.style.display = "block";
      inputTargetCompany.style.display = "block";
      groupSenderCompany.style.display = "block";
      labelTargetCompany.textContent = "購入プラットフォーム / 店舗等";
      inputTargetCompany.placeholder = "例：Amazon店、本社窓口";
      labelTargetName.textContent = "お客様のお名前";
      inputTargetName.placeholder = "例：佐藤様（空欄で「お客様各位」）";
    } else { // external
      labelTargetCompany.style.display = "block";
      inputTargetCompany.style.display = "block";
      groupSenderCompany.style.display = "block";
      labelTargetCompany.textContent = "相手の会社名";
      inputTargetCompany.placeholder = "例：株式会社〇〇";
      labelTargetName.textContent = "相手の役職・氏名";
      inputTargetName.placeholder = "例：佐藤様、鈴木部長";
    }
    
    // Live update if already generated
    if (isGenerated) {
      generateApology();
    }
  }

  selectRecipient.addEventListener("change", adjustFormLabels);
  adjustFormLabels();

  // --- 7. Presets Generator / Loader ---
  function renderPresets() {
    const troubleType = selectTrouble.value;
    const presets = PRESETS[troubleType] || [];
    
    presetButtonsContainer.innerHTML = "";
    
    if (presets.length === 0) {
      presetHelperCard.style.display = "none";
      return;
    }
    
    presetHelperCard.style.display = "flex";
    
    presets.forEach(preset => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "preset-btn";
      button.textContent = preset.label;
      button.dataset.presetId = preset.id;
      
      button.addEventListener("click", () => {
        // Toggle active style
        presetButtonsContainer.querySelectorAll(".preset-btn").forEach(b => b.classList.remove("active"));
        button.classList.add("active");
        
        // Fill input fields
        textareaReason.value = preset.reason;
        textareaMeasure.value = preset.measure;
        
        // Trigger live generation
        if (isGenerated) {
          generateApology();
        }
      });
      presetButtonsContainer.appendChild(button);
    });
  }

  // Deactivate active preset button when user types in textareas manually
  textareaReason.addEventListener("input", () => {
    presetButtonsContainer.querySelectorAll(".preset-btn").forEach(b => b.classList.remove("active"));
    if (isGenerated) generateApology();
  });
  textareaMeasure.addEventListener("input", () => {
    presetButtonsContainer.querySelectorAll(".preset-btn").forEach(b => b.classList.remove("active"));
    if (isGenerated) generateApology();
  });

  selectTrouble.addEventListener("change", () => {
    renderPresets();
    
    // Pre-fill default trouble details
    const troubleType = selectTrouble.value;
    if (troubleType === "delay") {
      inputTroubleDetail.placeholder = "例：本日15時納品予定の原稿";
    } else if (troubleType === "bug") {
      inputTroubleDetail.placeholder = "例：〇〇システムにおけるデータ表示不具合";
    } else if (troubleType === "meeting") {
      inputTroubleDetail.placeholder = "例：本日14時のお打ち合わせ";
    } else if (troubleType === "misdeliver") {
      inputTroubleDetail.placeholder = "例：誤った見積書ファイルが添付されたメール";
    } else if (troubleType === "response") {
      inputTroubleDetail.placeholder = "例：お見積もり依頼に対するご返信";
    } else {
      inputTroubleDetail.placeholder = "例：トラブル内容を具体的に記述";
    }
    
    if (isGenerated) {
      generateApology();
    }
  });
  
  // Initial presets load
  renderPresets();

  // --- 8. Core Apology Generator Logic ---
  function generateApology() {
    // Save Sender info
    localStorage.setItem("apology_sender_name", inputSender.value);
    localStorage.setItem("apology_sender_company", inputSenderCompany.value);

    // Get input values
    const recipient = selectRecipient.value;
    const severity = selectSeverity.value;
    const trouble = selectTrouble.value;
    
    const targetCompany = inputTargetCompany.value.trim();
    const targetName = inputTargetName.value.trim();
    const troubleDetail = inputTroubleDetail.value.trim() || "[対象内容/事象]";
    const reason = textareaReason.value.trim() || "[原因や経緯の詳細を記述]";
    const measure = textareaMeasure.value.trim() || "[再発防止の取り組みを記述]";
    const sender = inputSender.value.trim() || "[送信者名]";
    const senderCompany = inputSenderCompany.value.trim();

    // 8a. Generate Subject
    let subject = "";
    if (recipient === "external") {
      if (severity === "highest") {
        subject = `【重要・お詫び】${troubleDetail}に関するご報告とお詫び`;
      } else if (severity === "standard") {
        subject = `【お詫び】${troubleDetail}について`;
      } else {
        subject = `【ご報告】${troubleDetail}についてのお詫び`;
      }
    } else if (recipient === "internal") {
      if (severity === "highest") {
        subject = `【お詫びとご報告】${troubleDetail}の発生について`;
      } else if (severity === "standard") {
        subject = `【お詫び】${troubleDetail}の件`;
      } else {
        subject = `【お詫び】${troubleDetail}について`;
      }
    } else { // consumer
      if (severity === "highest") {
        subject = `【重要・お詫び】${troubleDetail}に関する重大なお詫びとお知らせ`;
      } else if (severity === "standard") {
        subject = `【お詫び】${troubleDetail}についてのご報告とお詫び`;
      } else {
        subject = `【お知らせ】${troubleDetail}に関するお詫び`;
      }
    }
    
    // 8b. Generate Body
    let body = "";

    // 1. Salutation (宛先)
    if (recipient === "external") {
      if (targetCompany) {
        body += `${targetCompany}\n`;
      }
      if (targetName) {
        body += `${targetName} 様\n\n`;
      } else {
        body += "ご担当者様\n\n";
      }
    } else if (recipient === "internal") {
      if (targetName) {
        body += `${targetName} 様\n\n`;
      } else {
        body += "関係者各位\n\n";
      }
    } else { // consumer
      if (targetName) {
        body += `${targetName} 様\n\n`;
      } else {
        body += "お客様 各位\n\n";
      }
    }

    // 2. Greeting / Self-Introduction
    if (recipient === "external") {
      body += "平素は格別のご高配を賜り、厚く御礼申し上げます。\n";
      if (senderCompany) {
        body += `${senderCompany}の${sender}でございます。\n\n`;
      } else {
        body += `${sender}でございます。\n\n`;
      }
    } else if (recipient === "internal") {
      body += `お疲れ様です。${sender}です。\n\n`;
    } else { // consumer
      body += "平素より弊社サービスをご利用いただき、誠にありがとうございます。\n";
      if (senderCompany) {
        body += `${senderCompany}の${sender}でございます。\n\n`;
      } else {
        body += `${sender}でございます。\n\n`;
      }
    }

    // 3. Apology Opening (冒頭のお詫び)
    if (severity === "highest") {
      if (recipient === "external" || recipient === "consumer") {
        body += `この度は、${troubleDetail}の件につきまして、多大なるご迷惑とご心配をおかけいたしましたことを、心より深くお詫び申し上げます。\n`;
        body += `こちらの不手際により、多大なるご支障をきたしてしまいましたこと、慙愧に堪えません。\n\n`;
      } else {
        body += `この度は、私の重大な過失により、${troubleDetail}につきまして、多大なるご迷惑とご心配をおかけいたしましたことを、深くお詫び申し上げます。\n\n`;
      }
    } else if (severity === "standard") {
      if (recipient === "external" || recipient === "consumer") {
        body += `この度は、${troubleDetail}の件につきまして、多大なるご迷惑とご心配をおかけいたしましたことを、深くお詫び申し上げます。\n\n`;
      } else {
        body += `この度は、私の不手際により、${troubleDetail}の件でご迷惑をおかけし、大変申し訳ございません。\n\n`;
      }
    } else { // polite / mild
      if (recipient === "external" || recipient === "consumer") {
        body += `この度は、${troubleDetail}に関しまして、ご不便をおかけいたしましたことをお詫び申し上げます。\n\n`;
      } else {
        body += `この度は、${troubleDetail}の件でご迷惑をおかけし、申し訳ございません。\n\n`;
      }
    }

    // 4. Cause / Reason (原因・経緯)
    if (recipient === "external" || recipient === "consumer") {
      body += "【経緯と原因】\n";
      body += `本件の経緯といたしましては、${reason}\n`;
      body += "こちらの不徹底により、多大なご不便をおかけしましたことを重ねてお詫び申し上げます。\n\n";
    } else {
      body += "【原因の報告】\n";
      body += `原因といたしましては、${reason}\n`;
      body += "業務管理の甘さを深く反省しております。\n\n";
    }

    // 5. Measure (今後の対策)
    body += "【今後の再発防止策】\n";
    body += "今後は二度とこのような事態を引き起こさぬよう、以下の通り再発防止に努めてまいります。\n";
    body += `${measure}\n\n`;

    // 6. Apology Closing (結びのお詫び)
    if (severity === "highest") {
      if (recipient === "external" || recipient === "consumer") {
        body += "本件の重大さを真摯に受け止め、信頼回復に努める所存でございます。\n";
        body += "甚だ勝手なお願いではございますが、何卒ご容赦いただけますよう平にご容赦のほどお願い申し上げます。\n";
        body += "まずは取り急ぎ、書中（メール）をもちまして深くお詫び申し上げます。\n";
      } else {
        body += "本件を深く深く反省し、信頼回復に向けて全身全霊で努めてまいります。\n";
        body += "重ねてではございますが、この度は誠に申し訳ございませんでした。\n";
      }
    } else if (severity === "standard") {
      if (recipient === "external" || recipient === "consumer") {
        body += "まずは取り急ぎ、メールにてお詫び申し上げます。\n";
        body += "何卒ご容赦のほどお願い申し上げます。\n";
      } else {
        body += "今後は細心の注意を払い、業務にあたってまいります。\n";
        body += "取り急ぎ、メールにてお詫び申し上げます。\n";
      }
    } else { // polite / mild
      if (recipient === "external" || recipient === "consumer") {
        body += "取り急ぎ、メールにてお詫びとご報告を申し上げます。\n";
      } else {
        body += "以降、同様のミスがないよう注意いたします。\n";
        body += "どうぞよろしくお願いいたします。\n";
      }
    }

    // 7. Signature (署名)
    body += "\n--------------------------------------------------\n";
    if (senderCompany) {
      body += `${senderCompany}\n`;
    }
    body += `${sender}\n`;
    body += "--------------------------------------------------";

    // Set UI outputs
    outputSubject.value = subject;
    outputBody.value = body;

    // Update Badge
    const severityLabels = {
      highest: "深謝",
      standard: "通常",
      polite: "丁寧"
    };
    badgeSeverity.textContent = severityLabels[severity] || "通常";
  }

  // --- 9. Event Listeners for Generation & Live-Sync ---
  btnGenerate.addEventListener("click", () => {
    isGenerated = true;
    generateApology();
    
    // Show results card
    resultContainer.classList.remove("hidden");
    
    // Smooth scroll to output
    resultContainer.scrollIntoView({ behavior: "smooth" });
  });

  // Watch inputs for dynamic update once generated
  const inputsToWatch = [
    selectRecipient, selectSeverity, selectTrouble,
    inputTargetCompany, inputTargetName, inputTroubleDetail,
    inputSender, inputSenderCompany
  ];

  inputsToWatch.forEach(input => {
    input.addEventListener("input", () => {
      if (isGenerated) generateApology();
    });
    input.addEventListener("change", () => {
      if (isGenerated) generateApology();
    });
  });

  // --- 10. Copy Action Buttons ---
  btnCopySubject.addEventListener("click", () => {
    navigator.clipboard.writeText(outputSubject.value)
      .then(() => showToast("件名をコピーしました！"))
      .catch(err => console.error("Failed to copy subject", err));
  });

  btnCopyBody.addEventListener("click", () => {
    navigator.clipboard.writeText(outputBody.value)
      .then(() => showToast("本文をコピーしました！"))
      .catch(err => console.error("Failed to copy body", err));
  });

  btnCopyAll.addEventListener("click", () => {
    const fullText = `件名: ${outputSubject.value}\n\n${outputBody.value}`;
    navigator.clipboard.writeText(fullText)
      .then(() => showToast("件名と本文をコピーしました！"))
      .catch(err => console.error("Failed to copy all", err));
  });

  // Toast Functionality
  function showToast(message) {
    toast.textContent = message;
    toast.classList.remove("hidden");
    
    // Auto hide after 2 seconds
    setTimeout(() => {
      toast.classList.add("hidden");
    }, 2000);
  }
});
