// background.js - Copy-Paste Helper Background service worker

// Listener for messages from content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'openSearch') {
    const searchUrl = getSearchUrl(request.engine, request.text);
    chrome.tabs.create({ url: searchUrl, active: true });
    sendResponse({ success: true });
  } else if (request.action === 'openTranslate') {
    const translateUrl = getTranslateUrl(request.lang, request.text);
    chrome.tabs.create({ url: translateUrl, active: true });
    sendResponse({ success: true });
  } else if (request.action === 'openDict') {
    const dictUrl = getDictUrl(request.engine, request.text);
    chrome.tabs.create({ url: dictUrl, active: true });
    sendResponse({ success: true });
  }
  return true; // async response indicator
});

// Construct Search URL
function getSearchUrl(engine, text) {
  const query = encodeURIComponent(text);
  switch (engine) {
    case 'bing':
      return `https://www.bing.com/search?q=${query}`;
    case 'duckduckgo':
      return `https://duckduckgo.com/?q=${query}`;
    case 'yahoo':
      return `https://search.yahoo.co.jp/search?p=${query}`;
    case 'google':
    default:
      return `https://www.google.com/search?q=${query}`;
  }
}

// Construct Translation URL
function getTranslateUrl(targetLang, text) {
  const query = encodeURIComponent(text);
  // Default to Japanese if translation lang not specified
  const tl = targetLang || 'ja';
  
  // Google Translate auto-detect source language
  return `https://translate.google.com/?sl=auto&tl=${tl}&text=${query}&op=translate`;
}

// Construct Dictionary URL
function getDictUrl(engine, text) {
  const query = encodeURIComponent(text);
  switch (engine) {
    case 'goo':
      return `https://dictionary.goo.ne.jp/srch/all/${query}/m0u/`;
    case 'kotobank':
      return `https://kotobank.jp/word/${query}`;
    case 'weblio':
    default:
      return `https://www.weblio.jp/content/${query}`;
  }
}
