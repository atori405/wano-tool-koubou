// --- Smart Fail-Safe Intercept Toolbar Click ---
(function() {
  var urlParams = new URLSearchParams(window.location.search);
  var mode = urlParams.get("mode");

  // Skip intercept when already in floating (iframe) or window (popup OS window) mode
  if (mode === "floating" || mode === "window") return;

  if (window.chrome && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].id) {
        // Try sending message to page content script to inject floating panel
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggleFloatingPanel" }, function(response) {
          if (chrome.runtime.lastError || !response || response.status !== "toggled") {
            // Fail-safe: Open popup.html as a draggable Chrome popup window
            var w = Math.min(screen.availWidth, 520);
            var h = Math.min(screen.availHeight, 680);
            var left = Math.round((screen.availWidth - w) / 2);
            var top = Math.round((screen.availHeight - h) / 4);
            chrome.windows.create({
              url: chrome.runtime.getURL("popup.html?mode=window"),
              type: "popup",
              width: w,
              height: h,
              left: left,
              top: top,
              focused: true
            });
          }
          window.close();
        });
      } else {
        // No active tab found - open as popup window directly
        chrome.windows.create({
          url: chrome.runtime.getURL("popup.html?mode=window"),
          type: "popup",
          width: 520,
          height: 680,
          focused: true
        });
        window.close();
      }
    });
  }
})();
// -----------------------------------------------------------------

// popup.js - Copy-Paste Helper Dashboard Controller

document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const enableCheck = document.getElementById('enable-check');
  const statusText = document.getElementById('status-text');
  const searchEngineSelect = document.getElementById('search-engine');
  const translateLangSelect = document.getElementById('translate-lang');
  const dictEngineSelect = document.getElementById('dict-engine');
  
  const blacklistInput = document.getElementById('blacklist-input');
  const addBlacklistBtn = document.getElementById('add-blacklist-btn');
  const blacklistList = document.getElementById('blacklist-list');

  // Default state
  let config = {
    enabled: true,
    searchEngine: 'google',
    translateLang: 'ja',
    dictEngine: 'weblio',
    blacklist: []
  };

  // 1. Load configuration from storage
  chrome.storage.local.get('copypasteHelperConfig', (result) => {
    if (result.copypasteHelperConfig) {
      config = { ...config, ...result.copypasteHelperConfig };
      // goo辞書は2025年6月にサービス終了済みのため、過去に選択済みの設定が
      // 残っていた場合はWeblioへ移行する
      if (config.dictEngine === 'goo') {
        config.dictEngine = 'weblio';
        saveConfig();
      }
    } else {
      // Initialize storage on first load
      saveConfig();
    }
    updateUI();
  });

  // Sync state to UI elements
  function updateUI() {
    enableCheck.checked = config.enabled;
    statusText.textContent = config.enabled ? "有効" : "無効";
    statusText.style.color = config.enabled ? "var(--color-matsu)" : "var(--color-susu)";
    
    searchEngineSelect.value = config.searchEngine;
    translateLangSelect.value = config.translateLang;
    dictEngineSelect.value = config.dictEngine;

    renderBlacklist();
  }

  // Render blacklist elements
  function renderBlacklist() {
    blacklistList.innerHTML = '';
    
    if (config.blacklist.length === 0) {
      blacklistList.innerHTML = '<div style="flex: 1; display: flex; align-items: center; justify-content: center; font-size: 11px; color: #aaa; text-align: center; padding: 10px;">登録されていません</div>';
      return;
    }

    config.blacklist.forEach((domain, idx) => {
      const item = document.createElement('div');
      item.className = 'blacklist-item';
      
      const domainSpan = document.createElement('span');
      domainSpan.className = 'blacklist-domain';
      domainSpan.textContent = domain;
      domainSpan.title = domain;

      const removeBtn = document.createElement('button');
      removeBtn.className = 'remove-blacklist-btn';
      removeBtn.textContent = '×';
      removeBtn.addEventListener('click', () => {
        config.blacklist = config.blacklist.filter((_, i) => i !== idx);
        saveConfig();
        renderBlacklist();
      });

      item.appendChild(domainSpan);
      item.appendChild(removeBtn);
      blacklistList.appendChild(item);
    });
  }

  // Save config to storage
  function saveConfig() {
    chrome.storage.local.set({ copypasteHelperConfig: config });
  }

  // Event Listeners
  enableCheck.addEventListener('change', (e) => {
    config.enabled = e.target.checked;
    statusText.textContent = config.enabled ? "有効" : "無効";
    statusText.style.color = config.enabled ? "var(--color-matsu)" : "var(--color-susu)";
    saveConfig();
  });

  searchEngineSelect.addEventListener('change', (e) => {
    config.searchEngine = e.target.value;
    saveConfig();
  });

  translateLangSelect.addEventListener('change', (e) => {
    config.translateLang = e.target.value;
    saveConfig();
  });

  dictEngineSelect.addEventListener('change', (e) => {
    config.dictEngine = e.target.value;
    saveConfig();
  });

  // Extract a bare hostname from whatever the user typed or pasted, since people
  // naturally paste the full address-bar URL (with protocol and path) rather than
  // typing a bare domain by hand.
  function extractHostname(raw) {
    let str = raw.trim();
    if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(str)) {
      str = 'https://' + str;
    }
    try {
      return new URL(str).hostname.toLowerCase();
    } catch (e) {
      return raw.trim().toLowerCase();
    }
  }

  // Add domain to blacklist
  addBlacklistBtn.addEventListener('click', () => {
    const raw = blacklistInput.value.trim();
    if (!raw) return;
    const domain = extractHostname(raw);

    // Simple domain regex
    const domainRegex = /^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!domainRegex.test(domain)) {
      alert("有効なドメイン名を入力してください（例: wikipedia.org ）。");
      return;
    }

    if (config.blacklist.includes(domain)) {
      alert("すでに登録されているドメインです。");
      return;
    }

    config.blacklist.push(domain);
    saveConfig();
    renderBlacklist();
    blacklistInput.value = '';
  });

  blacklistInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      addBlacklistBtn.click();
    }
  });
});
