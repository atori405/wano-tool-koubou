// content.js - Floating quick menu content script

(function() {
  let activeSelectionText = '';
  let rootEl = null;
  let shadowRoot = null;
  let tooltipEl = null;
  let config = {
    enabled: true,
    searchEngine: 'google',
    translateLang: 'ja',
    dictEngine: 'weblio',
    blacklist: []
  };

  // 1. Initial configuration load
  function loadConfig() {
    chrome.storage.local.get('copypasteHelperConfig', (result) => {
      if (result.copypasteHelperConfig) {
        config = { ...config, ...result.copypasteHelperConfig };
      }
    });
  }
  loadConfig();

  // Keep configuration updated on storage change
  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local' && changes.copypasteHelperConfig) {
      config = { ...config, ...changes.copypasteHelperConfig.newValue };
      if (!config.enabled) {
        hideTooltip();
      }
    }
  });

  // 2. Initialize Shadow DOM root container
  function initShadowDOM() {
    if (rootEl) return;

    rootEl = document.createElement('div');
    rootEl.id = 'copypaste-helper-root';
    document.body.appendChild(rootEl);

    shadowRoot = rootEl.attachShadow({ mode: 'open' });

    // Inject styles directly in Shadow DOM to keep it safe from parent page CSS
    const style = document.createElement('style');
    style.textContent = `
      .helper-tooltip {
        position: absolute;
        display: flex;
        gap: 6px;
        padding: 5px 8px;
        background: rgba(250, 248, 245, 0.88);
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
        border: 1px solid rgba(90, 75, 65, 0.25);
        border-radius: 20px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.12), 0 1px 3px rgba(0, 0, 0, 0.05);
        pointer-events: auto;
        transform: translate(-50%, -5px);
        opacity: 0;
        visibility: hidden;
        transition: transform 0.2s cubic-bezier(0.18, 0.89, 0.32, 1.28), opacity 0.2s ease, visibility 0.2s;
        z-index: 2147483647;
      }
      .helper-tooltip.visible {
        transform: translate(-50%, 0);
        opacity: 1;
        visibility: visible;
      }
      .helper-btn {
        width: 28px;
        height: 28px;
        border: none;
        background: transparent;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        color: #5a4b41;
        transition: background-color 0.15s, transform 0.1s, color 0.15s;
        padding: 0;
        position: relative;
      }
      .helper-btn:hover {
        background-color: rgba(90, 75, 65, 0.12);
        color: #345c32; /* Matsu green */
        transform: scale(1.12);
      }
      .helper-btn:active {
        transform: scale(0.95);
      }
      .helper-btn svg {
        width: 14px;
        height: 14px;
        fill: currentColor;
      }
      
      /* Simple clean tooltip text on hover */
      .helper-btn::after {
        content: attr(data-tooltip);
        position: absolute;
        bottom: 34px;
        left: 50%;
        transform: translateX(-50%) scale(0.85);
        background-color: #2b2b29;
        color: #fff;
        font-size: 8px;
        font-family: sans-serif;
        padding: 3px 6px;
        border-radius: 3px;
        white-space: nowrap;
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.15s, transform 0.15s;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
      }
      .helper-btn:hover::after {
        opacity: 1;
        transform: translateX(-50%) scale(1);
      }
    `;
    shadowRoot.appendChild(style);

    // Create Tooltip Wrapper
    tooltipEl = document.createElement('div');
    tooltipEl.className = 'helper-tooltip';

    // 1. Copy Button
    const btnCopy = createButton('btn-copy', 'コピー', `
      <svg viewBox="0 0 24 24">
        <path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/>
      </svg>
    `);
    btnCopy.addEventListener('click', () => {
      copySelectedText();
    });

    // 2. Search Button
    const btnSearch = createButton('btn-search', '調べる', `
      <svg viewBox="0 0 24 24">
        <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
      </svg>
    `);
    btnSearch.addEventListener('click', () => {
      chrome.runtime.sendMessage({
        action: 'openSearch',
        engine: config.searchEngine,
        text: activeSelectionText
      });
      hideTooltip();
    });

    // 3. Translate Button
    const btnTranslate = createButton('btn-translate', '翻訳', `
      <svg viewBox="0 0 24 24">
        <path d="M12.87 15.07l-2.54-2.51.03-.03c1.74-1.94 2.98-4.17 3.71-6.53H17V4h-7V2H8v2H1v2h11.17C11.5 7.92 10.44 9.75 9 11.35 8.07 10.32 7.3 9.19 6.69 8h-2c.73 1.63 1.73 3.17 2.98 4.56l-5.09 5.02L4 19l5-5 3.11 3.11.76-2.04zM18.5 10h-2L12 22h2l1.12-3h4.75L21 22h2l-4.5-12zm-2.62 7l1.62-4.33L19.12 17h-3.24z"/>
      </svg>
    `);
    btnTranslate.addEventListener('click', () => {
      chrome.runtime.sendMessage({
        action: 'openTranslate',
        lang: config.translateLang,
        text: activeSelectionText
      });
      hideTooltip();
    });

    // 4. Dictionary Button
    const btnDict = createButton('btn-dict', '辞書', `
      <svg viewBox="0 0 24 24">
        <path d="M18 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM6 4h5v8l-2.5-1.5L6 12V4zm12 16H6v-6h12v6zm0-8h-5V4h5v8z"/>
      </svg>
    `);
    btnDict.addEventListener('click', () => {
      chrome.runtime.sendMessage({
        action: 'openDict',
        engine: config.dictEngine,
        text: activeSelectionText
      });
      hideTooltip();
    });

    tooltipEl.appendChild(btnCopy);
    tooltipEl.appendChild(btnSearch);
    tooltipEl.appendChild(btnTranslate);
    tooltipEl.appendChild(btnDict);

    shadowRoot.appendChild(tooltipEl);
  }

  function createButton(id, title, svgHtml) {
    const btn = document.createElement('button');
    btn.className = 'helper-btn';
    btn.id = id;
    btn.setAttribute('data-tooltip', title);
    btn.innerHTML = svgHtml;
    return btn;
  }

  // 3. Monitor Text selection
  document.addEventListener('mouseup', (e) => {
    // Wait a brief moment to ensure window.getSelection is populated
    setTimeout(() => {
      handleSelection(e);
    }, 20);
  });

  // Keyboard navigation/clearing selection
  document.addEventListener('keyup', (e) => {
    if (e.key === 'Escape') {
      hideTooltip();
    }
  });

  // Handle selection changes
  function handleSelection(e) {
    // Check if configuration is disabled
    if (!config.enabled) {
      hideTooltip();
      return;
    }

    // Check blacklist domain list
    const currentHost = window.location.hostname;
    const isBlacklisted = config.blacklist.some(domain => {
      return currentHost === domain || currentHost.endsWith('.' + domain);
    });
    if (isBlacklisted) {
      hideTooltip();
      return;
    }

    const selection = window.getSelection();
    const selectedText = selection.toString().trim();

    // If selection is empty
    if (!selectedText) {
      // Don't close if they clicked inside the Shadow DOM menu itself
      if (rootEl && rootEl.contains(e.target)) {
        return;
      }
      hideTooltip();
      return;
    }

    // Ignore if selection is very short (like single punctuation)
    if (selectedText.length < 2 && !/[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FAF]/.test(selectedText)) {
      // Allow single Kanji or Japanese Kana, but ignore single alphabetic characters/symbols
      hideTooltip();
      return;
    }

    activeSelectionText = selectedText;
    initShadowDOM();

    // Get position coordinate bounds of highlighted text
    try {
      const range = selection.getRangeAt(0);
      const rect = range.getBoundingClientRect();

      if (rect.width === 0 || rect.height === 0) {
        hideTooltip();
        return;
      }

      // Calculate absolute scroll positions
      const x = rect.left + window.scrollX + rect.width / 2;
      let y = rect.top + window.scrollY;

      // Position tooltip 42px above the selection
      let finalY = y - 42;

      // If the tooltip would go above the viewport
      if (rect.top < 50) {
        // Position below selection instead
        finalY = rect.bottom + window.scrollY + 10;
      }

      tooltipEl.style.left = `${x}px`;
      tooltipEl.style.top = `${finalY}px`;
      
      // Make it visible
      tooltipEl.classList.add('visible');
    } catch (err) {
      hideTooltip();
    }
  }

  function hideTooltip() {
    if (tooltipEl && tooltipEl.classList.contains('visible')) {
      tooltipEl.classList.remove('visible');
    }
    activeSelectionText = '';
  }

  // 4. Clipboard copy action
  function copySelectedText() {
    if (!activeSelectionText) return;

    navigator.clipboard.writeText(activeSelectionText)
      .then(() => {
        playRinSound(); // Play soft Zen bell on copy success!
        
        // Show brief visual checkmark
        const copyBtn = shadowRoot.getElementById('btn-copy');
        if (copyBtn) {
          const originalSvg = copyBtn.innerHTML;
          copyBtn.innerHTML = `
            <svg viewBox="0 0 24 24" style="color: #345c32;">
              <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
            </svg>
          `;
          setTimeout(() => {
            copyBtn.innerHTML = originalSvg;
          }, 800);
        }
      })
      .catch(err => {
        console.error('Copy failed: ', err);
      });
  }

  // --- Web Audio API Synth Engine ---
  let audioCtx = null;

  function initAudio() {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
  }

  // Synthesize "Rin Bell" sound (チーン...)
  function playRinSound() {
    try {
      initAudio();
      const now = audioCtx.currentTime;

      // Traditional Rin Bell harmonic frequency blend
      const frequencies = [680, 1360, 2040, 2720];

      frequencies.forEach((f, idx) => {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(f, now);

        // Lower amplitude for higher harmonics, and faster decay
        const amplitude = idx === 0 ? 0.22 : 0.08 / idx;
        const decay = 2.0 / (idx + 1);

        gain.gain.setValueAtTime(amplitude, now);
        // Exponential fade
        gain.gain.exponentialRampToValueAtTime(0.0001, now + decay);

        osc.connect(gain);
        gain.connect(audioCtx.destination);

        osc.start(now);
        osc.stop(now + decay + 0.1);
      });
    } catch (e) {
      console.warn(e);
    }
  }
})();


// --- Universal Floating Panel Loader ---
(function() {
  "use strict";

  // Embedded Dashed Draggable Logic to guarantee 100% reliability
  function makeElementDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = "move";

    handle.addEventListener("mousedown", dragStart);

    function dragStart(e) {
      if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;

      element.style.setProperty("outline", "2px dashed #dfc299", "important");
      element.style.setProperty("outline-offset", "-2px", "important");
      element.style.setProperty("z-index", "2147483647", "important");

      // Add temporary shield to prevent iframe from stealing mouse events during dragging
      const existingShield = document.getElementById("wano-drag-shield");
      if (existingShield) existingShield.remove();
      const shield = document.createElement("div");
      shield.id = "wano-drag-shield";
      shield.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; cursor:move;";
      document.body.appendChild(shield);

      document.addEventListener("mouseup", dragEnd);
      document.addEventListener("mousemove", dragMove);
    }

    function dragMove(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      // Use getBoundingClientRect() for correct viewport-relative position
      // (element.offsetTop is unreliable for position:fixed elements on scrolled pages)
      const rect = element.getBoundingClientRect();
      let newTop = rect.top - pos2;
      let newLeft = rect.left - pos1;

      // Restrict within window boundaries to prevent going offscreen
      const maxTop = (window.innerHeight || document.documentElement.clientHeight) - 60;
      const maxLeft = (window.innerWidth || document.documentElement.clientWidth) - 60;

      newTop = Math.max(10, Math.min(newTop, maxTop));
      newLeft = Math.max(10, Math.min(newLeft, maxLeft));

      element.style.setProperty("position", "fixed", "important");
      element.style.setProperty("top", newTop + "px", "important");
      element.style.setProperty("left", newLeft + "px", "important");
      element.style.setProperty("right", "auto", "important");
      element.style.setProperty("bottom", "auto", "important");
      element.style.setProperty("margin", "0", "important");
    }

    function dragEnd() {
      element.style.removeProperty("outline");
      element.style.removeProperty("outline-offset");
      const shield = document.getElementById("wano-drag-shield");
      if (shield) shield.remove();
      document.removeEventListener("mouseup", dragEnd);
      document.removeEventListener("mousemove", dragMove);
    }
  }

  // 拡張機能ごとに一意のIDでネームスペースを切る(他拡張機能とのDOM ID衝突防止。
  // persistent-panelスキルのGotcha4)
  const NS_ID = "wano-" + chrome.runtime.id;

  function toggleFloatingPanel() {
    let container = document.getElementById(NS_ID + "-floating-container");
    if (container) {
      container.style.display = (container.style.display === "none") ? "flex" : "none";
      return;
    }

    container = document.createElement("div");
    container.id = NS_ID + "-floating-container";

    // Set initial position top right. No fixed right/left !important to allow dragging.
    container.style.cssText = "position:fixed !important; top:40px !important; left:" + Math.max(10, window.innerWidth - 440) + "px !important; z-index:2147483647 !important; width:430px !important; height:620px !important; background-color:#15110e !important; border:1.5px solid rgba(223, 194, 153, 0.4) !important; border-radius:12px !important; box-shadow:0 10px 45px rgba(0,0,0,0.92) !important; display:flex !important; flex-direction:column !important; overflow:hidden !important; box-sizing:border-box !important;";

    const iframeUrl = chrome.runtime.getURL("popup.html?mode=floating");
    container.innerHTML = `
      <div id="${NS_ID}-drag-header" style="display:flex; justify-content:space-between; align-items:center; background:#15110e; border-bottom:1px solid rgba(223,194,153,0.25); padding:10px 16px; cursor:move; user-select:none;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:16px;">⚡</span>
          <span style="font-size:13px; font-weight:700; color:#dfc299; font-family:sans-serif;">Copypaste Helper</span>
        </div>
        <button id="${NS_ID}-close" style="background:none; border:none; color:#c3b6ab; font-size:16px; cursor:pointer;" title="閉じる">✕</button>
      </div>
      <iframe src="${iframeUrl}" style="flex:1 !important; border:none !important; width:100% !important; height:100% !important; background:transparent !important;"></iframe>
    `;

    (document.body || document.documentElement).appendChild(container);

    // Bind Draggable
    const header = container.querySelector("#" + NS_ID + "-drag-header");
    makeElementDraggable(container, header);

    container.querySelector("#" + NS_ID + "-close").addEventListener("click", () => {
      container.style.display = "none";
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "toggleFloatingPanel") {
        toggleFloatingPanel();
        sendResponse({ status: "toggled" });
      }
      return true;
    });
  }
})();
